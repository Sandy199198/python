先确保npm指定到安防私有仓库

```
npm set registry http://192.168.0.10:4873
npm install
```
并确保全局安装webpack和dev-server

```
npm install -g webpack webpack-dev-server
```
安装完成后通过

```
npm start
```
启动开发环境，端口为8080

所有单元测试文件都在test目录下,所有开发文件均在src目录下，src子目录结构如下:

* **common** 项目公共文件
* **fonts** 字体文件
* **images** 图片文件
* **main.js** 主入口文件，前端路由都在此注册
* **pages** 所有业务功能的文件
* **store** 数据模型,对应vuex
* **style** 样式文件

其他命令：

进行eslint检查
```
npm run eslint
```

单元测试
```
npm test
```

编译打包
```
webpack --config webpack.config.release.js
```

