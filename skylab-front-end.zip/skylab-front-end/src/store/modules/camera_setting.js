import { CAMERA_SETTING } from 'common/namespace'
import Vue from 'vue'
import { SET_ERROR, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, printError, preRequest} from 'common/utils'

export const GET_CAMERA_LIST = `${CAMERA_SETTING}/getCameraList`
export const SET_CAMERA_LIST = `${CAMERA_SETTING}/setCameraList`
export const FETCH_CAMERA_LIST = `${CAMERA_SETTING}/fetchCameraList`
export const DEL_CAMERA = `${CAMERA_SETTING}/delCamera`
export const ADD_CAMERA = `${CAMERA_SETTING}/addCamera`
export const SET_CAMERA = `${CAMERA_SETTING}/setCamera`
export const SET_PAGE = `${CAMERA_SETTING}/setPage`
export const GET_PAGE = `${CAMERA_SETTING}/getPage`

export default {
    state: {
        page: {},
        cameraData: []
    },
    getters: {
        [GET_CAMERA_LIST](state) {
            return state.cameraData
        },
        [GET_PAGE](state) {
            return state.page
        }
    },
    mutations: {
        [SET_CAMERA_LIST](state, data) {
            state.cameraData = data
        },
        [SET_PAGE](state, page) {
            state.page = Object.assign({}, page)
        },
        [ADD_CAMERA](state, data) {
            state.cameraData.unshift(data)
        },
        [SET_CAMERA](state, data) {
            for (let [index, camera] of state.cameraData.entries()) {
                if (camera.id == data.id) {
                    state.cameraData.splice(index, 1, data)
                }
            }

        },
        [DEL_CAMERA](state, data) {
            for (let [i, a] of state.cameraData.entries()) {
                if (a.id == data.id) {
                    state.cameraData.splice(i, 1)
                    break
                }
            }
        }
    },
    actions: {
        [FETCH_CAMERA_LIST](context, camera) {
            let params = []
            let url = `${context.getters[GET_SERVICES].CaptureMaster}cameras/`

            for (let key in camera) {
                if (camera[key]) {
                    params.push(key + '=' + camera[key])
                }
            }

            params = params.join('&')
            if (params) {
                url += '?' + params
            }

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'GET',
                        headers: {
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(SET_CAMERA_LIST, data.data)
                        context.commit(SET_PAGE, data.paging)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('FETCH_CAMERA_LIST', e)
                        }
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_CAMERA_LIST', e)
                    }
                })
            })
        },
        [DEL_CAMERA](context, camera) {
            let id = camera.id

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(`${context.getters[GET_SERVICES].CaptureMaster}cameras/` + id, {
                        credentials: 'include',
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(DEL_CAMERA, camera)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('DEL_CAMERA', e)
                        }
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('DEL_CAMERA', e)
                    }
                })
            })
        },
        [ADD_CAMERA](context, camera) {
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(`${context.getters[GET_SERVICES].CaptureMaster}cameras/`, {
                        credentials: 'include',
                        method: 'POST',
                        body: JSON.stringify(camera),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        // context.commit(ADD_CAMERA, data.data)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('ADD_CAMERA', e)
                        }
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('ADD_CAMERA', e)
                    }
                })
            })
        },
        [SET_CAMERA](context, camera) {
            let id = camera.id

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(`${context.getters[GET_SERVICES].CaptureMaster}cameras/` + id, {
                        credentials: 'include',
                        method: 'PUT',
                        body: JSON.stringify(camera),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(SET_CAMERA, camera)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('SET_CAMERA', e)
                        }
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('SET_CAMERA', e)
                    }
                })
            })
        }
    }
}
