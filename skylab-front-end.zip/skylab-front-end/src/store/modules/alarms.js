import { ALARMS } from 'common/namespace'
import { analyzeHttpCode } from 'common/utils'

export const GET_ALARM = `${ALARMS}/getAlarm`
export const SET_ALARM = `${ALARMS}/setAlarm`
export const FETCH_ALARM = `${ALARMS}/fetchAlarm`

export const GET_ALARMS = `${ALARMS}/getAlarms`
export const ADD_ALARM = `${ALARMS}/addAlarm`
export const DEL_ALARM = `${ALARMS}/delAlarm`

export const GET_REALTIME_CAPTURES = `${ALARMS}/getRealtimeCaptures`
export const ADD_REALTIME_CAPTURE = `${ALARMS}/addRealtimeCapture`
export const GET_REALTIME_CAPTURE = `${ALARMS}/getRealtimeCapture`
export const SET_REALTIME_CAPTURE = `${ALARMS}/setRealtimeCapture`

export const GET_REALTIME_ALARMS = `${ALARMS}/getRealtimeAlarms`
export const ADD_REALTIME_ALARM = `${ALARMS}/addRealtimeAlarm`
export const GET_REALTIME_ALARM = `${ALARMS}/getRealtimeAlarm`
export const SET_REALTIME_ALARM = `${ALARMS}/setRealtimeAlarm`

export const CLEAR_ALARMS = `${ALARMS}/clearAlarms`

export default {
    state: {
        alarm: {},
        alarms: [],
        realtimeCapture: {},
        realtimeCaptures: [],
        realtimeAlarm: {},
        realtimeAlarms: []
    },
    getters: {
        [GET_ALARM](state) {
            return state.alarm
        },
        [GET_ALARMS](state) {
            return state.alarms
        },
        [GET_REALTIME_CAPTURE](state) {
            return state.realtimeCapture
        },
        [GET_REALTIME_CAPTURES](state) {
            return state.realtimeCaptures
        },
        [GET_REALTIME_ALARM](state) {
            return state.realtimeAlarm
        },
        [GET_REALTIME_ALARMS](state) {
            return state.realtimeAlarms
        }
    },
    mutations: {
        [ADD_ALARM](state, alarm) {
            state.alarms.unshift(alarm)
        },
        [DEL_ALARM](state, alarm) {
            for (let [i, a] of state.alarms.entries()) {
                if (a.id == alarm.id) {
                    state.alarms.splice(i, 1)
                    break
                }
            }
        },
        [SET_ALARM](state, alarm) {
            state.alarm = Object.assign({}, alarm)
        },
        [CLEAR_ALARMS](state) {
            // state.alarms.splice(8)
            state.alarms = []
        },
        [ADD_REALTIME_ALARM](state, wrapData) {
            let {from, data} = wrapData
            let alarmAll = localStorage.getItem('alarmAll')

            if (!data) return
            if (alarmAll == 'true' && from == 'globalAlarm') {
                state.realtimeAlarms.unshift(data)
            } else if (alarmAll == 'false' && from == 'capture') {
                state.realtimeAlarms.unshift(data)
            }
        },
        [SET_REALTIME_ALARM](state, wrapData) {
            let {from, data} = wrapData
            let alarmAll = localStorage.getItem('alarmAll')

            if (!data) return
            if (alarmAll == 'true' && from == 'globalAlarm') {
                state.realtimeAlarm = Object.assign({}, data)
            } else if (alarmAll == 'false' && from == 'capture') {
                state.realtimeAlarm = Object.assign({}, data)
            }
        },
        [ADD_REALTIME_CAPTURE](state, info) {
            state.realtimeCapture = Object.assign({}, info)
        }
    }
}
