import { USER_GROUP } from 'common/namespace'
import Vue from 'vue'
import { SET_ERROR, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, printError} from 'common/utils'

export const GET_USER_GROUP_LIST = `${USER_GROUP}/getUserGroupList`
export const SET_USER_GROUP_LIST = `${USER_GROUP}/setUserGroupList`
export const FETCH_USER_GROUP_LIST = `${USER_GROUP}/fetchUserGroupList`
export const DEL_USER_GROUP = `${USER_GROUP}/delUserGroup`
export const ADD_USER_GROUP = `${USER_GROUP}/addUserGroup`
export const SET_USER_GROUP = `${USER_GROUP}/setUserGroup`
export const SET_PAGE = `${USER_GROUP}/setPage`
export const GET_PAGE = `${USER_GROUP}/getPage`

export default {
    state: {
        page: {},
        userGroupData: []
    },
    getters: {
        [GET_USER_GROUP_LIST](state) {
            return state.userGroupData
        },
        [GET_PAGE](state) {
            return state.page
        }
    },
    mutations: {
        [SET_USER_GROUP_LIST](state, data) {
            state.userGroupData = data
        },
        [SET_PAGE](state, page) {
            state.page = Object.assign({}, page)
        },
        [ADD_USER_GROUP](state, data) {
            state.userGroupData.unshift(data)
        },
        [SET_USER_GROUP](state, data) {
            for (let [index, usergroup] of state.userGroupData.entries()) {
                if (usergroup.id == data.id) {
                    state.userGroupData.splice(index, 1, data)
                }
            }

        },
        [DEL_USER_GROUP](state, data) {
            for (let [i, a] of state.userGroupData.entries()) {
                if (a.id == data.id) {
                    state.userGroupData.splice(i, 1)
                    break
                }
            }
        }
    },
    actions: {
        [FETCH_USER_GROUP_LIST](context, group) {
            let params = []
            let url = `${context.getters[GET_SERVICES].Skylab}usergroups/`

            for (let key in group) {
                if (group[key]) {
                    params.push(key + '=' + group[key])
                }
            }

            params = params.join('&')
            if (params) {
                url += '?' + params
            }
            fetch(url, { credentials: 'include' }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(SET_USER_GROUP_LIST, data.data)
                context.commit(SET_PAGE, data.paging)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_USER_GROUP_LIST', e)
                }
            })
        },
        [DEL_USER_GROUP](context, userGroup) {
            let id = userGroup.id

            fetch(`${context.getters[GET_SERVICES].Skylab}usergroups/` + id, { credentials: 'include', method: 'DELETE' }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(DEL_USER_GROUP, userGroup)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('DEL_USER_GROUP', e)
                }
            })
        },
        [ADD_USER_GROUP](context, userGroup) {
            fetch(`${context.getters[GET_SERVICES].Skylab}usergroups/`, {
                credentials: 'include',
                method: 'POST',
                body: JSON.stringify(userGroup),
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(ADD_USER_GROUP, data.data)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('ADD_USER_GROUP', e)
                }
            })
        },
        [SET_USER_GROUP](context, userGroup) {
            let id = userGroup.id

            fetch(`${context.getters[GET_SERVICES].Skylab}usergroups/` + id, {
                credentials: 'include',
                method: 'PUT',
                body: JSON.stringify(userGroup),
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(SET_USER_GROUP, data.data)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SET_USER_GROUP', e)
                }
            })
        }
    }
}
