import { CAMERAS } from 'common/namespace'
import Vue from 'vue'
import { SET_ERROR, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, printError} from 'common/utils'
import { GET_USER_INFO } from 'store/modules/auth'
import {
    FETCH_ALL_BRANCHS,
    GET_ALL_BRANCHS } from 'store/modules/citywide_info'

export const GET_CAMERAS = `${CAMERAS}/getCameras`
export const SET_CAMERAS = `${CAMERAS}/setCameras`
export const FETCH_CAMERAS = `${CAMERAS}/fetchCameras`

export const SET_BRANCH_CAMERAS = `${CAMERAS}/setBranchCameras`
export const GET_BRANCH_CAMERAS = `${CAMERAS}/getBranchCameras`


export default {
    state: {
        cameras: [],
        branchCameras: []
    },

    getters: {
        [GET_CAMERAS](state) {
            return state.cameras
        },

        [GET_BRANCH_CAMERAS](state) {
            return state.branchCameras
        }
    },

    mutations: {
        [SET_CAMERAS](state, cameras) {
            state.cameras = cameras
        },

        [SET_BRANCH_CAMERAS](state, data) {
            let { cameras, branchs } = data
            let result = []
            let structure = {}
            let sequence = []

            for (let branch of branchs) {
                structure[branch.name] = []
                sequence.push(branch.name)
                for (let camera of cameras) {
                    if (branch.id == camera.user_group_id) {
                        structure[branch.name].push(camera)
                    }
                }
            }

            for (let name of sequence) {
                result.push({
                    branch: name,
                    cameras: structure[name]
                })
            }

            state.branchCameras = result
        }
    },

    actions: {
        [FETCH_CAMERAS](context, hasBranch) {
            let cameras = new Promise((resolve1, reject) => {
                fetch(`${context.getters[GET_SERVICES].Skylab}user_token`, {
                    credentials: 'include',
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    return new Promise((resolve2, reject) => {
                        try {
                            resolve2(data.data.access_token)
                        } catch (e) {
                            reject(e)
                        }
                    })
                }).then(code => {
                    return fetch(`${context.getters[GET_SERVICES].CaptureMaster}get-cameras?user_group_id=${context.getters[GET_USER_INFO].user_group_id}`, {
                        credentials: 'include',
                        headers: {
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return res.json()
                    }).then(data => {
                        context.commit(SET_CAMERAS, data.data)
                        resolve1()
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_CAMERAS', e)
                    }
                })
            })

            return hasBranch ? Promise.all([cameras, context.dispatch(FETCH_ALL_BRANCHS)]).then(() => {
                context.commit(SET_BRANCH_CAMERAS, {
                    branchs: context.getters[GET_ALL_BRANCHS],
                    cameras: context.getters[GET_CAMERAS],
                })
            }) : cameras
        }
    }
}
