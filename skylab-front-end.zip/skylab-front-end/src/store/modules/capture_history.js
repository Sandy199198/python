import { CAPTURE_HISTORY } from 'common/namespace'
import Vue from 'vue'
import { SET_ERROR, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, preRequest, printError} from 'common/utils'

export const GET_CAPTURE_HISTORY_LIST = `${CAPTURE_HISTORY}/getCaptureHistoryList`
export const SET_CAPTURE_HISTORY_LIST = `${CAPTURE_HISTORY}/setCaptureHistoryList`
export const FETCH_CAPTURE_HISTORY_LIST = `${CAPTURE_HISTORY}/fetchCaptureHistoryList`
export const CLEAR_CAPTURE_HISTORY_LIST = `${CAPTURE_HISTORY}/clearCaptureHistoryList`
export const SET_PAGE = `${CAPTURE_HISTORY}/setPage`
export const GET_PAGE = `${CAPTURE_HISTORY}/getPage`

export default {
    state: {
        page: {},
        captureHistoryData: []
    },
    getters: {
        [GET_CAPTURE_HISTORY_LIST](state) {
            return state.captureHistoryData
        },
        [GET_PAGE](state) {
            return state.page
        }
    },
    mutations: {
        [SET_CAPTURE_HISTORY_LIST](state, data) {
            state.captureHistoryData = data
        },
        [SET_PAGE](state, page) {
            // let pageObj = {}

            // for (let i in page) {
            //     if (i == 'page') {
            //         pageObj['current'] = page[i]
            //     } else if (i == 'page_count') {
            //         pageObj['total'] = page[i]
            //     } else if (i == 'per_page') {
            //         pageObj['size'] = page[i]
            //     } else {
            //         pageObj['totalitems'] = page[i]
            //     }
            // }
            state.page = Object.assign({}, page)
            // state.page = Object.assign({}, page)
        },
        [CLEAR_CAPTURE_HISTORY_LIST](state) {
            state.captureHistoryData = []
        }
    },
    actions: {
        [FETCH_CAPTURE_HISTORY_LIST](context, obj) {
            let params = []
            let url = `${context.getters[GET_SERVICES].Skylab}captures/`

            for (let key in obj) {
                if (obj[key]) {
                    if (key == 'cameraName') {
                        params.push('camera_name' + '=' + obj[key])
                    } else if (key == 'startTime') {
                        params.push('start_time' + '=' + obj[key])
                    } else if (key == 'endTime') {
                        params.push('end_time' + '=' + obj[key])
                    } else if (key == 'certId') {
                        params.push('cert_id' + '=' + obj[key])
                    } else {
                        params.push(key + '=' + obj[key])
                    }
                }
            }
            params.push('size' + '=' + 30)
            params = params.join('&')
            if (params) {
                url += '?' + params
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(SET_CAPTURE_HISTORY_LIST, data.data)
                        context.commit(SET_PAGE, data.paging)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('FETCH_CAPTURE_HISTORY_LIST', e)
                        }
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_CAPTURE_HISTORY_LIST', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_CAPTURE_HISTORY_LIST', e)
                }
            })
        }
    }
}
