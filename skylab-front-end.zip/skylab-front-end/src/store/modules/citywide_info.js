import { CITYWIDE_INFO } from 'common/namespace'
import Vue from 'vue'
import Immutable from 'immutable'
import { formatDate, splitTime, supplement, analyzeHttpCode, convertToSeconds, printError} from 'common/utils'
import { SET_ERROR, GET_PROMETHEUS_QUERY, GET_PROMETHEUS_QUERY_RANGE, GET_SERVICES } from 'store/modules/common'
import { GET_CAMERAS } from 'store/modules/cameras'
import { GET_USER_INFO } from 'store/modules/auth'

export const SET_INTERVAL_DATA = `${CITYWIDE_INFO}/setIntervalData`
export const GET_INTERVAL_DATA = `${CITYWIDE_INFO}/getIntervalData`
export const CLEAR_INTERVAL_DATA = `${CITYWIDE_INFO}/clearIntervalData`

export const FETCH_TRUNK_INTERVAL_DATA = `${CITYWIDE_INFO}/fetchTrunkIntervalData`
export const FETCH_BRANCH_INTERVAL_DATA = `${CITYWIDE_INFO}/fetchBranchIntervalData`
export const FETCH_CAMERA_INTERVAL_DATA = `${CITYWIDE_INFO}/fetchCameraIntervalData`

export const SET_PERIOD_DATA = `${CITYWIDE_INFO}/setPeriodData`
export const GET_PERIOD_DATA = `${CITYWIDE_INFO}/getPeriodData`
export const CLEAR_PERIOD_DATA = `${CITYWIDE_INFO}/clearPeriodData`

export const FETCH_TRUNK_PERIOD_DATA = `${CITYWIDE_INFO}/fetchTrunkPeriodData`
export const FETCH_BRANCH_PERIOD_DATA = `${CITYWIDE_INFO}/fetchBranchPeriodData`
export const FETCH_CAMERA_PERIOD_DATA = `${CITYWIDE_INFO}/fetchCameraPeriodData`

export const GET_LAST_DAYS_TABLE_DATA = `${CITYWIDE_INFO}/getLastDaysTableData`
export const GET_LAST_DAYS_TABLE_COLUMN_DATA = `${CITYWIDE_INFO}/getLastDaysTableColumnData`

export const SET_TABLE_DATA = `${CITYWIDE_INFO}/setTableData`
export const GET_TABLE_DATA = `${CITYWIDE_INFO}/getTableData`
export const GET_TABLE_COLUMN_DATA = `${CITYWIDE_INFO}/getTableColumnData`

export const FETCH_TRUNK_TABLE_DATA = `${CITYWIDE_INFO}/fetchTrunkTableData`
export const FETCH_BRANCH_TABLE_DATA = `${CITYWIDE_INFO}/fetchBranchTableData`

export const GET_BRANCHES_TABLE_DATA = `${CITYWIDE_INFO}/getBranchesTableData`
export const SET_BRANCHES_TABLE_DATA = `${CITYWIDE_INFO}/setBranchesTableData`
export const FETCH_BRANCHES_TABLE_DATA = `${CITYWIDE_INFO}/fetchBrachesTableData`

export const GET_ALL_BRANCHS = `${CITYWIDE_INFO}/getAllBranchs`
export const SET_ALL_BRANCHS = `${CITYWIDE_INFO}/setAllBranchs`

export const GET_BRANCH_MAP = `${CITYWIDE_INFO}/getBranchMap`
export const SET_BRANCH_MAP = `${CITYWIDE_INFO}/setBranchMap`

export const GET_BRANCH_ID_MAP = `${CITYWIDE_INFO}/getBranchIdMap`
export const SET_BRANCH_ID_MAP = `${CITYWIDE_INFO}/setBranchIdMap`

export const FETCH_ALL_BRANCHS = `${CITYWIDE_INFO}/fetchAllBranchs`

let citywideWeekDataTemplate = {
    title: {
        text: ''
    },

    xAxis: {
        categories: []
    },

    yAxis: {
        title: {
            text: '人次'
        },
        min: 0,
        plotLines: [{
            value: 0,
            width: 1,
            color: '#808080'
        }]
    },

    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle',
        borderWidth: 0,
        itemMarginTop: 4,
        itemMarginBottom: 4,
    },

    series: []
}
let citywideRealTimeDataTemplate = {
    chart: {
        type: 'column'
    },
    title: {
        text: '今日实时统计'
    },
    xAxis: {
        categories: [],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: '人次'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:f}</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: []
}


function mutiplePromisePipe(promise) {
    return promise.then((res) => {
        return Promise.all([analyzeHttpCode(res[0]), analyzeHttpCode(res[1]), analyzeHttpCode(res[2])])
    }).then(([captureData, alarmData, markedAlarmData]) => {
        return new Promise((resolve, reject) => {
            if (captureData.status == 'success' && alarmData.status == 'success' && markedAlarmData.status == 'success') {
                resolve([captureData, alarmData, markedAlarmData])
            } else {
                reject()
            }
        })
    })
}

export default {

    state: {
        citywideRealTimeData: Immutable.fromJS(citywideRealTimeDataTemplate),
        citywideWeekData: Immutable.fromJS(citywideWeekDataTemplate),
        citywideWeekTableData: [],
        citywideWeekTableColumnData: [],
        citywideTableData: [],
        citywideTableColumnData: [],
        allBranchs: [],
        branchMap: {},
        branchIdMap: {},
        cameras: [],
        cameraRealTimeData: Immutable.fromJS(citywideRealTimeDataTemplate),
        cameraWeekData: Immutable.fromJS(citywideWeekDataTemplate)
    },

    getters: {
        [GET_INTERVAL_DATA](state) {
            return state.citywideRealTimeData.toJS()
        },
        [GET_PERIOD_DATA](state) {
            return state.citywideWeekData.toJS()
        },
        [GET_LAST_DAYS_TABLE_DATA](state) {
            return state.citywideWeekTableData
        },
        [GET_LAST_DAYS_TABLE_COLUMN_DATA](state) {
            return state.citywideWeekTableColumnData
        },
        [GET_TABLE_DATA](state) {
            return state.citywideTableData
        },
        [GET_TABLE_COLUMN_DATA](state) {
            return state.citywideTableColumnData
        },
        [GET_ALL_BRANCHS](state) {
            return state.allBranchs
        },
        [GET_BRANCH_MAP](state) {
            return state.branchMap
        },
        [GET_BRANCH_ID_MAP](state) {
            return state.branchIdMap
        }
    },

    mutations: {
        [SET_BRANCH_MAP](state, data) {
            let branchMap = {}

            for (let [index, d] of data.entries()) {
                branchMap[d['name']] = d['id']
            }
            state.branchMap = branchMap
        },

        [SET_BRANCH_ID_MAP](state, data) {
            let branchIdMap = {}

            for (let [index, d] of data.entries()) {
                branchIdMap[d['id']] = d['name']
            }
            state.branchIdMap = branchIdMap
        },

        [SET_INTERVAL_DATA](state, wrapperData) {
            let series = []
            let { key, number, title, data, categories } = wrapperData

            for (let [index, d] of data.entries()) {
                let seriesData

                seriesData = {
                    name: key[index],
                    data: d.data.result.length ? d.data.result[0].values.map(v => +v[1]) : []
                }

                if (seriesData.data.length < number) {
                    seriesData.data = supplement(seriesData.data, number)
                }

                series.push(seriesData)
            }

            state.citywideRealTimeData = state.citywideRealTimeData.setIn(['title', 'text'], title).setIn(['xAxis', 'categories'], categories).set('series', series)
        },

        [CLEAR_INTERVAL_DATA](state) {
            state.citywideRealTimeData = Immutable.fromJS(citywideRealTimeDataTemplate)
        },

        [SET_PERIOD_DATA](state, wrapperData) {
            let series = []
            let { key, number, data, categories } = wrapperData
            let columns = [{
                title: '类型',
                prop: 'type'
            }]
            let tableData = [{
                type: key[0]
            }, {
                type: key[1]
            }, {
                type: key[2]
            }]

            for (let [index, d] of data.entries()) {
                let seriesData = {
                    name: key[index],
                    data: d.data.result.length ? d.data.result[0].values.map(v => +v[1]) : []
                }

                if (seriesData.data.length < number) {
                    seriesData.data = supplement(seriesData.data, number + 1)
                }

                series.push(seriesData)

                columns.push({
                    title: categories[categories.length - 1 - index],
                    prop: `prop_${index}`
                })
                seriesData.data.concat().reverse().splice(0, 3).forEach((n, i) => {
                    tableData[index][`prop_${i}`] = n
                })
            }

            state.citywideWeekTableData = tableData
            state.citywideWeekTableColumnData = columns
            state.citywideWeekData = state.citywideWeekData.setIn(['xAxis', 'categories'], categories).setIn(['series'], series)
        },

        [CLEAR_PERIOD_DATA](state) {
            state.citywideWeekData = Immutable.fromJS(citywideWeekDataTemplate)
            state.citywideWeekTableData = []
            state.citywideWeekTableColumnData = []
        },

        [SET_TABLE_DATA](state, wrapperData) {
            let { type, key, data, cameras } = wrapperData
            let groupsMap = {}
            let columns = key
            let tableData = []

            for (let [index, d] of data[0].data.result.entries()) {
                let cameraName

                if (type != 'user_group') {
                    for (let camera of cameras) {
                        if (camera.id == d.metric[type]) {
                            cameraName = camera.name
                            break
                        }
                    }
                }
                tableData.push({
                    name: type == 'user_group' ? state.branchIdMap[d.metric[type]] : cameraName,
                })
                groupsMap[d.metric[type]] = index
            }

            for (let [index, d] of data.entries()) {
                for (let r of d.data.result) {
                    tableData[groupsMap[r.metric[type]]][key[index + 1].prop] = r.value[1]
                }
            }

            // TODO: 临时方案，去除没有匹配到的分局 start
            let temporaryTableData = []

            for (let [index, d] of tableData.entries()) {
                if (d.name != undefined) {
                    temporaryTableData.push(d)
                }
            }
            // end

            state.citywideTableColumnData = columns
            state.citywideTableData = temporaryTableData
        },

        [SET_ALL_BRANCHS](state, data) {
            state.allBranchs = data
        }

    },

    actions: {

        [FETCH_TRUNK_INTERVAL_DATA](context, {
            start,
            end
        }) {
            mutiplePromisePipe(Promise.all([
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(capture_count[2h])))&start=${start}&end=${end}&step=2h`),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(alarm_count[2h])))&start=${start}&end=${end}&step=2h`),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(confirmed_alarm_count[2h])))&start=${start}&end=${end}&step=2h`)
            ])).then((data) => {
                context.commit(SET_INTERVAL_DATA, {
                    key: ['抓拍数', '告警数', '确认告警数'],
                    number: 13,
                    title: `市局 实时统计`,
                    categories: splitTime({
                        start,
                        // 服务端会返回13个点,所以切割时间加一小时
                        end: end + 2 * 60 * 60,
                        interval: 2 * 60 * 60,
                        format: 'h:m'
                    }),
                    data: data
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_TRUNK_INTERVAL_DATA', e)
                }
            })
        },

        [FETCH_BRANCH_INTERVAL_DATA](context, {
            start,
            end,
            id,
            name
        }) {
            mutiplePromisePipe(Promise.all([
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(capture_count{user_group="${id}"}[2h])))&start=${start}&end=${end}&step=2h`),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(alarm_count{user_group="${id}"}[2h])))&start=${start}&end=${end}&step=2h`),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(confirmed_alarm_count{user_group="${id}"}[2h])))&start=${start}&end=${end}&step=2h`)
            ])).then((data) => {
                context.commit(SET_INTERVAL_DATA, {
                    key: ['抓拍数', '告警数', '确认告警数'],
                    number: 13,
                    title: `${name} 实时统计`,
                    categories: splitTime({
                        start,
                        // 服务端会返回13个点,所以切割时间加一小时
                        end: end + 2 * 60 * 60,
                        interval: 2 * 60 * 60,
                        format: 'h:m'
                    }),
                    data: data
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_BRANCH_INTERVAL_DATA', e)
                }
            })
        },

        [FETCH_CAMERA_INTERVAL_DATA](context, {
            id,
            name,
            start,
            end
        }) {
            mutiplePromisePipe(Promise.all([
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(capture_count{camera="${name}"}[2h])))&start=${start}&end=${end}&step=2h`),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(alarm_count{camera="${name}"}[2h])))&start=${start}&end=${end}&step=2h`),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(confirmed_alarm_count{camera="${name}"}[2h])))&start=${start}&end=${end}&step=2h`)
            ])).then(data => {
                context.commit(SET_INTERVAL_DATA, {
                    key: ['抓拍数', '告警数', '确认告警数'],
                    number: 13,
                    title: `${name} 监控实时统计`,
                    categories: splitTime({
                        start,
                        // 服务端会返回13个点,所以切割时间加一小时
                        end: end + 2 * 60 * 60,
                        interval: 2 * 60 * 60,
                        format: 'h:m'
                    }),
                    data: data
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_CAMERA_INTERVAL_DATA', e)
                }
            })
        },

        [FETCH_TRUNK_PERIOD_DATA](context, {
            start,
            end,
            number
        }) {
            mutiplePromisePipe(Promise.all([
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(capture_count[24h])))&start=${start}&end=${end}&step=24h`),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(alarm_count[24h])))&start=${start}&end=${end}&step=24h`),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(confirmed_alarm_count[24h])))&start=${start}&end=${end}&step=24h`)
            ])).then(data => {
                context.commit(SET_PERIOD_DATA, {
                    key: ['抓拍数', '告警数', '确认告警数'],
                    number,
                    categories: splitTime({
                        start,
                        end: end + 60 * 60 * 24,
                        interval: 60 * 60 * 24,
                        format: 'M月D日'
                    }),
                    data: data
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_TRUNK_PERIOD_DATA', e)
                }
            })
        },

        [FETCH_BRANCH_PERIOD_DATA](context, {
            start,
            end,
            id,
            number,
            name
        }) {
            mutiplePromisePipe(Promise.all([
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(capture_count{user_group="${id}"}[24h])))&start=${start}&end=${end}&step=24h`),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(alarm_count{user_group="${id}"}[24h])))&start=${start}&end=${end}&step=24h`),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(confirmed_alarm_count{user_group="${id}"}[24h])))&start=${start}&end=${end}&step=24h`)
            ])).then(data => {
                context.commit(SET_PERIOD_DATA, {
                    key: ['抓拍数', '告警数', '确认告警数'],
                    number,
                    categories: splitTime({
                        start,
                        end: end + 60 * 60 * 24,
                        interval: 60 * 60 * 24,
                        format: 'M月D日'
                    }),
                    data: data
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_BRANCH_PERIOD_DATA', e)
                }
            })
        },

        [FETCH_CAMERA_PERIOD_DATA](context, {
            id,
            start,
            end,
            number
        }) {
            mutiplePromisePipe(Promise.all([fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(capture_count{camera_id="${id}"}[24h])))&start=${start}&end=${end}&step=24h`),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(alarm_count{camera_id="${id}"}[24h])))&start=${start}&end=${end}&step=24h`),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(confirmed_alarm_count{camera_id="${id}"}[24h])))&start=${start}&end=${end}&step=24h`)
            ])).then((data) => {
                context.commit(SET_PERIOD_DATA, {
                    key: ['抓拍数', '告警数', '确认告警数'],
                    number,
                    categories: splitTime({
                        start,
                        end: end + 60 * 60 * 24,
                        interval: 60 * 60 * 24,
                        format: 'M月D日'
                    }),
                    data: data
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_CAMERA_PERIOD_DATA', e)
                }
            })
        },

        [FETCH_TRUNK_TABLE_DATA](context) {
            let now = new Date()
            let deltaTimestamp = convertToSeconds(now) - convertToSeconds(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0))

            mutiplePromisePipe(Promise.all([
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=sort_desc(round(sum(increase(capture_count[${deltaTimestamp}s]))+by+(user_group)))`),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=sort_desc(round(sum(increase(alarm_count[${deltaTimestamp}s]))+by+(user_group)))`),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=sort_desc(round(sum(increase(confirmed_alarm_count[${deltaTimestamp}s]))+by+(user_group)))`)
            ])).then(data => {
                context.commit(SET_TABLE_DATA, {
                    data,
                    type: 'user_group',
                    key: [{
                        title: '分局',
                        prop: 'name'
                    }, {
                        title: '抓拍数',
                        prop: 'captures'
                    }, {
                        title: '告警数',
                        prop: 'alarms'
                    }, {
                        title: '确认告警数',
                        prop: 'markedAlarms'
                    }, {
                        title: '操作',
                        type: 'events'
                    }]
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_TRUNK_TABLE_DATA', e)
                }
            })
        },

        [FETCH_BRANCH_TABLE_DATA](context, id) {
            let now = new Date()
            let deltaTimestamp = convertToSeconds(now) - convertToSeconds(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0))

            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=topk(10,sort_desc(round(sum(increase(alarm_count{user_group="${id}"}[${deltaTimestamp}s]))+by+(camera_id))))`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                let cameras = data.data.result.slice(0, 10)
                let cmaeraParams = []

                for (let d of cameras) {
                    cmaeraParams.push(d.metric.camera_id)
                }

                return new Promise((resolve, reject) => {
                    resolve(cmaeraParams)
                })
            }).then( cmaeraParams => {
                return mutiplePromisePipe(Promise.all([
                    fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=topk(10,sort_desc(round(sum(increase(capture_count{user_group="${id}",camera_id=~"${cmaeraParams.join('|')}"}[${deltaTimestamp}s]))+by+(camera_id))))`),
                    fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=topk(10,sort_desc(round(sum(increase(alarm_count{user_group="${id}",camera_id=~"${cmaeraParams.join('|')}"}[${deltaTimestamp}s]))+by+(camera_id))))`),
                    fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=topk(10,sort_desc(round(sum(increase(confirmed_alarm_count{user_group="${id}",camera_id=~"${cmaeraParams.join('|')}"}[${deltaTimestamp}s]))+by+(camera_id))))`)
                ])).then(data => {
                    context.commit(SET_TABLE_DATA, {
                        data,
                        cameras: context.getters[GET_CAMERAS],
                        type: 'camera_id',
                        key: [{
                            title: '摄像头',
                            prop: 'name'
                        }, {
                            title: '抓拍数',
                            prop: 'captures'
                        }, {
                            title: '告警数',
                            prop: 'alarms'
                        }, {
                            title: '确认告警数',
                            prop: 'markedAlarms'
                        }, {
                            title: '操作',
                            type: 'events'
                        }]
                    })
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_BRANCH_TABLE_DATA', e)
                }
            })

        },

        [FETCH_ALL_BRANCHS](context) {
            return fetch(`${context.getters[GET_SERVICES].Skylab}usergroups/?without_pagination=1`, {
                credentials: 'include',
            }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(SET_ALL_BRANCHS, data.data)
                context.commit(SET_BRANCH_MAP, data.data)
                context.commit(SET_BRANCH_ID_MAP, data.data)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_ALL_BRANCHS', e)
                }
            })
        }
    }
}
