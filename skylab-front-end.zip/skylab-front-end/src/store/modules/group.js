import { GROUP } from 'common/namespace'
import Vue from 'vue'
import { SET_ERROR, SET_GLOBAL_ALARM, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, preRequest, printError} from 'common/utils'

export const UPDATE_GROUP = `${GROUP}/updateGroup`
export const GET_GROUP = `${GROUP}/getGroup`
export const SET_GROUP = `${GROUP}/setGroup`
export const FETCH_GROUP = `${GROUP}/fetchGroup`
export const ADD_GROUP = `${GROUP}/addGroup`
export const DEL_GROUP = `${GROUP}/delGroup`
export const SET_PAGE = `${GROUP}/setPage`
export const GET_PAGE = `${GROUP}/getPage`
export const SEARCH_GROUP = `${GROUP}/searchGroup`
export const FETCH_GROUP_PAGINATION = `${GROUP}/fetchGroupPagination`

export default {
    state: {
        groupItems: [],
        groupItem: {},
        page: {}
    },
    getters: {
        [GET_GROUP](state) {
            return state.groupItems
        },
        [GET_PAGE](state) {
            return state.page
        }
    },
    mutations: {
        [SET_GROUP](state, data) {
            state.groupItems = data
        },
        [ADD_GROUP](state, data) {
            data = Object.assign(data, {
                'subject_count': 0
            })
            state.groupItems.push(data)
        },
        [DEL_GROUP](state, id) {
            for (let [i, a] of state.groupItems.entries()) {
                if (a['id'] == id) {
                    state.groupItems.splice(i, 1)
                    break
                }
            }
        },
        [UPDATE_GROUP](state, data) {
            for (let [i, a] of state.groupItems.entries()) {
                if (a.id == data.id) {
                    state.groupItems.splice(i, 1, data)
                }
            }
        },
        [SET_PAGE](state, page) {
            state.page = Object.assign({}, page)
        }
    },
    actions: {
        [FETCH_GROUP](context, group) {
            let url = `${context.getters[GET_SERVICES].Skylab}groups/?size=2000`

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_GROUP, data.data)
                    context.commit(SET_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_GROUP', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_GROUP', e)
                }
            })
        },
        [FETCH_GROUP_PAGINATION](context, group) {
            let url = `${context.getters[GET_SERVICES].Skylab}groups/?size=20`

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_GROUP, data.data)
                    context.commit(SET_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_GROUP_PAGINATION', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_GROUP_PAGINATION', e)
                }
            })
        },
        [SEARCH_GROUP](context, options) {
            let url = `${context.getters[GET_SERVICES].Skylab}groups/?`
            let arr = []

            for (let i in options) {
                if (i == 'name' && options[i]) {
                    arr.push('name=' + options[i])
                } else if (i == 'page' && options[i]) {
                    arr.push('page=' + options[i] )
                }
            }
            arr.push('size=20')
            url += arr.join('&')
            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_GROUP, data.data)
                    context.commit(SET_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('SEARCH_GROUP', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SEARCH_GROUP', e)
                }
            })
        },
        [ADD_GROUP](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].Skylab}groups/`

            for (let key in options) {
                if (key != 'groups') {
                    tmpObj[key] = options[key]
                }
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'POST',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(ADD_GROUP, data.data)
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('ADD_GROUP', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('ADD_GROUP', e)
                }
            })
        },
        [UPDATE_GROUP](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].Skylab}groups/` + options.id

            for (let key in options) {
                if (key != 'groups') {
                    tmpObj[key] = options[key]
                }
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'PUT',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(UPDATE_GROUP, Object.assign(data.data, {
                            'subject_count': tmpObj['subject_count']
                        }))
                        resolve()
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('UPDATE_GROUP', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('UPDATE_GROUP', e)
                }
            })
        },
        [DEL_GROUP](context, id) {
            let url = `${context.getters[GET_SERVICES].Skylab}groups/` + id

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'DELETE',
                        headers: {
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(DEL_GROUP, id)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('DEL_GROUP', e)
                        }
                    })
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('DEL_GROUP', e)
                }
            })
        }
    }
}




