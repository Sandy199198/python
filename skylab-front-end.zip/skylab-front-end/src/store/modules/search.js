import { SEARCH } from 'common/namespace'
import Vue from 'vue'
import Immutable from 'immutable'
import { SET_ERROR, SET_GLOBAL_ALARM, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, preRequest, printError} from 'common/utils'

export const GET_IMG_SEARCH = `${SEARCH}/getImgSearch`
export const SET_IMG_SEARCH = `${SEARCH}/setImgSearch`
export const FETCH_IMG_SEARCH = `${SEARCH}/fetchImgSearch`
export const CLEAR_IMG_SEARCH = `${SEARCH}/clearImgSearch`
export const FETCH_CAPTURE_SEARCH = `${SEARCH}/fetchCaptureSearch`
export const GET_CAPTURE_SEARCH = `${SEARCH}/getCaptureSearch`
export const SET_CAPTURE_SEARCH = `${SEARCH}/setCaptureSearch`
export const FETCH_VIDEO_LIST = `${SEARCH}/fetchVideoList`
export const SEARCH_VIDEO_LIST = `${SEARCH}/searchVideoList`
export const GET_VIDEO_LIST = `${SEARCH}/getVideoList`
export const SET_VIDEO_LIST = `${SEARCH}/setVideoList`
export const GET_ALL_VIDEO_LIST = `${SEARCH}/getAllVideoList`
export const SET_ALL_VIDEO_LIST = `${SEARCH}/setAllVideoList`
export const SEARCH_VIDEO = `${SEARCH}/searchVideo`
export const REUPDATE_SEARCH_VIDEO = `${SEARCH}/reupdateSearchVideo`
export const SET_CAPTURE_VIDEO_SEARCH = `${SEARCH}/setCaptureVideoSearch`
export const FETCH_CAPTURE_VIDEO_SEARCH = `${SEARCH}/fetchCaptureVideoSearch`
export const GET_CAPTURE_VIDEO_SEARCH = `${SEARCH}/getCaptureVideoSearch`
export const SET_ALARM_VIDEO_SEARCH = `${SEARCH}/setAlarmVideoSearch`
export const FETCH_ALARM_VIDEO_SEARCH = `${SEARCH}/fetchAlarmVideoSearch`
export const GET_ALARM_VIDEO_SEARCH = `${SEARCH}/getAlarmVideoSearch`
export const EXPORT_ALARM_VIDEO = `${SEARCH}/exportAlarmVideo`
export const GET_EXPORT_ALARM_VIDEO = `${SEARCH}/getExportAlarmVideo`
export const GET_EXPORT_ALARM_VIDEO_HISTORY = `${SEARCH}/getExportAlarmVideoHistory`
export const EXPORT_ALARM_VIDEO_HISTORY = `${SEARCH}/exportAlarmVideoHistory`
export const GET_ALARM_VIDEO_ITEM = `${SEARCH}/getAlarmVideoItem`
export const SET_ALARM_VIDEO_ITEM = `${SEARCH}/setAlarmVideoItem`
export const DOWNLOAD = `${SEARCH}/download`
export const PROGRESS = `${SEARCH}/progress`
export const GET_PROGRESS = `${SEARCH}/getProgress`
export const SET_PAGE = `${SEARCH}/setPage`
export const GET_PAGE = `${SEARCH}/getPage`
// export const SET_PKSTATUS = `${SEARCH}/setPkstatus`
// export const GET_PKSTATUS = `${SEARCH}/getPkstatus`
// export const FETCH_PKSTATUS = `${SEARCH}/fetchPkstatus`

export default {
    state: {
        imgSearchList: [],
        page: {},
        captureSearchList: [],
        videoList: [],
        allVideoList: [],
        getCaptureVideoSearch: [],
        getAlarmVideoSearch: [],
        getExportAlarmVideo: [],
        getExportAlarmVideoHistory: [],
        getAlarmVideoItem: {},
        getProgress: {
            style: {},
            show: {
                display: 'none'
            }
        },
    },
    getters: {
        [GET_IMG_SEARCH](state) {
            return state.imgSearchList
        },
        [GET_PAGE](state) {
            return state.page
        },
        [GET_CAPTURE_SEARCH](state) {
            return state.captureSearchList
        },
        [GET_VIDEO_LIST](state) {
            return state.videoList
        },
        [GET_ALL_VIDEO_LIST](state) {
            return state.allVideoList
        },
        [GET_CAPTURE_VIDEO_SEARCH](state) {
            return state.getCaptureVideoSearch
        },
        [GET_ALARM_VIDEO_SEARCH](state) {
            return state.getAlarmVideoSearch
        },
        [GET_EXPORT_ALARM_VIDEO](state) {
            return state.getExportAlarmVideo
        },
        [GET_EXPORT_ALARM_VIDEO_HISTORY](state) {
            return state.getExportAlarmVideoHistory
        },
        [GET_ALARM_VIDEO_ITEM](state) {
            return state.getAlarmVideoItem
        },
        [GET_PROGRESS](state) {
            return state.getProgress
        },
    },
    mutations: {
        [SET_IMG_SEARCH](state, data) {
            state.imgSearchList.push(data)
        },
        [SET_PAGE](state, data) {
            state.page = Object.assign({}, data)
        },
        [SET_CAPTURE_SEARCH](state, data) {
            state.captureSearchList = data
        },
        [SET_VIDEO_LIST](state, data) {
            state.videoList = data
        },
        [SET_ALL_VIDEO_LIST](state, data) {
            state.allVideoList = data
        },
        [SEARCH_VIDEO](state, data) {
            for (let i in data) {
                state.videoList.unshift(data[i])
            }
        },
        [REUPDATE_SEARCH_VIDEO](state, data) {
            for (let [i, a] of state.videoList.entries()) {
                if (a.id == data.id) {
                    state.videoList.splice(i, 1, data)
                }
            }
        },
        [SET_CAPTURE_VIDEO_SEARCH](state, data) {
            state.getCaptureVideoSearch = data
        },
        [SET_ALARM_VIDEO_SEARCH](state, data) {
            state.getAlarmVideoSearch = data
        },
        [EXPORT_ALARM_VIDEO](state, data) {
            state.getExportAlarmVideo = Object.assign({}, data)
        },
        [EXPORT_ALARM_VIDEO_HISTORY](state, data) {
            state.getExportAlarmVideoHistory = data
        },
        [SET_ALARM_VIDEO_ITEM](state, data) {
            state.getAlarmVideoItem = Object.assign({}, data)
        },
        [PROGRESS](state, data) {
            state.getProgress.show = Object.assign({}, {})
            state.getProgress.style = Object.assign({}, {})
            state.getProgress.style.width = data.loaded ? (data.loaded / data.total) * 100 + '%' : 0 + '%'
            if (data.loaded < data.total && data.loaded != 0) {
                state.getProgress.show.display = 'block'
            } else {
                state.getProgress.show.display = 'none'
            }
        },
        [CLEAR_IMG_SEARCH](state) {
            state.imgSearchList = []
        }
    },
    actions: {
        [FETCH_IMG_SEARCH](context, options) {
            let url = `${context.getters[GET_SERVICES].Skylab}search/search-group`
            let {formdata, src} = options

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'POST',
                        body: formdata,
                        headers: {
                            'User-Access-Token': code
                        },
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(SET_IMG_SEARCH, {
                            photos: data.data,
                            sourceImg: src
                        })
                        context.commit(SET_PAGE, data.paging)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('FETCH_IMG_SEARCH', e)
                        }
                    })
                })
            })
        },
        [FETCH_CAPTURE_SEARCH](context, options) {
            let url = `${context.getters[GET_SERVICES].Skylab}search/search-capture`
            let formData = new FormData(options)

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'POST',
                        body: formData,
                        headers: {
                            'User-Access-Token': code
                        },
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(SET_CAPTURE_SEARCH, data.data)
                        // context.commit(SET_PAGE, data.paging)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('FETCH_CAPTURE_SEARCH', e)
                        }
                    })
                })
            })
        },
        [FETCH_VIDEO_LIST](context, size) {
            let tmpSize = !size ? 10 : 1000
            let url = `${context.getters[GET_SERVICES].Skylab}search/finish-video-list?size=` + tmpSize

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'GET',
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        },
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        if (tmpSize == 10) {
                            context.commit(SET_VIDEO_LIST, data.data)
                            context.commit(SET_PAGE, data.paging)
                        } else {
                            context.commit(SET_ALL_VIDEO_LIST, data.data)
                        }
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('FETCH_VIDEO_LIST', e)
                        }
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_VIDEO_LIST', e)
                    }
                })
            })
        },
        [SEARCH_VIDEO_LIST](context, page) {
            let url = `${context.getters[GET_SERVICES].Skylab}search/finish-video-list?page=` + page + '&size=10'

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'GET',
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        },
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(SET_VIDEO_LIST, data.data)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('SEARCH_VIDEO_LIST', e)
                        }
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('SEARCH_VIDEO_LIST', e)
                    }
                })
            })
        },
        [SEARCH_VIDEO](context, options, filename) {
            let url = `${context.getters[GET_SERVICES].Skylab}search/search-video`

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    let request = new XMLHttpRequest()

                    request.open('POST', url)
                    request.setRequestHeader('User-Access-Token', code)
                    request.withCredentials = true
                    request.onload = () => {
                        if (request.status == 200) {
                            let data = JSON.parse(request.response).data

                            context.commit(SEARCH_VIDEO, data)
                        }
                    }
                    request.upload.addEventListener('progress', function (e) {
                        context.commit(PROGRESS, e)
                    })
                    request.send(options)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('SEARCH_VIDEO', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SEARCH_VIDEO', e)
                }
            })
        },
        [REUPDATE_SEARCH_VIDEO](context, id) {
            let url = `${context.getters[GET_SERVICES].Skylab}search/video/` + id

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        },
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(REUPDATE_SEARCH_VIDEO, data.data)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('REUPDATE_SEARCH_VIDEO', e)
                        }
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('REUPDATE_SEARCH_VIDEO', e)
                    }
                })
            })
        },
        [FETCH_CAPTURE_VIDEO_SEARCH](context, options) {
            let url = `${context.getters[GET_SERVICES].Skylab}search/video-capture?`
            let arr = []

            for (let i in options) {
                arr.push(i + '=' + options[i])
            }
            url += arr.join('&')
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'GET',
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        },
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(SET_CAPTURE_VIDEO_SEARCH, data.data)
                        context.commit(SET_PAGE, data.paging)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('FETCH_CAPTURE_VIDEO_SEARCH', e)
                        }
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_CAPTURE_VIDEO_SEARCH', e)
                    }
                })
            })
        },
        [FETCH_ALARM_VIDEO_SEARCH](context, options) {
            let url = `${context.getters[GET_SERVICES].Skylab}search/video-alarm?`
            let arr = [], isFormat = options.hasOwnProperty('format')

            for (let i in options) {
                arr.push(i + '=' + options[i])
            }
            url += arr.join('&')
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'GET',
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        },
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(SET_ALARM_VIDEO_SEARCH, data.data)
                        context.commit(SET_PAGE, data.paging)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('FETCH_ALARM_VIDEO_SEARCH', e)
                        }
                    })
                })
            })
        },
        [SET_ALARM_VIDEO_ITEM](context, options) {
            let url = `${context.getters[GET_SERVICES].Skylab}exports/?`
            let arr = []

            for (let i in options) {
                arr.push(i + '=' + options[i])
            }
            url += arr.join('&')
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        },
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(SET_ALARM_VIDEO_ITEM, data.data)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('SET_ALARM_VIDEO_ITEM', e)
                        }
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('SET_ALARM_VIDEO_ITEM', e)
                    }
                })
            })
        },
        [EXPORT_ALARM_VIDEO](context, options) {
            let url = `${context.getters[GET_SERVICES].Skylab}exports/?`
            let arr = [], isNotHistory = options.hasOwnProperty('task_id')

            for (let i in options) {
                arr.push(i + '=' + options[i])
            }
            url += arr.join('&')
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'GET',
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        },
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        if (isNotHistory) {
                            context.commit(EXPORT_ALARM_VIDEO, data.data)
                        } else {
                            context.commit(EXPORT_ALARM_VIDEO_HISTORY, data.data)
                        }
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('EXPORT_ALARM_VIDEO', e)
                        }
                    })
                })
            })
        },
    }
}
