import { IMAGE_FILTER } from 'common/namespace'
import Vue from 'vue'
import { SET_ERROR, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, preRequest, printError} from 'common/utils'

export const GET_IMAGE_FILTER_LIST = `${IMAGE_FILTER}/getImageFilterList`
export const SET_IMAGE_FILTER_LIST = `${IMAGE_FILTER}/setImageFilterList`
export const FETCH_IMAGE_FILTER_LIST = `${IMAGE_FILTER}/fetchImageFilterList`
export const DELETE_IMAGE_FILTER = `${IMAGE_FILTER}/deleteImageFilter`
export const SET_PAGE = `${IMAGE_FILTER}/setPage`
export const GET_PAGE = `${IMAGE_FILTER}/getPage`

export default {
    state: {
        page: {},
        imageFilterData: []
    },
    getters: {
        [GET_IMAGE_FILTER_LIST](state) {
            return state.imageFilterData
        },
        [GET_PAGE](state) {
            return state.page
        },
    },
    mutations: {
        [SET_IMAGE_FILTER_LIST](state, data) {
            state.imageFilterData = data
        },
        [SET_PAGE](state, page) {
            state.page = Object.assign({}, page)
        },
        [DELETE_IMAGE_FILTER](state, data) {
            // for (let [i, a] of state.alarmHistoryData.entries()) {
            //     if (a.id == data.id) {
            //         state.alarmHistoryData.splice(i, 1)
            //         state.page.totalitems = state.page.totalitems - 1
            //         break
            //     }
            // }
        },
    },
    actions: {
        [FETCH_IMAGE_FILTER_LIST](context, obj) {
            let params = []
            let url = `http://192.168.0.10:10100/imgs/`

            for (let key in obj) {
                params.push(key + '=' + obj[key])
            }
            params.push('size' + '=' + 50)
            params = params.join('&')
            if (params) {
                url += '?' + params
            }
            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_IMAGE_FILTER_LIST, data.data.result)
                    context.commit(SET_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_IMAGE_FILTER_LIST', e)
                    }
                })
            })
        },
        [DELETE_IMAGE_FILTER](context, name) {
            console.log(name)

            fetch(`http://192.168.0.10:10100/imgs/?path=` + name, {
                credentials: 'include',
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                }
            }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                // context.commit(DELETE_IMAGE_FILTER, name)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('DELETE_IMAGE_FILTER', e)
                }
            })
        },
    }
}
