import { MEMBER } from 'common/namespace'
import Vue from 'vue'
import { SET_ERROR, SET_GLOBAL_ALARM, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, preRequest, printError} from 'common/utils'

export const GET_MEMBER = `${MEMBER}/getMember`
export const FETCH_MEMBER = `${MEMBER}/fetchMember`
export const SET_MEMBER = `${MEMBER}/setMember`
export const ADD_MEMBER = `${MEMBER}/addMember`
export const UPDATE_MEMBER = `${MEMBER}/updateMember`
export const DEL_MEMBER = `${MEMBER}/delMember`
export const UPLOAD_IMG = `${MEMBER}/uploadImg`
export const SET_UPLOAD_IMG = `${MEMBER}/setUploadImg`
export const GET_UPLOAD_IMG = `${MEMBER}/getUploadImg`
export const SET_PAGE = `${MEMBER}/setPage`
export const GET_PAGE = `${MEMBER}/getPage`
export const BULK_UPLOAD_ERROR = `${MEMBER}/bulkUploadError`
export const GET_BULK_UPLOAD_ERROR = `${MEMBER}/getBulkUploadError`
export const CLEAR_BULK_UPLOAD_ERROR = `${MEMBER}/clearBulkUploadError`
export const BULK_UPLOAD = `${MEMBER}/bulkUpload`
export const GET_BULK_UPLOAD = `${MEMBER}/getBulkUpload`
export const GET_PHOTO = `${MEMBER}/getPhoto`
export const FETCH_PHOTO = `${MEMBER}/fetchPhoto`
export const SET_PHOTO = `${MEMBER}/setPhoto`
export const DEL_PHOTO = `${MEMBER}/delPhoto`
export const GET_PHOTO_PAGE = `${MEMBER}/getPhotoPage`
export const SET_PHOTO_PAGE = `${MEMBER}/setPhotoPage`

export default {
    state: {
        memberItems: [],
        memberItem: {},
        page: {},
        imgObj: {},
        bulkErrorItems: [],
        bulkUploadItem: {},
        photos: [],
        photoPage: {}
    },
    getters: {
        [GET_MEMBER](state) {
            return state.memberItems
        },
        [GET_PAGE](state) {
            return state.page
        },
        [GET_UPLOAD_IMG](state) {
            return state.imgObj
        },
        [GET_BULK_UPLOAD_ERROR](state) {
            return state.bulkErrorItems
        },
        [GET_BULK_UPLOAD](state) {
            return state.bulkUploadItem
        },
        [GET_PHOTO](state) {
            return state.photos
        },
        [GET_PHOTO_PAGE](state) {
            return state.photoPage
        }
    },
    mutations: {
        [SET_MEMBER](state, data) {
            state.memberItems = data
        },
        [ADD_MEMBER](state, data) {
            state.memberItems.unshift(data)
        },
        [DEL_MEMBER](state, id) {
            for (let [i, a] of state.memberItems.entries()) {
                if (a['id'] == id) {
                    state.memberItems.splice(i, 1)
                    break
                }
            }
        },
        [UPDATE_MEMBER](state, data) {
            for (let [i, a] of state.memberItems.entries()) {
                if (a.id == data.id) {
                    state.memberItems.splice(i, 1, data)
                }
            }
        },
        [SET_PAGE](state, page) {
            let pageObj = Object.assign({}, page)

            state.page = Object.assign({}, pageObj)
        },
        [SET_UPLOAD_IMG](state, data) {
            state.imgObj = data.data
        },
        [BULK_UPLOAD_ERROR](state, data) {
            state.bulkErrorItems.push(data)
        },
        [BULK_UPLOAD](state, data) {
            state.bulkUploadItem = Object.assign({}, data)
            // state.bulkUploadItems.push(data)
        },
        [CLEAR_BULK_UPLOAD_ERROR](state) {
            state.bulkErrorItems = []
        },
        [SET_PHOTO](state, data) {
            state.photos = data
        },
        [SET_PHOTO_PAGE](state, page) {
            state.photoPage = Object.assign({}, page)
        }
    },
    actions: {
        [FETCH_MEMBER](context, options) {
            let url = `${context.getters[GET_SERVICES].Skylab}persons/?`
            let arr = []

            for (let i in options) {
                if (options[i]) {
                    if (i == 'groupId') {
                        arr.push('group_id' + '=' + options[i])
                    } else {
                        arr.push(i + '=' + options[i])
                    }
                    if (i == 'certId') {
                        arr.push('cert_id' + '=' + options[i])
                    } else {
                        arr.push(i + '=' + options[i])
                    }
                    if (i == 'criminalRecord') {
                        arr.push('criminal_record' + '=' + options[i])
                    } else {
                        arr.push(i + '=' + options[i])
                    }
                }
            }
            arr.push('size=20')
            url += arr.join('&')

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_MEMBER, data.data)
                    context.commit(SET_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_MEMBER', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_MEMBER', e)
                }
            })
        },
        [ADD_MEMBER](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].Skylab}persons/`

            for (let key in options) {
                if (key != 'groups') {
                    tmpObj[key] = options[key]
                }
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'POST',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(ADD_MEMBER, data.data)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('ADD_MEMBER', e)
                        }
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('ADD_MEMBER', e)
                    }
                })
            })
        },
        [UPDATE_MEMBER](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].Skylab}persons/` + options.id

            for (let key in options) {
                if (key != 'groups') {
                    tmpObj[key] = options[key]
                }
            }

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'PUT',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(UPDATE_MEMBER, data.data)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('UPDATE_MEMBER', e)
                        }
                    })
                })
            })
        },
        [DEL_MEMBER](context, id) {
            let url = `${context.getters[GET_SERVICES].Skylab}persons/` + id

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(DEL_MEMBER, id)
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('DEL_MEMBER', e)
                        }
                    })
                })
            })
        },
        [UPLOAD_IMG](context, options) {
            let url = `${context.getters[GET_SERVICES].Skylab}photos/`
            let formData = new FormData(options)

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'POST',
                        body: formData,
                        headers: {
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(SET_UPLOAD_IMG, data)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('UPLOAD_IMG', e)
                        }
                    })
                })
            })
        },
        [BULK_UPLOAD](context, options) {
            let url = `${context.getters[GET_SERVICES].Skylab}photos/`

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'POST',
                        body: options.formData,
                        headers: {
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(BULK_UPLOAD, data.data)
                        resolve()
                    }).catch(e => {
                        context.commit(BULK_UPLOAD_ERROR, {
                            fields: options.name,
                            message: e.message
                        })
                        resolve()
                    })
                })
            })
            // return fetch(url, {
            //     credentials: 'include',
            //     method: 'POST',
            //     body: options.formData
            // }).then(res => {
            //     return analyzeHttpCode(res)
            // }).then(data => {
            //     context.commit(BULK_UPLOAD, data.data)
            // }).catch(e => {
            //     context.commit(BULK_UPLOAD_ERROR, {
            //         fields: options.name,
            //         message: e.message
            //     })
            // })
        },
        [FETCH_PHOTO](context, options) {
            let url = `${context.getters[GET_SERVICES].Skylab}photos/?`
            let arr = []

            for (let i in options) {
                if (options[i]) {
                    if (i == 'groupId') {
                        arr.push('group_id' + '=' + options[i])
                    } else {
                        arr.push(i + '=' + options[i])
                    }
                }
            }
            arr.push('low_qulity=true')
            arr.push('size=20')
            url += arr.join('&')

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_PHOTO, data.data)
                    context.commit(SET_PHOTO_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_PHOTO', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_PHOTO', e)
                }
            })
        },
    }
}



