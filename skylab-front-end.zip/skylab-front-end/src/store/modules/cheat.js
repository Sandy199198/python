import { CHEAT } from 'common/namespace'
import Vue from 'vue'
import { SET_ERROR, SET_GLOBAL_ALARM, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, preRequest, printError} from 'common/utils'

export const UPDATE_VIDEO = `${CHEAT}/updateVideo`
export const GET_VIDEO = `${CHEAT}/getVideo`
export const SET_VIDEO = `${CHEAT}/setVideo`
export const FETCH_VIDEO = `${CHEAT}/fetchVideo`
export const UPDATE_DEPLOY = `${CHEAT}/updateDeploy`
export const GET_DEPLOY = `${CHEAT}/getDeploy`
export const SET_DEPLOY = `${CHEAT}/setDeploy`
export const FETCH_DEPLOY = `${CHEAT}/fetchDeploy`
export const SET_PAGE = `${CHEAT}/setPage`
export const GET_PAGE = `${CHEAT}/getPage`

export default {
    state: {
        videoItems: [],
        videoItem: {},
        deployItems: [],
        deployItem: {},
        page: {}
    },
    getters: {
        [GET_VIDEO](state) {
            return state.videoItems
        },
        [GET_DEPLOY](state) {
            return state.deployItems
        },
        [GET_PAGE](state) {
            return state.page
        }
    },
    mutations: {
        [SET_VIDEO](state, data) {
            state.videoItems = data
        },
        [UPDATE_VIDEO](state, data) {
            for (let [i, a] of state.videoItems.entries()) {
                if (a.id == data.id) {
                    state.videoItems.splice(i, 1, data)
                }
            }
        },
        [SET_PAGE](state, page) {
            state.page = Object.assign({}, page)
        },
        [SET_DEPLOY](state, data) {
            state.deployItems = data
        },
        [UPDATE_DEPLOY](state, data) {
            for (let [i, a] of state.deployItems.entries()) {
                if (a.id == data.id) {
                    state.deployItems.splice(i, 1, data)
                }
            }
        },
    },
    actions: {
        [FETCH_VIDEO](context, options) {
            let url = `${context.getters[GET_SERVICES].Skylab}internal/pk/videos/`
            // let url = `http://10.101.3.38:8005/internal/pk/videos/`

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_VIDEO, data.data)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_VIDEO', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_VIDEO', e)
                }
            })
        },
        [UPDATE_VIDEO](context, obj) {
            let url = `${context.getters[GET_SERVICES].Skylab}internal/pk/videos/`
            let id = obj.id
            // let url = `http://10.101.3.38:8005/internal/pk/videos/` + id
            let options = Object.assign({}, {
                groups: obj.options
            })

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        },
                        body: JSON.stringify(options)
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(UPDATE_VIDEO, data.data)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('UPDATE_VIDEO', e)
                        }
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('UPDATE_VIDEO', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('UPDATE_VIDEO', e)
                }
            })
        },
        [FETCH_DEPLOY](context, options) {
            let url = `${context.getters[GET_SERVICES].Skylab}internal/pk/deployments/`
            // let url = `http://10.101.3.38:8005/internal/pk/deployments/`

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_DEPLOY, data.data)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_DEPLOY', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_DEPLOY', e)
                }
            })
        },
        [UPDATE_DEPLOY](context, obj) {
            let url = `${context.getters[GET_SERVICES].Skylab}internal/pk/videos/`
            let id = obj.id
            // let url = `http://10.101.3.38:8005/internal/pk/deployments/` + id
            let options = Object.assign({}, {
                groups: obj.options
            })

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        },
                        body: JSON.stringify(options)
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(UPDATE_DEPLOY, data.data)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('UPDATE_DEPLOY', e)
                        }
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('UPDATE_DEPLOY', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('UPDATE_DEPLOY', e)
                }
            })
        },
    }
}




