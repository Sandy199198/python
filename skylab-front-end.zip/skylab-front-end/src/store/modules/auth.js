import { AUTH } from 'common/namespace'
import { SET_ERROR, GET_SERVICES, DISCONNECT_WEB_SOCKET, DISCONNECT_ALARM_WEB_SOCKET, DISCONNECT_VIDEO_WEB_SOCKET } from 'store/modules/common'
import URL from 'common/url'
import { analyzeHttpCode, printError} from 'common/utils'

export const LOGIN = `${AUTH}/login`
export const LOGOUT = `${AUTH}/logout`
export const CHECK_LOGIN = `${AUTH}/checkLogin`

export const GET_USER_INFO = `${AUTH}/getUserInfo`
export const SET_USER_INFO = `${AUTH}/setUserInfo`
export const CLEAR_USER_INFO = `${AUTH}/clearUserInfo`

export default {
    state: {
        userInfo: {}
    },
    getters: {
        [GET_USER_INFO](state) {
            return state.userInfo
        }
    },
    mutations: {
        [SET_USER_INFO](state, data) {
            state.userInfo = data
        },
        [CLEAR_USER_INFO](state) {
            state.userInfo = {}
        }
    },
    actions: {
        [LOGIN](context, params) {
            let { username, password } = params

            return new Promise((resolve, reject) => {
                fetch(`${context.getters[GET_SERVICES].Skylab}login`, {
                    credentials: 'include',
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        username,
                        password
                    })
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_USER_INFO, data.data)
                    resolve(data.data.user_id)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('LOGIN', e)
                    }
                })
            })

        },

        [LOGOUT](context, {
            router,
            route
        }) {
            fetch(`${context.getters[GET_SERVICES].Skylab}logout`, {
                credentials: 'include'
            }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(DISCONNECT_WEB_SOCKET)
                context.commit(DISCONNECT_ALARM_WEB_SOCKET)
                context.commit(DISCONNECT_VIDEO_WEB_SOCKET)
                setTimeout(() => {
                    context.commit(CLEAR_USER_INFO)
                    router.push({
                        name: URL.LOGIN,
                        params: {
                            redirect: route
                        }
                    })
                }, 0)
                window.location.reload()
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('LOGOUT', e)
                }
            })
        },

        [CHECK_LOGIN](context, params) {
            return new Promise((resolve, reject) => {
                fetch(`${context.getters[GET_SERVICES].Skylab}check_login`, {
                    credentials: 'include',
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    if (data.data) {
                        context.commit(SET_USER_INFO, data.data)
                        resolve()
                    } else {
                        context.commit(CLEAR_USER_INFO)
                        reject()
                    }
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('CHECK_LOGIN', e)
                    }
                })
            })
        }
    }
}
