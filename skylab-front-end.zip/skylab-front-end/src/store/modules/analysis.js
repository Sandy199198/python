import { ANALYSIS } from 'common/namespace'
import Vue from 'vue'
import { SET_ERROR, SET_GLOBAL_ALARM, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, preRequest, printError} from 'common/utils'

export const GET_COLLISION = `${ANALYSIS}/getCollision`
export const SET_COLLISION = `${ANALYSIS}/setCollision`
export const FETCH_COLLISION = `${ANALYSIS}/fetchCollision`
export const ADD_COLLISION = `${ANALYSIS}/addCollision`
export const DEL_COLLISION = `${ANALYSIS}/delCollision`

export const GET_COLLISION_POINT = `${ANALYSIS}/getCollisionPoint`
export const SET_COLLISION_POINT = `${ANALYSIS}/setCollisionPoint`
export const ADD_COLLISION_POINT = `${ANALYSIS}/addCollisionPoint`
export const DEL_COLLISION_POINT = `${ANALYSIS}/delCollisionPoint`

export const GET_COLLISION_TIME = `${ANALYSIS}/getCollisionTime`
export const SET_COLLISION_TIME = `${ANALYSIS}/setCollisionTime`
export const ADD_COLLISION_TIME = `${ANALYSIS}/addCollisionTime`
export const DEL_COLLISION_TIME = `${ANALYSIS}/delCollisionTime`

export const FETCH_COLLISION_ITEMS = `${ANALYSIS}/fetchCollisionItems`
export const SET_COLLISION_ITEMS = `${ANALYSIS}/setCollisionItems`
export const GET_COLLISION_ITEMS = `${ANALYSIS}/getCollisionItems`
export const SET_COLLISION_DETAIL_ITEMS = `${ANALYSIS}/setCollisionDetailItems`
export const GET_COLLISION_DETAIL_ITEMS = `${ANALYSIS}/getCollisionDetailItems`

export const GET_PEER = `${ANALYSIS}/getPeer`
export const SET_PEER = `${ANALYSIS}/setPeer`
export const ADD_PEER = `${ANALYSIS}/addPeer`
export const DEL_PEER = `${ANALYSIS}/delPeer`
export const FETCH_PAGE = `${ANALYSIS}/fetchPage`
export const SET_PAGE = `${ANALYSIS}/setPage`
export const GET_PAGE = `${ANALYSIS}/getPage`

export const GET_FREQUENCY = `${ANALYSIS}/getFrequency`
export const SET_FREQUENCY = `${ANALYSIS}/setFrequency`

export const CAPTURE_SEARCH = `${ANALYSIS}/captureSearch`
export const CAPTURE_SEARCH_RESULT = `${ANALYSIS}/captureSearchResult`
export const SET_CAPTURE_SEARCH = `${ANALYSIS}/setCaptureSearch`

export default {
    state: {
        collisionItems: [],
        collisionItem: {},
        collisionPointItems: [],
        collisionPointItem: {},
        collisionTimeItems: [],
        collisionTimeItem: {},
        peerItems: [],
        peerItem: {},
        frequencyItems: [],
        frequencyItem: {},
        page: {},
        allCollisionItems: [],
        collisionDetail: [],
        result: []
    },
    getters: {
        [GET_COLLISION](state) {
            return state.collisionItems
        },
        [GET_COLLISION_POINT](state) {
            return state.collisionPointItems
        },
        [GET_COLLISION_TIME](state) {
            return state.collisionTimeItems
        },
        [GET_PEER](state) {
            return state.peerItems
        },
        [GET_FREQUENCY](state) {
            return state.frequencyItems
        },
        [GET_PAGE](state) {
            return state.page
        },
        [GET_COLLISION_ITEMS](state) {
            return state.allCollisionItems
        },
        [GET_COLLISION_DETAIL_ITEMS](state) {
            return state.collisionDetail
        },
        [CAPTURE_SEARCH_RESULT](state) {
            return state.result
        }
    },
    mutations: {
        [SET_COLLISION](state, data) {
            state.collisionItems = data
        },

        [SET_COLLISION_TIME](state, data) {
            state.collisionTimeItems = data
        },

        [SET_COLLISION_POINT](state, data) {
            state.collisionPointItems = data
        },

        [SET_PEER](state, data) {
            state.peerItems = data
        },

        [SET_FREQUENCY](state, data) {
            state.frequencyItems = data
        },

        [SET_PAGE](state, page) {
            state.page = Object.assign({}, page)
        },

        [SET_COLLISION_ITEMS](state, data) {
            state.allCollisionItems = state.allCollisionItems.concat(data)
        },

        [ADD_COLLISION_POINT](state, data) {
            state.collisionPointItems.unshift(data)
        },

        [ADD_COLLISION_TIME](state, data) {
            state.collisionTimeItems.unshift(data)
        },

        [ADD_COLLISION](state, data) {
            state.collisionItems.unshift(data)
        },

        [SET_COLLISION_DETAIL_ITEMS](state, data) {
            state.collisionDetail = state.collisionDetail.concat(data)
        },

        [DEL_COLLISION](state, id) {
            for (let [i, a] of state.collisionItems.entries()) {
                if (a['job_id'] == id) {
                    state.collisionItems.splice(i, 1)
                    break
                }
            }
        },

        [DEL_COLLISION_TIME](state, id) {
            for (let [i, a] of state.collisionTimeItems.entries()) {
                if (a['job_id'] == id) {
                    state.collisionTimeItems.splice(i, 1)
                    break
                }
            }
        },

        [DEL_COLLISION_POINT](state, id) {
            for (let [i, a] of state.collisionPointItems.entries()) {
                if (a['job_id'] == id) {
                    state.collisionPointItems.splice(i, 1)
                    break
                }
            }
        },

        [ADD_PEER](state, data) {
            state.peerItems.unshift(data)
        },

        [DEL_PEER](state, id) {
            for (let [i, a] of state.peerItems.entries()) {
                if (a['job_id'] == id) {
                    state.peerItems.splice(i, 1)
                    break
                }
            }
        },

        [SET_CAPTURE_SEARCH](state, data) {
            state.result = data
        }
    },
    actions: {
        [FETCH_COLLISION](context, group) {
            let params = []
            let jobType = group.job_type
            let url = `${context.getters[GET_SERVICES].Skylab}analysis/`

            for (let key in group) {
                if (group[key]) {
                    params.push(key + '=' + group[key])
                }
            }

            params = params.join('&')
            if (params) {
                url += '?' + params
            }

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    if (jobType == 1) {
                        context.commit(SET_COLLISION_TIME, data.data)
                        context.commit(SET_PAGE, data.paging)
                    } else if (jobType == 2) {
                        context.commit(SET_COLLISION_POINT, data.data)
                        context.commit(SET_PAGE, data.paging)
                    } else if (jobType == 3) {
                        context.commit(SET_COLLISION, data.data)
                        context.commit(SET_PAGE, data.paging)
                    } else if (jobType == 4) {
                        context.commit(SET_PEER, data.data)
                        context.commit(SET_PAGE, data.paging)
                    } else {
                        context.commit(SET_FREQUENCY, data.data)
                        context.commit(SET_PAGE, data.paging)
                    }
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_COLLISION', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_COLLISION', e)
                }
            })
        },

        [ADD_COLLISION](context, options) {
            let jobType = options['job_type']
            let add = options['add']
            let obj = {}

            for (let i in options) {
                if (i != 'add') {
                    obj[i] = options[i]
                }
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(`${context.getters[GET_SERVICES].Skylab}analysis/collision/`, {
                        credentials: 'include',
                        method: 'POST',
                        body: JSON.stringify(obj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        if (jobType == 1) {
                            context.commit(ADD_COLLISION_TIME, data.data)
                        } else if (jobType == 2) {
                            context.commit(ADD_COLLISION_POINT, data.data)
                        } else if (jobType == 3) {
                            context.commit(ADD_COLLISION, data.data)
                        }
                        if (!add) {
                            context.commit(SET_GLOBAL_ALARM, '重新执行成功')
                        }
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('ADD_COLLISION', e)
                        }
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('ADD_COLLISION', e)
                    }
                })
            })
        },

        [ADD_PEER](context, options) {
            let params = {}
            let add  = options['add']

            for (let i in options) {
                if (i != 'add') {
                    params[i] = options[i]
                }
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(`${context.getters[GET_SERVICES].Skylab}analysis/peer/`, {
                        credentials: 'include',
                        method: 'POST',
                        body: JSON.stringify(params),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(ADD_PEER, data.data)
                        if (!add) {
                            context.commit(SET_GLOBAL_ALARM, '重新执行成功')
                        }
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('ADD_PEER', e)
                        }
                    })
                })
            })
        },

        [DEL_COLLISION](context, id) {
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(`${context.getters[GET_SERVICES].Skylab}analysis/${id}/cancel`, {
                        credentials: 'include',
                        method: 'PUT',
                        headers: {
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(DEL_COLLISION, id)
                        context.commit(DEL_COLLISION_POINT, id)
                        context.commit(DEL_COLLISION_TIME, id)
                        context.commit(DEL_PEER, id)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('DEL_COLLISION', e)
                        }
                    })
                })
            })
        },

        [FETCH_COLLISION_ITEMS](context, options) {
            let id = options.id
            let cusor = options.cusor
            let group = options.group
            let photo = options.photo

            preRequest(context).then(code => {
                if (!group) {
                    if (!cusor) {
                        fetch(`${context.getters[GET_SERVICES].Skylab}analysis/${id}`, {
                            credentials: 'include',
                            method: 'GET',
                            headers: {
                                'User-Access-Token': code
                            }
                        }).then(res => {
                            return analyzeHttpCode(res)
                        }).then(data => {
                            context.commit(SET_COLLISION_ITEMS, data.data.items)
                            context.commit(SET_PAGE, data.paging)
                        }).catch(e => {
                            if (e.type) {
                                context.commit(SET_ERROR, e.message)
                            } else {
                                printError('FETCH_COLLISION_ITEMS', e)
                            }
                        })
                    } else {
                        fetch(`${context.getters[GET_SERVICES].Skylab}analysis/${id}?cursor=${cusor}`, {
                            credentials: 'include',
                            method: 'GET',
                            headers: {
                                'User-Access-Token': code
                            }
                        }).then(res => {
                            return analyzeHttpCode(res)
                        }).then(data => {
                            context.commit(SET_COLLISION_ITEMS, data.data.items)
                            context.commit(SET_PAGE, data.paging)
                        }).catch(e => {
                            if (e.type) {
                                context.commit(SET_ERROR, e.message)
                            } else {
                                printError('FETCH_COLLISION_ITEMS', e)
                            }
                        })
                    }
                } else {
                    if (!cusor) {
                        fetch(`${context.getters[GET_SERVICES].Skylab}analysis/${id}/${group}/${photo}`, {
                            credentials: 'include',
                            method: 'GET',
                            headers: {
                                'User-Access-Token': code
                            }
                        }).then(res => {
                            return analyzeHttpCode(res)
                        }).then(data => {
                            context.commit(SET_COLLISION_DETAIL_ITEMS, data.data)
                            context.commit(SET_PAGE, data.paging)
                        }).catch(e => {
                            if (e.type) {
                                context.commit(SET_ERROR, e.message)
                            } else {
                                printError('FETCH_COLLISION_ITEMS', e)
                            }
                        })
                    } else {
                        fetch(`${context.getters[GET_SERVICES].Skylab}analysis/${id}/${group}/${photo}?cursor=${cusor}`, {
                            credentials: 'include',
                            method: 'GET',
                            headers: {
                                'User-Access-Token': code
                            }
                        }).then(res => {
                            return analyzeHttpCode(res)
                        }).then(data => {
                            context.commit(SET_COLLISION_DETAIL_ITEMS, data.data)
                            context.commit(SET_PAGE, data.paging)
                        }).catch(e => {
                            if (e.type) {
                                context.commit(SET_ERROR, e.message)
                            } else {
                                printError('FETCH_COLLISION_ITEMS', e)
                            }
                        })
                    }
                }
            })
        },

        [CAPTURE_SEARCH](context, options) {
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    let request = new XMLHttpRequest()

                    request.open('POST', `${context.getters[GET_SERVICES].Skylab}search/search-capture`)
                    request.setRequestHeader('User-Access-Token', code)
                    request.withCredentials = true
                    request.onload = () => {
                        if (request.status == 200) {
                            let data = JSON.parse(request.response).data

                            if (!data.length) {
                                context.commit(SET_CAPTURE_SEARCH, [])
                            } else {
                                context.commit(SET_CAPTURE_SEARCH, data)
                            }
                        }
                    }
                    request.send(new FormData(options))
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('CAPTURE_SEARCH', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('CAPTURE_SEARCH', e)
                }
            })
        }
    }
}
