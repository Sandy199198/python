import { COMMON } from 'common/namespace'
import { analyzeHttpCode, printError} from 'common/utils'

export const GET_HEIGHT = `${COMMON}/getHeight`
export const GET_HEIGHT_STYLE = `${COMMON}/getHeightStyle`
export const SET_HEIGHT = `${COMMON}/setHeight`

export const SET_GLOBAL_ALARM = `${COMMON}/setGlobalAlarm`
export const SET_ERROR = `${COMMON}/setError`

export const DISABLE_ERROR = `${COMMON}/disableError`
export const GET_GLOBAL_ALARM_MESSAGE = `${COMMON}/getGlobalAlarmMessage}`
export const GET_GLOBAL_ALARM_DISPLAY = `${COMMON}/getGlobalAlarmDisplay}`

export const FETCH_SERVICES = `${COMMON}/fetchServices`
export const SET_SERVICES = `${COMMON}/setServices`
export const GET_SERVICES = `${COMMON}/getServices`
export const GET_PROMETHEUS_QUERY = `${COMMON}/getPrometheusQuery`
export const GET_PROMETHEUS_QUERY_RANGE = `${COMMON}/getPrometheusQueryRange`

export const WEB_SOCKET = `${COMMON}/webSocket`
export const DISCONNECT_WEB_SOCKET = `${COMMON}/disconnectWebSocket`

export const VIDEO_WEB_SOCKET = `${COMMON}/videoWebSocket`
export const DISCONNECT_VIDEO_WEB_SOCKET = `${COMMON}/disconnectVideoWebSocket`

export const ALARM_WEB_SOCKET = `${COMMON}/alarmWebSocket`
export const DISCONNECT_ALARM_WEB_SOCKET = `${COMMON}/disconnectAlarmWebSocket`

export const GET_PROMPT = `${COMMON}/getPrompt`
export const SET_PROMPT = `${COMMON}/setPrompt`
export const DEL_PROMPT = `${COMMON}/delPrompt`
export const CLEAR_PROMPT = `${COMMON}/clearPrompt`

export const SET_VIDEO_URL = `${COMMON}/setVideoUrl`
export const GET_VIDEO_URL = `${COMMON}/getVideoUrl`


import { SET_WS_LOGS } from 'store/modules/logs'
import { ADD_ALARM, SET_ALARM, ADD_REALTIME_CAPTURE, ADD_REALTIME_ALARM, SET_REALTIME_ALARM} from 'store/modules/alarms'


export const ALARM = 'alarm'
export const USER_OPERATION = 'user_operation'
export const MARKED_ALARM = 'alarm_confirm'
export const CAPTURE = 'capture'


let uniqueKey = 0
let ws
let videoWs = []
let alarmWs = []

/*global process*/

export default {

    state: {
        globalAlarmDisplay: false,
        alarmMsg: '',
        winHeight: 0,
        promptList: [],
        videoUrls: [],
        services: {
            Skylab: process.env.NODE_ENV == 'production' ? '/' : 'http://192.168.0.11/'
        }
    },

    getters: {
        [GET_HEIGHT](state) {
            return state.winHeight
        },
        [GET_HEIGHT_STYLE](state) {
            return {
                height: `${state.winHeight}px`
            }
        },
        [GET_PROMPT](state) {
            return state.promptList
        },
        [GET_GLOBAL_ALARM_MESSAGE](state) {
            return state.alarmMsg
        },
        [GET_GLOBAL_ALARM_DISPLAY](state) {
            return state.globalAlarmDisplay
        },
        [GET_SERVICES](state) {
            return state.services
        },
        [GET_PROMETHEUS_QUERY](state) {
            return `${state.services.Prometheus}/api/v1/query`
        },
        [GET_PROMETHEUS_QUERY_RANGE](state) {
            return `${state.services.Prometheus}/api/v1/query_range`
        },
        [GET_VIDEO_URL](state) {
            return state.videoUrls
        }
    },

    mutations: {
        [SET_HEIGHT](state, height) {
            state.winHeight = height
        },

        [DISABLE_ERROR](state) {
            state.globalAlarmDisplay = false
        },

        [SET_ERROR](state, error) {
            if (error == '') return
            state.globalAlarmDisplay = true
            state.alarmMsg = error
        },

        [SET_GLOBAL_ALARM](state, msg) {
            state.globalAlarmDisplay = true
            state.alarmMsg = msg
        },

        [SET_SERVICES](state, data) {
            state.services = data
        },

        [SET_PROMPT](state, data) {
            state.promptList.push(data)
            if (state.promptList.length > 3) {
                state.promptList.shift()
            }
        },

        [DEL_PROMPT](state, index) {
            state.promptList.splice(index, 1)
        },

        [CLEAR_PROMPT](state) {
            state.promptList = []
        },

        [DISCONNECT_WEB_SOCKET](state) {
            if (ws) {
                ws.close()
                ws = null
            }
        },

        [DISCONNECT_VIDEO_WEB_SOCKET](state) {
            if (videoWs.length) {
                for (let index = 0; index < videoWs.length; index++) {
                    if (videoWs[index]) {
                        videoWs[index].close()
                        videoWs[index] = null
                    }
                }
            }
        },

        [DISCONNECT_ALARM_WEB_SOCKET](state, cid) {
            if (cid) {
                alarmWs[cid].close()
                alarmWs[cid] = null
            } else {
                if (alarmWs.length) {
                    for (let index = 0; index < alarmWs.length; index++) {
                        if (alarmWs[index]) {
                            alarmWs[index].close()
                            alarmWs[index] = null
                        }
                    }
                }
            }
        },
        [SET_VIDEO_URL](state, wrapData) {
            let {data, camIndex} = wrapData
            let videoUrl = data.push

            state.videoUrls[camIndex - 1] = videoUrl
        }
    },

    actions: {
        [FETCH_SERVICES](context) {
            return new Promise((resolve, reject) => {
                fetch(`${context.getters[GET_SERVICES].Skylab}services/`, {
                    credentials: 'include'
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {

                    if (process.env.NODE_ENV != 'production') {
                        Object.assign(data.data, {
                            Skylab: 'http://192.168.0.11/'
                        })
                    }

                    context.commit(SET_SERVICES, data.data)
                    resolve()
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_SERVICES', e)
                    }
                })
            })
        },

        [WEB_SOCKET](context, cid) {
            if (ws) {
                // if (cid == ws.url.match(/cid=(\S*)/)[1]) {
                return
                // }
            }
            ws = new WebSocket(`${context.getters[GET_SERVICES].NotifyWS}?cid=${cid}`)

            ws.onmessage = (e) => {
                let data = JSON.parse(e.data)

                if (!data.data) return

                switch (data.type) {
                    case USER_OPERATION:
                        context.commit(SET_WS_LOGS, data.data)
                        context.commit(SET_PROMPT, {
                            key: uniqueKey,
                            type: USER_OPERATION,
                            text: `${data.data.real_name}对系统进行了操作`,
                            data: data.data
                        })
                        break
                    case ALARM:
                        context.commit(ADD_ALARM, data.data)
                        context.commit(SET_ALARM, data.data)
                        context.commit(ADD_REALTIME_ALARM, {
                            from: 'globalAlarm',
                            data: data.data
                        })
                        context.commit(SET_REALTIME_ALARM, {
                            from: 'globalAlarm',
                            data: data.data
                        })
                        context.commit(SET_PROMPT, {
                            key: uniqueKey,
                            type: ALARM,
                            text: `${data.data.camera_name}相机，发现可疑人员`,
                            data: data.data
                        })
                        break
                    case MARKED_ALARM:
                        context.commit(SET_PROMPT, {
                            key: uniqueKey,
                            type: MARKED_ALARM,
                            text: `操作员${data.data.real_name}，确认犯罪人员`,
                            data: data.data
                        })
                        break
                    case CAPTURE:
                        context.commit(ADD_REALTIME_ALARM, {
                            from: 'capture',
                            data: data.data.alarm
                        })
                        context.commit(ADD_REALTIME_CAPTURE, data.data.capture)
                        context.commit(SET_REALTIME_ALARM, {
                            from: 'capture',
                            data: data.data.alarm
                        })
                        break
                }
                uniqueKey += 1
            }
        },

        [ALARM_WEB_SOCKET](context, alarmObj) {
            let {camIndex, cid} = alarmObj
            let aws = alarmWs[cid]

            if (aws) {
                return
            }
            aws = new WebSocket(`${context.getters[GET_SERVICES].NotifyWS}?cid=${cid}`)
            alarmWs[cid] = aws
            aws.onmessage = (e) => {
                let data = JSON.parse(e.data)

                if (!data.data) return

                switch (data.type) {
                    case ALARM:
                        context.commit(ADD_REALTIME_ALARM, {
                            from: 'globalAlarm',
                            data: data.data
                        })
                        context.commit(SET_REALTIME_ALARM, {
                            from: 'globalAlarm',
                            data: data.data
                        })
                        break
                    case CAPTURE:
                        context.commit(ADD_REALTIME_ALARM, {
                            from: 'capture',
                            data: data.data.alarm
                        })
                        context.commit(ADD_REALTIME_CAPTURE, data.data.capture)
                        context.commit(SET_REALTIME_ALARM, {
                            from: 'capture',
                            data: data.data.alarm
                        })
                        break
                }
            }
        },

        [VIDEO_WEB_SOCKET](context, obj) {
            let {url, camIndex} = obj
            let vws = videoWs[camIndex - 1]

            if (vws) {
                vws.close()
                vws = null
            }
            vws = new WebSocket(url)
            videoWs[camIndex - 1] = vws
            vws.onmessage = (e) => {
                let data = JSON.parse(e.data)

                if (!data) return
                context.commit(SET_VIDEO_URL, {
                    data,
                    camIndex
                })
            }
        }
    }

}
