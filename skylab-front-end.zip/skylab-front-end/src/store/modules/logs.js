import { LOG } from 'common/namespace'
import Vue from 'vue'
import { formatDate, analyzeHttpCode, printError} from 'common/utils'
import { SET_ERROR, GET_SERVICES } from 'store/modules/common'

export const GET_LOG_LIST = `${LOG}/getLogList`
export const SET_LOG_LIST = `${LOG}/setLogList`
export const FETCH_LOG_LIST = `${LOG}/fetchLogList`

export const GET_WS_LOGS = `${LOG}/getWSLogs`
export const SET_WS_LOGS = `${LOG}/setWSLogs`
export const FETCH_WS_LOGS = `${LOG}/fetchWSLogs`

export const SET_PAGE = `${LOG}/setPage`
export const GET_PAGE = `${LOG}/getPage`

export const GET_HISTORY_LOG = `${LOG}/getHistoryLog`
export const SET_HISTORY_LOG = `${LOG}/setHistoryLog`
export const FETCH_HISTORY_LOG = `${LOG}/fetchHistoryLog`

export const ACTION_TYPE_LOGIN = 1
export const ACTION_TYPE_LOGOUT = 2
export const ACTION_TYPE_MARKED_ALARM = 3
export const ACTION_TYPE_ADD_POINT = 4
export const ACTION_TYPE_MODIFY_POINT = 5
export const ACTION_TYPE_DEL_POINT = 6

export function formatOperationLog(data) {
    let msg = ''

    switch (data.action_type) {
        case ACTION_TYPE_LOGIN:
        case ACTION_TYPE_LOGOUT:
            break
        case ACTION_TYPE_MARKED_ALARM:
            msg = `比中目标人员${data.message}`
            break
        case ACTION_TYPE_ADD_POINT:
            msg = `增加了点位${data.message}`
            break
        case ACTION_TYPE_MODIFY_POINT:
            msg = `修改了点位${data.message}`
            break
        case ACTION_TYPE_DEL_POINT:
            msg = `删除了点位${data.message}`
            break
    }
    return `<i class="fa fa-caret-right" style="margin-right:10px;color:#92c0f5;"></i>&nbsp;${formatDate(data.timestamp, 'Y-M-D h:m')}&nbsp;${data.user_group_name}&nbsp;<strong style="color:#92c0f5;">${data.real_name}</strong>&nbsp;【${data.action}】${msg}`
}

export default {
    state: {
        logs: [],
        wslogs: [''],
        page: {}
    },
    getters: {
        [GET_LOG_LIST](state) {
            return state.logs
        },
        [GET_WS_LOGS](state) {
            return state.wslogs
        },
        [GET_PAGE](state) {
            return state.page
        },
    },
    mutations: {
        [SET_LOG_LIST](state, data) {
            state.logs = data
        },
        [SET_WS_LOGS](state, data) {
            state.wslogs.push(formatOperationLog(data))
        },
        [SET_PAGE](state, page) {
            state.page = Object.assign({}, page)
        },
        [SET_HISTORY_LOG](state, data) {
            let list = []

            for (let log of data) {
                list.push(formatOperationLog(log))
            }
            state.wslogs = list
        }
    },
    actions: {
        [FETCH_LOG_LIST](context, obj) {
            let params = []
            let url = `${context.getters[GET_SERVICES].Skylab}statistic/query/`

            for (let key in obj) {
                if (obj[key]) {
                    if (key == 'realName') {
                        params.push('real_name' + '=' + obj[key])
                    } else if (key == 'startTime') {
                        params.push('start_time' + '=' + obj[key])
                    } else if (key == 'endTime') {
                        params.push('end_time' + '=' + obj[key])
                    } else if (key == 'actionType') {
                        params.push('action_type' + '=' + obj[key])
                    } else if (key == 'userGroupId') {
                        params.push('user_group_id' + '=' + obj[key])
                    } else {
                        params.push(key + '=' + obj[key])
                    }
                }
            }

            params = params.join('&')
            if (params) {
                url += '?' + params
            }
            fetch(url, { credentials: 'include' }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(SET_LOG_LIST, data.data)
                context.commit(SET_PAGE, data.paging)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_LOG_LIST', e)
                }
            })
        },

        [FETCH_HISTORY_LOG](context) {
            fetch(`${context.getters[GET_SERVICES].Skylab}statistic/query/?page=1&size=5`, {
                credentials: 'include'
            }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(SET_HISTORY_LOG, data.data)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_HISTORY_LOG', e)
                }
            })
        }
    }
}
