import { REAL_TIME } from 'common/namespace'
import Vue from 'vue'
import { SET_ERROR, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, preRequest, printError} from 'common/utils'

export const FETCH_CAMERA_CONFIG_LIST = `${REAL_TIME}/fetchCameraConfigList`
export const GET_CAMERA_CONFIG_LIST = `${REAL_TIME}/getCameraConfigList`
export const SET_CAMERA_CONFIG_LIST = `${REAL_TIME}/setCameraConfigList`

export const FETCH_CAMERA = `${REAL_TIME}/fetchCamera`

export default {
    state: {
        cameraConfigList: []
    },
    getters: {
        [GET_CAMERA_CONFIG_LIST](state) {
            return state.cameraConfigList
        }
    },
    mutations: {
        [SET_CAMERA_CONFIG_LIST](state, wrapperData) {
            let {deployId, data } = wrapperData
            let deployData = state.cameraConfigList
            let newData = []

            if (deployId) {
                for (let d of deployData) {
                    if (d.id == deployId) {
                        d.cameras = []
                        d.cameras = data
                    }
                    newData.push(d)
                }
                state.cameraConfigList = newData
            } else {
                state.cameraConfigList = data
            }
        }
    },
    actions: {
        [FETCH_CAMERA_CONFIG_LIST](context) {
            let url = `${context.getters[GET_SERVICES].Skylab}monitor/camera_confg_list`

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code,
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_CAMERA_CONFIG_LIST, {
                        data: data.data,
                        deployId: false
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_CAMERA_CONFIG_LIST', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_CAMERA_CONFIG_LIST', e)
                }
            })
        },
        [FETCH_CAMERA](context, deployId) {
            let url = `${context.getters[GET_SERVICES].Skylab}monitor/cameras?id=${deployId}`

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code,
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_CAMERA_CONFIG_LIST, {
                        data: data.data,
                        deployId: deployId
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_CAMERA', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_CAMERA', e)
                }
            })
        },
    }
}
