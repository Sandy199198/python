import { DEPLOYMENT } from 'common/namespace'
import Vue from 'vue'
import Immutable from 'immutable'
import { SET_ERROR, SET_GLOBAL_ALARM, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, preRequest, printError} from 'common/utils'

export const GET_DEPLOYMENT = `${DEPLOYMENT}/getDeployment`
export const SET_DEPLOYMENT = `${DEPLOYMENT}/setDeployment`
export const FETCH_DEPLOYMENT = `${DEPLOYMENT}/fetchDeployment`
export const SEARCH_DEPLOYMENT = `${DEPLOYMENT}/searchDeployment`
export const ADD_DEPLOYMENT = `${DEPLOYMENT}/addDeployment`
export const DEL_DEPLOYMENT = `${DEPLOYMENT}/delDeployment`
export const UPDATE_DEPLOYMENT = `${DEPLOYMENT}/updateDeployment`
export const SET_PAGE = `${DEPLOYMENT}/setPage`
export const GET_PAGE = `${DEPLOYMENT}/getPage`

export default {
    state: {
        deploymentList: [],
        deploymentPage: {},
    },
    getters: {
        [GET_DEPLOYMENT](state) {
            return state.deploymentList
        },
        [GET_PAGE](state) {
            return state.deploymentPage
        },
    },
    mutations: {
        [SET_DEPLOYMENT](state, data) {
            state.deploymentList = data
        },
        [SET_PAGE](state, data) {
            state.deploymentPage = Object.assign({}, data)
        },
        [ADD_DEPLOYMENT](state, data) {
            state.deploymentList.push(data)
        },
        [DEL_DEPLOYMENT](state, id) {
            for (let [i, a] of state.deploymentList.entries()) {
                if (a['id'] == id) {
                    state.deploymentList.splice(i, 1)
                    break
                }
            }
        },
        [UPDATE_DEPLOYMENT](state, data) {
            for (let [i, a] of state.deploymentList.entries()) {
                if (a.id == data.id) {
                    state.deploymentList.splice(i, 1, data)
                }
            }
        },
    },
    actions: {
        [FETCH_DEPLOYMENT](context, options) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}deployments/?size=20`

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_DEPLOYMENT, data.data)
                    context.commit(SET_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_DEPLOYMENT', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_DEPLOYMENT', e)
                }
            })
        },
        [SEARCH_DEPLOYMENT](context, options) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}deployments/?`
            let arr = []

            for (let i in options) {
                if (i == 'name' && options[i]) {
                    arr.push('name=' + options[i])
                } else if (i == 'page' && options[i]) {
                    arr.push('page=' + options[i] )
                }
            }
            arr.push('size=20')
            url += arr.join('&')
            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_DEPLOYMENT, data.data)
                    context.commit(SET_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('SEARCH_DEPLOYMENT', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SEARCH_DEPLOYMENT', e)
                }
            })
        },
        [ADD_DEPLOYMENT](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].CaptureMaster}deployments/`

            for (let key in options) {
                tmpObj[key] = options[key]
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'POST',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(ADD_DEPLOYMENT, data.data)
                        resolve()
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('ADD_DEPLOYMENT', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('ADD_DEPLOYMENT', e)
                }
            })
        },
        [UPDATE_DEPLOYMENT](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].CaptureMaster}deployments/` + options.id

            for (let key in options) {
                tmpObj[key] = options[key]
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'PUT',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(UPDATE_DEPLOYMENT, data.data)
                        resolve()
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('UPDATE_DEPLOYMENT', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('UPDATE_DEPLOYMENT', e)
                }
            })
        },
        [DEL_DEPLOYMENT](context, id) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}deployments/` + id

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'DELETE',
                        headers: {
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(DEL_DEPLOYMENT, id)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('DEL_DEPLOYMENT', e)
                        }
                    })
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('DEL_DEPLOYMENT', e)
                }
            })
        },
    }
}
