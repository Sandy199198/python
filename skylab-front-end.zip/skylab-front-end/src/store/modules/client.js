import { CLIENT_GROUP } from 'common/namespace'
import Vue from 'vue'
import Immutable from 'immutable'
import { SET_ERROR, SET_GLOBAL_ALARM, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, preRequest, printError} from 'common/utils'

export const GET_CLIENT_GROUP = `${CLIENT_GROUP}/getClientGroup`
export const SET_CLIENT_GROUP = `${CLIENT_GROUP}/setClientGroup`
export const FETCH_CLIENT_GROUP = `${CLIENT_GROUP}/fetchClientGroup`
export const SEARCH_CLIENT_GROUP = `${CLIENT_GROUP}/searchClientGroup`
export const ADD_CLIENT_GROUP = `${CLIENT_GROUP}/addClientGroup`
export const DEL_CLIENT_GROUP = `${CLIENT_GROUP}/delClientGroup`
export const UPDATE_CLIENT_GROUP = `${CLIENT_GROUP}/updateClientGroup`
export const SET_CLIENT_GROUP_PAGE = `${CLIENT_GROUP}/setClientGroupPage`
export const GET_CLIENT_GROUP_PAGE = `${CLIENT_GROUP}/getClientGroupPage`

export const GET_CLIENT = `${CLIENT_GROUP}/getClient`
export const SET_CLIENT = `${CLIENT_GROUP}/setClient`
export const FETCH_CLIENT = `${CLIENT_GROUP}/fetchClient`
export const SEARCH_CLIENT = `${CLIENT_GROUP}/searchClient`
export const DEL_CLIENT = `${CLIENT_GROUP}/delClient`
export const UPDATE_CLIENT = `${CLIENT_GROUP}/updateClient`
export const SET_CLIENT_PAGE = `${CLIENT_GROUP}/setClientPage`
export const GET_CLIENT_PAGE = `${CLIENT_GROUP}/getClientPage`

export default {
    state: {
        clientGroupList: [],
        clientGroupPage: {},
        clientList: [],
        clientPage: {},
    },
    getters: {
        [GET_CLIENT_GROUP](state) {
            return state.clientGroupList
        },
        [GET_CLIENT_GROUP_PAGE](state) {
            return state.clientGroupPage
        },
        [GET_CLIENT](state) {
            return state.clientList
        },
        [GET_CLIENT_PAGE](state) {
            return state.clientPage
        },
    },
    mutations: {
        [SET_CLIENT_GROUP](state, data) {
            state.clientGroupList = data
        },
        [SET_CLIENT_GROUP_PAGE](state, data) {
            state.clientGroupPage = Object.assign({}, data)
        },
        [ADD_CLIENT_GROUP](state, data) {
            state.clientGroupList.push(data)
        },
        [DEL_CLIENT_GROUP](state, id) {
            for (let [i, a] of state.clientGroupList.entries()) {
                if (a['id'] == id) {
                    state.clientGroupList.splice(i, 1)
                    break
                }
            }
        },
        [UPDATE_CLIENT_GROUP](state, data) {
            for (let [i, a] of state.clientGroupList.entries()) {
                if (a.id == data.id) {
                    state.clientGroupList.splice(i, 1, data)
                }
            }
        },
        [SET_CLIENT](state, data) {
            let clientData = []

            if (data.length) {
                for (let [i, client] of data.entries()) {
                    let cameras = []
                    let deployments = client.deployments

                    if (deployments.length) {
                        for (let deployment of deployments) {
                            if (deployment.cameras.length) {
                                for (let [i, camera] of deployment.cameras.entries()) {
                                    deployment.cameras[i]['deployment_name'] = deployment.name
                                    cameras.push(deployment.cameras[i])
                                }
                            }
                        }
                    }
                    data[i].cameras = cameras
                    clientData.push(data[i])
                }
            }
            state.clientList = clientData
        },
        [SET_CLIENT_PAGE](state, data) {
            state.clientPage = Object.assign({}, data)
        },
        [DEL_CLIENT](state, id) {
            for (let [i, a] of state.clientList.entries()) {
                if (a['id'] == id) {
                    state.clientList.splice(i, 1)
                    break
                }
            }
        },
        [UPDATE_CLIENT](state, data) {
            for (let [i, a] of state.clientList.entries()) {
                if (a.id == data.id) {
                    state.clientList.splice(i, 1, data)
                }
            }
        },
    },
    actions: {
        [FETCH_CLIENT_GROUP](context, options) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}client_groups/?size=20`

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_CLIENT_GROUP, data.data)
                    context.commit(SET_CLIENT_GROUP_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_CLIENT_GROUP', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_CLIENT_GROUP', e)
                }
            })
        },
        [SEARCH_CLIENT_GROUP](context, options) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}client_groups/?`
            let arr = []

            for (let i in options) {
                if (i == 'name' && options[i]) {
                    arr.push('name=' + options[i])
                } else if (i == 'page' && options[i]) {
                    arr.push('page=' + options[i] )
                }
            }
            arr.push('size=20')
            url += arr.join('&')
            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_CLIENT_GROUP, data.data)
                    context.commit(SET_CLIENT_GROUP_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('SEARCH_CLIENT_GROUP', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SEARCH_CLIENT_GROUP', e)
                }
            })
        },
        [ADD_CLIENT_GROUP](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].CaptureMaster}client_groups/`

            for (let key in options) {
                tmpObj[key] = options[key]
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'POST',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(ADD_CLIENT_GROUP, data.data)
                        resolve()
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('ADD_CLIENT_GROUP', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('ADD_CLIENT_GROUP', e)
                }
            })
        },
        [UPDATE_CLIENT_GROUP](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].CaptureMaster}client_groups/` + options.id

            for (let key in options) {
                tmpObj[key] = options[key]
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'PUT',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(UPDATE_CLIENT_GROUP, data.data)
                        resolve()
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('UPDATE_CLIENT_GROUP', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('UPDATE_CLIENT_GROUP', e)
                }
            })
        },
        [DEL_CLIENT_GROUP](context, id) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}client_groups/` + id

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'DELETE',
                        headers: {
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(DEL_CLIENT_GROUP, id)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('DEL_CLIENT_GROUP', e)
                        }
                    })
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('DEL_CLIENT_GROUP', e)
                }
            })
        },
        [FETCH_CLIENT](context, options) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}clients/?size=20`

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_CLIENT, data.data)
                    context.commit(SET_CLIENT_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_CLIENT', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_CLIENT', e)
                }
            })
        },
        [SEARCH_CLIENT](context, options) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}clients/?`
            let arr = []

            for (let i in options) {
                if (i == 'name' && options[i]) {
                    arr.push('name=' + options[i])
                } else if (i == 'page' && options[i]) {
                    arr.push('page=' + options[i] )
                }
            }
            arr.push('size=20')
            url += arr.join('&')
            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_CLIENT, data.data)
                    context.commit(SET_CLIENT_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('SEARCH_CLIENT', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SEARCH_CLIENT', e)
                }
            })
        },
        [UPDATE_CLIENT](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].CaptureMaster}clients/` + options.id

            for (let key in options) {
                tmpObj[key] = options[key]
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'PUT',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(UPDATE_CLIENT, data.data)
                        resolve()
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('UPDATE_CLIENT', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('UPDATE_CLIENT', e)
                }
            })
        },
        [DEL_CLIENT](context, id) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}clients/` + id

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'DELETE',
                        headers: {
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(DEL_CLIENT, id)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('DEL_CLIENT', e)
                        }
                    })
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('DEL_CLIENT', e)
                }
            })
        },
    }
}
