import { ALARM_HISTORY } from 'common/namespace'
import Vue from 'vue'
import { SET_ERROR, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, preRequest, printError} from 'common/utils'

export const GET_ALARM_HISTORY_LIST = `${ALARM_HISTORY}/getAlarmHistoryList`
export const SET_ALARM_HISTORY_LIST = `${ALARM_HISTORY}/setAlarmHistoryList`
export const FETCH_ALARM_HISTORY_LIST = `${ALARM_HISTORY}/fetchAlarmHistoryList`
export const DELETE_ALARM_HISTORY = `${ALARM_HISTORY}/deleteAlarmHistory`
export const MARKED_ALARM_HISTORY = `${ALARM_HISTORY}/markedAlarmHistory`
export const CLEAR_ALARM_HISTORY_LIST = `${ALARM_HISTORY}/clearAlarmHistoryList`
export const EXPORT_ALARM_HISTORY = `${ALARM_HISTORY}/exportAlarmHistory`
export const SET_EXPORT_ALARM_HISTORY = `${ALARM_HISTORY}/setExportAlarmHistory`
export const FETCH_EXPORT_ALARM_HISTORY_LIST = `${ALARM_HISTORY}/fetchExportAlarmHistoryList`
export const GET_EXPORT_ALARM_HISTORY_LIST = `${ALARM_HISTORY}/getExportAlarmHistoryList`
export const SET_EXPORT_ALARM_HISTORY_LIST = `${ALARM_HISTORY}/setExportAlarmHistoryList`
export const SET_PAGE = `${ALARM_HISTORY}/setPage`
export const GET_PAGE = `${ALARM_HISTORY}/getPage`

export default {
    state: {
        page: {},
        alarmHistoryData: [],
        exportHistoryData: []
    },
    getters: {
        [GET_ALARM_HISTORY_LIST](state) {
            return state.alarmHistoryData
        },
        [GET_PAGE](state) {
            return state.page
        },
        [GET_EXPORT_ALARM_HISTORY_LIST](state) {
            return state.exportHistoryData
        }
    },
    mutations: {
        [SET_ALARM_HISTORY_LIST](state, data) {
            state.alarmHistoryData = data
        },
        [SET_PAGE](state, page) {
            state.page = Object.assign({}, page)
        },
        [DELETE_ALARM_HISTORY](state, data) {
            for (let [i, a] of state.alarmHistoryData.entries()) {
                if (a.id == data.id) {
                    state.alarmHistoryData.splice(i, 1)
                    state.page.totalitems = state.page.totalitems - 1
                    break
                }
            }
        },
        [CLEAR_ALARM_HISTORY_LIST](state) {
            state.alarmHistoryData = []
        },
        [SET_EXPORT_ALARM_HISTORY](state, data) {
            state.exportHistoryData.unshift(data)
        },
        [SET_EXPORT_ALARM_HISTORY_LIST](state, data) {
            state.exportHistoryData = data
        }
    },
    actions: {
        [FETCH_ALARM_HISTORY_LIST](context, obj) {
            let params = []
            let url = `${context.getters[GET_SERVICES].Skylab}alarms/`

            for (let key in obj) {
                if (obj[key]) {
                    if (key == 'cameraName') {
                        params.push('camera_name' + '=' + obj[key])
                    } else if (key == 'startTime') {
                        params.push('start_time' + '=' + obj[key])
                    } else if (key == 'endTime') {
                        params.push('end_time' + '=' + obj[key])
                    } else if (key == 'certId') {
                        params.push('cert_id' + '=' + obj[key])
                    } else {
                        params.push(key + '=' + obj[key])
                    }
                }
            }
            params.push('size' + '=' + 10)
            params = params.join('&')
            if (params) {
                url += '?' + params
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(SET_ALARM_HISTORY_LIST, data.data)
                        context.commit(SET_PAGE, data.paging)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('FETCH_ALARM_HISTORY_LIST', e)
                        }
                    })
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_ALARM_HISTORY_LIST', e)
                }
            })
        },
        [DELETE_ALARM_HISTORY](context, alarm) {
            let id = alarm.id

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(`${context.getters[GET_SERVICES].Skylab}alarms/` + id, {
                        credentials: 'include',
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(DELETE_ALARM_HISTORY, alarm)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('DELETE_ALARM_HISTORY', e)
                        }
                    })
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('DELETE_ALARM_HISTORY', e)
                }
            })
        },
        [MARKED_ALARM_HISTORY](context, obj) {
            let alarm = {
                'mark_index': obj.markIndex
            }

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(`${context.getters[GET_SERVICES].Skylab}alarms/` + obj.id, {
                        credentials: 'include',
                        method: 'PUT',
                        body: JSON.stringify(alarm),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        //context.commit(MARKED_ALARM_HISTORY, obj)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('MARKED_ALARM_HISTORY', e)
                        }
                    })
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('MARKED_ALARM_HISTORY', e)
                }
            })
        },
        [EXPORT_ALARM_HISTORY](context, obj) {
            let params = {}
            let url = `${context.getters[GET_SERVICES].Skylab}exports/`

            for (let key in obj) {
                if (obj[key]) {
                    if (key == 'cameraName') {
                        params['camera_name'] = obj[key]
                    } else if (key == 'startTime') {
                        params['start_time'] = obj[key]
                    } else if (key == 'endTime') {
                        params['end_time'] = obj[key]
                    } else if (key == 'certId') {
                        params['cert_id'] = obj[key]
                    } else {
                        params[key] = obj[key]
                    }
                }
            }
            params['type'] = 0
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'POST',
                        body: JSON.stringify(params),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(SET_EXPORT_ALARM_HISTORY, data.data)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('EXPORT_ALARM_HISTORY', e)
                        }
                    })
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('EXPORT_ALARM_HISTORY', e)
                }
            })
        },
        [FETCH_EXPORT_ALARM_HISTORY_LIST](context) {
            let url = `${context.getters[GET_SERVICES].Skylab}exports/?type=0&size=100`

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        headers: {
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(SET_EXPORT_ALARM_HISTORY_LIST, data.data)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('FETCH_EXPORT_ALARM_HISTORY_LIST', e)
                        }
                    })
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_EXPORT_ALARM_HISTORY_LIST', e)
                }
            })
        }
    }
}
