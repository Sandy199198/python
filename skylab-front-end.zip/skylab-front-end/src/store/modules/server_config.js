import { SERVER_CONFIG } from 'common/namespace'
import Vue from 'vue'
import Immutable from 'immutable'
import { SET_ERROR, SET_GLOBAL_ALARM, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, preRequest, printError} from 'common/utils'

export const GET_CAPTURE_CORE = `${SERVER_CONFIG}/getCaptureCore`
export const SET_CAPTURE_CORE = `${SERVER_CONFIG}/setCaptureCore`
export const FETCH_CAPTURE_CORE = `${SERVER_CONFIG}/fetchCaptureCore`
export const SEARCH_CAPTURE_CORE = `${SERVER_CONFIG}/searchCaptureCore`
export const ADD_CAPTURE_CORE = `${SERVER_CONFIG}/addCaptureCore`
export const DEL_CAPTURE_CORE = `${SERVER_CONFIG}/delCaptureCore`
export const UPDATE_CAPTURE_CORE = `${SERVER_CONFIG}/updateCaptureCore`
export const SET_CAPTURE_PAGE = `${SERVER_CONFIG}/setCapturePage`
export const GET_CAPTURE_PAGE = `${SERVER_CONFIG}/getCapturePage`

export const GET_MEDIA_CORE = `${SERVER_CONFIG}/getMediaCore`
export const SET_MEDIA_CORE = `${SERVER_CONFIG}/setMediaCore`
export const FETCH_MEDIA_CORE = `${SERVER_CONFIG}/fetchMediaCore`
export const SEARCH_MEDIA_CORE = `${SERVER_CONFIG}/searchMediaCore`
export const ADD_MEDIA_CORE = `${SERVER_CONFIG}/addMediaCore`
export const DEL_MEDIA_CORE = `${SERVER_CONFIG}/delMediaCore`
export const UPDATE_MEDIA_CORE = `${SERVER_CONFIG}/updateMediaCore`
export const SET_MEDIA_PAGE = `${SERVER_CONFIG}/setMediaPage`
export const GET_MEDIA_PAGE = `${SERVER_CONFIG}/getMediaPage`

export const GET_STORAGE_CORE = `${SERVER_CONFIG}/getStorageCore`
export const SET_STORAGE_CORE = `${SERVER_CONFIG}/setStorageCore`
export const FETCH_STORAGE_CORE = `${SERVER_CONFIG}/fetchStorageCore`
export const SEARCH_STORAGE_CORE = `${SERVER_CONFIG}/searchStorageCore`
export const ADD_STORAGE_CORE = `${SERVER_CONFIG}/addStorageCore`
export const DEL_STORAGE_CORE = `${SERVER_CONFIG}/delStorageCore`
export const UPDATE_STORAGE_CORE = `${SERVER_CONFIG}/updateStorageCore`
export const SET_STORAGE_PAGE = `${SERVER_CONFIG}/setStoragePage`
export const GET_STORAGE_PAGE = `${SERVER_CONFIG}/getStoragePage`

export default {
    state: {
        coreCaptureList: [],
        capturePage: {},
        coreMediaList: [],
        mediaPage: {},
        coreStorageList: [],
        storagePage: {},
    },
    getters: {
        [GET_CAPTURE_CORE](state) {
            return state.coreCaptureList
        },
        [GET_CAPTURE_PAGE](state) {
            return state.capturePage
        },
        [GET_MEDIA_CORE](state) {
            return state.coreMediaList
        },
        [GET_MEDIA_PAGE](state) {
            return state.mediaPage
        },
        [GET_STORAGE_CORE](state) {
            return state.coreStorageList
        },
        [GET_STORAGE_PAGE](state) {
            return state.storagePage
        }
    },
    mutations: {
        [SET_CAPTURE_CORE](state, data) {
            state.coreCaptureList = data
        },
        [SET_CAPTURE_PAGE](state, data) {
            state.capturePage = Object.assign({}, data)
        },
        [ADD_CAPTURE_CORE](state, data) {
            state.coreCaptureList.push(data)
        },
        [DEL_CAPTURE_CORE](state, id) {
            for (let [i, a] of state.coreCaptureList.entries()) {
                if (a['id'] == id) {
                    state.coreCaptureList.splice(i, 1)
                    break
                }
            }
        },
        [UPDATE_CAPTURE_CORE](state, data) {
            for (let [i, a] of state.coreCaptureList.entries()) {
                if (a.id == data.id) {
                    state.coreCaptureList.splice(i, 1, data)
                }
            }
        },
        [SET_MEDIA_CORE](state, data) {
            state.coreMediaList = data
        },
        [SET_MEDIA_PAGE](state, data) {
            state.mediaPage = Object.assign({}, data)
        },
        [ADD_MEDIA_CORE](state, data) {
            state.coreMediaList.push(data)
        },
        [DEL_MEDIA_CORE](state, id) {
            for (let [i, a] of state.coreMediaList.entries()) {
                if (a['id'] == id) {
                    state.coreMediaList.splice(i, 1)
                    break
                }
            }
        },
        [UPDATE_MEDIA_CORE](state, data) {
            for (let [i, a] of state.coreMediaList.entries()) {
                if (a.id == data.id) {
                    state.coreMediaList.splice(i, 1, data)
                }
            }
        },
        [SET_STORAGE_CORE](state, data) {
            state.coreStorageList = data
        },
        [SET_STORAGE_PAGE](state, data) {
            state.storagePage = Object.assign({}, data)
        },
        [ADD_STORAGE_CORE](state, data) {
            state.coreStorageList.push(data)
        },
        [DEL_STORAGE_CORE](state, id) {
            for (let [i, a] of state.coreStorageList.entries()) {
                if (a['id'] == id) {
                    state.coreStorageList.splice(i, 1)
                    break
                }
            }
        },
        [UPDATE_STORAGE_CORE](state, data) {
            for (let [i, a] of state.coreStorageList.entries()) {
                if (a.id == data.id) {
                    state.coreStorageList.splice(i, 1, data)
                }
            }
        }
    },
    actions: {
        [FETCH_CAPTURE_CORE](context, options) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/capture-cores/?size=20`

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_CAPTURE_CORE, data.data)
                    context.commit(SET_CAPTURE_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_CAPTURE_CORE', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_CAPTURE_CORE', e)
                }
            })
        },
        [SEARCH_CAPTURE_CORE](context, options) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/capture-cores/?`
            let arr = []

            for (let i in options) {
                if (i == 'name' && options[i]) {
                    arr.push('name=' + options[i])
                } else if (i == 'page' && options[i]) {
                    arr.push('page=' + options[i] )
                }
            }
            arr.push('size=20')
            url += arr.join('&')
            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_CAPTURE_CORE, data.data)
                    context.commit(SET_CAPTURE_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('SEARCH_CAPTURE_CORE', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SEARCH_CAPTURE_CORE', e)
                }
            })
        },
        [ADD_CAPTURE_CORE](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/capture-cores/`

            for (let key in options) {
                tmpObj[key] = options[key]
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'POST',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(ADD_CAPTURE_CORE, data.data)
                        resolve()
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('ADD_CAPTURE_CORE', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('ADD_CAPTURE_CORE', e)
                }
            })
        },
        [UPDATE_CAPTURE_CORE](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/capture-cores/` + options.id

            for (let key in options) {
                tmpObj[key] = options[key]
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'PUT',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(UPDATE_CAPTURE_CORE, data.data)
                        resolve()
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('UPDATE_CAPTURE_CORE', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('UPDATE_CAPTURE_CORE', e)
                }
            })
        },
        [DEL_CAPTURE_CORE](context, id) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/capture-cores/` + id

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'DELETE',
                        headers: {
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(DEL_CAPTURE_CORE, id)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('DEL_CAPTURE_CORE', e)
                        }
                    })
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('DEL_CAPTURE_CORE', e)
                }
            })
        },
        [FETCH_MEDIA_CORE](context, options) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/media-servers/?size=20`

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_MEDIA_CORE, data.data)
                    context.commit(SET_MEDIA_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_MEDIA_CORE', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_MEDIA_CORE', e)
                }
            })
        },
        [SEARCH_MEDIA_CORE](context, options) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/media-servers/?`
            let arr = []

            for (let i in options) {
                if (i == 'name' && options[i]) {
                    arr.push('name=' + options[i])
                } else if (i == 'page' && options[i]) {
                    arr.push('page=' + options[i] )
                }
            }
            arr.push('size=20')
            url += arr.join('&')
            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_MEDIA_CORE, data.data)
                    context.commit(SET_MEDIA_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('SEARCH_MEDIA_CORE', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SEARCH_MEDIA_CORE', e)
                }
            })
        },
        [ADD_MEDIA_CORE](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/media-servers/`

            for (let key in options) {
                tmpObj[key] = options[key]
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'POST',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(ADD_MEDIA_CORE, data.data)
                        resolve()
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('ADD_MEDIA_CORE', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('ADD_MEDIA_CORE', e)
                }
            })
        },
        [UPDATE_MEDIA_CORE](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/media-servers/` + options.id

            for (let key in options) {
                tmpObj[key] = options[key]
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'PUT',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(UPDATE_MEDIA_CORE, data.data)
                        resolve()
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('UPDATE_MEDIA_CORE', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('UPDATE_MEDIA_CORE', e)
                }
            })
        },
        [DEL_MEDIA_CORE](context, id) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/media-servers/` + id

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'DELETE',
                        headers: {
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(DEL_MEDIA_CORE, id)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('DEL_MEDIA_CORE', e)
                        }
                    })
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('DEL_MEDIA_CORE', e)
                }
            })
        },
        [FETCH_STORAGE_CORE](context, options) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/storage-servers/?size=20`

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_STORAGE_CORE, data.data)
                    context.commit(SET_STORAGE_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_STORAGE_CORE', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_STORAGE_CORE', e)
                }
            })
        },
        [SEARCH_STORAGE_CORE](context, options) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/storage-servers/?`
            let arr = []

            for (let i in options) {
                if (i == 'name' && options[i]) {
                    arr.push('name=' + options[i])
                } else if (i == 'page' && options[i]) {
                    arr.push('page=' + options[i] )
                }
            }
            arr.push('size=20')
            url += arr.join('&')
            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'User-Access-Token': code
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_STORAGE_CORE, data.data)
                    context.commit(SET_STORAGE_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('SEARCH_STORAGE_CORE', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SEARCH_STORAGE_CORE', e)
                }
            })
        },
        [ADD_STORAGE_CORE](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/storage-servers/`

            for (let key in options) {
                tmpObj[key] = options[key]
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'POST',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(ADD_STORAGE_CORE, data.data)
                        resolve()
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('ADD_STORAGE_CORE', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('ADD_STORAGE_CORE', e)
                }
            })
        },
        [UPDATE_STORAGE_CORE](context, options) {
            let tmpObj = {}
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/storage-servers/` + options.id

            for (let key in options) {
                tmpObj[key] = options[key]
            }
            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'PUT',
                        body: JSON.stringify(tmpObj),
                        headers: {
                            'Content-Type': 'application/json',
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(UPDATE_STORAGE_CORE, data.data)
                        resolve()
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('UPDATE_STORAGE_CORE', e)
                    }
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('UPDATE_STORAGE_CORE', e)
                }
            })
        },
        [DEL_STORAGE_CORE](context, id) {
            let url = `${context.getters[GET_SERVICES].CaptureMaster}service/storage-servers/` + id

            return new Promise((resolve, reject) => {
                preRequest(context).then(code => {
                    fetch(url, {
                        credentials: 'include',
                        method: 'DELETE',
                        headers: {
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return analyzeHttpCode(res)
                    }).then(data => {
                        context.commit(DEL_STORAGE_CORE, id)
                        resolve()
                    }).catch(e => {
                        if (e.type) {
                            context.commit(SET_ERROR, e.message)
                        } else {
                            printError('DEL_STORAGE_CORE', e)
                        }
                    })
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('DEL_STORAGE_CORE', e)
                }
            })
        },
    }
}
