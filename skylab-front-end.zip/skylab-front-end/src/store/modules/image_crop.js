import { IMAGE_CROP } from 'common/namespace'
import Vue from 'vue'
import { SET_ERROR, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, preRequest, printError} from 'common/utils'

export const GET_IMAGE_CROP_LIST = `${IMAGE_CROP}/getImageCropList`
export const SET_IMAGE_CROP_LIST = `${IMAGE_CROP}/setImageCropList`
export const FETCH_IMAGE_CROP_LIST = `${IMAGE_CROP}/fetchImageCropList`
export const MARK_IMAGE_CROP = `${IMAGE_CROP}/markImageCrop`
export const SET_PAGE = `${IMAGE_CROP}/setPage`
export const GET_PAGE = `${IMAGE_CROP}/getPage`
export const CLEAR_IMAGE_CROP_LIST = `${IMAGE_CROP}/clearImageCropList`

export const GET_IMAGE_CROP_PREVIEW = `${IMAGE_CROP}/getImageCropPreview`
export const SET_IMAGE_CROP_PREVIEW = `${IMAGE_CROP}/setImageCropPreview`
export const CLEAR_IMAGE_CROP_PREVIEW = `${IMAGE_CROP}/clearImageCropPreview`
export const PUT_IMAGE_CROP_PREVIEW = `${IMAGE_CROP}/putImageCropPreview`

export const GET_IMAGE_CROP_RESULT = `${IMAGE_CROP}/getImageCropResult`
export const SET_IMAGE_CROP_RESULT = `${IMAGE_CROP}/setImageCropResult`
export const FETCH_IMAGE_CROP_RESULT = `${IMAGE_CROP}/fetchImageCropResult`
export const SET_RESULT_PAGE = `${IMAGE_CROP}/setResultPage`
export const GET_RESULT_PAGE = `${IMAGE_CROP}/getResultPage`
export const CLEAR_IMAGE_CROP_RESULT = `${IMAGE_CROP}/clearImageCropResult`
export const DEL_IMAGE_CROP_RESULT = `${IMAGE_CROP}/delImageCropResult`

export default {
    state: {
        page: {},
        imageCropData: [],
        resultPage: {},
        imageCropResult: [],
        imagePreview: []
    },
    getters: {
        [GET_IMAGE_CROP_LIST](state) {
            return state.imageCropData
        },
        [GET_PAGE](state) {
            return state.page
        },
        [GET_IMAGE_CROP_RESULT](state) {
            return state.imageCropResult
        },
        [GET_RESULT_PAGE](state) {
            return state.resultPage
        },
        [GET_IMAGE_CROP_PREVIEW](state) {
            return state.imagePreview
        }
    },
    mutations: {
        [SET_IMAGE_CROP_LIST](state, data) {
            state.imageCropData = data
        },
        [SET_PAGE](state, page) {
            state.page = Object.assign({}, page)
        },
        [MARK_IMAGE_CROP](state, data) {
        },
        [CLEAR_IMAGE_CROP_LIST](state) {
            state.imageCropData = []
        },
        [SET_IMAGE_CROP_RESULT](state, data) {
            state.imageCropResult = data
        },
        [SET_RESULT_PAGE](state, page) {
            state.resultPage = Object.assign({}, page)
        },
        [CLEAR_IMAGE_CROP_RESULT](state) {
            state.imageCropResult = []
        },
        [SET_IMAGE_CROP_PREVIEW](state, data) {
            state.imagePreview = data
        },
        [CLEAR_IMAGE_CROP_PREVIEW](state) {
            state.imagePreview = []
        }
    },
    actions: {
        [FETCH_IMAGE_CROP_LIST](context, obj) {
            let params = []
            let url = `http://192.168.0.10:10100/mark-imgs/`

            for (let key in obj) {
                params.push(key + '=' + obj[key])
            }
            params.push('size' + '=' + 1)
            params = params.join('&')
            if (params) {
                url += '?' + params
            }
            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_IMAGE_CROP_LIST, data.data)
                    context.commit(SET_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_IMAGE_CROP_LIST', e)
                    }
                })
            })
        },
        [MARK_IMAGE_CROP](context, obj) {
            let {markData, id} = obj
            let url = `http://192.168.0.10:10100/mark-action/` + id

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'PUT',
                    body: JSON.stringify({
                        'mark_data': markData
                    }),
                    headers: {
                        'Content-Type': 'application/json',
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    // console.log('111111')
                    // context.commit(SET_IMAGE_CROP_LIST, data.data)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('MARK_IMAGE_CROP', e)
                    }
                })
            })
        },
        [PUT_IMAGE_CROP_PREVIEW](context, obj) {
            let url = `http://192.168.0.10:10100/mark-action/`

            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    method: 'POST',
                    body: JSON.stringify({
                        'mark_data': obj
                    }),
                    headers: {
                        'Content-Type': 'application/json',
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_IMAGE_CROP_PREVIEW, data.data)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('PUT_IMAGE_CROP_PREVIEW', e)
                    }
                })
            })
        },
        [FETCH_IMAGE_CROP_RESULT](context, obj) {
            let params = []
            let url = `http://192.168.0.10:10100/mark-action/`

            for (let key in obj) {
                params.push(key + '=' + obj[key])
            }
            params.push('size' + '=' + 20)
            params.push('has_confirm' + '=' + true)
            params = params.join('&')
            if (params) {
                url += '?' + params
            }
            preRequest(context).then(code => {
                fetch(url, {
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json',
                    }
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_IMAGE_CROP_RESULT, data.data)
                    context.commit(SET_RESULT_PAGE, data.paging)
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_IMAGE_CROP_RESULT', e)
                    }
                })
            })
        },
        [DEL_IMAGE_CROP_RESULT](context, id) {
            fetch(`http://192.168.0.10:10100/mark-results/` + id, {
                credentials: 'include',
                method: 'DELETE',
            }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                // context.commit(DELETE_IMAGE_FILTER, name)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('DELETE_IMAGE_FILTER', e)
                }
            })
        },
    }
}
