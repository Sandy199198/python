import { BRANCH_STATISTICS } from 'common/namespace'
import Vue from 'vue'
import Immutable from 'immutable'
import { SET_ERROR, GET_PROMETHEUS_QUERY, GET_PROMETHEUS_QUERY_RANGE } from 'store/modules/common'
import { splitTime, supplement, analyzeHttpCode, convertToSecond, convertToSeconds, printError} from 'common/utils'
import { GET_BRANCH_ID_MAP } from 'store/modules/citywide_info'

export const GET_CAPTURE_COUNT = `${BRANCH_STATISTICS}/getCaptureCount`
export const SET_CAPTURE_COUNT = `${BRANCH_STATISTICS}/setCaptureCount`
export const FETCH_CAPTURE_COUNT = `${BRANCH_STATISTICS}/fetchCaptureCount`

export const GET_ALARM_COUNT = `${BRANCH_STATISTICS}/getAlarmCount`
export const SET_ALARM_COUNT = `${BRANCH_STATISTICS}/setAlarmCount`
export const FETCH_ALARM_COUNT = `${BRANCH_STATISTICS}/fetchAlarmCount`

export const GET_MARKED_ALARM_COUNT = `${BRANCH_STATISTICS}/getMarkedAlarmCount`
export const SET_MARKED_ALARM_COUNT = `${BRANCH_STATISTICS}/setMarkedAlarmCount`
export const FETCH_MARKED_ALARM_COUNT = `${BRANCH_STATISTICS}/fetchMarkedAlarmCount`

export const GET_BRANCH_DATA = `${BRANCH_STATISTICS}/getChartData`
export const SET_BRANCH_DATA = `${BRANCH_STATISTICS}/setChartData`
export const FETCH_BRANCH_DATA = `${BRANCH_STATISTICS}/fetchChartData`
export const CLEAR_BRANCH_DATA = `${BRANCH_STATISTICS}/clearBranchData`

export const GET_ALL_BRANCHES_INTERVAL_ALARM = `${BRANCH_STATISTICS}/getAllBranchesIntervalAlarm`
export const SET_ALL_BRANCHES_INTERVAL_ALARM = `${BRANCH_STATISTICS}/setAllBranchesIntervalAlarm`
export const FETCH_ALL_BRANCHES_INTERVAL_ALARM = `${BRANCH_STATISTICS}/fetchAllBranchesIntervalAlarm`

export const GET_ALL_BRANCHES_TODAY_COLUMN = `${BRANCH_STATISTICS}/getAllBranchesTodayColumn`
export const GET_ALL_BRANCHES_TODAY_DATA = `${BRANCH_STATISTICS}/getAllBranchesTodayData`
export const SET_ALL_BRANCHES_TODAY_DATA = `${BRANCH_STATISTICS}/setAllBranchesTodayData`
export const FETCH_ALL_BRANCHES_TODAY_DATA = `${BRANCH_STATISTICS}/fetchAllBranchesTodayData`

export const GET_BRANCHES_PERIOD_DATA = `${BRANCH_STATISTICS}/getBranchesPeriodData`
export const SET_BRANCHES_PERIOD_DATA = `${BRANCH_STATISTICS}/setBranchesPeriodData`
export const FETCH_BRANCHES_PERIOD_DATA = `${BRANCH_STATISTICS}/fetchBranchesPeriodData`

export const FETCH_CAMERAS_INTERVAL_DATA = `${BRANCH_STATISTICS}/fetchCamerasData`
export const FETCH_CAMERAS_PERIOD_DATA = `${BRANCH_STATISTICS}/fetchCamerasPeriodData`
export const FETCH_ALL_CAMERAS_TODAY_DATA = `${BRANCH_STATISTICS}/fetchAllCamerasTodayData`




export const TYPE_CAPTURES = 'capture_count'
export const TYPE_ALARMS = 'alarm_count'
export const TYPE_MARKED_ALARMS = 'confirmed_alarm_count'
export function getTypeString(type) {
    switch (type) {
        case TYPE_CAPTURES:
            return '抓拍'
        case TYPE_ALARMS:
            return '告警'
        case TYPE_MARKED_ALARMS:
            return '确认告警'
    }
}


let branchDataTemplate = {
    name: 'branch',
    chart: {
        type: 'column',
        options3d: {
            enabled: true,
            alpha: 15,
            beta: 15,
            viewDistance: 55,
            depth: 80
        }
    },

    title: {
        text: '各分局信息统计'
    },

    xAxis: {
        categories: []
    },

    yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
            text: '人次'
        }
    },

    tooltip: {
        headerFormat: '<b>{point.key}</b><br>',
        pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.name}: {point.y}'
    },

    series: []
}

let branchIntervalDataTemplate = Object.assign({}, branchDataTemplate, {
    title: {
        text: '各分局告警统计'
    },

    tooltip: {
        headerFormat: '<b>当前时间 {point.key}</b><br>',
        pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.name}: {point.y}'
    }
})

let branchPeriodDataTemplate = {
    title: {
        text: '各分局告警统计',
    },
    xAxis: {
        categories: []
    },
    yAxis: {
        title: {
            text: '人次'
        },
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle',
        borderWidth: 0
    },
    series: []
}


export default {
    state: {
        captureCount: 0,
        alarmCount: 0,
        markedAlarmCount: 0,
        branchData: Immutable.fromJS(branchDataTemplate),
        branchIntervalData: Immutable.fromJS(branchIntervalDataTemplate),
        branchTableColumn: [],
        branchTableData: [],
        branchPeriodData: Immutable.fromJS(branchPeriodDataTemplate)
    },
    getters: {
        [GET_CAPTURE_COUNT](state) {
            return state.captureCount
        },
        [GET_ALARM_COUNT](state) {
            return state.alarmCount
        },
        [GET_MARKED_ALARM_COUNT](state) {
            return state.markedAlarmCount
        },
        [GET_BRANCH_DATA](state) {
            return state.branchData.toJS()
        },
        [GET_ALL_BRANCHES_INTERVAL_ALARM](state) {
            return state.branchIntervalData.toJS()
        },
        [GET_ALL_BRANCHES_TODAY_COLUMN](state) {
            return state.branchTableColumn
        },
        [GET_ALL_BRANCHES_TODAY_DATA](state) {
            return state.branchTableData
        },
        [GET_BRANCHES_PERIOD_DATA](state) {
            return state.branchPeriodData.toJS()
        }
    },
    mutations: {

        [SET_CAPTURE_COUNT](state, count) {
            if (count > state.captureCount) {
                state.captureCount = count
            }
        },

        [SET_ALARM_COUNT](state, count) {
            if (count > state.alarmCount) {
                state.alarmCount = count
            }
        },

        [SET_MARKED_ALARM_COUNT](state, count) {
            if (count > state.markedAlarmCount) {
                state.markedAlarmCount = count
            }
        },

        [SET_BRANCH_DATA](state, wrapperData) {
            let {data, map} = wrapperData
            let series = []
            let categories = []
            let seriesNames = ['抓拍数', '告警数', '确认告警数']
            let sequence = {}

            for (let [index, r] of data[0].data.result.entries()) {
                categories.push(map[r.metric.user_group])
                sequence[r.metric.user_group] = index
            }

            for (let [index, dataType] of data.entries()) {
                let seriesData = []
                let name = seriesNames[index]

                for (let r of dataType.data.result) {
                    seriesData[sequence[r.metric.user_group]] = +r.value[1]
                }

                series.push({
                    name,
                    data: seriesData
                })
            }

            // TODO: 临时方案，去除没有匹配到的分局 start
            let temporaryCategories = []
            let temporarySeries = series.concat()
            let correctionIndex = 0

            for (let [index, d] of categories.entries()) {
                if (d != undefined) {
                    temporaryCategories.push(d)
                } else {
                    for (let s of temporarySeries) {
                        s.data.splice(index - correctionIndex, 1)
                    }
                    correctionIndex++
                }
            }

            //end

            state.branchData = state.branchData.mergeDeep({
                xAxis: {
                    categories: temporaryCategories
                },
                series: temporarySeries
            })
        },

        [CLEAR_BRANCH_DATA](state) {
            state.branchData = Immutable.fromJS(branchDataTemplate)
        },

        [SET_ALL_BRANCHES_INTERVAL_ALARM](state, wrapperData) {
            let series = []
            let {isBranch, type, title, number, data, categories } = wrapperData
            let branchIntervalData = state.branchIntervalData

            for (let d of data) {
                let seriesData = {
                    name: isBranch ? d.metric.camera : d.metric.user_group,
                    data: d.values.map(v => +v[1])
                }

                if (seriesData.data.length < number) {
                    seriesData.data = supplement(seriesData.data, number)
                }
                series.push(seriesData)
            }

            state.branchIntervalData = branchIntervalData.setIn(['title', 'text'], title).setIn(['xAxis', 'categories'], categories).setIn(['series'], series)
        },

        [SET_ALL_BRANCHES_TODAY_DATA](state, wrapperData) {
            let {isBranch,  data, type } = wrapperData
            let columns = isBranch ? [{
                title: '摄像头',
                prop: 'type',
                width: '40%'
            }, {
                title: `今日${getTypeString(type)}总数`,
                prop: 'count',
                width: '40%'
            }, {
                title: '操作',
                type: 'events'
            }] : [{
                title: '分局',
                prop: 'type',
                width: '40%'
            }, {
                title: `今日${getTypeString(type)}总数`,
                prop: 'count',
                width: '40%'
            }, {
                title: '操作',
                type: 'events'
            }]
            let tableData = []

            for (let d of data.result) {
                tableData.push({
                    type: isBranch ? d.metric.camera : d.metric.user_group,
                    count: d.value[1]
                })
            }

            state.branchTableColumn = columns
            state.branchTableData = tableData
        },

        [SET_BRANCHES_PERIOD_DATA](state, wrapperData) {
            let { isBranch, title, type, data, categories, number } = wrapperData
            let branchPeriodData = state.branchPeriodData
            let series = []

            for (let d of data.result) {
                let seriesData = {
                    name: isBranch ? d.metric.camera : d.metric.user_group,
                    data: d.values.map(v => +v[1])
                }

                if (seriesData.data.length < number) {
                    seriesData.data = supplement(seriesData.data, number)
                }
                series.push(seriesData)
            }

            state.branchPeriodData = branchPeriodData.setIn(['title', 'text'], title).setIn(['xAxis', 'categories'], categories).set('series', series)
        }
    },
    actions: {

        [FETCH_CAPTURE_COUNT](context) {
            let now = new Date()
            let deltaTimestamp = convertToSeconds(now) - convertToSeconds(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0))

            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=round(sum(increase(capture_count[${deltaTimestamp}s])))`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(SET_CAPTURE_COUNT, data.result[0].value[1])
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_CAPTURE_COUNT', e)
                }
            })
        },

        [FETCH_ALARM_COUNT](context) {
            let now = new Date()
            let deltaTimestamp = convertToSeconds(now) - convertToSeconds(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0))

            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=round(sum(increase(alarm_count[${deltaTimestamp}s])))`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(SET_ALARM_COUNT, data.result[0].value[1])
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_ALARM_COUNT', e)
                }
            })
        },

        [FETCH_MARKED_ALARM_COUNT](context) {
            let now = new Date()
            let deltaTimestamp = convertToSeconds(now) - convertToSeconds(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0))

            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=round(sum(increase(confirmed_alarm_count[${deltaTimestamp}s])))`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(SET_MARKED_ALARM_COUNT, data.result[0].value[1])
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_MARKED_ALARM_COUNT', e)
                }
            })
        },

        [FETCH_BRANCH_DATA](context) {
            let now = new Date()
            let deltaTimestamp = convertToSeconds(now) - convertToSeconds(new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0))

            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=topk(5,sort_desc(round(sum(increase(capture_count[${deltaTimestamp}s]))+by+(user_group))))`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                if (data.status == 'success') {
                    if (data.data.result.length) {
                        let list = []

                        for (let d of data.data.result) {
                            list.push(d.metric.user_group)
                        }
                        return Promise.resolve(list)
                    }
                } else {
                    return Promise.reject()
                }
            }).then(branchParams => {
                return Promise.all([fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=topk(5,sort_desc(round(sum(increase(capture_count{user_group=~"${branchParams.join('|')}"}[${deltaTimestamp}s]))+by+(user_group))))`),
                    fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=topk(5,sort_desc(round(sum(increase(alarm_count{user_group=~"${branchParams.join('|')}"}[${deltaTimestamp}s]))+by+(user_group))))`),
                    fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=topk(5,sort_desc(round(sum(increase(confirmed_alarm_count{user_group=~"${branchParams.join('|')}"}[${deltaTimestamp}s]))+by+(user_group))))`)
                ])
            }).then((res) => {
                return Promise.all([analyzeHttpCode(res[0]), analyzeHttpCode(res[1]), analyzeHttpCode(res[2])])
            }).then(([captureData, alarmData, markedAlarmData]) => {
                return new Promise((resolve, reject) => {
                    if (captureData.status == 'success' && alarmData.status == 'success' && markedAlarmData.status == 'success') {
                        resolve([captureData, alarmData, markedAlarmData])
                    } else {
                        reject()
                    }
                })
            }).then((data) => {
                context.commit(SET_BRANCH_DATA, {
                    data,
                    map: context.getters[GET_BRANCH_ID_MAP]
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_BRANCH_DATA', e)
                }
            })
        },

        [FETCH_ALL_BRANCHES_INTERVAL_ALARM](context, {
            start,
            end,
            type
        } = {}) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(${type}[2h]))+by+(user_group))&start=${start}&end=${end}&step=2h`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(SET_ALL_BRANCHES_INTERVAL_ALARM, {
                        type,
                        title: `各分局${getTypeString(type)}统计`,
                        number: 13,
                        categories: splitTime({
                            start,
                            // 服务端会返回13个点,所以切割时间加一小时
                            end: end + 2 * 60 * 60,
                            interval: 2 * 60 * 60,
                            format: 'h:m'
                        }),
                        data: data.result
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_ALL_BRANCHES_INTERVAL_ALARM', e)
                }
            })
        },

        [FETCH_CAMERAS_INTERVAL_DATA](context, {
            branch,
            start,
            end,
            type
        }) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(increase(${type}{user_group="${branch}"}[2h]))&start=${start}&end=${end}&step=2h`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(SET_ALL_BRANCHES_INTERVAL_ALARM, {
                        isBranch: true,
                        type,
                        title: `各抓拍点${getTypeString(type)}统计`,
                        number: 13,
                        categories: splitTime({
                            start,
                            // 服务端会返回13个点,所以切割时间加一小时
                            end: end + 2 * 60 * 60,
                            interval: 2 * 60 * 60,
                            format: 'h:m'
                        }),
                        data: data.result
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_CAMERAS_INTERVAL_DATA', e)
                }
            })
        },


        [FETCH_ALL_BRANCHES_TODAY_DATA](context, type) {
            let todayType = ''

            let deltaTimestamp = 80000

            switch (type) {
                case TYPE_CAPTURES:
                    todayType = 'capture_count'
                    break
                case TYPE_ALARMS:
                    todayType = 'alarm_count'
                    break
                case TYPE_MARKED_ALARMS:
                    todayType = 'confirmed_alarm_count'
                    break
            }

            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=round(inrease(${todayType}[${deltaTimestamp}s]))`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(SET_ALL_BRANCHES_TODAY_DATA, {
                        type,
                        data
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_ALL_BRANCHES_TODAY_DATA', e)
                }
            })
        },

        [FETCH_ALL_CAMERAS_TODAY_DATA](context, {
            type,
            branch
        }) {
            let todayType = ''

            let deltaTimestamp = 80000

            switch (type) {
                case TYPE_CAPTURES:
                    todayType = 'capture_count'
                    break
                case TYPE_ALARMS:
                    todayType = 'alarm_count'
                    break
                case TYPE_MARKED_ALARMS:
                    todayType = 'confirmed_alarm_count'
                    break
            }

            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=sort_desc(round(increase(${todayType}{user_group="${branch}"}[${deltaTimestamp}s])))`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(SET_ALL_BRANCHES_TODAY_DATA, {
                        isBranch: true,
                        type,
                        data
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_ALL_CAMERAS_TODAY_DATA', e)
                }
            })
        },

        [FETCH_BRANCHES_PERIOD_DATA](context, {
            start,
            end,
            number,
            type
        }) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(sum(increase(${type}[24h]))+by+(user_group))&start=${start}&end=${end}&step=24h`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(SET_BRANCHES_PERIOD_DATA, {
                        title: `各抓拍点${getTypeString(type)}统计`,
                        type,
                        data,
                        number,
                        categories: splitTime({
                            start,
                            end,
                            interval: 60 * 60 * 24,
                            format: 'M月D日'
                        }),
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_BRANCHES_PERIOD_DATA', e)
                }
            })
        },

        [FETCH_CAMERAS_PERIOD_DATA](context, {
            branch,
            start,
            end,
            number,
            type
        }) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(increase(${type}{user_group="${branch}"}[24h]))&start=${start}&end=${end}&step=24h`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(SET_BRANCHES_PERIOD_DATA, {
                        isBranch: true,
                        title: `各抓拍点${getTypeString(type)}统计`,
                        type,
                        data,
                        number,
                        categories: splitTime({
                            start,
                            end,
                            interval: 60 * 60 * 24,
                            format: 'M月D日'
                        }),
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_CAMERAS_PERIOD_DATA', e)
                }
            })
        }
    }
}
