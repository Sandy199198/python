import { SYSTEM_FREQUENCY } from 'common/namespace'
import Immutable from 'immutable'
import { SET_ERROR, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, printError} from 'common/utils'

export const GET_SYSTEM_FREQUENCY_GROUP = `${SYSTEM_FREQUENCY}/getSystemFrequencyGroup`
export const SET_SYSTEM_FREQUENCY_GROUP = `${SYSTEM_FREQUENCY}/setSystemFrequencyGroup`
export const FETCH_SYSTEM_FREQUENCY_GROUP = `${SYSTEM_FREQUENCY}/fetchSystemFrequencyGroup`

export const GET_SYSTEM_FREQUENCY_USER = `${SYSTEM_FREQUENCY}/getSystemFrequencyUser`
export const SET_SYSTEM_FREQUENCY_USER = `${SYSTEM_FREQUENCY}/setSystemFrequencyUser`
export const FETCH_SYSTEM_FREQUENCY_USER = `${SYSTEM_FREQUENCY}/fetchSystemFrequencyUser`

let chartGroupTemplate = {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: '分局使用频次',
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: false
            },
            showInLegend: true
        }
    },
    legend: {
        align: 'right',
        verticalAlign: 'middle',
        floating: true,
        itemMarginTop: 4,
        itemMarginBottom: 4,
        layout: 'vertical'
    },
    series: [{
        name: '分局使用频次',
        colorByPoint: true,
        innerSize: 100,
        borderWidth: 0,
        shadow: {
            offsetX: 0,
            offsetY: 0,
            opaicty: .5,
            color: 'rgb(14, 27, 41)',
            width: 5
        },
        data: []
    }]

}

let chartUserTemplate = {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: '用户使用频次',
        x: -40
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: false
            },
            showInLegend: true
        }
    },
    legend: {
        align: 'right',
        verticalAlign: 'middle',
        itemMarginTop: 4,
        itemMarginBottom: 4,
        layout: 'vertical'
    },
    series: [{
        name: '用户使用频次',
        colorByPoint: true,
        innerSize: 100,
        borderWidth: 0,
        shadow: {
            offsetX: 0,
            offsetY: 0,
            opaicty: .5,
            color: 'rgb(14, 27, 41)',
            width: 5
        },
        data: []
    }]

}

export default {
    state: {
        systemFrequencyGroup: Immutable.fromJS(chartGroupTemplate),
        systemFrequencyUser: Immutable.fromJS(chartUserTemplate)
    },
    getters: {
        [GET_SYSTEM_FREQUENCY_GROUP](state) {
            return state.systemFrequencyGroup.toJS()
        },
        [GET_SYSTEM_FREQUENCY_USER](state) {
            return state.systemFrequencyUser.toJS()
        }
    },
    mutations: {
        [SET_SYSTEM_FREQUENCY_GROUP](state, wrapperData) {
            let seriesData = []
            let total = 0
            let { data, title } = wrapperData

            for (let item of data) {
                let s = {
                    name: item.user_group_name,
                    y: +item.count
                }

                total += +item.count
                seriesData.push(s)
            }

            for (let item of seriesData) {
                item.y = item.y / total
            }

            state.systemFrequencyGroup = state.systemFrequencyGroup.setIn(['series', 0, 'data'], seriesData).setIn(['title', 'text'], title)
        },
        [SET_SYSTEM_FREQUENCY_USER](state, wrapperData) {
            let seriesData = []
            let total = 0
            let { data, title } = wrapperData

            for (let item of data) {
                let s = {
                    name: item.real_name,
                    y: +item.count
                }

                total += +item.count
                seriesData.push(s)
            }

            for (let item of seriesData) {
                item.y = item.y / total
            }

            state.systemFrequencyUser = state.systemFrequencyUser.setIn(['series', 0, 'data'], seriesData).setIn(['title', 'text'], title)
        }
    },
    actions: {
        [FETCH_SYSTEM_FREQUENCY_GROUP](context, {
            start,
            end,
            type
        }) {
            fetch(`${context.getters[GET_SERVICES].Skylab}statistic/usergroup/?start_time=` + start + `&end_time=` + end + ``, { credentials: 'include' }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(SET_SYSTEM_FREQUENCY_GROUP, {
                    data: data.data,
                    title: `分局${type}使用频次`
                })
            }).catch(e  => {
                printError('FETCH_SYSTEM_FREQUENCY_GROUP', e)
                //context.commit(SET_ERROR, e.message)
            })
        },
        [FETCH_SYSTEM_FREQUENCY_USER](context, {
            start,
            end,
            type
        }) {
            fetch(`${context.getters[GET_SERVICES].Skylab}statistic/user/?start_time=` + start + `&end_time=` + end + ``, { credentials: 'include' }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(SET_SYSTEM_FREQUENCY_USER, {
                    data: data.data,
                    title: `用户${type}使用频次`
                })
            }).catch(e  => {
                printError('FETCH_SYSTEM_FREQUENCY_USER', e)
                // context.commit(SET_ERROR, e.message)
            })
        }
    }
}
