import { RESOURCE } from 'common/namespace'
import Immutable from 'immutable'
import { formatDate, responseError, statisticBurdenStyle, statisticIOFilter, analyzeHttpCode, getIp, computeUnit, printError } from 'common/utils'
import { SET_ERROR, GET_PROMETHEUS_QUERY, GET_SERVICES } from 'store/modules/common'
import { GET_USER_INFO } from 'store/modules/auth'

export const SERVICE_FETCH_MEMORY_DATA = `${RESOURCE}/fetchMemoryData`
export const SERVICE_SET_MEMORY_DATA = `${RESOURCE}/setchMemoryData`
export const SERVICE_GET_MEMORY_DATA = `${RESOURCE}/getchMemoryData`

export const SERVER_FETCH_MEMORY_DATA = `${RESOURCE}/fetchServerMemoryData`
export const SERVER_SET_MEMORY_DATA = `${RESOURCE}/setServerMemoryData`
export const SERVER_GET_MEMORY_DATA = `${RESOURCE}/getServerchMemoryData`
export const SERVER_CLEAR_MEMORY_DATA = `${RESOURCE}/clearServerchMemoryData`

export const SERVICE_FETCH_CPU_DATA = `${RESOURCE}/fetchServiceCPUData`
export const SERVICE_SET_CPU_DATA = `${RESOURCE}/setServiceCPUData`
export const SERVICE_GET_CPU_DATA = `${RESOURCE}/getServiceCPUData`

export const FETCH_SWAP_DATA = `${RESOURCE}/fetchSwapData`
export const SET_SWAP_DATA = `${RESOURCE}/setchSwapData`
export const GET_SWAP_DATA = `${RESOURCE}/getchSwapData`
export const CLEAR_SWAP_DATA = `${RESOURCE}/clearSwapData`

export const FETCH_CPU_DATA = `${RESOURCE}/fetchCPUData`
export const GET_CPU_DATA = `${RESOURCE}/getCPUData`
export const SET_CPU_DATA = `${RESOURCE}/setCPUData`

export const FETCH_CPU_DETAIL_DATA = `${RESOURCE}/fetchCPUDetailData`
export const GET_CPU_DETAIL_DATA = `${RESOURCE}/getCPUDetailData`
export const SET_CPU_DETAIL_DATA = `${RESOURCE}/setCPUDetailData`

export const SERVICE_GET_READ_BYTES = `${RESOURCE}/getReadBytes`
export const SERVICE_SET_READ_BYTES = `${RESOURCE}/setReadBytes`
export const SERVICE_FETCH_READ_BYTES = `${RESOURCE}/fetchReadBytes`
export const SERVICE_CLEAR_READ_BYTES = `${RESOURCE}/clearReadBytes`

export const SERVICE_GET_WRITE_BYTES = `${RESOURCE}/getWriteBytes`
export const SERVICE_SET_WRITE_BYTES = `${RESOURCE}/setWriteBytes`
export const SERVICE_FETCH_WRITE_BYTES = `${RESOURCE}/fetchWriteBytes`
export const SERVICE_CLEAR_WRITE_BYTES = `${RESOURCE}/clearWriteBytes`

export const SERVER_GET_READ_BYTES = `${RESOURCE}/getServerReadBytes`
export const SERVER_SET_READ_BYTES = `${RESOURCE}/setServerReadBytes`
export const SERVER_FETCH_READ_BYTES = `${RESOURCE}/fetchServerReadBytes`
export const SERVER_CLEAR_READ_BYTES = `${RESOURCE}/clearServerReadBytes`

export const SERVER_GET_WRITE_BYTES = `${RESOURCE}/getServerWriteBytes`
export const SERVER_SET_WRITE_BYTES = `${RESOURCE}/setServerWriteBytes`
export const SERVER_FETCH_WRITE_BYTES = `${RESOURCE}/fetchServerWriteBytes`
export const SERVER_CLEAR_WRITE_BYTES = `${RESOURCE}/clearServerWriteBytes`

export const SERVER_GET_NET_RECEIVE_BYTES = `${RESOURCE}/getNetReceiveBytes`
export const SERVER_SET_NET_RECEIVE_BYTES = `${RESOURCE}/setNetReceiveBytes`
export const SERVER_FETCH_NET_RECEIVE_BYTES = `${RESOURCE}/fetchNetReceiveBytes`
export const SERVER_CLEAR_NET_RECEIVE_BYTES = `${RESOURCE}/clearNetReceiveBytes`

export const SERVER_GET_NET_SEND_BYTES = `${RESOURCE}/getNetSendBytes`
export const SERVER_SET_NET_SEND_BYTES = `${RESOURCE}/setNetSendBytes`
export const SERVER_FETCH_NET_SEND_BYTES = `${RESOURCE}/fetchNetSendBytes`
export const SERVER_CLEAR_NET_SEND_BYTES = `${RESOURCE}/clearNetSendBytes`

export const SERVER_GET_SYSTEM_LOAD = `${RESOURCE}/getSystemLoad`
export const SERVER_SET_SYSTEM_LOAD = `${RESOURCE}/setSystemLoad`
export const SERVER_FETCH_SYSTEM_LOAD = `${RESOURCE}/fetchSystemLoad`
export const SERVER_CLEAR_SYSTEM_LOAD = `${RESOURCE}/clearSystemLoad`

export const SERVER_GET_ALL_MEMORY = `${RESOURCE}/getAllMemory`
export const SERVER_SET_ALL_MEMORY = `${RESOURCE}/setAllMemory`
export const SERVER_FETCH_ALL_MEMORY = `${RESOURCE}/fetchAllMemory`
export const SERVER_CLEAR_ALL_MEMORY = `${RESOURCE}/clearAllMemory`

export const CITYWIDE_GET_MEMORY = `${RESOURCE}/getCitywideMemory`
export const CITYWIDE_SET_MEMORY = `${RESOURCE}/setCitywideMemory`
export const CITYWIDE_FETCH_MEMORY = `${RESOURCE}/fetchCitywideMemory`
export const CITYWIDE_CLEAR_MEMORY = `${RESOURCE}/clearCitywideMemory`

export const BRANCH_GET_MEMORY = `${RESOURCE}/getBranchMemory`
export const BRANCH_SET_MEMORY = `${RESOURCE}/setBranchMemory`
export const BRANCH_FETCH_MEMORY = `${RESOURCE}/fetchBranchMemory`
export const BRANCH_CLEAR_MEMORY = `${RESOURCE}/clearBranchMemory`

export const CITYWIDE_GET_DISK = `${RESOURCE}/getCitywideDisk`
export const CITYWIDE_SET_DISK = `${RESOURCE}/setCitywideDisk`
export const CITYWIDE_FETCH_DISK = `${RESOURCE}/fetchCitywideDisk`

export const BRANCH_GET_DISK = `${RESOURCE}/getBranchDisk`
export const BRANCH_SET_DISK = `${RESOURCE}/setBranchDisk`
export const BRANCH_FETCH_DISK = `${RESOURCE}/fetchBranchDisk`

export const CITYWIDE_GET_LOAD = `${RESOURCE}/getCitywideLoad`
export const CITYWIDE_SET_LOAD = `${RESOURCE}/setCitywideLoad`
export const CITYWIDE_FETCH_LOAD = `${RESOURCE}/fetchCitywideLoad`
export const CITYWIDE_CLEAR_LOAD = `${RESOURCE}/clearCitywideLoad`

export const BRANCH_GET_LOAD = `${RESOURCE}/getBranchLoad`
export const BRANCH_SET_LOAD = `${RESOURCE}/setBranchLoad`
export const BRANCH_FETCH_LOAD = `${RESOURCE}/fetchBranchLoad`
export const BRANCH_CLEAR_LOAD = `${RESOURCE}/clearBranchLoad`

export const SERVER_GET_TCP = `${RESOURCE}/getAllTcp`
export const SERVER_SET_TCP = `${RESOURCE}/setAllTcp`
export const SERVER_FETCH_TCP = `${RESOURCE}/fetchAllTcp`
export const SERVER_CLEAR_TCP = `${RESOURCE}/clearAllTcp`

export const SERVER_GET_DISK = `${RESOURCE}/getServerDisk`
export const SERVER_SET_DISK = `${RESOURCE}/setServerDisk`
export const SERVER_FETCH_DISK = `${RESOURCE}/fetchServerDisk`

export const FETCH_MACHINES = `${RESOURCE}/fetchMachines`
export const GET_MACHINES = `${RESOURCE}/getMachines`
export const SET_MACHINES = `${RESOURCE}/setMachines`
export const GET_MACHINES_BRANCH_NAME = `${RESOURCE}/getMachinesBranchName`

export const GET_LAST_SELECTED_MACHINE = `${RESOURCE}/getLastSelectedMachine`
export const SET_LAST_SELECTED_MACHINE = `${RESOURCE}/setLastSelectedMachine`

export const GET_LAST_SELECTED_BRANCH = `${RESOURCE}/getLastSelectedBranch`
export const SET_LAST_SELECTED_BRANCH = `${RESOURCE}/setLastSelectedBranch`

let memoryTemplate = {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: 0,
        plotShadow: false
    },
    title: {
        text: '服务的<br>内存占用',
        align: 'center',
        verticalAlign: 'middle',
        y: 50
    },
    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b><br/>',
        shadow: false
    },
    plotOptions: {
        pie: {
            dataLabels: {
                enabled: true,
                distance: 10,
                style: {
                    fontWeight: 'bold',
                    color: 'white'
                },
                format: '{point.name}: <span style="color:#FFF">{point.y:.2f}%</span>'
            },
            startAngle: -90,
            endAngle: 90,
            center: ['50%', '85%']
        }
    },
    series: [{
        type: 'pie',
        name: '硬盘使用率',
        innerSize: '50%',
        size: '110%',
        borderWidth: 0,
        shadow: {
            offsetX: 0,
            offsetY: 0,
            opaicty: .3,
            color: 'rgb(20, 44, 64)',
            width: 5
        },
        data: [{
            name: '已使用率',
            color: 'rgb(0,144,142)',
            y: 0
        }, {
            name: '剩余空间',
            y: 100
        }]
    }]
}

let cpuTemplate = Object.assign({}, memoryTemplate, {
    title: {
        text: 'CPU占用率',
        align: 'center',
        verticalAlign: 'middle',
        y: 80
    }
})

let cpuDetailTemplate = {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: ''
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: false
            },
            showInLegend: true
        }
    },
    legend: {
        align: 'right',
        verticalAlign: 'middle',
        itemMarginTop: 4,
        itemMarginBottom: 4,
        layout: 'vertical',
        x: -100
    },
    series: [{
        name: 'CPU占用详情',
        colorByPoint: true,
        innerSize: 100,
        borderWidth: 0,
        shadow: {
            offsetX: 0,
            offsetY: 0,
            opaicty: .5,
            color: 'rgb(14, 27, 41)',
            width: 5
        },
        data: [{
            name: '用户态CPU占比',
            y: 0,
            color: 'rgb(241, 92, 128)'
        }, {
            name: '系统态CPU占比',
            y: 0,
            color: 'rgb(255, 188, 117)'
        }, {
            name: '空闲CPU占比',
            y: 0,
            color: 'rgb(124, 181, 236)'
        }, {
            name: 'CPU iowait占比',
            y: 0,
            color: 'rgb(153, 158, 255)'
        }, {
            name: '其他',
            y: 0,
            color: 'rgb(144, 237, 125)'
        }]
    }]
}

let readBytesTemplate = {
    chart: {
        type: 'area'
    },
    title: {
        text: '30s内读磁盘字节数'
    },
    xAxis: {
        categories: []
    },
    yAxis: {
        title: {
            text: 'kBps'
        },
        labels: {
            formatter: function () {
                return this.value
            }
        }
    },
    tooltip: {
        headerFormat: '<b>磁盘：{series.name}<br></b>',
        pointFormat: '<b style="color:yellow">{point.y:.2f}</b> kBps'
    },
    plotOptions: {
        area: {
            marker: {
                enabled: true,
                symbol: 'circle',
                radius: 2,
                states: {
                    hover: {
                        enabled: true
                    }
                }
            }
        }
    },
    series: []
}

let serverMemoryTemplate = Object.assign({}, readBytesTemplate, {
    title: {
        text: '内存占比'
    },
    yAxis: {
        title: {
            text: ''
        },
        labels: {
            formatter: function () {
                return this.value + '%'
            }
        }
    },
    tooltip: {
        headerFormat: '<b>{series.name} 内存占比:<br></b>',
        pointFormat: '<b style="color:yellow"><br>{point.y:.2f}%</b>'
    }
})

let swapTemplate = Object.assign({}, readBytesTemplate, {
    title: {
        text: 'SWAP占用率'
    },
    yAxis: {
        title: {
            text: ''
        },
        labels: {
            formatter: function () {
                return this.value + '%'
            }
        }
    },
    tooltip: {
        headerFormat: '<b>{series.name} SWAP占用率:<br></b>',
        pointFormat: '<b style="color:yellow"><br>{point.y:.2f}%</b>'
    }
})

let writeBytesTemplate = Object.assign({}, readBytesTemplate, {
    title: {
        text: '30s内写磁盘字节数'
    }
})

let readServerBytesTemplate = Object.assign({}, readBytesTemplate, {
    chart: {
        type: 'line'
    },
    title: {
        text: '硬盘写速率'
    }
})

let writeServerBytesTemplate = Object.assign({}, readBytesTemplate, {
    chart: {
        type: 'line'
    },
    title: {
        text: '硬盘读速率'
    }
})

let netReceiveBytesTemplate = Object.assign({}, readBytesTemplate, {
    chart: {
        type: 'line'
    },
    title: {
        text: '网络接收速率'
    }
})

let netSendBytesTemplate = Object.assign({}, readBytesTemplate, {
    chart: {
        type: 'line'
    },
    title: {
        text: '网络传输速率'
    }
})

let systemTemplate = Object.assign({}, readBytesTemplate, {
    chart: {
        type: 'line'
    },
    title: {
        text: '系统负荷'
    },
    yAxis: {
        title: {
            text: ''
        },
        labels: {
            formatter: function () {
                return this.value
            }
        }
    },
    tooltip: {
        headerFormat: '<b>{series.name} 负载:<br></b>',
        pointFormat: '<b style="color:yellow"><br>{point.y:.2f}%</b>'
    }
})

let allMemoryTemplate = Object.assign({}, readBytesTemplate, {
    title: {
        text: '各服务器内存占比'
    },
    yAxis: {
        title: {
            text: ''
        },
        labels: {
            formatter: function () {
                return this.value + '%'
            }
        }
    },
    tooltip: {
        headerFormat: '<b>{series.name} 内存占比:<br></b>',
        pointFormat: '<b style="color:yellow"><br>{point.y:.2f}%</b>'
    }
})

let citywideMemoryTemplate = Object.assign({}, readBytesTemplate, {
    title: {
        text: '市局所有服务器平均内存占比'
    },
    yAxis: {
        title: {
            text: ''
        },
        labels: {
            formatter: function () {
                return this.value + '%'
            }
        }
    },
    tooltip: {
        headerFormat: '<b>{series.name} 内存占比:<br></b>',
        pointFormat: '<b style="color:yellow"><br>{point.y:.2f}%</b>'
    }
})

let branchMemoryTemplate = Object.assign({}, readBytesTemplate, {
    title: {
        text: '分局所有服务器平均内存占比'
    },
    yAxis: {
        title: {
            text: ''
        },
        labels: {
            formatter: function () {
                return this.value + '%'
            }
        }
    },
    tooltip: {
        headerFormat: '<b>{series.name} 内存占比:<br></b>',
        pointFormat: '<b style="color:yellow"><br>{point.y:.2f}%</b>'
    }
})

let citywideDiskTemplate = Object.assign({}, memoryTemplate, {
    title: {
        text: '硬盘占用率',
        align: 'center',
        verticalAlign: 'middle',
        y: 80
    }
})

let branchDiskTemplate = Object.assign({}, memoryTemplate, {
    title: {
        text: '硬盘占用率',
        align: 'center',
        verticalAlign: 'middle',
        y: 80
    }
})

let citywideLoadTemplate = Object.assign({}, readBytesTemplate, {
    chart: {
        type: 'line'
    },
    title: {
        text: '市局所有服务器平均负载'
    },
    yAxis: {
        title: {
            text: ''
        },
        labels: {
            formatter: function () {
                return this.value
            }
        }
    },
    tooltip: {
        headerFormat: '<b>{series.name}负载占比:<br></b>',
        pointFormat: '<b style="color:yellow"><br>{point.y:.2f}%</b>'
    }
})

let branchLoadTemplate = Object.assign({}, readBytesTemplate, {
    chart: {
        type: 'line'
    },
    title: {
        text: '分局所有服务器平均负载'
    },
    yAxis: {
        title: {
            text: ''
        },
        labels: {
            formatter: function () {
                return this.value
            }
        }
    },
    tooltip: {
        headerFormat: '<b>{series.name}负载占比:<br></b>',
        pointFormat: '<b style="color:yellow"><br>{point.y:.2f}%</b>'
    }
})

let tcpTemplate = Object.assign({}, readBytesTemplate, {
    chart: {
        type: 'line'
    },
    title: {
        text: 'TCP连接数'
    },
    yAxis: {
        title: {
            text: '连接数'
        },
        labels: {
            formatter: function () {
                return this.value
            }
        }
    },
    tooltip: {
        headerFormat: '<b>TCP：{series.name}<br></b>',
        pointFormat: '<b style="color:yellow">{point.y:.0f}</b> 个'
    },
})

let serverDiskTemplate = Object.assign({}, memoryTemplate, {
    title: {
        text: '硬盘占用率',
        align: 'center',
        verticalAlign: 'middle',
        y: 80
    }
})

export default {
    state: {
        memory: Immutable.fromJS(memoryTemplate),
        serverMemory: Immutable.fromJS(serverMemoryTemplate),
        swap: Immutable.fromJS(swapTemplate),
        cpu: Immutable.fromJS(cpuTemplate),
        serviceCpu: Immutable.fromJS(cpuTemplate),
        cpuDetail: Immutable.fromJS(cpuDetailTemplate),
        readBytes: Immutable.fromJS(readBytesTemplate),
        writeBytes: Immutable.fromJS(writeBytesTemplate),
        readServerBytes: Immutable.fromJS(readServerBytesTemplate),
        writeServerBytes: Immutable.fromJS(writeServerBytesTemplate),
        netReceiveBytes: Immutable.fromJS(netReceiveBytesTemplate),
        netSendBytes: Immutable.fromJS(netSendBytesTemplate),
        systemData: Immutable.fromJS(systemTemplate),
        allMemoryData: Immutable.fromJS(allMemoryTemplate),
        citywideMemoryData: Immutable.fromJS(citywideMemoryTemplate),
        citywideDiskData: Immutable.fromJS(citywideDiskTemplate),
        citywideLoadData: Immutable.fromJS(citywideLoadTemplate),
        tcpData: Immutable.fromJS(tcpTemplate),
        serverDiskData: Immutable.fromJS(serverDiskTemplate),
        branchMemoryData: Immutable.fromJS(branchMemoryTemplate),
        branchDiskData: Immutable.fromJS(branchDiskTemplate),
        branchLoadData: Immutable.fromJS(branchLoadTemplate),
        machines: [],
        machinesBranchName: '',
        lastSelectedMachine: '',
        lastSelectedBranch: ''
    },
    getters: {
        [SERVICE_GET_MEMORY_DATA](state) {
            return state.memory.toJS()
        },
        [SERVER_GET_MEMORY_DATA](state) {
            return state.serverMemory.toJS()
        },
        [GET_SWAP_DATA](state) {
            return state.swap.toJS()
        },
        [GET_CPU_DATA](state) {
            return state.cpu.toJS()
        },
        [SERVICE_GET_CPU_DATA](state) {
            return state.cpu.toJS()
        },
        [GET_CPU_DETAIL_DATA](state) {
            return state.cpuDetail.toJS()
        },
        [SERVICE_GET_READ_BYTES](state) {
            return state.readBytes.toJS()
        },
        [SERVICE_GET_WRITE_BYTES](state) {
            return state.writeBytes.toJS()
        },
        [SERVER_GET_READ_BYTES](state) {
            return state.readServerBytes.toJS()
        },
        [SERVER_GET_WRITE_BYTES](state) {
            return state.writeServerBytes.toJS()
        },
        [SERVER_GET_NET_RECEIVE_BYTES](state) {
            return state.netReceiveBytes.toJS()
        },
        [SERVER_GET_NET_SEND_BYTES](state) {
            return state.netSendBytes.toJS()
        },
        [SERVER_GET_SYSTEM_LOAD](state) {
            return state.systemData.toJS()
        },
        [SERVER_GET_ALL_MEMORY](state) {
            return state.allMemoryData.toJS()
        },
        [CITYWIDE_GET_MEMORY](state) {
            return state.citywideMemoryData.toJS()
        },
        [CITYWIDE_GET_DISK](state) {
            return state.citywideDiskData.toJS()
        },
        [CITYWIDE_GET_LOAD](state) {
            return state.citywideLoadData.toJS()
        },
        [BRANCH_GET_MEMORY](state) {
            return state.branchMemoryData.toJS()
        },
        [BRANCH_GET_DISK](state) {
            return state.branchDiskData.toJS()
        },
        [BRANCH_GET_LOAD](state) {
            return state.branchLoadData.toJS()
        },
        [SERVER_GET_TCP](state) {
            return state.tcpData.toJS()
        },
        [SERVER_GET_DISK](state) {
            return state.serverDiskData.toJS()
        },
        [GET_MACHINES](state) {
            return state.machines
        },
        [GET_MACHINES_BRANCH_NAME](state) {
            return state.machinesBranchName
        },
        [GET_LAST_SELECTED_MACHINE](state) {
            return state.lastSelectedMachine
        },
        [GET_LAST_SELECTED_BRANCH](state) {
            return state.lastSelectedBranch
        }
    },
    mutations: {
        [SERVICE_SET_MEMORY_DATA](state, data) {
            let seriesData = []
            let memory = state.memory.updateIn(['series', 0, 'data', 0, 'y'], v => +data)
                .updateIn(['series', 0, 'data', 1, 'y'], v => 100 - data)

            state.memory = statisticBurdenStyle(memory, data)
        },

        [SERVER_SET_MEMORY_DATA](state, wrapperData) {
            let series = state.serverMemory
            let { time, data, title} = wrapperData
            let tempData = []

            for (let i in data) {
                let item = {
                    metric: {
                        device: data[i].metric.instance.split(':')[0]
                    },
                    value: [
                        data[i].value[0],
                        data[i].value[1]
                    ]
                }

                tempData.push(item)
            }
            series = statisticIOFilter(series, tempData, Immutable)
            series = series.setIn(['title', 'text'], title)
            state.serverMemory = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [SERVER_CLEAR_MEMORY_DATA](state) {
            state.serverMemory = Immutable.fromJS(serverMemoryTemplate)
        },

        [SERVICE_SET_CPU_DATA](state, data) {
            let seriesData = []
            let cpu = state.cpu.updateIn(['series', 0, 'data', 0, 'y'], v => +data)
                .updateIn(['series', 0, 'data', 1, 'y'], v => (1 - data))

            state.cpu = statisticBurdenStyle(cpu, data)
        },

        [SET_SWAP_DATA](state, wrapperData) {
            let series = state.swap
            let { time, data, title} = wrapperData
            let tempData = []

            for (let i in data) {
                let item = {
                    metric: {
                        device: data[i].metric.instance.split(':')[0]
                    },
                    value: [
                        data[i].value[0],
                        data[i].value[1]
                    ]
                }

                tempData.push(item)
            }
            series = statisticIOFilter(series, tempData, Immutable)
            series = series.setIn(['title', 'text'], title)
            state.swap = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [CLEAR_SWAP_DATA](state) {
            state.swap = Immutable.fromJS(swapTemplate)
        },

        [SET_CPU_DATA](state, data) {
            let seriesData = []
            let cpu = state.cpu.updateIn(['series', 0, 'data', 0, 'y'], v => +data)
                .updateIn(['series', 0, 'data', 1, 'y'], v => (1 - data))

            state.cpu = statisticBurdenStyle(cpu, data)
        },

        [SET_CPU_DETAIL_DATA](state, data) {
            let seriesData = []
            let other = 1

            for (let i in data) {
                if (!data[i]) {
                    continue
                }
                other = other - parseFloat(data[i].value[1])
            }
            let cpuDetail = state.cpuDetail.updateIn(['series', 0, 'data', 0, 'y'], v => {
                if (!data[0]) {
                    return 0
                } else {
                    return parseFloat(data[0].value[1])
                }
            }).updateIn(['series', 0, 'data', 1, 'y'], v => {
                if (!data[1]) {
                    return 0
                } else {
                    return parseFloat(data[1].value[1])
                }
            }).updateIn(['series', 0, 'data', 2, 'y'], v => {
                if (!data[2]) {
                    return 0
                } else {
                    return parseFloat(data[2].value[1])
                }
            }).updateIn(['series', 0, 'data', 3, 'y'], v => {
                if (!data[3]) {
                    return 0
                } else {
                    return parseFloat(data[3].value[1])
                }
            }).updateIn(['series', 0, 'data', 4, 'y'], v => other)

            state.cpuDetail = cpuDetail
        },

        [SERVICE_SET_READ_BYTES](state, wrapperData) {
            let series = state.readBytes
            let { time, data } = wrapperData

            series = statisticIOFilter(series, data, Immutable)
            state.readBytes = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [SERVICE_CLEAR_READ_BYTES](state) {
            state.readBytes = Immutable.fromJS(readBytesTemplate)
        },

        [SERVICE_SET_WRITE_BYTES](state, wrapperData) {
            let series = state.writeBytes
            let { time, data } = wrapperData

            series = statisticIOFilter(series, data, Immutable)

            state.writeBytes = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [SERVICE_CLEAR_WRITE_BYTES](state) {
            state.writeBytes = Immutable.fromJS(writeBytesTemplate)
        },

        [SERVER_SET_READ_BYTES](state, wrapperData) {
            let series = state.readServerBytes
            let { time, data, title} = wrapperData

            for (let d of data) {
                d.value[1] = (+d.value[1] / 1024).toFixed(2)
            }

            series = statisticIOFilter(series, data, Immutable)
            series = series.setIn(['title', 'text'], title)
            state.readServerBytes = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [SERVER_CLEAR_READ_BYTES](state) {
            state.readServerBytes = Immutable.fromJS(readServerBytesTemplate)
        },

        [SERVER_SET_WRITE_BYTES](state, wrapperData) {
            let series = state.writeServerBytes
            let { time, data, title} = wrapperData

            for (let d of data) {
                d.value[1] = (+d.value[1] / 1024).toFixed(2)
            }

            series = statisticIOFilter(series, data, Immutable)
            series = series.setIn(['title', 'text'], title)
            state.writeServerBytes = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [SERVER_CLEAR_WRITE_BYTES](state) {
            state.writeServerBytes = Immutable.fromJS(writeServerBytesTemplate)
        },

        [SERVER_SET_NET_RECEIVE_BYTES](state, wrapperData) {
            let series = state.netReceiveBytes
            let { time, data, title} = wrapperData

            for (let d of data) {
                d.value[1] = (+d.value[1] / 1024).toFixed(2)
            }

            series = statisticIOFilter(series, data, Immutable)
            series = series.setIn(['title', 'text'], title)
            state.netReceiveBytes = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [SERVER_CLEAR_NET_RECEIVE_BYTES](state) {
            state.netReceiveBytes = Immutable.fromJS(netReceiveBytesTemplate)
        },

        [SERVER_SET_NET_SEND_BYTES](state, wrapperData) {
            let series = state.netSendBytes
            let { time, data, title} = wrapperData

            for (let d of data) {
                d.value[1] = (+d.value[1] / 1024).toFixed(2)
            }

            series = statisticIOFilter(series, data, Immutable)
            series = series.setIn(['title', 'text'], title)
            state.netSendBytes = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [SERVER_CLEAR_NET_SEND_BYTES](state) {
            state.netSendBytes = Immutable.fromJS(netSendBytesTemplate)
        },

        [SERVER_SET_SYSTEM_LOAD](state, wrapperData) {
            let series = state.systemData
            let { time, data, title} = wrapperData
            let tempData = []

            for (let i in data) {
                let item = {
                    metric: {
                        device: i == 0 ? '1分钟' : (i == 1 ? '5分钟' : '15分钟')
                    },
                    value: [
                        data[i].value[0],
                        data[i].value[1]
                    ]
                }

                tempData.push(item)
            }

            series = statisticIOFilter(series, tempData, Immutable)
            series = series.setIn(['title', 'text'], title)
            state.systemData = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [SERVER_CLEAR_SYSTEM_LOAD](state) {
            state.systemData = Immutable.fromJS(systemTemplate)
        },

        [SERVER_SET_ALL_MEMORY](state, wrapperData) {
            let series = state.allMemoryData
            let { time, data } = wrapperData
            let tempData = []

            for (let i in data) {
                let item = {
                    metric: {
                        device: data[i].metric.instance
                    },
                    value: [
                        data[i].value[0],
                        data[i].value[1]
                    ]
                }

                tempData.push(item)
            }

            series = statisticIOFilter(series, tempData, Immutable)
            state.allMemoryData = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [SERVER_CLEAR_ALL_MEMORY](state) {
            state.allMemoryData = Immutable.fromJS(allMemoryTemplate)
        },

        [CITYWIDE_SET_MEMORY](state, wrapperData) {
            let series = state.citywideMemoryData
            let { time, data } = wrapperData
            let tempData = []
            let item = {
                metric: {
                    device: '市局服务器'
                },
                value: [
                    data[0].value[0],
                    data[0].value[1]
                ]
            }

            tempData.push(item)
            series = statisticIOFilter(series, tempData, Immutable)
            state.citywideMemoryData = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [CITYWIDE_CLEAR_MEMORY](state) {
            state.citywideMemoryData = Immutable.fromJS(citywideMemoryTemplate)
        },

        [BRANCH_SET_MEMORY](state, wrapperData) {
            let series = state.branchMemoryData
            let { time, data, name, title} = wrapperData
            let tempData = []
            let item = {}

            if (data.length) {
                item = {
                    metric: {
                        device: name
                    },
                    value: [
                        data[0].value[0],
                        data[0].value[1]
                    ]
                }
            } else {
                item = {
                    metric: {
                        device: name
                    },
                    value: [
                        time,
                        0
                    ]
                }
            }

            tempData.push(item)
            series = statisticIOFilter(series, tempData, Immutable)
            series = series.setIn(['title', 'text'], title)
            state.branchMemoryData = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [BRANCH_CLEAR_MEMORY](state) {
            state.branchMemoryData = Immutable.fromJS(branchMemoryTemplate)
        },

        [CITYWIDE_SET_DISK](state, data) {
            let seriesData = []
            let diskData = state.citywideDiskData.updateIn(['series', 0, 'data', 0, 'y'], v => +data)
                .updateIn(['series', 0, 'data', 1, 'y'], v => 100 - data)

            state.citywideDiskData = statisticBurdenStyle(diskData, data)
        },

        [BRANCH_SET_DISK](state, data) {
            let seriesData = []
            let diskData = state.branchDiskData.updateIn(['series', 0, 'data', 0, 'y'], v => +data)
                .updateIn(['series', 0, 'data', 1, 'y'], v => 100 - data)

            state.branchDiskData = statisticBurdenStyle(diskData, data)
        },

        [CITYWIDE_SET_LOAD](state, wrapperData) {
            let series = state.citywideLoadData
            let { time, data } = wrapperData
            let tempData = []

            for (let i in data) {
                let item = {
                    metric: {
                        device: i == 0 ? '1分钟' : (i == 1 ? '5分钟' : '15分钟')
                    },
                    value: [
                        data[i].value[0],
                        data[i].value[1]
                    ]
                }

                tempData.push(item)
            }

            series = statisticIOFilter(series, tempData, Immutable)
            state.citywideLoadData = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [CITYWIDE_CLEAR_LOAD](state) {
            state.citywideLoadData = Immutable.fromJS(citywideLoadTemplate)
        },

        [BRANCH_SET_LOAD](state, wrapperData) {
            let series = state.branchLoadData
            let { time, data, name, title} = wrapperData
            let tempData = []

            for (let i in data) {
                let item = {}

                if (data[i].result[0]) {
                    item = {
                        metric: {
                            device: i == 0 ? '1分钟' : (i == 1 ? '5分钟' : '15分钟')
                        },
                        value: [
                            data[i].result[0].value[0],
                            data[i].result[0].value[1]
                        ],
                        name: name
                    }
                } else {
                    item = {
                        metric: {
                            device: i == 0 ? '1分钟' : (i == 1 ? '5分钟' : '15分钟')
                        },
                        value: [
                            time,
                            0
                        ],
                        name: name
                    }
                }

                tempData.push(item)
            }

            series = statisticIOFilter(series, tempData, Immutable)
            series = series.setIn(['title', 'text'], title)
            state.branchLoadData = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [BRANCH_CLEAR_LOAD](state) {
            state.branchLoadData = Immutable.fromJS(branchLoadTemplate)
        },

        [SERVER_SET_TCP](state, wrapperData) {
            let series = state.tcpData
            let { time, data, title} = wrapperData
            let tempData = []

            for (let i in data) {
                let item = {
                    metric: {
                        device: data[i].metric.instance.split(':')[0]
                    },
                    value: [
                        data[i].value[0],
                        data[i].value[1]
                    ]
                }

                tempData.push(item)
            }
            series = statisticIOFilter(series, tempData, Immutable)
            series = series.setIn(['title', 'text'], title)
            state.tcpData = series.updateIn(['xAxis', 'categories'], list => {
                return list.push(time)
            })
        },

        [SERVER_CLEAR_TCP](state) {
            state.tcpData = Immutable.fromJS(tcpTemplate)
        },

        [SERVER_SET_DISK](state, data) {
            let seriesData = []
            let diskData = state.serverDiskData.updateIn(['series', 0, 'data', 0, 'y'], v => +data)
                .updateIn(['series', 0, 'data', 1, 'y'], v => 100 - data)

            state.serverDiskData = statisticBurdenStyle(diskData, data)
        },

        [SET_MACHINES](state, data) {
            let machines = []

            for (let branch in data) {
                if (data.hasOwnProperty(branch)) {
                    for (let d of data[branch]) {
                        machines.push({
                            text: d,
                            value: d
                        })
                    }
                }
            }
            state.machines = machines
            state.machinesBranchName = data
        },

        [SET_LAST_SELECTED_MACHINE](state, name) {
            state.lastSelectedMachine = name
        },

        [SET_LAST_SELECTED_BRANCH](state, name) {
            state.lastSelectedBranch = name
        }
    },
    actions: {
        [SERVICE_FETCH_MEMORY_DATA](context) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=sum(container_memory_usage_bytes{name='security-sd'})/sum(node_memory_MemTotal{job="node"})*100`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(SERVICE_SET_MEMORY_DATA, data.result[0].value[1])
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SERVICE_FETCH_MEMORY_DATA', e)
                }
            })
        },

        [SERVER_FETCH_MEMORY_DATA](context, name) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=(node_memory_MemTotal{instance="${name}"}-node_memory_MemFree{instance="${name}"}-node_memory_Buffers{instance="${name}"}-node_memory_Cached{instance="${name}"})/node_memory_MemTotal{instance="${name}"}*100`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (context.getters[GET_LAST_SELECTED_MACHINE] != name) return
                if (data.result.length) {
                    context.commit(SERVER_SET_MEMORY_DATA, {
                        time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                        data: data.result,
                        title: `${getIp(name)} 内存占比`
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SERVER_FETCH_MEMORY_DATA', e)
                }
            })
        },

        [FETCH_SWAP_DATA](context, name) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=(node_memory_SwapTotal{instance="${name}"}-node_memory_SwapFree{instance="${name}"})/node_memory_SwapTotal{instance="${name}"}*100`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (context.getters[GET_LAST_SELECTED_MACHINE] != name) return
                if (data.result.length) {
                    context.commit(SET_SWAP_DATA, {
                        time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                        data: data.result,
                        title: `${getIp(name)} SWAP占用率`
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_SWAP_DATA', e)
                }
            })
        },

        [SERVICE_FETCH_CPU_DATA](context) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=sum(container_cpu_usage_seconds_total{name="security-sd"})/sum(node_cpu{job="node"}) * 100`).then(res => {
                return res.json()
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        if (data.data.result.length) {
                            resolve(data.data.result[0])
                        }
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                context.commit(SERVICE_SET_CPU_DATA, data.value[1])
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SERVICE_FETCH_CPU_DATA', e)
                }
            })
        },

        [FETCH_CPU_DATA](context) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=sum(container_cpu_usage_seconds_total{name="security-sd"})/sum(node_cpu{job="node"})*100`).then(res => {
                return res.json()
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        if (data.data.result.length) {
                            resolve(data.data.result[0])
                        }
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                context.commit(SET_CPU_DATA, data.value[1])
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_CPU_DATA', e)
                }
            })
        },

        [FETCH_CPU_DETAIL_DATA](context) {
            Promise.all([
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=(avg by (instance)(irate(node_cpu{instance="192.168.0.10:9111",job="node",mode="user"}[30s]))*100)`).then(res => {
                    return res.json()
                }).then(data => {
                    return new Promise((resolve, reject) => {
                        if (data.status == 'success') {
                            resolve(data.data.result[0])
                        } else {
                            reject()
                        }
                    })
                }),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=(avg by (instance)(irate(node_cpu{instance="192.168.0.10:9111",job="node",mode="system"}[30s]))*100)`).then(res => {
                    return res.json()
                }).then(data => {
                    return new Promise((resolve, reject) => {
                        if (data.status == 'success') {
                            resolve(data.data.result[0])
                        } else {
                            reject()
                        }
                    })
                }),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=(avg by (instance)(irate(node_cpu{instance="192.168.0.10:9111",job="node",mode="idle"}[30s]))*100)`).then(res => {
                    return res.json()
                }).then(data => {
                    return new Promise((resolve, reject) => {
                        if (data.status == 'success') {
                            resolve(data.data.result[0])
                        } else {
                            reject()
                        }
                    })
                }),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=(avg by (instance)(irate(node_cpu{instance="192.168.0.10:9111",job="node",mode="iowait"}[30s]))*100)`).then(res => {
                    return res.json()
                }).then(data => {
                    return new Promise((resolve, reject) => {
                        if (data.status == 'success') {
                            resolve(data.data.result[0])
                        } else {
                            reject()
                        }
                    })
                })
            ]).then(([usercpu, systemcpu, freecpu, iowaitcpu]) => {
                context.commit(SET_CPU_DETAIL_DATA, [usercpu, systemcpu, freecpu, iowaitcpu])
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_CPU_DETAIL_DATA', e)
                }
            })
        },

        [SERVER_FETCH_SYSTEM_LOAD](context, name) {
            Promise.all([
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=node_load1{instance="${name}"}`).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    return new Promise((resolve, reject) => {
                        if (data.status == 'success') {
                            if (context.getters[GET_LAST_SELECTED_MACHINE] != name) return
                            if (data.data.result.length) {
                                resolve(data.data.result[0])
                            }
                        } else {
                            reject()
                        }
                    })
                }),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=node_load5{instance="${name}"}`).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    return new Promise((resolve, reject) => {
                        if (data.status == 'success') {
                            if (data.data.result.length) {
                                resolve(data.data.result[0])
                            }
                        } else {
                            reject()
                        }
                    })
                }),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=node_load15{instance="${name}"}`).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    return new Promise((resolve, reject) => {
                        if (data.status == 'success') {
                            if (data.data.result.length) {
                                resolve(data.data.result[0])
                            }
                        } else {
                            reject()
                        }
                    })
                })
            ]).then(([oneM, fiveM, ftM]) => {
                context.commit(SERVER_SET_SYSTEM_LOAD, {
                    time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                    data: [oneM, fiveM, ftM],
                    title: `${getIp(name)} 系统负荷`
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SERVER_FETCH_SYSTEM_LOAD', e)
                }
            })
        },

        [SERVICE_FETCH_READ_BYTES](context) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=rate(container_blkio_io_service_bytes_recursive_total{name='security-sd', op='Read'}[30s])`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(SERVICE_SET_READ_BYTES, {
                        time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                        data: data.result
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SERVICE_FETCH_READ_BYTES', e)
                }
            })
        },

        [SERVICE_FETCH_WRITE_BYTES](context) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=rate(container_blkio_io_service_bytes_recursive_total{name='security-sd', op='Write'}[30s])`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(SERVICE_SET_WRITE_BYTES, {
                        time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                        data: data.result
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SERVICE_FETCH_WRITE_BYTES', e)
                }
            })
        },

        [SERVER_FETCH_READ_BYTES](context, name) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=rate(node_disk_bytes_read{instance="${name}"}[5m])`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (context.getters[GET_LAST_SELECTED_MACHINE] != name) return
                if (data.result.length) {
                    context.commit(SERVER_SET_READ_BYTES, {
                        time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                        data: data.result,
                        title: `${getIp(name)} 硬盘读速率`
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SERVICE_FETCH_WRITE_BYTES', e)
                }
            })
        },

        [SERVER_FETCH_WRITE_BYTES](context, name) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=rate(node_disk_bytes_written{instance="${name}"}[5m])`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (context.getters[GET_LAST_SELECTED_MACHINE] != name) return
                if (data.result.length) {
                    context.commit(SERVER_SET_WRITE_BYTES, {
                        time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                        data: data.result,
                        title: `${getIp(name)} 硬盘写速率`
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SERVER_FETCH_WRITE_BYTES', e)
                }
            })
        },

        [SERVER_FETCH_NET_RECEIVE_BYTES](context, name) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=rate(node_network_receive_bytes{instance="${name}"}[5m])`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (context.getters[GET_LAST_SELECTED_MACHINE] != name) return
                if (data.result.length) {
                    context.commit(SERVER_SET_NET_RECEIVE_BYTES, {
                        time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                        data: data.result,
                        title: `${getIp(name)} 网络接收速率`
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SERVER_FETCH_NET_RECEIVE_BYTES', e)
                }
            })
        },

        [SERVER_FETCH_NET_SEND_BYTES](context, name) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=rate(node_network_transmit_bytes{instance="${name}"}[5m])`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (context.getters[GET_LAST_SELECTED_MACHINE] != name) return
                if (data.result.length) {
                    context.commit(SERVER_SET_NET_SEND_BYTES, {
                        time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                        data: data.result,
                        title: `${getIp(name)} 网络传输速率`
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SERVER_FETCH_NET_SEND_BYTES', e)
                }
            })
        },

        [SERVER_FETCH_ALL_MEMORY](context) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=100*(node_memory_MemTotal-node_memory_MemFree-node_memory_Buffers-node_memory_Cached)%2fnode_memory_MemTotal`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(SERVER_SET_ALL_MEMORY, {
                        time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                        data: data.result
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SERVER_FETCH_ALL_MEMORY', e)
                }
            })
        },

        [CITYWIDE_FETCH_MEMORY](context) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=avg((node_memory_MemTotal-node_memory_MemFree-node_memory_Buffers-node_memory_Cached)/node_memory_MemTotal)*100`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(CITYWIDE_SET_MEMORY, {
                        time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                        data: data.result
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('CITYWIDE_FETCH_MEMORY', e)
                }
            })
        },

        [BRANCH_FETCH_MEMORY](context, name) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=avg((node_memory_MemTotal{usergroup='${name}'}-node_memory_MemFree{usergroup='${name}'}-node_memory_Buffers{usergroup='${name}'}-node_memory_Cached{usergroup='${name}'})/node_memory_MemTotal{usergroup='${name}'})*100`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (context.getters[GET_LAST_SELECTED_BRANCH] != name) return
                context.commit(BRANCH_SET_MEMORY, {
                    time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                    data: data.result,
                    name: name,
                    title: `${getIp(name)} 服务器平均内存占比`
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('BRANCH_FETCH_MEMORY', e)
                }
            })
        },

        [CITYWIDE_FETCH_DISK](context) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=avg((sum(node_filesystem_size) by (instance)-sum(node_filesystem_avail) by (instance))/sum(node_filesystem_size) by (instance))*100`).then(res => {
                return res.json()
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length) {
                    context.commit(CITYWIDE_SET_DISK, data.result[0].value[1])
                } else {
                    context.commit(BRANCH_SET_DISK, 0)
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('CITYWIDE_FETCH_DISK', e)
                }
            })
        },

        [BRANCH_FETCH_DISK](context, name) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=avg((sum(node_filesystem_size{usergroup='${name}'}) by (instance)-sum(node_filesystem_avail{usergroup='${name}'}) by (instance))/sum(node_filesystem_size{usergroup='${name}'}) by (instance))*100`).then(res => {
                return res.json()
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (context.getters[GET_LAST_SELECTED_BRANCH] != name) return
                if (data.result.length) {
                    context.commit(BRANCH_SET_DISK, data.result[0].value[1])
                } else {
                    context.commit(BRANCH_SET_DISK, 0)
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('BRANCH_FETCH_DISK', e)
                }
            })
        },

        [CITYWIDE_FETCH_LOAD](context) {
            Promise.all([
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=avg(node_load1)`).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    return new Promise((resolve, reject) => {
                        if (data.status == 'success') {
                            if (data.data.result.length) {
                                resolve(data.data.result[0])
                            }
                        } else {
                            reject()
                        }
                    })
                }),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=avg(node_load5)`).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    return new Promise((resolve, reject) => {
                        if (data.status == 'success') {
                            if (data.data.result.length) {
                                resolve(data.data.result[0])
                            }
                        } else {
                            reject()
                        }
                    })
                }),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=avg(node_load15)`).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    return new Promise((resolve, reject) => {
                        if (data.status == 'success') {
                            if (data.data.result.length) {
                                resolve(data.data.result[0])
                            }
                        } else {
                            reject()
                        }
                    })
                })
            ]).then(([oneM, fiveM, ftM]) => {
                context.commit(CITYWIDE_SET_LOAD, {
                    time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                    data: [oneM, fiveM, ftM]
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('CITYWIDE_FETCH_LOAD', e)
                }
            })
        },

        [BRANCH_FETCH_LOAD](context, name) {
            Promise.all([
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=avg(node_load1{usergroup='${name}'})`).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    return new Promise((resolve, reject) => {
                        if (data.status == 'success') {
                            if (context.getters[GET_LAST_SELECTED_BRANCH] != name) return
                            resolve(data.data)
                            // if (data.data.result.length) {
                            //     resolve(data.data.result[0])
                            // }
                        } else {
                            reject()
                        }
                    })
                }),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=avg(node_load5{usergroup='${name}'})`).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    return new Promise((resolve, reject) => {
                        if (data.status == 'success') {
                            resolve(data.data)
                            // if (data.data.result.length) {
                            //     resolve(data.data.result[0])
                            // }
                        } else {
                            reject()
                        }
                    })
                }),
                fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=avg(node_load15{usergroup='${name}'})`).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    return new Promise((resolve, reject) => {
                        if (data.status == 'success') {
                            resolve(data.data)
                            // if (data.data.result.length) {
                            //     resolve(data.data.result[0])
                            // }
                        } else {
                            reject()
                        }
                    })
                })
            ]).then(([oneM, fiveM, ftM]) => {
                context.commit(BRANCH_SET_LOAD, {
                    time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                    data: [oneM, fiveM, ftM],
                    name: name,
                    title: `${name} 服务器平均负载`,
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('BRANCH_FETCH_LOAD', e)
                }
            })
        },

        [SERVER_FETCH_TCP](context, name) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=node_tcp_connection_states{state="established",instance="${name}"}`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (context.getters[GET_LAST_SELECTED_MACHINE] != name) return
                if (data.result.length) {
                    context.commit(SERVER_SET_TCP, {
                        time: formatDate(parseInt(new Date() / 1000, 10), 'h:m:s'),
                        data: data.result,
                        title: `${getIp(name)} TCP连接数`
                    })
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SERVER_FETCH_TCP', e)
                }
            })
        },

        [SERVER_FETCH_DISK](context, name) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=(sum(node_filesystem_size{instance="${name}"})-sum(node_filesystem_avail{instance="${name}"}))/sum(node_filesystem_size{instance="${name}"})*100`).then(res => {
                return res.json()
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (context.getters[GET_LAST_SELECTED_MACHINE] != name) return
                if (data.result.length) {
                    context.commit(SERVER_SET_DISK, data.result[0].value[1])
                } else {
                    context.commit(BRANCH_SET_DISK, 0)
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SERVER_FETCH_DISK', e)
                }
            })
        },

        [FETCH_MACHINES](context) {
            return new Promise((resolve1, reject) => {
                fetch(`${context.getters[GET_SERVICES].Skylab}user_token`, {
                    credentials: 'include',
                }).then(res => {
                    return res.json()
                }).then(data => {
                    return new Promise((resolve2, reject) => {
                        try {
                            resolve2(data.data.access_token)
                        } catch (e) {
                            reject(e)
                        }
                    })
                }).then(code => {
                    return fetch(`${context.getters[GET_SERVICES].Skylab}machines/`, {
                        credentials: 'include',
                        headers: {
                            'User-Access-Token': code
                        }
                    }).then(res => {
                        return res.json()
                    }).then(data => {
                        context.commit(SET_MACHINES, data.data)
                        resolve1()
                    })
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_MACHINES', e)
                    }
                })
            })
        },
    }
}
