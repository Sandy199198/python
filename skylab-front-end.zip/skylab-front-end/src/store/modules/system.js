import { SYSTEM } from 'common/namespace'
import Highcharts from 'highcharts'
import Immutable from 'immutable'
import { SET_ERROR, GET_SERVICES, GET_PROMETHEUS_QUERY, GET_PROMETHEUS_QUERY_RANGE } from 'store/modules/common'
import { splitTime, supplement, analyzeHttpCode, printError} from 'common/utils'

export const SET_ALL_SYSTEMS = `${SYSTEM}/setAllSystems`
export const GET_ALL_SYSTEMS = `${SYSTEM}/getAllSystems`
export const FETCH_ALL_SYSTEMS = `${SYSTEM}/fetchAllSystems`

export const POST_SYSTEM = `${SYSTEM}/saveSystem`
export const PUT_SYSTEM = `${SYSTEM}/updateSystem`
export const DELETE_SYSTEM = `${SYSTEM}/deleteSystem`
export const ADD_SYSTEM = `${SYSTEM}/addSystem`
export const UPDATE_SYSTEM = `${SYSTEM}/updateSystem`
export const DEL_SYSTEM = `${SYSTEM}/delSystem`

export const GET_ALL_SYSTEM_REQUEST_COUNT = `${SYSTEM}/getAllSystemRequestCount`
export const SET_ALL_SYSTEM_REQUEST_COUNT = `${SYSTEM}/setAllSystemRequestCount`
export const GET_ALL_SYSTEM_REQUEST_DETAIL = `${SYSTEM}/getAllSystemRequestDetail`
export const SET_ALL_SYSTEM_REQUEST_DETAIL = `${SYSTEM}/setAllSystemRequestDetail`
export const FETCH_ALL_SYSTEM_REQUEST_COUNT = `${SYSTEM}/fetchAllSystemRequestCount`

export const GET_SYSTEM_INIT_GROUPS = `${SYSTEM}/getSystemInitGroups`
export const GET_SYSTEM_INIT_INTERFACES = `${SYSTEM}/getSystemInitInterfaces`
export const SET_SYSTEM_INIT_GROUPS = `${SYSTEM}/setSystemInitGroups`
export const SET_SYSTEM_INIT_INTERFACES = `${SYSTEM}/setSystemInitInterfaces`
export const FETCH_SYSTEM_INIT_DATA = `${SYSTEM}/fetchSystemInitData`

export const GET_SYSTEM_REQUEST_INTERVAL_COUNT = `${SYSTEM}/getSystemRequestIntervalCount`
export const FETCH_SYSTEM_REQUEST_INTERVAL_COUNT = `${SYSTEM}/fetchSystemRequestIntervalCount`
export const SET_SYSTEM_REQUEST_INTERVAL_COUNT = `${SYSTEM}/setSystemRequestIntervalCount`
export const CLEAR_SYSTEM_REQUEST_INTERVAL_COUNT = `${SYSTEM}/clearSystemRequestIntervalCount`
export const SET_SYSTEM_REQUEST_COUNT = `${SYSTEM}setSystemRequestCount`
export const GET_SYSTEM_REQUEST_COUNT_COLUMNS = `${SYSTEM}/getSystemRequestCountColumns`
export const GET_SYSTEM_REQUEST_COUNT = `${SYSTEM}/getSystemRequestCount`
export const FETCH_SYSTEM_REQUEST_COUNT = `${SYSTEM}/fetchSystemRequestCount`

export const GET_SYSTEM_REQUEST_PERIOD_COUNT = `${SYSTEM}/getSystemRequestPeriodCount`
export const SET_SYSTEM_REQUEST_PERIOD_COUNT = `${SYSTEM}/setSystemRequestPeriodCount`
export const FETCH_SYSTEM_REQUEST_PERIOD_COUNT = `${SYSTEM}/fetchSystemRequestPeriodCount`

export const SET_SYSTEM_HOT_REQUEST_DATA = `${SYSTEM}/setSystemHotRequestData`
export const GET_SYSTEM_HOT_REQUEST_DATA = `${SYSTEM}/getSystemHotRequestData`
export const GET_SYSTEM_HOT_REQUEST_DATA_COLUMNS = `${SYSTEM}/getSystemHotRequestDataColumns`

let chartTemplate = {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: '第三方接口调用'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: false
            },
            showInLegend: true
        }
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        floating: true,
        verticalAlign: 'middle',
        itemMarginTop: 4,
        itemMarginBottom: 4,
    },
    series: [{
        name: '调用占比',
        colorByPoint: true,
        innerSize: 100,
        borderWidth: 0,
        shadow: {
            offsetX: 0,
            offsetY: 0,
            opaicty: .5,
            color: 'rgb(14, 27, 41)',
            width: 5
        },
        data: []
    }]

}


let intervalChartTemplate = {
    chart: {
        type: 'column',
        animation: Highcharts.svg
    },

    title: {
        text: '暂无数据'
    },

    xAxis: {
        gridLineWidth: 1,
        categories: []
    },

    yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
            text: ''
        }
    },

    tooltip: {
        headerFormat: '<b>{point.key}</b><br>',
        pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.name}: {point.y}'
    },

    legend: {
        enabled: false
    },

    series: []
}

let periodChartTemplate = {
    title: {
        text: '暂无数据',
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        categories: []
    },
    yAxis: {
        title: {
            text: '次数'
        },
        plotLines: [{
            value: 0,
            width: 1,
            color: '#808080'
        }]
    },
    tooltip: {
        valueSuffix: '次',
        pointFormat: '<span style="color:{point.color}">\u25CF</span> {series.name}: <b>{point.y}</b><br/>'
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle',
        borderWidth: 0,
        itemMarginTop: 4,
        itemMarginBottom: 4,
    },
    series: []

}


export default {
    state: {
        groups: [],
        interfaces: [],
        systems: [],
        systemAllRequestCount: Immutable.fromJS(chartTemplate),
        systemRequestDetail: [],
        systemRequestCount2h: Immutable.fromJS(intervalChartTemplate),
        systemRequestCountColumns: [],
        systemRequestCount: [],
        systemRequestCountPeriod: Immutable.fromJS(periodChartTemplate),
        systemHotRequestDataColumns: [],
        systemHotRequestData: []
    },
    getters: {
        [GET_ALL_SYSTEMS](state) {
            return state.systems
        },
        [GET_ALL_SYSTEM_REQUEST_COUNT](state) {
            return state.systemAllRequestCount.toJS()
        },
        [GET_ALL_SYSTEM_REQUEST_DETAIL](state) {
            return state.systemRequestDetail
        },
        [GET_SYSTEM_INIT_GROUPS](state) {
            return state.groups
        },
        [GET_SYSTEM_INIT_INTERFACES](state) {
            return state.interfaces
        },
        [GET_SYSTEM_REQUEST_INTERVAL_COUNT](state) {
            return state.systemRequestCount2h.toJS()
        },
        [GET_SYSTEM_REQUEST_COUNT_COLUMNS](state) {
            return state.systemRequestCountColumns
        },
        [GET_SYSTEM_REQUEST_COUNT](state) {
            return state.systemRequestCount
        },
        [GET_SYSTEM_REQUEST_PERIOD_COUNT](state) {
            return state.systemRequestCountPeriod.toJS()
        },
        [GET_SYSTEM_HOT_REQUEST_DATA_COLUMNS](state) {
            return state.systemHotRequestDataColumns
        },
        [GET_SYSTEM_HOT_REQUEST_DATA](state) {
            return state.systemHotRequestData
        }
    },
    mutations: {
        [SET_ALL_SYSTEMS](state, data) {
            state.systems = data
        },

        [SET_ALL_SYSTEM_REQUEST_COUNT](state, data) {
            let seriesData = []
            let total = 0

            for (let item of data) {
                let s = {
                    name: item.metric.application,
                    y: +item.value[1]
                }

                total += +item.value[1]
                seriesData.push(s)
            }

            for (let item of seriesData) {
                item.y = item.y / total
            }

            state.systemAllRequestCount = state.systemAllRequestCount.setIn(['series', 0, 'data'], seriesData).setIn(['title', 'text'], '各接口调用总量')
        },

        [SET_ALL_SYSTEM_REQUEST_DETAIL](state, data) {
            let total = 0
            let detail = []

            for (let item of data) {
                total += +item.value[1]
            }

            for (let item of data) {
                let d = {
                    name: item.metric.application,
                    count: +item.value[1],
                    percentage: Math.round((+item.value[1] / total) * 100) + '%'
                }

                detail.push(d)
            }

            state.systemRequestDetail = detail
        },

        [SET_SYSTEM_INIT_GROUPS](state, data) {
            state.groups = data.groups
        },

        [SET_SYSTEM_INIT_INTERFACES](state, data) {
            state.interfaces = data.interfaces
        },

        [ADD_SYSTEM](state, data) {
            state.systems.push(data)
        },

        [UPDATE_SYSTEM](state, data) {
            for (let [index, system] of state.systems.entries()) {
                if (system.id == data.id) {
                    state.systems.splice(index, 1, data)
                }
            }
        },

        [DEL_SYSTEM](state, id) {
            for (let [index, system] of state.systems.entries()) {
                if (system.id == id) {
                    state.systems.splice(index, 1)
                }
            }
        },

        [SET_SYSTEM_REQUEST_INTERVAL_COUNT](state, warpperData) {
            let series = []
            let { title, data, categories, number } = warpperData

            for (let d of data) {
                let seriesData = {
                    name: d.metric.interface,
                    data: d.values.map(v => +v[1])
                }

                if (seriesData.data.length < number) {
                    seriesData.data = supplement(seriesData.data, number)
                }
                series.push(seriesData)
            }
            state.systemRequestCount2h = state.systemRequestCount2h.set('series', series).setIn(['title', 'text'], title).setIn(['xAxis', 'categories'], categories)
        },

        [CLEAR_SYSTEM_REQUEST_INTERVAL_COUNT](state) {
            state.systemRequestCount2h = Immutable.fromJS(intervalChartTemplate)
        },

        [SET_SYSTEM_REQUEST_COUNT](state, data) {
            let columns = [{
                title: '应用',
                prop: 'name'
            }]
            let tableData

            if (data.length) {
                tableData = {
                    name: data[0].metric.application
                }
            }
            let tableDataList = []

            for (let [index, d] of data.entries()) {
                let prop = 'interface' + index

                columns.push({
                    title: d.metric.interface,
                    prop
                })
                tableData[prop] = d.value[1]
            }
            if (tableData) {
                tableDataList.push(tableData)
            }
            state.systemRequestCountColumns = columns
            state.systemRequestCount = tableDataList
        },

        [SET_SYSTEM_REQUEST_PERIOD_COUNT](state, wrapperData) {
            let { title, number, data, categories } = wrapperData
            let series = []

            for (let d of data) {
                let seriesData = {
                    name: d.metric.interface,
                    data: d.values.map(v => +v[1])
                }

                if (seriesData.data.length < number) {
                    seriesData.data = supplement(seriesData.data, number)
                }
                series.push(seriesData)
            }

            state.systemRequestCountPeriod = state.systemRequestCountPeriod.set('series', series).setIn(['title', 'text'], title).setIn(['xAxis', 'categories'], categories)
        },

        [SET_SYSTEM_HOT_REQUEST_DATA](state, wrapperData) {
            let columns = []
            let tableData = []
            let { th, data } = wrapperData

            th = th.reverse()
            th.unshift('点位')

            for (let [index, t] of th.entries()) {
                columns.push({
                    title: t,
                    prop: `prop${index}`
                })
            }

            for (let d of data) {
                let tmpData = {
                    prop0: d.metric.interface
                }

                if (d.values.length < 4) {
                    d.values = supplement(d.values, 4, [0, 0])
                }
                for (let [index, item] of d.values.reverse().entries()) {
                    tmpData[`prop${index + 1}`] = item[1]
                }
                tableData.push(tmpData)
            }

            state.systemHotRequestDataColumns = columns
            state.systemHotRequestData = tableData
        }
    },
    actions: {
        [FETCH_ALL_SYSTEM_REQUEST_COUNT](context) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=sort_desc(sum(requests_count)without(interface))`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                if (data.result.length != 0) {
                    context.commit(SET_ALL_SYSTEM_REQUEST_COUNT, data.result)
                    context.commit(SET_ALL_SYSTEM_REQUEST_DETAIL, data.result)
                }
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_ALL_SYSTEM_REQUEST_COUNT', e)
                }
            })
        },

        [FETCH_SYSTEM_REQUEST_INTERVAL_COUNT](context, {
            name = '',
            start = '',
            end = '',
            number = 13
        }) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(increase(requests_count{application="${name}"}[2h]))&start=${start}&end=${end}&step=2h`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                context.commit(SET_SYSTEM_REQUEST_INTERVAL_COUNT, {
                    number,
                    title: data.result.length != 0 ? `${name} 接口调用量实时统计` : '暂无数据',
                    categories: splitTime({
                        start,
                        // 服务端会返回13个点,所以切割时间加一小时
                        end: end + 2 * 60 * 60,
                        interval: 2 * 60 * 60,
                        format: 'h:m'
                    }),
                    data: data.result
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_SYSTEM_REQUEST_INTERVAL_COUNT', e)
                }
            })
        },

        [FETCH_SYSTEM_REQUEST_PERIOD_COUNT](context, {
            name = '',
            start = '',
            end = '',
            number = ''
        }) {
            fetch(`${context.getters[GET_PROMETHEUS_QUERY_RANGE]}?query=round(increase(requests_count{application="${name}"}[24h]))&start=${start}&end=${end}&step=24h`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                context.commit(SET_SYSTEM_REQUEST_PERIOD_COUNT, {
                    number,
                    title: data.result.length != 0 ? '' : '暂无数据',
                    categories: splitTime({
                        start,
                        end,
                        interval: 24 * 60 * 60,
                        format: 'M-D'
                    }),
                    data: data.result
                })
                context.commit(SET_SYSTEM_HOT_REQUEST_DATA, {
                    th: splitTime({
                        start: end - 3 * 24 * 60 * 60,
                        end,
                        interval: 24 * 60 * 60,
                        format: 'M-D'
                    }),
                    data: data.result
                })
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_SYSTEM_REQUEST_PERIOD_COUNT', e)
                }
            })
        },

        [FETCH_SYSTEM_REQUEST_COUNT](context, name) {
            let roundParams = `requests_count{application="${name}"}`

            fetch(`${context.getters[GET_PROMETHEUS_QUERY]}?query=round(${roundParams})`).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                return new Promise((resolve, reject) => {
                    if (data.status == 'success') {
                        resolve(data.data)
                    } else {
                        reject()
                    }
                })
            }).then(data => {
                context.commit(SET_SYSTEM_REQUEST_COUNT, data.result)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_SYSTEM_REQUEST_COUNT', e)
                }
            })
        },

        [FETCH_ALL_SYSTEMS](context, { name = '' } = {}) {
            let getUrl = `${context.getters[GET_SERVICES].Skylab}applications/`

            if (name) {
                getUrl += `?name=${encodeURIComponent(name)}`
            }
            fetch(getUrl, {
                credentials: 'include',
            }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(SET_ALL_SYSTEMS, data.data)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_ALL_SYSTEMS', e)
                }
            })
        },

        [POST_SYSTEM](context, {
            name = '',
            expireTime = '',
            groups = [],
            Interfaces = [],
            remark = ''
        } = {}) {
            fetch(`${context.getters[GET_SERVICES].Skylab}applications/`, {
                method: 'POST',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name,
                    'expire_time': expireTime,
                    groups: groups.join(','),
                    interfaces: Interfaces.join(','),
                    remark
                })
            }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(ADD_SYSTEM, data.data)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('POST_SYSTEM', e)
                }
            })
        },

        [PUT_SYSTEM](context, {
            id = '',
            name = '',
            expireTime = '',
            groups = [],
            Interfaces = [],
            remark = ''
        } = {}) {
            fetch(`${context.getters[GET_SERVICES].Skylab}applications/${id}`, {
                method: 'PUT',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name,
                    'expire_time': expireTime,
                    groups: groups.join(','),
                    interfaces: Interfaces.join(','),
                    remark
                })
            }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(UPDATE_SYSTEM, data.data)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('PUT_SYSTEM', e)
                }
            })
        },

        [DELETE_SYSTEM](context, id) {
            fetch(`${context.getters[GET_SERVICES].Skylab}applications/${id}`, {
                method: 'DELETE',
                credentials: 'include'
            }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(DEL_SYSTEM, id)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('DELETE_SYSTEM', e)
                }
            })
        },

        [FETCH_SYSTEM_INIT_DATA](context) {
            return new Promise((resolve, reject) => {
                fetch(`${context.getters[GET_SERVICES].Skylab}applications/init`, {
                    credentials: 'include'
                }).then(res => {
                    return analyzeHttpCode(res)
                }).then(data => {
                    context.commit(SET_SYSTEM_INIT_GROUPS, data.data)
                    context.commit(SET_SYSTEM_INIT_INTERFACES, data.data)
                    resolve()
                }).catch(e => {
                    if (e.type) {
                        context.commit(SET_ERROR, e.message)
                    } else {
                        printError('FETCH_SYSTEM_INIT_DATA', e)
                    }
                })
            })
        }
    }
}
