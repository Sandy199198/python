import { USER } from 'common/namespace'
import Vue from 'vue'
import { SET_ERROR, GET_SERVICES } from 'store/modules/common'
import { analyzeHttpCode, printError} from 'common/utils'

export const GET_USER_LIST = `${USER}/getUserList`
export const SET_USER_LIST = `${USER}/setUserList`
export const FETCH_USER_LIST = `${USER}/fetchUserList`
export const DEL_USER = `${USER}/delUser`
export const RESET_PASSWORD = `${USER}/resetPassword`
export const SET_USER = `${USER}/setUser`
export const ADD_USER = `${USER}/addUser`
export const SET_PAGE = `${USER}/setPage`
export const GET_PAGE = `${USER}/getPage`

export default {
    state: {
        users: [],
        page: {},
    },
    getters: {
        [GET_USER_LIST](state) {
            return state.users
        },
        [GET_PAGE](state) {
            return state.page
        }
    },
    mutations: {
        [SET_USER_LIST](state, data) {
            state.users = data
        },
        [SET_PAGE](state, page) {
            state.page = Object.assign({}, page)
        },
        [ADD_USER](state, data) {
            state.users.unshift(data)
        },
        [SET_USER](state, data) {
            for (let [index, user] of state.users.entries()) {
                if (user.user_id == data.user_id) {
                    state.users.splice(index, 1, data)
                }
            }

        },
        [DEL_USER](state, data) {
            for (let [i, a] of state.users.entries()) {
                if (a.user_id == data.user_id) {
                    state.users.splice(i, 1)
                    break
                }
            }
        }
    },
    actions: {
        [FETCH_USER_LIST](context, user) {
            let params = []
            let url = `${context.getters[GET_SERVICES].Skylab}users/`

            for (let key in user) {
                if (user[key]) {
                    if (key == 'userGroupId') {
                        params.push('user_group_id' + '=' + user[key])
                    } else {
                        params.push(key + '=' + user[key])
                    }
                }
            }

            params = params.join('&')
            if (params) {
                url += '?' + params
            }
            fetch(url, { credentials: 'include' }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(SET_USER_LIST, data.data)
                context.commit(SET_PAGE, data.paging)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('FETCH_USER_LIST', e)
                }
            })
        },
        [DEL_USER](context, user) {
            let id = user.user_id
            let groupId = user.user_group_id

            fetch(`${context.getters[GET_SERVICES].Skylab}usergroups/` + groupId + '/users/' + id, { credentials: 'include', method: 'DELETE' }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(DEL_USER, user)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('DEL_USER', e)
                }
            })
        },
        [RESET_PASSWORD](context, user) {
            let groupId = user.user_group_id
            let id = user.user_id

            fetch(`${context.getters[GET_SERVICES].Skylab}usergroups/` + groupId + '/users/' + id + '/password', { credentials: 'include', method: 'PUT' }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                //context.commit(DEL_USER, user)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('RESET_PASSWORD', e)
                }
            })
        },
        [SET_USER](context, user) {
            let groupId = user.user_group_id
            let id = user.user_id

            fetch(`${context.getters[GET_SERVICES].Skylab}usergroups/` + groupId + '/users/' + id, {
                credentials: 'include',
                method: 'PUT',
                body: JSON.stringify(user),
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(SET_USER, data.data)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('SET_USER', e)
                }
            })
        },
        [ADD_USER](context, user) {
            let params = {}
            let groupId = user.userGroupId

            for (let key in user) {
                if (user[key]) {
                    if (key == 'userGroupId') {
                        params['user_group_id'] = user[key]
                    } else {
                        params[key] = user[key]
                    }
                }
            }
            fetch(`${context.getters[GET_SERVICES].Skylab}usergroups/` + groupId + '/users/', {
                credentials: 'include',
                method: 'POST',
                body: JSON.stringify(params),
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(res => {
                return analyzeHttpCode(res)
            }).then(data => {
                context.commit(ADD_USER, data.data)
            }).catch(e => {
                if (e.type) {
                    context.commit(SET_ERROR, e.message)
                } else {
                    printError('ADD_USER', e)
                }
            })
        }
    }
}
