import Vue from 'vue'
import Vuex from 'vuex'

import common from 'store/modules/common'
import branchStatistics from 'store/modules/branch-statistics'
import cameras from 'store/modules/cameras'
import alarms from 'store/modules/alarms'
import userInfo from 'store/modules/user_info'
import userGroupInfo from 'store/modules/user_group_info'
import citywideInfo from 'store/modules/citywide_info'
import system from 'store/modules/system'
import auth from 'store/modules/auth'
import systemFrequency from 'store/modules/system_frequency'
import logs from 'store/modules/logs'
import resource from 'store/modules/resource'
import analysis from 'store/modules/analysis'
import realtime from 'store/modules/realtime'
import group from 'store/modules/group'
import member from 'store/modules/member'
import search from 'store/modules/search'
import captureHistory from 'store/modules/capture_history'
import alarmHistory from 'store/modules/alarm_history'
import cheat from 'store/modules/cheat'
import core from 'store/modules/core'
import serverConfig from 'store/modules/server_config'
import cameraSetting from 'store/modules/camera_setting'
import client from 'store/modules/client'
import deployment from 'store/modules/deployment'
import imageFilter from 'store/modules/image_filter'
import imageCrop from 'store/modules/image_crop'

Vue.use(Vuex)

const store = new Vuex.Store({
    modules: {
        common,
        branchStatistics,
        cameras,
        alarms,
        userInfo,
        userGroupInfo,
        citywideInfo,
        system,
        auth,
        systemFrequency,
        logs,
        resource,
        analysis,
        realtime,
        group,
        member,
        search,
        captureHistory,
        alarmHistory,
        cheat,
        core,
        serverConfig,
        cameraSetting,
        client,
        deployment,
        imageFilter,
        imageCrop
    }
})

export default store
