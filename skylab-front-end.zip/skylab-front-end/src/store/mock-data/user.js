import Mock from 'mockjs'

export const users = {
    data: [{
        userId: 1,
        userGroupId: 1,
        username: 'admin',
        resetPassword: false,
        role: 2,
        notifacation: 1,
        realName: 'admin',
        phone: '11111',
        mail: '-',
        remark: '-'
    }, {
        userId: 2,
        userGroupId: 1,
        username: 'user',
        resetPassword: false,
        role: 2,
        notifacation: 1,
        realName: 'user',
        phone: '11111',
        mail: '-',
        remark: '-'
    }]
}
