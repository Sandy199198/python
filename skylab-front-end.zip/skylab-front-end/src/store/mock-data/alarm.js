import Mock from 'mockjs'

export function getAlarm() {
    return Mock.mock({
        'data|1': [{
            'id': '@increment(1)',
            'camera_id|1-5': 1,
            'camera_name': '@cname',
            'camera_location': '@county',
            'face': '@image("70x70","#666","#FFF","png","pic")',
            'target_face': '@image("70x70","#50B347","#FFF","png","pic")',
            'score|1-100': 100,
            'group|1': [
                '杀人犯',
                '在逃犯',
                '抢劫犯'
            ],
            'target_name': '@cname',
            'timestamp': '@now'
        }]

    })
}
