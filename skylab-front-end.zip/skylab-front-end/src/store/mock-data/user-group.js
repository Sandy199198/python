import Mock from 'mockjs'

export const userGroups = {
    data: [{
        id: 1,
        name: 'group1',
        remark: '-',
        users: [{
            userId: 2,
            userGroupId: 1,
            username: 'user',
            resetPassword: false,
            role: 2,
            notifacation: 1,
            realName: 'user',
            phone: '11111',
            mail: '-',
            remark: '-'
        }, {
            userId: 1,
            userGroupId: 1,
            username: 'admin',
            resetPassword: false,
            role: 2,
            notifacation: 1,
            realName: 'admin',
            phone: '11111',
            mail: '-',
            remark: '-'
        }]
    }, {
        id: 2,
        name: 'group2',
        remark: '-',
        users: [{
            userId: 2,
            userGroupId: 1,
            username: 'user',
            resetPassword: false,
            role: 2,
            notifacation: 1,
            realName: 'user',
            phone: '11111',
            mail: '-',
            remark: '-'
        }, {
            userId: 1,
            userGroupId: 1,
            username: 'admin',
            resetPassword: false,
            role: 2,
            notifacation: 1,
            realName: 'admin',
            phone: '11111',
            mail: '-',
            remark: '-'
        }]
    }]
}
