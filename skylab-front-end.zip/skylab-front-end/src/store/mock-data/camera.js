import Mock from 'mockjs'

export const cameras = {
    data: [{
        id: 1,
        latlng: '13392259.418932473, 3711032.0551881073',
        name: 'camera1'
    }, {
        id: 2,
        latlng: '13401431.862326695, 3701859.611793886',
        name: 'camera2'
    }, {
        id: 3,
        latlng: '13431395.177414482, 3719898.7504691877',
        name: 'camera3'
    }, {
        id: 4,
        latlng: '13352359.290167611, 3740995.370275896',
        name: 'camera4'
    }, {
        id: 5,
        latlng: '13359544.370826418, 3720357.3726388984',
        name: 'camera5'
    }]
}
