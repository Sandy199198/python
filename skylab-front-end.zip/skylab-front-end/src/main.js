import Vue from 'vue'
import VueRouter from 'vue-router'

import URL from 'common/url'

import router from 'pages/main/router'
import store from 'store/store'
import parts from 'common/parts'
import { CHECK_LOGIN } from 'store/modules/auth'
import { FETCH_SERVICES, GET_SERVICES } from 'store/modules/common'
import { GET_USER_INFO } from 'store/modules/auth'


import SkeletonComponent from 'pages/main/skeleton.vue'

import 'styles/reset.css'
import 'styles/main.scss'

Vue.use(VueRouter)
parts(Vue)

router.beforeEach((to, from, next) => {
    let initInterface

    if (to.name == URL.LOGIN) {
        store.dispatch(CHECK_LOGIN).then(() => {
            let redirect = decodeURIComponent(to.query.redirect)

            if (to.query.redirect) {
                redirect += redirect.indexOf('?') != -1 ? `&user_id=${store.getters[GET_USER_INFO].user_id}` : `?user_id=${store.getters[GET_USER_INFO].user_id}`
                window.location.href = redirect
            } else {
                next({
                    name: URL.HOME
                })
            }
        }).catch(e => {
            next()
        })
    } else {
        store.dispatch(CHECK_LOGIN).then(() => {
            if (Object.keys(store.getters[GET_SERVICES]).length == 1) {
                store.dispatch(FETCH_SERVICES).then(() => {
                    next()
                })
            } else {
                next()
            }
        }).catch(e => {
            console.log('login 过期了')
            next({
                name: URL.LOGIN,
                // params: {
                //     redirect: to
                // }
            })
        })
    }
})

const app = new Vue({
    template: `
        <SkeletonComponent>
            <transition name="page" mode="out-in"
                @before-enter="beforeEnter"
                @after-enter="afterEnter"
                @before-leave="beforeLeave"
            >
                <router-view></router-view>
            </transition>
        </SkeletonComponent>
    `,
    store,
    router,
    components: {
        SkeletonComponent
    },
    methods: {
        beforeEnter(el) {
            if (el.dataset.role == URL.HOME) {
                for (let item of el.querySelectorAll('.item')) {
                    item.style.opacity = 0
                }
            }
        },
        afterEnter(el) {
            if (el.dataset.role == URL.HOME) {
                for (let item of el.querySelectorAll('.item')) {
                    setTimeout(() => {
                        item.style.opacity = 1
                    }, 0)
                }
            }
        },
        beforeLeave(el) {
            if (el.dataset.role == URL.HOME) {
                for (let item of el.querySelectorAll('.item')) {
                    item.style.display = 'none'
                }
            }
        }
    }
}).$mount('#main')

let timer

window.onresize = function () {
    clearTimeout(timer)
    timer = setTimeout(() => {
        // window.location.reload()
    }, 1500)
}
