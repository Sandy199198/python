<template>
    <div class="deploy-setting">
        <div class="table_content">
            <TableComponent :data="getDeploy" :columns="deployColumns" class="deploys">
                <span v-for="(item, index) in this.getDeploy" :slot="'element' + index">
                    <div v-if="item.groups.length == 0">
                        <span>-</span>
                    </div>
                    <div v-else>
                        <p v-for="i in item.groups">
                            <span>{{i.name}}:&nbsp;{{i.trusted_db_threshold}},&nbsp;{{i.untrusted_db_threshold}},&nbsp;{{i.trusted_query_threshold}},&nbsp;{{i.untrusted_query_threshold}}</span>
                        </p>
                    </div>
                </span>
                <span v-for="(item, index) in this.getDeploy" :slot="'events' + index">
                    <a href="#" title="编辑" @click.prevent="editDeploy(index)">编辑</a>
                </span>
            </TableComponent>
            <ConfirmComponent :show="deployEditObj.show" :title="deployEditObj.text" :confirm="deployEditObj.confirm">
                <div slot="content">
                    <div class="panel-body" style="padding-left: -11px;">
                        <div class="form-group">
                            <label class="control-label col3">布控名称</label>
                            <div class="col9">
                                <input type="text" name="groupname" placeholder="必填" class="form-control" disabled v-model="deployGroupData.name"/>
                            </div>
                        </div>
                        <div class="form-group video-title-con">
                            <label class="col3 control-label"></label>
                            <div class="col9">
                                <div class="video-title">
                                    <span>目标库报警</span>
                                    <span>干扰库报警</span>
                                    <span>目标库推送</span>
                                    <span>干扰库推送</span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group" v-for="item in deployTempList">
                            <label class="control-label col3">{{item.name}}</label>
                            <div class="col9">
                                <div class="threshold-con">
                                    <input class="threshold" v-model.number="item.trusted_db_threshold" type="number"/>
                                    <input class="threshold" v-model.number="item.untrusted_db_threshold" type="number"/>
                                    <input class="threshold" v-model.number="item.trusted_query_threshold" type="number"/>
                                    <input class="threshold" v-model.number="item.untrusted_query_threshold" type="number"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
        </div>    
    </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import TableComponent from '@nanyun/table'
import PaginationComponent from '@nanyun/pagination'
import ConfirmComponent from '@nanyun/confirm'
import {GET_DEPLOY, FETCH_DEPLOY, SET_DEPLOY, UPDATE_DEPLOY} from
'store/modules/cheat'
import { STATUS } from 'common/config'

export default {
    data() {
        return {
            deployGroupData: {},
            deploySearchObj: {},
            deployEditObj: {
                autoClose: 10000,
                text: '编辑底库',
                show: {
                    value: false
                },
                confirm: () => {
                    this.deploySearchObj.options = []
                    this.deployTempList.map((item) => {
                        item['trusted_db_threshold'] = parseFloat(item['trusted_db_threshold'])
                        item['untrusted_db_threshold'] = parseFloat(item['untrusted_db_threshold'])
                        item['trusted_query_threshold'] = parseFloat(item['trusted_query_threshold'])
                        item['untrusted_query_threshold'] = parseFloat(item['untrusted_query_threshold'])
                        this.deploySearchObj.options.push(Object.assign({}, item))
                    })
                    this.updateDeploy(this.deploySearchObj).then(() => {
                        this.fetchDeploy()
                    })
                }
            },
            deployAllBranch: [],
            deployColumns: [{
                title: '布控名称',
                prop: 'name'
            }, {
                title: '底库相关',
                prop: 'groups',
                type: 'element',
            }, {
                title: '操作',
                type: 'events'
            }],
            deployTempList: [],
        }
    },
    created() {
        this.fetchData()
    },
    computed: {
        ...mapGetters({
            getDeploy: GET_DEPLOY
        }),
    },
    methods: {
        fetchData() {
            this.fetchDeploy()
        },
        ...mapActions({
            fetchDeploy: FETCH_DEPLOY,
            setDeploy: SET_DEPLOY,
            updateDeploy: UPDATE_DEPLOY
        }),
        editDeploy(index) {
            this.deployEditObj.show.value = !this.deployEditObj.show.value
            this.deployGroupData = Object.assign({}, this.getDeploy[index])
            this.deployTempList = []
            this.deployGroupData.groups.map((item) => {
                this.deployTempList.push(Object.assign({}, item))
            })
            this.deploySearchObj = Object.assign({}, {
                id: this.deployGroupData.id
            })
        }
    },
    components: {
        TableComponent,
        PaginationComponent,
        ConfirmComponent
    }
}
</script>

<style scoped>
    .deploy-setting{
        height: 100%;
        background: #1d2c3f;
        padding: 50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        width: 100%;
        /*margin: 20px 55px 70px 25px;*/
        .condition{
            margin-top: 16px;
            margin-bottom: 15px;
            input{
                height: 16px;
            }
            .btn{
                display: inline-block;
                color: #fff;
                text-decoration: none;
                padding-left: 32px;
                padding-right: 32px;
                margin-left: 17px;
                background: #4990e2;
                border-radius: 3px;
                font-size: 12px;
                line-height: 2;
                &.search{
                    vertical-align: top;
                }
            }
        }
        .form-group{
            height: 40px;
            position: relative;
            margin-left: -11px;
            margin-right: -11px;
            &.video-title-con{
                height: 26px;
                line-height: 26px;
            }
        }
        .col3{
            width: 25%;
            float: left;
            min-height: 1px;
        }
        .col9{
            width:70%;
            float:left;
            min-height: 1px;
            .threshold-con{
                display: flex;
            }
            input.threshold{
                flex: 1;
                max-width: 60px;
                margin-right: 5px;
            }
        }
        .control-label{
            padding-right: 15px;
            padding-top: 5px;
            text-align: right;
        }
        lable{
            line-height: 32px;
            display: inline-block;
            margin-bottom: 5px;
        }
        .form-select{
            width: 84%;
        }
        .minWidth{
            min-width:150px;
        }
        input:disabled{
            cursor: not-allowed;
            background-color: #eeeeee;
        }
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button{
            -webkit-appearance: none !important;
            margin: 0; 
        }
        .video-title{
            display: flex;
            span{
                flex: 1;
            }
        }
        .deploys{
            margin-top: 20px;
        }
    }
</style>