<template>
    <div class="user">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="table_content">
            <div class="condition">
                名称：
                <input type="text"  class="input-style minWidth150" placeholder="请输入名称" v-model="searchName"/>
                手机号：
                <input type="text"  class="input-style minWidth150" placeholder="请输入手机号" v-model="searchPhone"/>
                邮箱：
                <input type="text"  class="input-style minWidth150" placeholder="请输入邮箱" v-model="searchEmail"/>
                用户分组：
                <select class="select input-style minWidth150" name="searchGroupName">
                    <option value="">用户分组/不限</option>
                    <option v-for="option in this.getUserGroupList" :value="option.id">{{option.name}}</option>
                </select>
                <a href="#" @click.prevent="search()" class="button-style">搜&nbsp;索</a>
                <a href="#" @click.prevent="add()" class="button-style" style="float:right;">新&nbsp;建</a>
            </div>
            <TableComponent :data="getUserList" :columns="columns">
                <span v-for="(item, index) in this.getUserList" :slot="'events' + index">
                    <a href="#" title="修改"  @click.prevent="edit(index)">修改</a>
		            &nbsp;&nbsp;
                    <a href="#" title="删除"  @click.prevent="del(index)">删除</a>
                    &nbsp;&nbsp;
                    <a href="#" title="重置密码"  @click.prevent="reset(index)" v-if="item.role == '3'">重置密码</a>
                </span>
            </TableComponent>
            <div style="overflow:hidden">
                <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
            </div>
            <ConfirmComponent :show="deleteObj.show" :title="deleteObj.text" :content="deleteObj.content" :confirm="deleteObj.confirm"> 
            </ConfirmComponent>
            <ConfirmComponent :show="resetPasswordObj.show" :title="resetPasswordObj.text" :content="resetPasswordObj.content" :confirm="resetPasswordObj.confirm"> 
            </ConfirmComponent>
            <ConfirmComponent :show="editObj.show" :title="editObj.text" :confirm="editObj.confirm"> 
                <div slot="content">
                    <div class="panel-body" style="padding-top:-11px;">
                        <div class="form-group">
                            <label class="control-label col3">用户名</label>
                            <div class="col9">
                                <input type="text" name="username" placeholder="必填" class="form-control form-input" v-if="userData.user_id" disabled  v-model="userData.username"/>
                                <input type="text" name="username" placeholder="必填" class="form-control form-input" v-model="userData.username" v-else/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">姓名</label>
                            <div class="col9">
                                <input type="text" name="real_name" placeholder="必填" class="form-control form-input" v-model="userData.real_name"/>
                            </div>
                        </div>
                        <div class="form-group" v-show="!userData.user_id">
                            <label class="control-label col3">密码</label>
                            <div class="col9">
                                <input type="password" name="password" placeholder="必填" class="form-control form-input" v-model="userData.password"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">用户类型</label>
                            <div class="col9" v-if="userData.role">
                                <select v-model="userData.role" class="form-control form-select" name="role">
                                    <option v-for="option in userData.roles" :value="option.value">{{option.text}}</option>
                                </select>
                            </div>
                            <div class="col9" v-else>
                                <select class="form-control form-select" name="role">
                                    <option v-for="option in userData.roles" :value="option.value">{{option.text}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">用户分组</label>
                            <div class="col9" v-if="userData.user_group_id">
                                <select v-model="userData.user_group_id" class="form-control  form-select" name="user_group_id">
                                    <option v-for="option in userData.groups" :value="option.id">{{option.name}}</option>
                                </select>
                            </div>
                            <div class="col9" v-else>
                                <select class="form-control  form-select" name="user_group_id">
                                    <option v-for="option in userData.groups" :value="option.id">{{option.name}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">手机号</label>
                            <div class="col9">
                                <input type="text" name="phone" placeholder="选填" class="form-control form-input" v-model="userData.phone"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">邮箱</label>
                            <div class="col9">
                                <input type="text" name="mail" placeholder="选填" class="form-control form-input" v-model="userData.mail"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">是否告警</label>
                            <div class="col9" v-if="userData.notification">
                                <select v-model="userData.notification" class="form-control  form-select" name="notification">
                                    <option v-for="option in userData.notifications" :value="option.value">{{option.text}}</option>
                                </select>
                            </div>
                            <div class="col9" v-else>
                                <select class="form-control  form-select" name="notification">
                                    <option v-for="option in userData.notifications" :value="option.value">{{option.text}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">备注</label>
                            <div class="col9">
                                <textarea name="remark" class="form-control form-textarea" rows="3" v-model="userData.remark"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
        </div>
    </div>
</template>

<script>
    import TableComponent from '@nanyun/table'
    import ConfirmComponent from '@nanyun/confirm'
    import PaginationComponent from '@nanyun/pagination'
    import {GET_USER_LIST, FETCH_USER_LIST, DEL_USER, RESET_PASSWORD, SET_USER, ADD_USER, GET_PAGE} from 'store/modules/user_info'
    import {GET_USER_GROUP_LIST, FETCH_USER_GROUP_LIST} from 'store/modules/user_group_info'
    import { ROLES, NOTIFICATIONS } from 'common/config'
    import FormFieldComponent from 'common/components/form-field.vue'
    import { mapActions, mapGetters, mapMutations } from 'vuex'
    import CrumbsComponent from 'common/components/crumbs.vue'
    import URL from 'common/url'

    export default {
        data() {
            return {
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '用户管理',
                    silent: true
                }],
                columns: [{
                    title: '用户名',
                    prop: 'username',
                    handle: d => {
                        return d ? d : '-'
                    }
                }, {
                    title: '姓名',
                    prop: 'real_name',
                    handle: d => {
                        return d ? d : '-'
                    }
                }, {
                    title: '用户类型',
                    prop: 'role',
                    handle: d => {
                        let roleName = '-'

                        ROLES.forEach(function (role) {
                            if (role.value == d) {
                                roleName = role.text
                            }
                        })
                        return roleName
                    }
                }, {
                    title: '用户分组',
                    prop: 'user_group_id',
                    handle: d => {
                        let groupName = '-'

                        this.getUserGroupList.forEach(function (group) {
                            if (group.id == d) {
                                groupName = group.name
                            }
                        })
                        return groupName
                    }
                }, {
                    title: '手机号',
                    prop: 'phone',
                    handle: d => {
                        return d ? d : '-'
                    }
                }, {
                    title: '邮箱',
                    prop: 'mail',
                    handle: d => {
                        return d ? d : '-'
                    }
                }, {
                    title: '告警通知',
                    prop: 'notification',
                    handle: d => {
                        let notificationName = '-'

                        NOTIFICATIONS.forEach(function (notification) {
                            if (notification.value == d) {
                                notificationName = notification.text
                            }
                        })
                        return notificationName
                    }
                }, {
                    title: '备注',
                    prop: 'remark',
                    handle: d => {
                        return d ? d : '-'
                    }
                }, {
                    title: '操作',
                    type: 'events'
                }],
                deleteObj: {
                    autoClose: 10000,
                    text: '确认删除',
                    content: '确定删除该用户?',
                    show: {
                        value: false
                    },
                    confirm: () => {
                        this.delUser(this.getUserList[this.index])
                    }
                },
                editObj: {
                    autoClose: 10000,
                    text: this.index ? '编辑用户' : '新增用户',
                    show: {
                        value: false
                    },
                    confirm: () => {
                        if (this.index === '') {
                            this.userData.role = document.querySelector('[name=role]').value
                            this.userData.userGroupId = document.querySelector('[name=user_group_id]').value
                            this.userData.notification = document.querySelector('[name=notification]').value
                            this.addUser(this.userData)
                        } else {
                            this.setUser(this.userData)
                        }
                    }
                },
                resetPasswordObj: {
                    autoClose: 10000,
                    text: '密码重置',
                    content: '密码将被重置为该用户用户名，确定要重置该用户密码吗?',
                    show: {
                        value: false
                    },
                    confirm: () => {
                        this.resetPassword(this.getUserList[this.index])
                    }
                },
                searchObj: {},
                userData: {},
                index: ''
            }
        },

        created() {
            this.fetchData()
        },

        computed: {
            ...mapGetters({
                getUserList: GET_USER_LIST,
                getUserGroupList: GET_USER_GROUP_LIST,
                getPage: GET_PAGE
            })
        },

        methods: {
            fetchData() {
                this.fetchUserList(this.searchObj)
                this.fetchUserGroupList()
            },
            ...mapActions({
                fetchUserList: FETCH_USER_LIST,
                fetchUserGroupList: FETCH_USER_GROUP_LIST,
                delUser: DEL_USER,
                resetPassword: RESET_PASSWORD,
                setUser: SET_USER,
                addUser: ADD_USER
            }),
            edit(index) {
                this.editObj.show.value = !this.editObj.show.value
                this.userData = Object.assign({}, this.getUserList[index])
                this.userData.notifications = NOTIFICATIONS
                this.userData.roles = ROLES
                this.userData.groups = this.getUserGroupList
                this.index = index
            },
            add() {
                this.userData = {}
                this.editObj.show.value = !this.editObj.show.value
                this.userData.notifications = NOTIFICATIONS
                this.userData.roles = ROLES
                this.userData.groups = this.getUserGroupList
                this.index = ''
            },
            del(index) {
                this.deleteObj.show.value = !this.deleteObj.show.value
                this.index = index
            },
            reset(index) {
                this.resetPasswordObj.show.value = !this.resetPasswordObj.show.value
                this.index = index
            },
            search() {
                this.searchObj = {
                    username: this.searchName,
                    phone: this.searchPhone,
                    email: this.searchEmail,
                    userGroupId: document.querySelector('[name=searchGroupName]').value
                }

                this.fetchData(this.searchObj)
            },
            pageEvent(page) {
                this.searchObj = {
                    username: this.searchName,
                    phone: this.searchPhone,
                    email: this.searchEmail,
                    userGroupId: document.querySelector('[name=searchGroupName]').value,
                    page: page,
                    size: this.getPage.size
                }
                this.fetchData()
            }
        },
        components: {
            TableComponent,
            ConfirmComponent,
            PaginationComponent,
            FormFieldComponent,
            CrumbsComponent
        }
    }
</script>

<style scoped>
    .user{
        padding:50px 80px;
        box-sizing: border-box;
        min-height: 100%;
    }
    .table_content{
        width:100%;
        .condition {
            color:#fff;
            margin-bottom: 30px;
        }
        input, select{
            margin-right:20px;
        }
    }
    .panel-body{
        height: 400px;
    }
    .form-select{
        width: 84%;
    }
    .minWidth{
        min-width:150px;
    }
    
</style>