<template>
    <div class="userGroup">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="table_content">
            <div class="condition">
                分组名称：
                <input type="text" placeholder="请输入分组名称" name="searchName" class="input-style minWidth" v-model="searchName"/>
                <a href="#" @click.prevent="search()" class="button-style">搜&nbsp;索</a>
                <a href="#" @click.prevent="add" class="button-style" style="float:right">新&nbsp;建</a>
            </div>
            <TableComponent :data="getUserGroupList" :columns="columns">
                <span v-for="(item, index) in this.getUserGroupList" :slot="'events' + index">
                    <a href="#" @click.prevent="edit(index)">编辑</a>
                    <a href="#" @click.prevent="del(index)">删除</a>
                </span>
            </TableComponent>
            <div style="overflow:hidden">
                <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
            </div>
            <ConfirmComponent :show="deleteObj.show" :title="deleteObj.text" :content="deleteObj.content" :confirm="deleteObj.confirm"> 
            </ConfirmComponent>
            <ConfirmComponent :show="editObj.show" :title="editObj.text" :confirm="editObj.confirm"> 
                <div slot="content">
                    <div class="panel-body" style="padding-top:-11px;">
                        <div class="form-group">
                            <label class="control-label col3">用户分组名称</label>
                            <div class="col9 simple">
                                <input type="text" name="name" placeholder="必填" class="form-control form-input" v-model="userGroupData.name"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">备注</label>
                            <div class="col9 simple">
                                <textarea name="remark" class="form-control form-textarea" rows="3" v-model="userGroupData.remark"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
        </div>
    </div>
</template>

<script>
    import TableComponent from '@nanyun/table'
    import ConfirmComponent from '@nanyun/confirm'
    import PaginationComponent from '@nanyun/pagination'
    import {GET_USER_GROUP_LIST, FETCH_USER_GROUP_LIST, DEL_USER_GROUP, ADD_USER_GROUP, SET_USER_GROUP, GET_PAGE} from 'store/modules/user_group_info'
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    import CrumbsComponent from 'common/components/crumbs.vue'
    import URL from 'common/url'

    export default{
        data() {
            return {
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '用户管理组',
                    silent: true
                }],
                columns: [{
                    title: '分组名称',
                    prop: 'name',
                    handle: d => {
                        return d ? d : '-'
                    }
                }, {
                    title: '用户数',
                    prop: 'users',
                    handle: d => {
                        return d ? d.length : 0
                    }
                }, {
                    title: '备注',
                    prop: 'remark',
                    handle: d => {
                        return d ? d : '-'
                    }
                }, {
                    title: '操作',
                    type: 'events'
                }],
                deleteObj: {
                    autoClose: 10000,
                    text: '确认删除',
                    content: '确定删除该用户组?',
                    show: {
                        value: false
                    },
                    confirm: () => {
                        this.delUserGroup(this.getUserGroupList[this.index])
                    }
                },
                editObj: {
                    autoClose: 10000,
                    text: '编辑用户组',
                    show: {
                        value: false
                    },
                    confirm: () => {
                        if (this.index === '') {
                            this.addUserGroup(this.userGroupData)
                        } else {
                            this.setUserGroup(this.userGroupData)
                        }
                    }
                },
                index: '',
                userGroupData: {}
            }
        },

        created() {
            this.fetchData()
        },

        computed: {
            ...mapGetters({
                getUserGroupList: GET_USER_GROUP_LIST,
                getPage: GET_PAGE
            })
        },

        methods: {
            fetchData() {
                this.fetchUserGroupList(this.userGroupData)
            },
            ...mapActions({
                fetchUserGroupList: FETCH_USER_GROUP_LIST,
                delUserGroup: DEL_USER_GROUP,
                addUserGroup: ADD_USER_GROUP,
                setUserGroup: SET_USER_GROUP
            }),
            edit(index) {
                this.editObj.show.value = !this.editObj.show.value
                this.userGroupData = Object.assign({}, this.getUserGroupList[index])
                this.index = index
            },
            del(index) {
                this.deleteObj.show.value = !this.deleteObj.show.value
                this.userGroupData = this.getUserGroupList[index]
                this.index = index
            },
            add() {
                this.editObj.show.value = !this.editObj.show.value
                this.userGroupData = {}
                this.index = ''
            },
            search() {
                this.userGroupData = {
                    name: this.searchName
                }
                this.fetchData()
            },
            pageEvent(page) {
                this.userGroupData = {
                    name: this.searchName,
                    page: page,
                    size: this.getPage.size
                }
                this.fetchData()
            }
        },
        components: {
            TableComponent,
            ConfirmComponent,
            PaginationComponent,
            CrumbsComponent
        }
    }
</script>

<style scoped>
    .userGroup{
        padding:50px 80px;
        box-sizing: border-box;
        min-height: 100%;
    }
    .table_content{
        width:100%;
        .condition {
            color:#fff;
            margin-bottom: 30px;
            input{
                margin-right:20px;
            }
        }
    }
    .panel-body{
        height: 100px;
    }
</style>