<template>
    <div class="log">
        <div>
            <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
            <ModuleComponent>
                <div slot="title" class="log-header">滚动日志</div>
                <div slot="content" class="log-content">
                    <SystemRollLogs></SystemRollLogs>
                </div>
            </ModuleComponent>
        </div>
        <div>
            <SystemFrequencyGroup></SystemFrequencyGroup>
        </div>
    </div>    
</template>

<script>
    import URL from 'common/url'
    import {mapGetters, mapActions } from 'vuex'
    import SystemFrequencyGroup from 'pages/system-manage/system-frequency.vue'
    import SystemRollLogs from 'pages/system-manage/system-roll-logs.vue'
    import ModuleComponent from 'common/components/module.vue'
    import CrumbsComponent from 'common/components/crumbs.vue'

    export default {

        data() {
            return {
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '系统监控',
                    silent: true
                }]
            }
        },

        components: {
            SystemFrequencyGroup,
            SystemRollLogs,
            ModuleComponent,
            CrumbsComponent
        }
    }
</script>

<style scoped>
    .log{
        padding:50px 80px;
        box-sizing: border-box;
        .log-content{
            height: 200px;
        }
    }
</style>