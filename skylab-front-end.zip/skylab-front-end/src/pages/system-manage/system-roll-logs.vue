<template>
    <div class="roll">
        <div class="inner" role="roll">
            <p v-for="(item,index) of this.getWSLogs" :key="index" :style="pStyle" v-html="item"> </p>
        </div>
    </div> 
</template>

<script>
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    import Velocity from 'velocity-animate'
    import {
        FETCH_HISTORY_LOG,
        GET_WS_LOGS,
        FETCH_WS_LOGS} from 'store/modules/logs'

    export default {

        data() {
            return {
                index: -1,
                pStyle: {},
                start: false
            }
        },

        props: {
            height: {
                type: Number,
                default: 40
            },
            duration: {
                type: Number,
                default: 500
            }
        },

        created() {
            this.fetchHistoryLog()
            this.pStyle = {
                height: `${this.height}px`,
                lineHeight: `${this.height}px`
            }
        },

        computed: {
            ...mapGetters({
                getWSLogs: GET_WS_LOGS
            })
        },

        watch: {
            getWSLogs(value) {
                this.roll()
            }
        },

        methods: {
            roll() {
                this.index += 1
                if (this.start) return
                this.start = true
                Velocity(this.$el.querySelector('[role=roll]'), {
                    top: (-1 * this.index * this.height) + 'px'
                }, {
                    easing: 'swing',
                    duration: this.duration,
                    complete: () => {
                        this.start = false
                    }
                })
            },
            ...mapActions({
                fetchHistoryLog: FETCH_HISTORY_LOG
            }),
        }
    }
</script>

<style scoped>
.roll{
    width: 100%;
    height: 100%;
    overflow: hidden;
    position: relative;
    .inner {
        position: absolute;
        top: 0;
        left: 0;
        p{
            margin:0;
            font-size:14px;
            color:#FFF;
            box-sizing: border-box;
        }
    }
}
</style>