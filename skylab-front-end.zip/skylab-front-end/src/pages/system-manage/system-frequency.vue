<template>
    <div class="system-access">
        <div class="services-request-statistics">
            <ModuleComponent>
                <div slot="title" class="period-header">频次统计
                    <PeriodButtonComponent :select="selectPeriod"></PeriodButtonComponent>
                </div>
                <div slot="content" class="request-content">
                    <div class="chart">
                        <Highcharts :data="getSystemFrequencyGroup" :themeType="themeType" :theme="theme"></Highcharts>
                    </div>
                    <div class="chart">
                        <Highcharts :data="getSystemFrequencyUser" :themeType="themeType" :theme="theme"></Highcharts>
                    </div>
                </div>
            </ModuleComponent>
        </div>
    </div> 
</template>

<script>
    import {
        GET_SYSTEM_FREQUENCY_USER,
        FETCH_SYSTEM_FREQUENCY_USER,
        GET_SYSTEM_FREQUENCY_GROUP,
        FETCH_SYSTEM_FREQUENCY_GROUP
    } from 'store/modules/system_frequency'
    import {
        mapGetters,
        mapActions } from 'vuex'
    import Highcharts, { THEME_TYPE } from '@nanyun/highcharts'
    import ModuleComponent from 'common/components/module.vue'
    import PeriodButtonComponent from 'common/components/period-button.vue'
    import { getInitialDate, WEEK, MONTH } from 'common/utils'

    export default {
        data() {
            return {
                themeType: THEME_TYPE.DARK_UNICA,
                theme: {
                    chart: {
                        backgroundColor: 'rgba(0,0,0,0)'
                    }
                },
                selectedPeriod: WEEK,
            }
        },
        created() {
            this.fetchData()
        },
        watch: {
            selectedPeriod() {
                this.fetchData()
            }
        },
        components: {
            Highcharts,
            ModuleComponent,
            PeriodButtonComponent
        },
        computed: {
            ...mapGetters({
                getSystemFrequencyGroup: GET_SYSTEM_FREQUENCY_GROUP,
                getSystemFrequencyUser: GET_SYSTEM_FREQUENCY_USER
            })
        },
        methods: {
            fetchData() {
                let { start: periodStart, end: periodEnd } = getInitialDate({seconds: this.selectedPeriod, hours: 0})
                let type = this.selectedPeriod / (60 * 60 * 24) == 30 ? '一个月' : '七天'

                this.fetchSystemFrequencyGroup({
                    start: periodStart,
                    end: periodEnd,
                    type: type
                })
                this.fetchSystemFrequencyUser({
                    start: periodStart,
                    end: periodEnd,
                    type: type
                })
            },
            selectPeriod(period) {
                this.selectedPeriod = period
            },
            ...mapActions({
                fetchSystemFrequencyGroup: FETCH_SYSTEM_FREQUENCY_GROUP,
                fetchSystemFrequencyUser: FETCH_SYSTEM_FREQUENCY_USER
            })
        },
    }
</script>

<style scoped>
    .system-access{
        .services-request-statistics{
            margin-top: 20px;
            .request-header{
                a{
                    color:#FFF;
                }
            }
            .request-content{
                height: 300px;
                display: flex;
                .chart{
                    flex:1;
                }
            }
        }
    }
    .panel-span{
        float:right
    }
</style>