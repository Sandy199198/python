<template>
    <div class="logContent">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="table_content">
            <div class="condition">
                <div>
                    操作员：
                    <input type="text" placeholder="请输入操作员"  class="input-style custom" v-model="searchName"/>   
                </div>
                <div>
                    分局：
                    <select class="select input-style" name="searchGroupName">
                        <option value="">分局/不限</option>
                        <option v-for="option in this.getUserGroupList" :value="option.id">{{option.name}}</option>
                    </select> 
                </div>
                <div>
                    操作类型：
                    <select class="select input-style" name="searchAction">
                        <option value="">操作类型/不限</option>
                        <option v-for="option in actions" :value="option.value">{{option.text}}</option>
                    </select>
                </div>
                <div>
                    开始时间：
                    <DatepickerComponent :date="startTime" :limit="startLimit" v-on:change="changeStartDate" class="datepicker"></DatepickerComponent>
                </div>
                <div>
                    结束时间：
                    <DatepickerComponent :date="endTime" :limit="endLimit" v-on:change="changeEndDate" class="datepicker"></DatepickerComponent>
                </div>
                <a href="#" @click.prevent="search()" class="button-style" style="float:right">搜&nbsp;索</a>
                <a href="#" @click.prevent="exportResult()" class="button-style" style="float:right;margin-right:10px;">导&nbsp;出</a>
            </div>
            <!--<div class="condition">
                操作类型：
                <select class="select input-style" name="searchAction">
                    <option value="">操作类型/不限</option>
                    <option v-for="option in actions" :value="option.value">{{option.text}}</option>
                </select>
                <a href="#" @click.prevent="search()" class="button-style" style="float:right">搜&nbsp;索</a>
                <a href="#" @click.prevent="exportResult()" class="button-style" style="float:right;margin-right:10px;">导&nbsp;出</a>
            </div>-->
            <TableComponent :data="getLogList" :columns="columns">
                <span v-for="(item, index) in this.getLogList" :slot="'events' + index">
                </span>
            </TableComponent>
            <div style="overflow:hidden">
                <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
            </div>
        </div>
    </div>
</template>

<script>
    import TableComponent from '@nanyun/table'
    import ConfirmComponent from '@nanyun/confirm'
    import PaginationComponent from '@nanyun/pagination'
    import DatepickerComponent from 'common/components/datepicker.vue'
    import {GET_LOG_LIST, FETCH_LOG_LIST, GET_PAGE} from 'store/modules/logs'
    import {GET_USER_GROUP_LIST, FETCH_USER_GROUP_LIST} from 'store/modules/user_group_info'
    import {formatDate, parseDateStrToTimestamp, convertToSeconds, convertDoubleNumber} from 'common/utils'
    import { GET_SERVICES } from 'store/modules/common'
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    import { ACTIONS } from 'common/config'
    import CrumbsComponent from 'common/components/crumbs.vue'
    import URL from 'common/url'

    export default {
        data() {
            return {
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '日志管理',
                    silent: true
                }],
                columns: [{
                    title: '分局名称',
                    width: '30%',
                    prop: 'user_group_name',
                    handle: d => {
                        return d ? d : '-'
                    }
                }, {
                    title: '时间',
                    width: '15%',
                    prop: 'timestamp',
                    handle: d => {
                        return formatDate(d, 'Y-M-D h:m')
                    }
                }, {
                    title: '操作员',
                    width: '15%',
                    prop: 'real_name',
                    handle: d => {
                        return d ? d : '-'
                    }
                }, {
                    title: '操作',
                    width: '15%',
                    prop: 'action',
                    handle: d => {
                        return d ? d : '-'
                    }
                }, {
                    title: '备注',
                    prop: 'message',
                    handle: d => {
                        return d ? d : '-'
                    }
                }],
                searchName: this.$route.query.name,
                index: '',
                searchObj: {},
                actions: ACTIONS,
                startTime: {
                    time: ''
                },
                endTime: {
                    time: ''
                },
                startLimit: [],
                endLimit: [],
                limitEndDate: '',
                limitStartDate: ''
            }
        },

        created() {
            this.fetchData('default')
        },

        computed: {
            ...mapGetters({
                getLogList: GET_LOG_LIST,
                getPage: GET_PAGE,
                getServices: GET_SERVICES,
                getUserGroupList: GET_USER_GROUP_LIST
            })
        },

        methods: {
            fetchData(type) {
                if (type) {
                    let now = new Date()
                    let endDataTime = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1)
                    let startDateTime = new Date(+endDataTime - 7 * 24 * 60 * 60 * 1000) //默认一周开始日期
                    let limitStartDate = new Date(+endDataTime - 30 * 24 * 60 * 60 * 1000) //一个月开始日期

                    this.startTime.time = startDateTime.getFullYear() + '-' + convertDoubleNumber(startDateTime.getMonth() + 1) + '-' + convertDoubleNumber(startDateTime.getDate())
                    this.endTime.time = endDataTime.getFullYear() + '-' + convertDoubleNumber(endDataTime.getMonth() + 1) + '-' + convertDoubleNumber(endDataTime.getDate())
                    //限制日期只能选择1个月
                    this.limitEndDate = endDataTime.getFullYear() + '-' + convertDoubleNumber(endDataTime.getMonth() + 1) + '-' + convertDoubleNumber(endDataTime.getDate() + 1)
                    this.limitStartDate = limitStartDate.getFullYear() + '-' + convertDoubleNumber(limitStartDate.getMonth() + 1) + '-' + convertDoubleNumber(limitStartDate.getDate())
                    this.endLimit = [{
                        type: 'fromto',
                        from: this.startTime.time,
                        to: this.limitEndDate
                    }]
                    this.startLimit = [{
                        type: 'fromto',
                        from: this.limitStartDate,
                        to: this.endTime.time
                    }]
                    this.searchObj = {
                        realName: this.searchName,
                        startTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.startTime.time + ' 00:00:00'))),
                        endTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.endTime.time + ' 00:00:00')))
                    }
                }
                this.fetchLogList(this.searchObj)
                this.fetchUserGroupList()
            },
            ...mapActions({
                fetchLogList: FETCH_LOG_LIST,
                fetchUserGroupList: FETCH_USER_GROUP_LIST
            }),
            search() {
                this.searchObj = {
                    realName: this.searchName,
                    startTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.startTime.time + ' 00:00:00'))),
                    endTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.endTime.time + ' 00:00:00'))),
                    actionType: document.querySelector('[name=searchAction]').value,
                    userGroupId: document.querySelector('[name=searchGroupName]').value
                }
                this.fetchData()
            },
            exportResult() {
                let params = []
                let url = `${this.getServices.Skylab}statistic/query/`
                let obj = {
                    realName: this.searchName,
                    startTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.startTime.time + ' 00:00:00'))),
                    endTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.endTime.time + ' 00:00:00'))),
                    actionType: document.querySelector('[name=searchAction]').value,
                    userGroupId: document.querySelector('[name=searchGroupName]').value
                }

                for (let key in obj) {
                    if (obj[key]) {
                        if (key == 'realName') {
                            params.push('real_name' + '=' + encodeURIComponent(obj[key]))
                        } else if (key == 'startTime') {
                            params.push('start_time' + '=' + obj[key])
                        } else if (key == 'endTime') {
                            params.push('end_time' + '=' + obj[key])
                        } else if (key == 'actionType') {
                            params.push('action_type' + '=' + obj[key])
                        } else if (key == 'userGroupId') {
                            params.push('user_group_id' + '=' + obj[key])
                        } else {
                            params.push(key + '=' + obj[key])
                        }
                    }
                }

                params = params.join('&') + '&format=xlsx'
                if (params) {
                    url += '?' + params
                }
                window.open(url)
            },
            pageEvent(page) {
                this.searchObj = {
                    realName: this.searchName,
                    startTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.startTime.time + ' 00:00:00'))),
                    endTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.endTime.time + ' 00:00:00'))),
                    actionType: document.querySelector('[name=searchAction]').value,
                    page: page,
                    size: this.getPage.size
                }
                this.fetchData()
            },
            changeStartDate(startDate) {
                this.endLimit = [{
                    type: 'fromto',
                    from: startDate,
                    to: this.limitEndDate
                }]
            },
            changeEndDate(endDate) {
                this.startLimit = [{
                    type: 'fromto',
                    from: this.limitStartDate,
                    to: endDate
                }]
            }
        },
        components: {
            TableComponent,
            ConfirmComponent,
            PaginationComponent,
            DatepickerComponent,
            CrumbsComponent
        }
    }
</script>

<style scoped>
    .logContent{
        padding:50px 80px;
        box-sizing: border-box;
        min-height: 100%;
    }
    .table_content{
        width:100%;
        .condition {
            color:#fff;
            margin-bottom: 30px;
            &>div{
                float: left;
            }
            .datepicker{
                min-width: 200px;
                display:inline-block;
                border-radius: 2px;
                font-family: sans-serif;
                font-size: 100%;
                line-height: 22px;
                margin: 0 15px 10px 0;
            }
        }
        input, select{
            margin-right:10px;
            margin-bottom:10px;
        }
        input.custom{
            min-width: 188px;
        }
    }

    .form-group{
        height: 50px;
        position: relative;
        margin-left: -11px;
        margin-right: -11px;
    }
    .col3{
        width: 25%;
        float: left;
        min-height: 1px;
    }
    .col9{
        width:70%;
        float:left;
        min-height: 1px;
    }
    .control-label{
        padding-left: 15px;
        padding-top: 5px;
        text-align: left;
    }
    lable{
        line-height: 32px;
        display: inline-block;
        margin-bottom: 5px;
    }
    .minWidth{
        min-width: 150px;
    }
</style>