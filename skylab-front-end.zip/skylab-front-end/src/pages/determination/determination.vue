<template>
    <div>人脸研判</div>
</template>

<script></script>

<style></style>