<template>
    <Highcharts :style="style" :data="getSystemRequestCount" :themeType="themeType" :theme="theme"></Highcharts>
</template>

<script>
    import {
        GET_ALL_SYSTEM_REQUEST_COUNT,
        FETCH_ALL_SYSTEM_REQUEST_COUNT
    } from 'store/modules/system'
    import {
        mapGetters,
        mapActions } from 'vuex'
    import Highcharts, { THEME_TYPE } from '@nanyun/highcharts'

    export default {
        props: {
            customTheme: {
                type: Object,
                default: null
            }
        },
        data() {
            return {
                themeType: THEME_TYPE.DARK_UNICA,
                theme: this.customTheme ? this.customTheme : {
                    chart: {
                        backgroundColor: 'rgb(50,60,78)'
                    }
                },
                style: {
                    width: '100%',
                    height: '100%'
                }
            }
        },
        created() {
            this.fetchData()
        },
        components: {
            Highcharts
        },
        computed: {
            ...mapGetters({
                getSystemRequestCount: GET_ALL_SYSTEM_REQUEST_COUNT
            })
        },
        methods: {
            fetchData() {
                this.fetchSystemRequestCount()
            },
            ...mapActions({
                fetchSystemRequestCount: FETCH_ALL_SYSTEM_REQUEST_COUNT
            })
        },
    }
</script>

<style> </style>