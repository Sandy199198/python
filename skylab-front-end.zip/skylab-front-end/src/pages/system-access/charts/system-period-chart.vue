<template>
    <Highcharts :data="data" :themeType="themeType" :theme="theme" :style="style"></Highcharts>
</template>

<script>
    import Highcharts, { THEME_TYPE } from '@nanyun/highcharts'
    import {
        mapGetters,
        mapActions } from 'vuex'

    export default {

        props: {
            data: {
                type: Object,
                default() {
                    return {}
                }
            }
        },

        data() {
            return {
                themeType: THEME_TYPE.DARK_UNICA,
                theme: {
                    chart: {
                        backgroundColor: '#323c4e'
                    }
                },
                style: {
                    width: '100%',
                    height: '250px'
                }
            }
        },

        components: {
            Highcharts
        }
    }
</script>

<style> </style>
