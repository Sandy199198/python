<template>
    <div class="system-detail">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
            <SystemIntervalChartComponent :chartData="getSystemRequestIntervalCount"></SystemIntervalChartComponent>
        <div class="request-count">
            <TableComponent :columns="getSystemRequestCountColumns" :data="getSystemRequestCount"></TableComponent>
        </div>
        <ModuleComponent class="statistics">
            <div slot="title" class="statistics-header">
                信息统计
                <PeriodButtonComponent :select="selectPeriod"></PeriodButtonComponent>
            </div>
            <div slot="content" class="period">
                <div class="chart">
                    <SystemPeriodChartComponent :data="getSystemRequestPeriodCount"></SystemPeriodChartComponent>
                </div>
                <div class="table">
                    <TableComponent :columns="getSystemHotRequestDataColumns" :data="getSystemHotRequestData"></TableComponent>
                </div>
            </div>
        </ModuleComponent>
    </div>
</template>

<script>
    import URL from 'common/url'
    import {
        mapGetters,
        mapActions } from 'vuex'
    import {
        FETCH_SYSTEM_REQUEST_INTERVAL_COUNT,
        FETCH_SYSTEM_REQUEST_COUNT,
        FETCH_SYSTEM_REQUEST_PERIOD_COUNT,
        GET_SYSTEM_REQUEST_INTERVAL_COUNT,
        GET_SYSTEM_REQUEST_COUNT_COLUMNS,
        GET_SYSTEM_REQUEST_COUNT,
        GET_SYSTEM_HOT_REQUEST_DATA,
        GET_SYSTEM_HOT_REQUEST_DATA_COLUMNS,
        GET_SYSTEM_REQUEST_PERIOD_COUNT } from 'store/modules/system'
    import { getInitialDate } from 'common/utils'
    import ModuleComponent from 'common/components/module.vue'
    import PeriodButtonComponent from 'common/components/period-button.vue'
    import TableComponent from '@nanyun/table'
    import SystemIntervalChartComponent from 'pages/system-access/charts/system-interval-chart.vue'
    import SystemPeriodChartComponent from 'pages/system-access/charts/system-period-chart.vue'
    import CrumbsComponent from 'common/components/crumbs.vue'
    import { WEEK, MONTH } from 'common/utils'


    export default {
        data() {
            return {
                selectedPeriod: WEEK,
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '系统汇总',
                    path: {
                        name: URL.ACCESS.SYSTEM_ACCESS
                    }
                }, {
                    name: decodeURIComponent(this.$route.params.application),
                    silent: true
                }]
            }
        },

        watch: {
            selectedPeriod() {
                this.fetchData()
            },

            $route() {
                this.fetchData()
                this.crumbs.pop()
                this.crumbs.push({
                    name: decodeURIComponent(this.$route.params.application),
                    silent: true
                })
            }
        },

        created() {
            this.fetchData()
            this.interval = setInterval(() => {
                this.fetchIntervalData()
            }, 10000)
        },

        computed: {
            ...mapGetters({
                getSystemRequestCountColumns: GET_SYSTEM_REQUEST_COUNT_COLUMNS,
                getSystemRequestCount: GET_SYSTEM_REQUEST_COUNT,
                getSystemHotRequestData: GET_SYSTEM_HOT_REQUEST_DATA,
                getSystemHotRequestDataColumns: GET_SYSTEM_HOT_REQUEST_DATA_COLUMNS,
                getSystemRequestPeriodCount: GET_SYSTEM_REQUEST_PERIOD_COUNT,
                getSystemRequestIntervalCount: GET_SYSTEM_REQUEST_INTERVAL_COUNT
            }),
            getPeriodNumber() {
                switch (this.selectedPeriod) {
                    case WEEK:
                        return 7
                    case MONTH:
                        return 30
                }
            }
        },

        methods: {
            fetchData() {
                let { start: periodStart, end: periodEnd } = getInitialDate({seconds: this.selectedPeriod, hours: 0})
                let name = this.$route.params.application

                if (name) {
                    name = decodeURIComponent(name)
                }

                this.fetchSystemRequestCount(name)

                this.fetchIntervalData()

                this.fetchSystemRequestPeriodCount({
                    name,
                    start: periodStart,
                    end: periodEnd,
                    number: this.getPeriodNumber
                })
            },

            fetchIntervalData() {
                let { start: intervalStart, end: intervalEnd } = getInitialDate()
                let name = this.$route.params.application

                if (name) {
                    name = decodeURIComponent(name)
                }

                this.fetchSystemRequestIntervalCount({
                    name,
                    start: intervalStart,
                    end: intervalEnd
                })
            },

            selectPeriod(period) {
                this.selectedPeriod = period
            },

            back() {
                this.$router.push({
                    name: URL.SYSTEM_ACCESS
                })
            },

            ...mapActions({
                fetchSystemRequestCount: FETCH_SYSTEM_REQUEST_COUNT,
                fetchSystemRequestPeriodCount: FETCH_SYSTEM_REQUEST_PERIOD_COUNT,
                fetchSystemRequestIntervalCount: FETCH_SYSTEM_REQUEST_INTERVAL_COUNT
            })
        },

        destroyed() {
            clearInterval(this.interval)
        },

        components: {
            TableComponent,
            ModuleComponent,
            SystemIntervalChartComponent,
            SystemPeriodChartComponent,
            CrumbsComponent,
            PeriodButtonComponent
        }

    }
</script>

<style scoped>
    .system-detail{
        padding:50px 80px;
        box-sizing: border-box;
        background: rgb(24, 44, 65);
        .request-count, .statistics{
            margin-top:30px;
        }
        .statistics{
            .statistics-header{
                display: flex;                
                justify-content: space-between;
            }
            .period{
                display: flex;
                padding: 30px 0;
                justify-content: space-between;
                .chart,.table {
                    flex: 0 0 48%;
                }
            }
        }
    }
</style>