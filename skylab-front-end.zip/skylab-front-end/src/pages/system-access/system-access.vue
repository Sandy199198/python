<template>
    <div class="system-access">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="services-statistics">
            <div class="system-header">
                <div class="search">
                    <input type="text" class="input-style" v-model="search" placeholder="请输入名称">
                    <button class="button-style" @click.prevent="searchSystem">搜&nbsp;索</button>
                </div>
                <div class="create">
                    <button class="button-style" @click.prevent="openCreateSystemLayer">新&nbsp;建</button>
                </div>
            </div>
            <div class="services">
                <TableComponent :columns="systemColumns" :data="getAllSystems">
                    <span v-for="(item,index) in getAllSystems" :slot="'events' + index">
                        <a href="#" @click.prevent="edit(index)">修改</a>
                        <a href="#" @click.prevent="del(index)">删除</a>
                        <a href="#" @click.prevent="detail(index)">查看详情</a>
                    </span> 
                </TableComponent>
            </div>
        </div>
        <div class="services-request-statistics">
            <ModuleComponent>
                <div slot="title">接口调用量</div>
                <div slot="content" class="request-content">
                    <div class="chart">
                        <SystemRequestCountComponent></SystemRequestCountComponent>
                    </div>
                    <div class="table">
                        <TableComponent :columns="requestColumns" :data="getSystemRequestDetail">
                            <span>
                                <a href="#"></a>
                            </span>
                        </TableComponent>
                    </div>
                </div>
            </ModuleComponent>
        </div>
        <ConfirmComponent :show="showInfoConfirm"
            title="系统应用"
            :confirm="submitSystemInfo"
            :cancel="resetSystemInfo"
        >
            <div slot="content" class="system-form">
                <FormFieldComponent>
                    <label for="name" slot="label">名称</label>
                    <input type="text" slot="field" class="form-control" v-model="systemInfo.name">
                </FormFieldComponent>
                <FormFieldComponent>
                    <label for="datetime" slot="label">有效期</label>
                    <DatePickerComponent slot="field" :date="date" :options="dateOptions"></DatePickerComponent>
                </FormFieldComponent>
                <FormFieldComponent>
                    <label for="" slot="label">开放接口</label>
                    <div slot="field">
                        <div class="interfaces">
                            <span v-for="interface in getSystemInitInterfaces">
                                <input :id="'i'+interface.id" v-model="systemInfo.Interfaces" type="checkbox" :value="interface.info">
                                <label :for="'i'+interface.id"> {{interface.info}} </label>
                            </span>
                        </div>
                    </div>
                </FormFieldComponent>
                <FormFieldComponent>
                    <label for="" slot="label">开放底库</label>
                    <div slot="field">
                        <div class="groups">
                            <span v-for="group in getSystemInitGroups">
                                <input :id="'g_'+group.id" v-model="systemInfo.groups" type="checkbox" :value="group.name">
                                <label :for="'g_'+group.id">{{group.name}}</label>
                            </span>
                        </div>
                    </div>
                </FormFieldComponent>
                <FormFieldComponent>
                    <label for="remark" slot="label">备注</label>
                    <textarea slot="field" class="form-control" v-model.trim="systemInfo.remark" id="remark" cols="30" rows="5"></textarea>
                </FormFieldComponent>
            </div>
        </ConfirmComponent>
        <ConfirmComponent :show="showDelConfirm"
            title="删除"
            :confirm="confirmDel"
        >
            <div slot="content">确定要删除当前应用吗？</div>
        </ConfirmComponent>
    </div> 
</template>

<script>
    import URL from 'common/url'
    import { formatDate, parseDateStrToTimestamp, convertToSeconds } from 'common/utils'
    import TableComponent from '@nanyun/table'
    import ConfirmComponent from '@nanyun/confirm'
    import FormFieldComponent from 'common/components/form-field.vue'
    import ModuleComponent from 'common/components/module.vue'
    import DatePickerComponent from 'common/components/datepicker.vue'
    import CrumbsComponent from 'common/components/crumbs.vue'
    import {
        mapGetters,
        mapActions } from 'vuex'
    import {
        GET_HEIGHT_STYLE
    } from 'store/modules/common'
    import {
        GET_ALL_SYSTEMS,
        GET_ALL_SYSTEM_REQUEST_DETAIL,
        FETCH_SYSTEM_INIT_DATA,
        GET_SYSTEM_INIT_GROUPS,
        GET_SYSTEM_INIT_INTERFACES,
        POST_SYSTEM,
        PUT_SYSTEM,
        DELETE_SYSTEM } from 'store/modules/system'

    import SystemRequestCountComponent from 'pages/system-access/charts/system-request-count-chart.vue'

    export default {
        data() {
            return {
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '系统汇总',
                    silent: true
                }],
                date: {
                    time: ''
                },
                dateOptions: {
                    type: 'min',
                    format: 'YYYY-MM-DD HH:mm',
                    dark: false,
                },
                search: '',
                systemInfo: {
                    id: '',
                    name: '',
                    expireTime: '',
                    groups: [],
                    Interfaces: [],
                    remark: ''
                },
                showInfoConfirm: {
                    value: false
                },
                showDelConfirm: {
                    value: false
                },
                systemColumns: [{
                    title: '名称',
                    prop: 'name'
                }, {
                    title: 'token',
                    prop: 'token'
                }, {
                    title: '有效期',
                    prop: 'expire_time',
                    handle(val) {
                        return formatDate(val, 'Y年M月D日 h点m分')
                    }
                }, {
                    title: '开放接口',
                    prop: 'interfaces'
                }, {
                    title: '开放底库',
                    prop: 'groups'
                }, {
                    title: '备注',
                    prop: 'remark'
                }, {
                    title: '操作',
                    type: 'events'
                }],
                requestColumns: [{
                    title: '子系统',
                    prop: 'name'
                }, {
                    title: '接口调用量',
                    prop: 'count'
                }, {
                    title: '占比',
                    prop: 'percentage'
                }]
            }
        },
        // created() {
        //     header上已发过该请求
        //     this.fetchAllSystem()
        // },
        computed: {
            ...mapGetters({
                getAllSystems: GET_ALL_SYSTEMS,
                getSystemRequestDetail: GET_ALL_SYSTEM_REQUEST_DETAIL,
                getSystemInitGroups: GET_SYSTEM_INIT_GROUPS,
                getSystemInitInterfaces: GET_SYSTEM_INIT_INTERFACES
            })
        },
        methods: {
            openCreateSystemLayer() {
                this.resetSystemInfo()
                this.fetchSystemInitData().then(() => {
                    this.showInfoConfirm.value = true
                })
            },
            resetSystemInfo(obj = {}) {
                if ('groups' in obj) {
                    obj.groups = obj.groups.split(',')
                }
                if ('interfaces' in obj) {
                    obj.Interfaces = obj.interfaces.split(',')
                    delete obj.interfaces
                }
                if ('expire_time' in obj) {
                    obj.expireTime = obj.expire_time
                    delete obj.expire_time
                }
                this.systemInfo = Object.assign({}, {
                    name: '',
                    expireTime: '',
                    groups: [],
                    Interfaces: [],
                    remark: ''
                }, obj)
            },
            submitSystemInfo() {
                let {id, name, expireTime, groups, Interfaces, remark } = this.systemInfo
                let params = {
                    id,
                    name,
                    expireTime: convertToSeconds(parseDateStrToTimestamp(this.date.time)),
                    groups,
                    Interfaces,
                    remark
                }

                if (Object.is(id, undefined)) {
                    this.saveSystem(params)
                } else {
                    this.putSystem(params)
                }
            },
            searchSystem() {
                this.fetchAllSystem({
                    name: this.search
                })
            },
            edit(index) {
                let data = this.getAllSystems[index]

                this.date.time = formatDate(data.expire_time, 'Y-M-D h:m')
                this.resetSystemInfo(Object.assign({}, data))
                this.fetchSystemInitData().then(() => {
                    this.showInfoConfirm.value = true
                })
            },
            del(index) {
                let data = this.getAllSystems[index]

                this.showDelConfirm.value = true
                this.currentDelDataId = data.id
            },
            confirmDel() {
                this.delSystem(this.currentDelDataId)
            },
            detail(index) {
                let data = this.getAllSystems[index]

                this.$router.push({
                    name: URL.ACCESS.SYSTEM_DETAIL,
                    params: {
                        application: encodeURIComponent(data.name)
                    }
                })
            },
            ...mapActions({
                fetchSystemInitData: FETCH_SYSTEM_INIT_DATA,
                saveSystem: POST_SYSTEM,
                putSystem: PUT_SYSTEM,
                delSystem: DELETE_SYSTEM
            })
        },
        components: {
            ConfirmComponent,
            TableComponent,
            SystemRequestCountComponent,
            FormFieldComponent,
            ModuleComponent,
            DatePickerComponent,
            CrumbsComponent
        }
    }
</script>

<style scoped>
    .system-access{
        padding:50px 80px;
        box-sizing: border-box;
        background: rgb(24, 44, 65);
        input,textarea{
            outline: none;
        }
        .system-header{
            display: flex;
            justify-content: space-between;
            .search{
                input{
                    margin-right: 10px;
                }
            }
            button{
                font-size:14px;
            }
        }
        .services-statistics{
            .services{
                margin-top: 30px;
            }
        }
        .services-request-statistics{
            margin-top: 50px;
            .request-content{
                height: 300px;
                display: flex;
                justify-content: space-between;
                .chart{
                    flex:0 0 48%;
                }
                .table{
                    flex:0 0 48%;
                }
            }
        }
        .system-form{
            width: 400px;
            >div{
                display: flex;
            }
            .interfaces,.groups{
                display: inline-flex;
                flex-wrap: wrap;
                span{
                    flex-grow:0;
                    display: inline-block;
                    flex:0 0 auto;
                    margin:2px 10px 10px 0;
                }
                input{
                    vertical-align: middle;
                }
            }
        }
    }
</style>