<template>
    <div class="home" :data-role="routeName">
        <div class="map" :style="contentHeightStyle">
            <div class="alarm-info">
                {{dateTime}}&nbsp;
                今日抓拍<CounterComponent :init="getCaptureCount"></CounterComponent>次&nbsp;
                告警<CounterComponent :init="getAlarmCount"></CounterComponent>次&nbsp;
                确认告警<CounterComponent :init="getMarkedAlarmCount"></CounterComponent>次
                <!--<div class="access">
                    <button class="button-style" @click.prevent="goMain">进入系统</button>
                </div>-->
            </div>
            <div id="alarm" class="item branch" :style="itemStyle">
                <component :is="componentAlarm"></component>
            </div>
            <div class="item action" :style="itemStyle">
                <!--<component :is="componentServer"></component>-->
                <component :is="componentUserAction"></component>
            </div>
            <div class="item maintenance" :style="itemStyle">
                <component :is="componentMaintenance"></component>
            </div>
            <div class="item server" :style="itemStyle">
                <component :is="componentAction"></component>
            </div>
            <div id="map"></div>
        </div>
    </div>    
</template>

<script>
    import Vue from 'vue'
    import ol from 'openlayers'
    import 'openlayers/css/ol.css'
    import {
        computeSize,
        setCameraSymbols,
        setCameraSymbol,
        formatDate,
        setAlarmAboutCamera } from 'common/utils'
    import URL from 'common/url'
    import { DEFAULT_CENTER } from 'common/config'

    import AlarmChartComponent from 'pages/home/alarm-chart.vue'
    import ServerChartComponent from 'pages/home/server-chart.vue'
    import SystemRequestCountComponent from 'pages/system-access/charts/system-request-count-chart.vue'
    import MaintenanceComponent from 'pages/home/maintenance-chart.vue'
    import ActionComponent from 'pages/home/action-chart.vue'
    import CounterComponent from 'common/components/counter.vue'
    import UserActionComponent from 'pages/home/useraction-chart.vue'
    import themeStyle from 'common/chart-style'
    import {
        GET_HEIGHT,
        SET_HEIGHT,
        GET_SERVICES } from 'store/modules/common'
    import {
        GET_CAPTURE_COUNT,
        FETCH_CAPTURE_COUNT,
        FETCH_ALARM_COUNT,
        GET_ALARM_COUNT,
        FETCH_MARKED_ALARM_COUNT,
        GET_MARKED_ALARM_COUNT } from 'store/modules/branch-statistics'
    import {
        GET_CAMERAS,
        FETCH_CAMERAS } from 'store/modules/cameras'
    import {
        SET_ALARM,
        DEL_ALARM,
        GET_ALARM } from 'store/modules/alarms'
    import {
        mapActions,
        mapGetters,
        mapMutations } from 'vuex'

    let cameraPromise
    let map
    let mounted

    export default {

        mixins: [computeSize],

        data() {
            return {
                themeStyle,
                itemStyle: {},
                captureCount: 567,
                alarmCount: 88,
                confirmAlarmCount: 72,
                dateTime: formatDate(parseInt(new Date() / 1000, 10), 'Y年M月D日'),
                componentAlarm: '',
                componentServer: '',
                componentMaintenance: '',
                componentAction: '',
                componentUserAction: ''
            }
        },

        created() {
            mounted = false

            cameraPromise = Promise.all([this.fetchCameras(), new Promise((resolve, reject) => {
                setTimeout(() => {
                    resolve()
                }, 600)
            })])
        },

        components: {
            AlarmChartComponent,
            ServerChartComponent,
            MaintenanceComponent,
            CounterComponent,
            ActionComponent,
            UserActionComponent
        },

        beforeMount() {
            let winHeight = parseInt(this.contentHeightStyle.height)

            this.setHeight(winHeight)
            this.itemStyle = {
                width: '27%',
                height: `${(winHeight - 165) / 2}px`
            }
        },

        mounted() {
            cameraPromise.then(() => {
                this.timer = setInterval(() => {
                    this.fetchData()
                    this.dateTime = formatDate(parseInt(new Date() / 1000, 10), 'Y年M月D日')
                }, 5000)
            }).then(() => {
                map = new ol.Map({
                    target: 'map',
                    layers: [
                        new ol.layer.Tile({
                            source: new ol.source.XYZ({
                                url: `${this.getServices.GisServer}{z}/{x}/{y}.png`
                            })
                        })
                    ],
                    controls: [
                        new ol.control.Zoom(),
                        new ol.control.ZoomSlider()
                    ],
                    view: new ol.View({
                        center: DEFAULT_CENTER,
                        maxZoom: 15,
                        zoom: 10
                    })
                })

                setTimeout(() => {
                    this.fetchData()
                    setTimeout(() => {
                        this.componentAlarm = 'AlarmChartComponent'
                        // this.componentServer = 'ServerChartComponent'
                        this.componentMaintenance = 'MaintenanceComponent'
                        this.componentAction = 'ActionComponent',
                        this.componentUserAction = 'UserActionComponent'
                    }, 1000)
                    setTimeout(() => {
                        if (!map) return
                        setCameraSymbols({
                            ol,
                            map,
                            cameras: this.getCameras,
                            clickCallback: cameraOverlay => {
                                let elem = cameraOverlay.getElement()

                                if (!elem.dataset.alarm) return
                                delete elem.dataset.alarm
                                elem.className = 'map-camera'

                                let alarmCard = map.getOverlayById(`alarm-${elem.dataset['id']}`)

                                alarmCard.getElement().className = 'alarm-card remove'
                                setTimeout(() => {
                                    map.removeOverlay(alarmCard)
                                    this.$router.push({
                                        name: URL.GIS,
                                        params: {
                                            cameraId: cameraOverlay.getId()
                                        }
                                    })
                                }, 500)
                            },
                            createdCallback() {
                                mounted = true
                            }
                        })

                    }, 2000)
                }, 300)
            })
        },

        watch: {
            getAlarm(alarm) {
                if (!mounted) {
                    this.delAlarm(alarm)
                    setTimeout(() => {
                        this.setAlarm(alarm)
                    }, 1000)
                    return
                }

                setAlarmAboutCamera({
                    ol,
                    map,
                    alarm
                })
            }
        },

        computed: {
            routeName() {
                return this.$route.name
            },
            ...mapGetters({
                getCaptureCount: GET_CAPTURE_COUNT,
                getAlarmCount: GET_ALARM_COUNT,
                getMarkedAlarmCount: GET_MARKED_ALARM_COUNT,
                getCameras: GET_CAMERAS,
                getAlarm: GET_ALARM,
                getWinHeight: GET_HEIGHT,
                getServices: GET_SERVICES
            })
        },

        methods: {
            fetchData() {
                setTimeout(() => {
                    this.fetchCaptureCount()
                    this.fetchAlarmCount()
                    this.fetchMarkedAlarmCount()
                }, 0)
            },
            goMain() {
                clearInterval(this.timer)
                this.$router.push({
                    name: URL.GIS
                })
            },
            ...mapActions({
                fetchCaptureCount: FETCH_CAPTURE_COUNT,
                fetchAlarmCount: FETCH_ALARM_COUNT,
                fetchMarkedAlarmCount: FETCH_MARKED_ALARM_COUNT,
                fetchCameras: FETCH_CAMERAS
            }),
            ...mapMutations({
                setAlarm: SET_ALARM,
                delAlarm: DEL_ALARM,
                setHeight: SET_HEIGHT
            })
        },

        destroyed() {
            clearInterval(this.timer)
            map.destroyed = true
            map.getOverlays().clear()
            map = null
        }
    }

</script>

<style scoped>
    .alarm-info{
        height: 80px;
        color:#fff;
        width: auto;
        text-align: center;
        line-height: 100px;
        font-size:26px;
        position: fixed;
        z-index:999;
        top:95px;
        left: 80px;
        right: 80px;
        background: rgba(0,0,0,.6);
        border-radius: 5px;
        box-shadow: 0 2px 12px #0e1b29;
        .num{
            color:rgb(254,213,68); 
            font-size:36px;
            vertical-align: bottom;
            margin:0 5px;
        }
        .access{
            position: absolute;
            top: 30px;
            right: 50px;
            font-size:14px;
            padding-top:0;
            line-height: 100%;
        }
    }
    .map {
        box-shadow: 0 -5px 10px rgb(14,27,41);
        #map{
            height: 100%;
        }
        .item {
            position: fixed;
            z-index:999;
            box-sizing: border-box;
            padding:1%;
            transition:opacity .7s;
            background: rgba(0,0,0,.6);
        }
        .branch {
            top:185px;
            left:80px;
        }
        .server {
            bottom:20px;
            left: 80px;
        }
        .maintenance {
            top: 185px;
            right:80px;
        }
        .action {
            bottom:20px;
            right: 80px;
        }
    } 
</style>