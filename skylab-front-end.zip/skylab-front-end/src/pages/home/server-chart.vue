<template>
    <Highcharts :data="getSystemRequestCount" :style="style" :themeType="themeType" :theme="theme" :plugins="plugins" :update="update"></Highcharts>
</template>

<script>
    import {
        GET_ALL_SYSTEM_REQUEST_COUNT,
        FETCH_ALL_SYSTEM_REQUEST_COUNT
    } from 'store/modules/system'
    import {
        mapGetters,
        mapActions } from 'vuex'
    import Highcharts, { THEME_TYPE } from '@nanyun/highcharts'
    import themeStyle from 'common/chart-style'

    export default {

        props: {
            delay: {
                type: Number,
                default: 1000
            },
            intervalTime: {
                type: Number,
                default: 5000
            }
        },

        data() {
            return {
                themeType: THEME_TYPE.DARK_UNICA,
                theme: themeStyle,
                plugins: [],
                style: {
                    width: '100%',
                    height: '100%'
                }
            }
        },
        created() {
            this.fetchData()
            setTimeout(() => {
                this.interval = setInterval(() => {
                    this.fetchData()
                }, this.intervalTime)
            }, this.delay)
        },
        components: {
            Highcharts
        },
        computed: {
            ...mapGetters({
                getSystemRequestCount: GET_ALL_SYSTEM_REQUEST_COUNT
            })
        },
        methods: {
            fetchData() {
                this.fetchSystemRequestCount()
            },
            update(chart, data, render) {
                chart.update({
                    title: {
                        text: data.title.text
                    }
                })

                for (let [index, s] of data.series.entries()) {
                    if (chart.series[index]) {
                        chart.series[index].setData(s.data)
                    } else {
                        chart.addSeries(s)
                    }
                }
            },
            ...mapActions({
                fetchSystemRequestCount: FETCH_ALL_SYSTEM_REQUEST_COUNT
            })
        },
        destroyed() {
            clearInterval(this.interval)
        },
    }
</script>

<style>
    
</style>