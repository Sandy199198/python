<template>
    <Highcharts :data="getSystemFrequencyUser" :themeType="themeType" :theme="theme" :style="style" :update="update"></Highcharts>
</template>

<script>
    import {
        GET_SYSTEM_FREQUENCY_USER,
        FETCH_SYSTEM_FREQUENCY_USER
    } from 'store/modules/system_frequency'
    import {
        mapGetters,
        mapActions } from 'vuex'
    import Highcharts, { THEME_TYPE } from '@nanyun/highcharts'
    import ModuleComponent from 'common/components/module.vue'
    import themeStyle from 'common/chart-style'
    import { getInitialDate, WEEK, MONTH } from 'common/utils'

    export default {

        props: {
            delay: {
                type: Number,
                default: 2000
            },
            intervalTime: {
                type: Number,
                default: 5000
            }
        },

        data() {
            return {
                themeType: THEME_TYPE.DARK_UNICA,
                theme: themeStyle,
                style: {
                    width: '100%',
                    height: '100%'
                },
                selectedPeriod: WEEK
            }
        },

        created() {
            this.fetchData()
            setTimeout(() => {
                // this.interval = setInterval(() => {
                //     this.fetchData()
                // }, this.intervalTime)
            }, this.delay)
        },

        components: {
            Highcharts,
            ModuleComponent
        },

        computed: {
            ...mapGetters({
                getSystemFrequencyUser: GET_SYSTEM_FREQUENCY_USER
            })
        },

        methods: {
            fetchData() {
                let { start: periodStart, end: periodEnd } = getInitialDate({seconds: this.selectedPeriod, hours: 0})
                let type = this.selectedPeriod / (60 * 60 * 24) == 30 ? '一个月' : '七天'

                this.fetchSystemFrequencyUser({
                    start: periodStart,
                    end: periodEnd,
                    type: type
                })
            },
            update(chart, data, render) {
                for (let [index, s] of data.series.entries()) {
                    if (chart.series[index]) {
                        chart.series[index].setData(s.data)
                    } else {
                        chart.addSeries(s)
                    }
                }
            },
            ...mapActions({
                fetchSystemFrequencyUser: FETCH_SYSTEM_FREQUENCY_USER
            })
        },

        destroyed() {
            clearInterval(this.interval)
        }
    }
</script>

<style scoped>
   
</style>