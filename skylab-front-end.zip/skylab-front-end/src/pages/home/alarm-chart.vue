<template>
    <Highcharts :style="style" :themeType="themeType" :theme="theme" :data="chartData" :plugins="plugins" :update="update"></Highcharts>
</template>

<script>
    import {
        mapGetters,
        mapMutations,
        mapActions } from 'vuex'
    import {
        GET_BRANCH_DATA,
        CLEAR_BRANCH_DATA,
        FETCH_BRANCH_DATA } from 'store/modules/branch-statistics'
    import {
        FETCH_ALL_BRANCHS } from 'store/modules/citywide_info'
    import Highcharts, { THEME_TYPE } from '@nanyun/highcharts'
    import Highcharts3D from 'highcharts/highcharts-3d'
    import themeStyle from 'common/chart-style'

    export default {

        props: {
            delay: {
                type: Number,
                default: 500
            },
            intervalTime: {
                type: Number,
                default: 5000
            }
        },

        data() {
            return {
                themeType: THEME_TYPE.DARK_UNICA,
                theme: themeStyle,
                plugins: [],
                style: {
                    width: '100%',
                    height: '100%'
                }
            }
        },

        created() {
            this.fetchData()
            setTimeout(() => {
                this.interval = setInterval(() => {
                    this.fetchData()
                }, this.intervalTime)
            }, this.delay)
        },

        computed: {
            ...mapGetters({
                chartData: GET_BRANCH_DATA,
            })
        },

        methods: {
            fetchData() {
                this.fetchAllBranchs().then(() => {
                    this.fetchBranchData()
                })
            },
            update(chart, data, render) {
                chart.update({
                    xAxis: {
                        categories: data.xAxis.categories
                    }
                })

                for (let [index, s] of data.series.entries()) {
                    if (chart.series[index]) {
                        chart.series[index].setData(s.data)
                    } else {
                        chart.addSeries(s)
                    }
                }
            },
            ...mapMutations({
                clearBranchData: CLEAR_BRANCH_DATA
            }),
            ...mapActions({
                fetchAllBranchs: FETCH_ALL_BRANCHS,
                fetchBranchData: FETCH_BRANCH_DATA
            })
        },

        destroyed() {
            this.clearBranchData()
            clearInterval(this.interval)
        },

        components: {
            Highcharts
        }
    }
</script>

<style></style>