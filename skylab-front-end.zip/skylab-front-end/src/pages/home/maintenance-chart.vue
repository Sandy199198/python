<template>
    <Highcharts :style="style" :themeType="themeType" :theme="theme" :plugins="plugins" :data="getAllMemory" :update="update"></Highcharts>
</template>

<script>

    import {
        CITYWIDE_GET_MEMORY,
        CITYWIDE_CLEAR_MEMORY,
        CITYWIDE_FETCH_MEMORY
    } from 'store/modules/resource'
    import {
        mapGetters,
        mapActions,
        mapMutations } from 'vuex'
    import Highcharts, { THEME_TYPE } from '@nanyun/highcharts'
    import ModuleComponent from 'common/components/module.vue'
    import themeStyle from 'common/chart-style'


    export default {
        props: {
            delay: {
                type: Number,
                default: 500
            },
            intervalTime: {
                type: Number,
                default: 5000
            }
        },

        data() {
            return {
                themeType: THEME_TYPE.DARK_UNICA,
                theme: themeStyle,
                plugins: [],
                style: {
                    width: '100%',
                    height: '100%'
                }
            }
        },

        created() {
            this.fetchData()
            setTimeout(() => {
                this.interval = setInterval(() => {
                    this.fetchData()
                }, this.intervalTime)
            }, this.delay)
        },
        computed: {
            ...mapGetters({
                getAllMemory: CITYWIDE_GET_MEMORY
            })
        },
        methods: {
            fetchData() {
                this.fetchAllMemory()
            },
            update(chart, data, render) {
                chart.update({
                    xAxis: {
                        categories: data.xAxis.categories
                    }
                })
                for (let [index, s] of data.series.entries()) {
                    if (chart.series[index]) {
                        if (s.data.length >= 11) {
                            chart.series[index].removePoint(0)
                        }
                        chart.series[index].addPoint(s.data[s.data.length - 1])
                    } else {
                        chart.addSeries(s)
                    }
                }
            },
            ...mapMutations({
                clearAllMemory: CITYWIDE_CLEAR_MEMORY
            }),
            ...mapActions({
                fetchAllMemory: CITYWIDE_FETCH_MEMORY
            })
        },
        destroyed() {
            this.clearAllMemory()
            clearInterval(this.interval)
        },
        components: {
            Highcharts,
            ModuleComponent
        }
    }
</script>

<style scoped>
    .maintenance-container{
        position: relative;
    }
</style>