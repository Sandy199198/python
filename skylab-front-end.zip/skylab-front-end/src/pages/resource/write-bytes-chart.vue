<template>
    <Highcharts :data="getWriteBytes" :themeType="themeType" :theme="theme" :style="style" :update="update"></Highcharts>
</template>

<script>
    import {
        mapGetters,
        mapMutations,
        mapActions } from 'vuex'
    import Highcharts, { THEME_TYPE } from '@nanyun/highcharts'
    import {
        SERVICE_GET_WRITE_BYTES,
        SERVICE_FETCH_WRITE_BYTES,
        SERVICE_CLEAR_WRITE_BYTES } from 'store/modules/resource'

    export default {
        props: {
            delay: {
                type: Number,
                default: 0
            },
            intervalTime: {
                type: Number,
                default: 5000
            }
        },

        data() {
            return {
                themeType: THEME_TYPE.DARK_UNICA,
                theme: {
                    chart: {
                        backgroundColor: 'rgba(0,0,0,0)'
                    }
                },
                style: {
                    width: '100%',
                    height: '300px',
                    backgroundImage: 'linear-gradient(-180deg, #000304 4%, #002636 99%)'
                }
            }
        },

        created() {
            this.fetchData()
            setTimeout(() => {
                this.interval = setInterval(() => {
                    this.fetchData()
                }, this.intervalTime)
            }, this.delay)
        },

        computed: {
            ...mapGetters({
                getWriteBytes: SERVICE_GET_WRITE_BYTES
            })
        },

        methods: {
            fetchData() {
                this.fetchWriteBytes()
            },
            update(chart, data, render) {
                chart.update({
                    title: {
                        text: data.title.text
                    },
                    xAxis: {
                        categories: data.xAxis.categories
                    }
                })
                for (let [index, s] of data.series.entries()) {
                    if (chart.series[index]) {
                        if (s.data.length >= 7) {
                            chart.series[index].removePoint(0)
                        }
                        chart.series[index].addPoint(s.data[s.data.length - 1])
                    } else {
                        chart.addSeries(s)
                    }
                }
            },
            ...mapMutations({
                clearWriteBytes: SERVICE_CLEAR_WRITE_BYTES
            }),
            ...mapActions({
                fetchWriteBytes: SERVICE_FETCH_WRITE_BYTES
            })
        },

        destroyed() {
            this.clearWriteBytes()
            clearInterval(this.interval)
        },

        components: {
            Highcharts
        }
    }
</script>

<style>
</style>