<template>
    <div class="branch">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="resource">
                <div class="chart">
                    <CitywideMemoryChartComponent :delay="memoryDelay"></CitywideMemoryChartComponent>
                </div>
                <div class="chart">
                    <CitywideLoadChartComponent :delay="loadDelay"></CitywideLoadChartComponent>
                </div>
                <div class="chart">
                    <CitywideDiskChartComponent :delay="diskDelay"></CitywideDiskChartComponent>
                </div>
        </div>
    </div>
</template>

<script>
    import CitywideMemoryChartComponent from 'pages/resource/citywide-memory-chart.vue'
    import CitywideDiskChartComponent from 'pages/resource/citywide-disk-chart.vue'
    import CitywideLoadChartComponent from 'pages/resource/citywide-load-chart.vue'
    import URL from 'common/url'
    import CrumbsComponent from 'common/components/crumbs.vue'

    export default {
        data() {
            return {
                memoryDelay: 0,
                diskDelay: 300,
                loadDelay: 600,
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '市局服务器监控',
                    silent: true
                }]
            }
        },
        components: {
            CitywideMemoryChartComponent,
            CitywideDiskChartComponent,
            CitywideLoadChartComponent,
            CrumbsComponent
        }
    }
</script>

<style scoped>
    .branch{
        min-height: 100%;
        padding:50px 80px;
        box-sizing: border-box;
        .selector{
            color: #FFF;
            font-size: 14px;
            line-height: 25px;
            width: 300px;
            select{
                margin-left:10px;
            }
        }
        .resource{
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            margin-top:30px;

            .chart{
                margin:10px 0;
                box-sizing: border-box;
                flex:0 0 32%;
                height: 300px;
                background: rgb(50,60,80);
            }
        }
    }
</style>