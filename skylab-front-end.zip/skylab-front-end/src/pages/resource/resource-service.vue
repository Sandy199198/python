<template>
   <div class="resource">
        <div class="chart">
            <MemoryChartComponent :delay="memoryDelay"></MemoryChartComponent>
        </div>
        <div class="chart">
            <CPUChartComponent :delay="cpuDelay"></CPUChartComponent>
        </div>
        <div class="chart">
            <ReadBytesComponent :delay="readBytesDelay"></ReadBytesComponent>
        </div>
        <div class="chart">
            <WriteBytesComponent :delay="writeBytesDelay"></WriteBytesComponent>
        </div>
   </div> 
</template>

<script>
    import MemoryChartComponent from 'pages/resource/memory-chart.vue'
    import CPUChartComponent from 'pages/resource/cpu-chart.vue'
    import ReadBytesComponent from 'pages/resource/read-bytes-chart.vue'
    import WriteBytesComponent from 'pages/resource/write-bytes-chart.vue'

    export default {
        data: function () {
            return {
                memoryDelay: 0,
                cpuDelay: 300,
                readBytesDelay: 600,
                writeBytesDelay: 900,
            }
        },
        components: {
            MemoryChartComponent,
            CPUChartComponent,
            ReadBytesComponent,
            WriteBytesComponent,
        }
    }
</script>

<style scoped>
    .resource{
        min-height: 100%;
        padding:50px 80px;
        box-sizing: border-box;
        background: rgb(24, 44, 65);
        display: flex;
        flex-wrap: wrap;
        justify-content: center;

        .chart{
            margin:30px 10px;
            box-sizing: border-box;
            min-width: 500px;
            flex:0 0 45%;
            backgroundImage: 'linear-gradient(-180deg, #000304 4%, #002636 99%)'
        }
    }
</style>