<template>
    <Highcharts :style="style" :themeType="themeType" :theme="theme" :data="chartData" :update="update"></Highcharts>
</template>

<script>
    import Immutable from 'immutable'
    import Vue from 'vue'
    import Highcharts, { THEME_TYPE } from '@nanyun/highcharts'
    import themeStyle from 'common/chart-style'

    export default {
        props: {
            chartData: {
                type: Object,
                required: true
            }
        },

        data() {
            return {
                themeType: THEME_TYPE.DARK_UNICA,
                theme: {
                    chart: {
                        backgroundColor: 'rgba(0,0,0,0)'
                    }
                },
                style: {
                    width: '100%',
                    height: '300px',
                    backgroundImage: 'linear-gradient(-180deg, #000304 4%, #002636 99%)'
                },
                reRender: true,
            }
        },

        watch: {
            $route() {
                this.reRender = true
            }
        },

        created() {
            this.reRender = true
        },
        methods: {
            update(chart, data, render) {
                if (this.reRender) {
                    render()
                    this.reRender = false
                } else {
                    chart.update({
                        title: {
                            text: data.title.text
                        },
                        xAxis: {
                            categories: data.xAxis.categories
                        }
                    })
                    for (let [index, s] of data.series.entries()) {
                        if (chart.series[index]) {
                            if (s.data.length >= 7) {
                                chart.series[index].removePoint(0)
                            }
                            chart.series[index].addPoint(s.data[s.data.length - 1])
                        } else {
                            chart.addSeries(s)
                        }
                    }
                }
            }
        },
        components: {
            Highcharts
        }
    }
</script>

<style scoped>
</style>