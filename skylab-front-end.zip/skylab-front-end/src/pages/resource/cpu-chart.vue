<template>
    <Highcharts :data="serviceCpu" :themeType="themeType" :theme="theme" :style="style" :update="update"></Highcharts>
</template>

<script>
    import {
        mapGetters,
        mapActions } from 'vuex'
    import Highcharts, { THEME_TYPE } from '@nanyun/highcharts'
    import {
        SERVICE_FETCH_CPU_DATA,
        SERVICE_GET_CPU_DATA } from 'store/modules/resource'

    export default {
        props: {
            delay: {
                type: Number,
                default: 0
            },
            intervalTime: {
                type: Number,
                default: 5000
            }
        },
        data() {
            return {
                themeType: THEME_TYPE.DARK_UNICA,
                theme: {
                    chart: {
                        backgroundColor: 'rgba(0,0,0,0)'
                    }
                },
                style: {
                    width: '100%',
                    height: '300px',
                    backgroundImage: 'linear-gradient(-180deg, #000304 4%, #002636 99%)'
                }
            }
        },

        created() {
            this.fetchData()
            setTimeout(() => {
                this.interval = setInterval(() => {
                    this.fetchData()
                }, this.intervalTime)
            }, this.delay)
        },

        computed: {
            ...mapGetters({
                serviceCpu: SERVICE_GET_CPU_DATA
            })
        },

        methods: {
            fetchData() {
                this.fetchServiceCPUData()
            },
            update(chart, data, render) {
                for (let [index, s] of data.series.entries()) {
                    if (chart.series[index]) {
                        chart.series[index].setData(s.data)
                    } else {
                        chart.addSeries(s)
                    }
                }
            },
            ...mapActions({
                fetchServiceCPUData: SERVICE_FETCH_CPU_DATA,
            })
        },

        destroyed() {
            clearInterval(this.interval)
        },

        components: {
            Highcharts
        }
    }
</script>

<style></style>