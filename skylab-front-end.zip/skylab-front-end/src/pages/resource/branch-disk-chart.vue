<template>
    <Highcharts :data="chartData" :themeType="themeType" :theme="theme" :style="style" :update="update"></Highcharts>
</template>

<script>
    import Immutable from 'immutable'
    import Vue from 'vue'
    import Highcharts, { THEME_TYPE } from '@nanyun/highcharts'
    import themeStyle from 'common/chart-style'

    export default {
        props: {
            chartData: {
                type: Object,
                required: true
            }
        },
        data() {
            return {
                themeType: THEME_TYPE.DARK_UNICA,
                theme: {
                    chart: {
                        backgroundColor: 'rgba(0,0,0,0)'
                    }
                },
                style: {
                    width: '100%',
                    height: '300px',
                    backgroundImage: 'linear-gradient(-180deg, #000304 4%, #002636 99%)'
                },
                reRender: true,
                prevCategories: [],
                prevSeriesNum: 0
            }
        },

        created() {
            this.reRender = true
        },
        watch: {
            $route() {
                this.reRender = true
            }
        },

        methods: {
            update(chart, data, render) {
                if (this.reRender) {
                    render()
                    this.reRender = false
                } else {
                    for (let [index, s] of data.series.entries()) {
                        if (chart.series[index]) {
                            chart.series[index].setData(s.data)
                        } else {
                            chart.addSeries(s)
                        }
                    }
                }
            }
        },

        components: {
            Highcharts
        }
    }
</script>

<style></style>