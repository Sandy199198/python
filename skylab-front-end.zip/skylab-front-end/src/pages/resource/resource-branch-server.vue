<template>
    <div class="branch">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="selector">
            选择分局: 
            <select class="form-control" @change="go()" v-model="selectedBranch">
                <option :value="option.name" v-for="option in getAllBranchs">{{option.name}}</option>
            </select>
        </div>    
        <div class="resource">
            <div class="chart">
                <BranchMemoryChartComponent :chartData="getBranchMemory"></BranchMemoryChartComponent>
            </div>
            <div class="chart">
                <BranchLoadChartComponent :chartData="getBranchLoad"></BranchLoadChartComponent>
            </div>
            <div class="chart">
                <BranchDiskChartComponent :chartData="getBranchDisk"></BranchDiskChartComponent>
            </div>
    </div> 
    </div>
</template>

<script>
    import {mapGetters, mapActions, mapMutations } from 'vuex'
    import BranchMemoryChartComponent from 'pages/resource/branch-memory-chart.vue'
    import BranchDiskChartComponent from 'pages/resource/branch-disk-chart.vue'
    import BranchLoadChartComponent from 'pages/resource/branch-load-chart.vue'
    import URL from 'common/url'
    import { GET_ALL_BRANCHS, FETCH_ALL_BRANCHS } from 'store/modules/citywide_info'
    import { BRANCH_GET_DISK,
            BRANCH_FETCH_DISK,
            BRANCH_GET_LOAD,
            BRANCH_FETCH_LOAD,
            BRANCH_CLEAR_LOAD,
            BRANCH_GET_MEMORY,
            BRANCH_CLEAR_MEMORY,
            BRANCH_FETCH_MEMORY,
            SET_LAST_SELECTED_BRANCH } from 'store/modules/resource'
    import CrumbsComponent from 'common/components/crumbs.vue'

    export default {
        data() {
            return {
                memoryDelay: 0,
                diskDelay: 300,
                loadDelay: 600,
                selectedBranch: '',
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '市局服务器监控',
                    path: {
                        name: URL.RESOURCE.RESOURCE_CITYWIDE_SERVER
                    }
                }, {
                    name: '分局',
                    silent: true
                }]
            }
        },
        created() {
            this.fetchAllBranchs().then(() => {
                this.fetchData()
            })

            setTimeout(() => {
                this.interval = setInterval(() => {
                    this.fetchData()
                }, 5000)
            }, this.memoryDelay)
        },

        watch: {
            $route() {
                this.clearMemory()
                this.clearLoad()
                this.fetchData()
            },
        },

        computed: {
            ...mapGetters({
                getBranchDisk: BRANCH_GET_DISK,
                getBranchLoad: BRANCH_GET_LOAD,
                getBranchMemory: BRANCH_GET_MEMORY,
                getAllBranchs: GET_ALL_BRANCHS
            }),
        },
        methods: {
            fetchData() {
                let name = this.$route.params.branch || this.getAllBranchs[0].name

                setTimeout(() => {
                    this.fetchBranchMemory(name)
                }, 100)

                setTimeout(() => {
                    this.fetchBranchDisk(name)
                }, 500)

                setTimeout(() => {
                    this.fetchBranchLoad(name)
                }, 1000)

                this.selectedBranch = name
                this.setLastSelectedBranch(name)

                this.crumbs.splice(this.crumbs.length - 1, 1, {
                    name,
                    silent: true
                })
            },
            go() {
                if (Object.is(this.selectedBranch, undefined)) return
                this.$router.push({
                    name: URL.RESOURCE.RESOURCE_BRANCH_SERVER,
                    params: {
                        branch: this.selectedBranch
                    }
                })
            },
            ...mapMutations({
                clearMemory: BRANCH_CLEAR_MEMORY,
                clearLoad: BRANCH_CLEAR_LOAD,
                setLastSelectedBranch: SET_LAST_SELECTED_BRANCH
            }),
            ...mapActions({
                fetchAllBranchs: FETCH_ALL_BRANCHS,
                fetchBranchDisk: BRANCH_FETCH_DISK,
                fetchBranchLoad: BRANCH_FETCH_LOAD,
                fetchBranchMemory: BRANCH_FETCH_MEMORY
            })
        },
        destroyed() {
            this.clearMemory()
            this.clearLoad()
            clearInterval(this.interval)
        },
        components: {
            BranchMemoryChartComponent,
            BranchDiskChartComponent,
            BranchLoadChartComponent,
            CrumbsComponent
        }
    }
</script>

<style scoped>
    .branch{
        min-height: 100%;
        padding:50px 80px;
        box-sizing: border-box;
        .selector{
            color: #FFF;
            font-size: 14px;
            line-height: 25px;
            width: 300px;
            select{
                margin-left:10px;
            }
        }
        .resource{
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            margin-top:30px;
            
            .chart{
                margin:10px 0;
                box-sizing: border-box;
                flex:0 0 32%;
                height: 300px;
                background: rgb(50,60,80);
            }
        }
    }
    
</style>