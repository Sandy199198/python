<template>
    <div class="branch">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="selector">
            选择服务器:
            <select class="form-control" @change="go()" v-model="selectedMachine" v-if="getMachines.length">
                <option :value="index" v-for="(option,index) in getMachines">{{option.text | getIp}}</option>
            </select>
            <span v-else>&nbsp;&nbsp;暂无服务器</span>
        </div>
    <div class="resource">
            <div class="chart">
                <MemoryChartComponent :chartData="getMemory"></MemoryChartComponent>
            </div>
            <div class="chart">
                <SwapChartComponent :chartData="getSwap"></SwapChartComponent>
            </div>
            <div class="chart">
                <TCPChartComponent :chartData="getTcp"></TCPChartComponent>
            </div>
            <div class="chart">
                <SystemChartComponent :chartData="getSystemLoad"></SystemChartComponent>
            </div>
            <div class="chart">
                <ReadBytesComponent :chartData="getReadByte"></ReadBytesComponent>
            </div>
            <div class="chart">
                <WriteBytesComponent :chartData="getWriteByte"></WriteBytesComponent>
            </div>
            <div class="chart">
                <NetReceiveComponent :chartData="getNetReceiveByte"></NetReceiveComponent>
            </div>
            <div class="chart">
                <NetSendComponent :chartData="getNetSendByte"></NetSendComponent>
            </div>
            <div class="chart">
                <ServerDiskChartComponent :chartData="getDisk"></ServerDiskChartComponent>
            </div>
    </div> 
    </div>
</template>

<script>
    import MemoryChartComponent from 'pages/resource/memory-chart.vue'
    import SwapChartComponent from 'pages/resource/swap-chart.vue'
    import SystemChartComponent from 'pages/resource/system-load-chart.vue'
    import TCPChartComponent from 'pages/resource/server-tcp-chart.vue'
    import ServerDiskChartComponent from 'pages/resource/server-disk-chart.vue'
    //import CPUDetailChartComponent from 'pages/resource/cpu-detail-chart.vue'
    import ReadBytesComponent from 'pages/resource/server-read-bytes-chart.vue'
    import WriteBytesComponent from 'pages/resource/server-write-bytes-chart.vue'
    import NetReceiveComponent from 'pages/resource/net-receive-chart.vue'
    import NetSendComponent from 'pages/resource/net-send-chart.vue'
    import { GET_MACHINES, FETCH_MACHINES,
        SERVER_GET_MEMORY_DATA, SERVER_FETCH_MEMORY_DATA, SERVER_CLEAR_MEMORY_DATA,
        GET_SWAP_DATA, FETCH_SWAP_DATA, CLEAR_SWAP_DATA,
        SERVER_GET_SYSTEM_LOAD, SERVER_FETCH_SYSTEM_LOAD, SERVER_CLEAR_SYSTEM_LOAD,
        SERVER_GET_TCP, SERVER_CLEAR_TCP, SERVER_FETCH_TCP,
        SERVER_GET_DISK, SERVER_FETCH_DISK,
        SERVER_GET_READ_BYTES, SERVER_FETCH_READ_BYTES, SERVER_CLEAR_READ_BYTES,
        SERVER_GET_WRITE_BYTES, SERVER_FETCH_WRITE_BYTES, SERVER_CLEAR_WRITE_BYTES,
        SERVER_GET_NET_RECEIVE_BYTES, SERVER_FETCH_NET_RECEIVE_BYTES, SERVER_CLEAR_NET_RECEIVE_BYTES,
        SERVER_GET_NET_SEND_BYTES, SERVER_FETCH_NET_SEND_BYTES, SERVER_CLEAR_NET_SEND_BYTES,
        GET_MACHINES_BRANCH_NAME,
        SET_LAST_SELECTED_MACHINE } from 'store/modules/resource'
    import URL from 'common/url'
    import CrumbsComponent from 'common/components/crumbs.vue'
    import { mapGetters, mapActions, mapMutations } from 'vuex'
    import { getIp } from 'common/utils'

    export default {
        data: function () {
            return {
                memoryDelay: 0,
                swapDelay: 300,
                systemDelay: 600,
                tcpDelay: 900,
                diskDelay: 1200,
                readBytesDelay: 1500,
                writeBytesDelay: 1800,
                netReadBytesDelay: 2100,
                netWriteBytesDelay: 2400,
                selectedMachine: '',
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '市局服务器监控',
                    path: {
                        name: URL.RESOURCE.RESOURCE_CITYWIDE_SERVER
                    }
                }, {
                    name: '分局',
                    silent: true
                }, {
                    name: '服务器',
                    silent: true
                }]
            }
        },
        created() {
            this.fetchMachines().then(() => {
                this.fetchData()
            })
            setTimeout(() => {
                this.interval = setInterval(() => {
                    this.fetchData()
                }, 5000)
            }, this.memoryDelay)
        },

        watch: {
            $route() {
                this.clearMemory()
                this.clearSwap()
                this.clearSystemLoad()
                this.clearTcp()
                this.clearReadByte()
                this.clearWriteByte()
                this.clearNetReceiveByte()
                this.clearNetSendByte()
                this.fetchData()
            },
        },

        computed: {
            ...mapGetters({
                getMachines: GET_MACHINES,
                getMemory: SERVER_GET_MEMORY_DATA,
                getSwap: GET_SWAP_DATA,
                getSystemLoad: SERVER_GET_SYSTEM_LOAD,
                getTcp: SERVER_GET_TCP,
                getDisk: SERVER_GET_DISK,
                getReadByte: SERVER_GET_READ_BYTES,
                getWriteByte: SERVER_GET_WRITE_BYTES,
                getNetReceiveByte: SERVER_GET_NET_RECEIVE_BYTES,
                getNetSendByte: SERVER_GET_NET_SEND_BYTES,
                getMachinesBranchName: GET_MACHINES_BRANCH_NAME
            }),
            getCurrentName() {
                return this.$route.params.machine !== undefined ? this.getMachines[this.$route.params.machine].value : (this.getMachines.length ? this.getMachines[0].value : '')
            },
            getBranchName() {
                for (let branchName in this.getMachinesBranchName) {
                    if (this.getMachinesBranchName.hasOwnProperty(branchName)) {
                        let branch = this.getMachinesBranchName[branchName]

                        for (let name of branch) {
                            if (name == this.getCurrentName) {
                                return branchName
                            }
                        }
                    }
                }
            },
        },
        methods: {
            fetchData() {
                let name = this.getCurrentName

                if (!name) {
                    return
                }
                setTimeout(() => {
                    this.fetchMemory(name)
                }, 100)

                setTimeout(() => {
                    this.fetchSwap(name)
                }, 500)

                setTimeout(() => {
                    this.fetchSystemLoad(name)
                }, 1000)

                setTimeout(() => {
                    this.fetchTcp(name)
                }, 1500)

                setTimeout(() => {
                    this.fetchDisk(name)
                }, 2000)

                setTimeout(() => {
                    this.fetchReadByte(name)
                }, 2500)

                setTimeout(() => {
                    this.fetchWriteByte(name)
                }, 3000)

                setTimeout(() => {
                    this.fetchNetReceiveByte(name)
                }, 3500)

                setTimeout(() => {
                    this.fetchNetSendByte(name)
                }, 4000)

                let selected = 0

                for (let [index, m] of this.getMachines.entries()) {
                    if (m.value  == name) {
                        selected = index
                        break
                    }
                }
                this.selectedMachine = selected
                this.setLastSelectedMachine(name)

                this.crumbs.splice(this.crumbs.length - 2, 2, {
                    name: this.getBranchName,
                    path: {
                        name: URL.RESOURCE.RESOURCE_BRANCH_SERVER,
                        params: {
                            branch: this.getBranchName
                        }
                    }
                }, {
                    name: getIp(name),
                    silent: true
                })
            },
            go() {
                if (Object.is(this.selectedMachine, undefined)) return
                this.$router.push({
                    name: URL.RESOURCE.RESOURCE_SERVER,
                    params: {
                        machine: encodeURIComponent(this.selectedMachine)
                    }
                })
            },
            ...mapMutations({
                clearMemory: SERVER_CLEAR_MEMORY_DATA,
                clearSwap: CLEAR_SWAP_DATA,
                clearSystemLoad: SERVER_CLEAR_SYSTEM_LOAD,
                clearTcp: SERVER_CLEAR_TCP,
                clearReadByte: SERVER_CLEAR_READ_BYTES,
                clearWriteByte: SERVER_CLEAR_WRITE_BYTES,
                clearNetReceiveByte: SERVER_CLEAR_NET_RECEIVE_BYTES,
                clearNetSendByte: SERVER_CLEAR_NET_SEND_BYTES,
                setLastSelectedMachine: SET_LAST_SELECTED_MACHINE
            }),
            ...mapActions({
                fetchMachines: FETCH_MACHINES,
                fetchMemory: SERVER_FETCH_MEMORY_DATA,
                fetchSwap: FETCH_SWAP_DATA,
                fetchSystemLoad: SERVER_FETCH_SYSTEM_LOAD,
                fetchTcp: SERVER_FETCH_TCP,
                fetchDisk: SERVER_FETCH_DISK,
                fetchReadByte: SERVER_FETCH_READ_BYTES,
                fetchWriteByte: SERVER_FETCH_WRITE_BYTES,
                fetchNetReceiveByte: SERVER_FETCH_NET_RECEIVE_BYTES,
                fetchNetSendByte: SERVER_FETCH_NET_SEND_BYTES
            })
        },
        destroyed() {
            this.clearMemory()
            this.clearSwap()
            this.clearSystemLoad()
            this.clearTcp()
            this.clearReadByte()
            this.clearWriteByte()
            this.clearNetReceiveByte()
            this.clearNetSendByte()
            clearInterval(this.interval)
        },
        components: {
            MemoryChartComponent,
            SwapChartComponent,
            SystemChartComponent,
            TCPChartComponent,
            ReadBytesComponent,
            WriteBytesComponent,
            NetReceiveComponent,
            NetSendComponent,
            ServerDiskChartComponent,
            CrumbsComponent
        }
    }
</script>

<style scoped>
    .branch{
        min-height: 100%;
        padding:50px 80px;
        box-sizing: border-box;
        .selector{
            color: #FFF;
            font-size: 14px;
            line-height: 25px;
            width: 400px;
            select{
                margin-left:10px;
            }
        }
        .resource{
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            margin-top:30px;

            .chart{
                margin:20px 0;
                box-sizing: border-box;
                flex:0 0 32%;
                height: 300px;
                background: rgb(50,60,80);
            }
        }
    }
</style>