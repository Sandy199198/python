<template>
    <div class="colContent">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="resultCon">
            <TableComponent :columns="columns" :data="getCollisionItems">
                <span v-for="(item, index) in this.getCollisionItems" :slot="'element' + index" >
                    <img :src="item.path" :style="style">
                </span>
                <span v-for="(item, index) in this.getCollisionItems" :slot="'events' + index">
                    <a href="#" @click.prevent="detail(index)">详情</a>
                </span>
            </TableComponent>
            <a href="#" @click.prevent="showMore(getPage.cursor)" class="more" v-show="getPage.cursor">更多...</a>
        </div>
    </div>
</template>

<script>
    import URL from 'common/url'
    import TableComponent from '@nanyun/table'
    import PaginationComponent from '@nanyun/pagination'
    import {formatDate, parseDateStrToTimestamp, convertToSeconds} from 'common/utils'
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    import { ACTIONS } from 'common/config'
    import { FETCH_COLLISION_ITEMS, GET_COLLISION_ITEMS, SET_COLLISION_ITEMS, GET_PAGE} from 'store/modules/analysis'
    import CrumbsComponent from 'common/components/crumbs.vue'

    let fromPage
    let routesMap = {
        [URL.ANALYSIS.COLLISION_POINTS]: '多地点分析',
        [URL.ANALYSIS.COLLISION_TIME]: '多时间段分析',
        [URL.ANALYSIS.COLLISION]: '碰撞检测',
        [URL.ANALYSIS.PEER]: '同行分析',
        [URL.ANALYSIS.FREQUENCY]: '频次检测'
    }

    export default {
        beforeRouteEnter(to, from, next) {
            if (from.name != URL.ANALYSIS.COLLISION_DETAIL) {
                fromPage = from
            }
            next()
        },

        data() {
            return {
                style: {
                    width: '114px',
                    height: '114px'
                },
                columns: [{
                    title: '抓拍图',
                    type: 'element',
                }, {
                    title: '频次',
                    prop: 'count'
                }, {
                    title: '抓拍时间',
                    prop: 'timestamp',
                    handle: d => {
                        return formatDate(d, 'Y-M-D h:m')
                    }
                }, {
                    title: '相机名称',
                    prop: 'camera_name',
                    handle: d => {
                        return d ? d : '-'
                    }
                }, {
                    title: '操作',
                    type: 'events'
                }],
                isShow: true,
                pathId: window.location.pathname.split('/')[3],
                group: window.location.pathname.split('/').length > 4 ? window.location.pathname.split('/')[4] : '',
                photo: window.location.pathname.split('/').length > 4 ? window.location.pathname.split('/')[5] : '',
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '任务展示',
                    silent: true
                }]
            }
        },
        methods: {
            fetchData() {
                let options = {
                    id: this.pathId,
                    cusor: '',
                    group: this.group,
                    photo: this.photo
                }

                this.fetchCollisionItems(options)
            },
            ...mapActions({
                fetchCollisionItems: FETCH_COLLISION_ITEMS,
            }),
            showMore(index) {
                let options = {
                    id: this.pathId,
                    cusor: index,
                    group: this.group,
                    photo: this.photo
                }

                this.fetchCollisionItems(options)
            },
            detail(index) {
                let item = this.getCollisionItems[index]
                let group = item.group
                let photo = item['photo_id']
                let params = {
                    id: this.pathId,
                    cusor: '',
                    group: group,
                    photo: photo
                }

                this.$router.push({
                    name: URL.ANALYSIS.COLLISION_DETAIL,
                    params: params
                })
            }
        },
        computed: {
            ...mapGetters({
                getCollisionItems: GET_COLLISION_ITEMS,
                getPage: GET_PAGE
            })
        },
        created() {
            this.fetchData()

            if (fromPage.name) {
                this.crumbs.splice(1, 0, {
                    name: routesMap[fromPage.name],
                    path: {
                        name: fromPage.name,
                        params: fromPage.params
                    }
                })
            }
        },
        components: {
            TableComponent,
            PaginationComponent,
            CrumbsComponent
        }
    }
</script>

<style scoped>
    .colContent{
        background: #1d2c3f;
        padding:50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        .resultCon{
            width: 100%;
            margin-top: 15px;
            .more{
                text-align: center;
                border-radius: 3px;
                display: block;
                margin-top: 15px;
                color: #fff;
                width: 100%;
                font-size: 14px;
                line-height: 2;
                background: #3e485b;
            }
        }
    }
</style>