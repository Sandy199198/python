<template>
    <div class="colContent">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="resultCon">
            <TableComponent :columns="columns" :data="getFrequency">
                <span v-for="(item, index) in this.getFrequency" :slot="'events' + index">
                    <a href="#" @click.prevent="detail(index)">详情</a>
                </span>
            </TableComponent>
            <div style="overflow:hidden">
                <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
            </div>
        </div>
    </div>
</template>

<script>
    import URL from 'common/url'
    import TableComponent from '@nanyun/table'
    import PaginationComponent from '@nanyun/pagination'
    import {formatDate, parseDateStrToTimestamp, convertToSeconds} from 'common/utils'
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    import { ACTIONS } from 'common/config'
    import {GET_FREQUENCY, FETCH_COLLISION, SET_FREQUENCY, GET_PAGE} from 'store/modules/analysis'
    import CrumbsComponent from 'common/components/crumbs.vue'

    export default {
        data() {
            return {
                columns: [{
                    title: '类型',
                    prop: 'job_type',
                    handle: d => {
                        return d == 5 ? '频次检测' : '-'
                    }
                }, {
                    title: '开始时间',
                    prop: 'start_time',
                    handle: d => {
                        return formatDate(d, 'Y-M-D h:m:s')
                    }
                }, {
                    title: '结束时间',
                    prop: 'end_time',
                    handle: d => {
                        return d ? formatDate(d, 'Y-M-D h:m:s') : '-'
                    }
                }, {
                    title: '操作',
                    type: 'events'
                }],
                page: {
                    'job_type': 5
                },
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '频次检测',
                    silent: true
                }]
            }
        },
        methods: {
            detail(index) {
                let id = this.getFrequency[index]['job_id']

                this.$router.push({
                    name: URL.ANALYSIS.COLLISION_INFO,
                    params: {
                        id: id
                    }
                })
            },
            pageEvent(page) {
                this.page = Object.assign(this.page, {
                    page: page
                })
                this.fetchData()
            },
            fetchData() {
                this.fetchCollision(this.page)
            },
            ...mapActions({
                fetchCollision: FETCH_COLLISION,
            }),
        },
        computed: {
            ...mapGetters({
                getFrequency: GET_FREQUENCY,
                getPage: GET_PAGE
            })
        },
        created() {
            this.fetchData()
        },
        components: {
            TableComponent,
            PaginationComponent,
            CrumbsComponent
        }
    }
</script>

<style scoped>
.colContent{
    background: #1d2c3f;
    padding:50px 80px;
    box-sizing: border-box;
    min-height: 100%;
    .resultCon{
        width: 100%;
        margin-top: 15px;
    }
}
</style>