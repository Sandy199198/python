<template>
    <div class="colContent">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="optionCon">
            <ModuleComponent>
                <div class="statistics-title" slot="title">
                    <span>条件选择</span>
                    <span class="error" name="errorShow" v-show="camIsError"></span>
                    <span class="error" name="timeSearchError" v-show="timeErrorShow" :style="{marginLeft: '15px'}"></span>
                    <a href="#" class="button-style" @click.prevent="search">搜索</a>
                </div>
                <form name="formOptions" slot="content">
                    <input type="hidden" name="start_time">
                    <input type="hidden" name="end_time">
                    <div class="content">
                        <div class="col-3">
                            <div class="camList">
                                <FileUploadComponent></FileUploadComponent>
                            </div>
                        </div>
                        <div class="col-3">
                            <div class="form-group">
                                <span class="title">阈&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;值:</span>
                                <div class="col-9">
                                    <input type="text" value="70" class="form-control" name="threshold">
                                    <span class="error" name="thresholdSearchError" v-show="tErrorShow"></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <span class="title">结果选择:</span>
                                <div class="col-9">
                                    <select class="form-control" name="limit">
                                        <option value="100">返回100条结果</option>
                                        <option value="50">返回50条结果</option>
                                        <option value="10">返回10条结果</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <span class="title">时&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;间:</span>
                                <div class="camCon col-9">
                                    <div class="item">
                                        <DatepickerComponent class="time-slt" :date="startTime" :limit="startLimit" :options="dateOptions" v-on:change="changeStartDate" id="startTime"></DatepickerComponent>
                                    </div>
                                    <span class="to">~</span>
                                    <div class="item">
                                        <DatepickerComponent class="time-slt" :date="endTime" :limit="endLimit" :options="dateOptions" v-on:change="changeEndDate" id="endTime"></DatepickerComponent>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </ModuleComponent>
        </div>
        <div class="optionCon">
            <ModuleComponent>
                <div class="statistics-title" slot="title">
                    <span>结果展示</span>
                    <span class="error" name="errorTaskShow" v-show="taskIsError"></span>
                    <a href="#" class="button-style" @click.prevent="addTask">新建任务</a>
                    <div class="taskoptions">
                        <div class="form-group">
                            <div class="col-9">
                                <input type="text" class="form-control" name="time" placeholder="时间间隔(min)">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-9">
                                <input type="text" class="form-control" placeholder="阈值(1~100)" name="taskThreshold">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-9">
                                <select class="form-control" name="taskLimit">
                                    <option value="100">出现频率前100</option>
                                    <option value="3">重复出现3次以上</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="content" slot="content">
                    <div v-if="captureSearchResult.length" class="content-items">
                        <div class="card-items" v-for="article in captureSearchResult">
                            <p class="capture-group">{{article.capture_group}}</p>
                            <div class="card" v-for="item in article.captures">
                                <input type="checkbox" class="checkbox" :value="item.timestamp" v-on:change="checkChange" :id="article.capture_group">
                                <div>
                                    <img :src="item.path">
                                    <span class="score">{{item.score.toFixed(2)}}</span>
                                </div>
                                <span>{{item.camera_name}}</span>
                                <br>
                                <span>{{item.timestamp | formatDate}}</span>
                            </div>
                        </div>
                    </div>
                    <div class="no-result" v-else>暂无结果</div>
                </div>
            </ModuleComponent>
        </div>
        <div class="resultCon">
            <TableComponent :columns="columns" :data="getPeer">
                <span v-for="(item, index) in this.getPeer" :slot="'events' + index">
                    <a href="#" @click.prevent="detail(index)">详情</a>
                    <a href="#" @click.prevent="del(index)">删除</a>
                    <a href="#" @click.prevent="refresh(index)">重新执行</a>
                </span>
            </TableComponent>
            <div style="overflow:hidden">
                <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
            </div>
        </div>
        <ConfirmComponent :show="showDelConfirm"
            title="删除"
            :confirm="confirmDel"
        >
            <div slot="content">确定要删除当前任务吗？</div>
        </ConfirmComponent>
    </div>
</template>

<script>
    import URL from 'common/url'
    import TableComponent from '@nanyun/table'
    import ConfirmComponent from '@nanyun/confirm'
    import DatepickerComponent from 'common/components/datepicker.vue'
    import FileUploadComponent from 'common/components/upload.vue'
    import PaginationComponent from '@nanyun/pagination'
    import {formatDate, parseDateStrToTimestamp, convertToSeconds, parseDate} from 'common/utils'
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    import { ACTIONS } from 'common/config'
    import {GET_PEER, FETCH_COLLISION, SET_PEER, GET_PAGE, ADD_PEER, DEL_COLLISION, CAPTURE_SEARCH_RESULT, CAPTURE_SEARCH} from 'store/modules/analysis'
    import {GET_SERVICES} from 'store/modules/common'
    import ModuleComponent from 'common/components/module.vue'
    import CrumbsComponent from 'common/components/crumbs.vue'

    export default {
        data() {
            return {
                columns: [{
                    title: '类型',
                    prop: 'job_type',
                    handle: d => {
                        return d == 4 ? '同行分析' : '-'
                    }
                }, {
                    title: '开始时间',
                    prop: 'start_time',
                    handle: d => {
                        return formatDate(d, 'Y-M-D h:m')
                    }
                }, {
                    title: '操作',
                    type: 'events'
                }],
                camShowList: [{
                    id: 1,
                    name: '相机1'
                }, {
                    id: 2,
                    name: '相机2'
                }, {
                    id: 3,
                    name: '相机3'
                }, {
                    id: 4,
                    name: '相机4'
                }],
                cameras: [],
                camIsError: false,
                taskIsError: false,
                startTime: {
                    time: ''
                },
                startLimit: [],
                endTime: {
                    time: ''
                },
                endLimit: [],
                dateOptions: {
                    type: 'day',
                    format: 'YYYY-MM-DD',
                },
                taskOptions: {},
                taskThreshold: 70,
                frequency: 3,
                pictureInfo: [],
                tempPicInfo: [],
                tErrorShow: false,
                timeErrorShow: false,
                // result: this.captureSearchResult || [],
                page: {
                    'job_type': 4
                },
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '同行分析',
                    silent: true
                }],
                showDelConfirm: {
                    value: false
                },
                index: '',
            }
        },
        methods: {
            addTask() {
                let value = document.querySelector('[name=taskLimit]').value
                let tValue = document.querySelector('[name=taskThreshold]').value
                let time = document.querySelector('[name=time]').value
                let taskError = document.querySelector('[name=errorTaskShow]')
                let tEmpty = '阈值不能为空'
                let noPicInfo = '搜索结果未选择'
                let pInvalid = '结果范围不能唯一'
                let tInvalid = '阈值范围1~100'
                let timeEmpty = '时间间隔不能为空'

                if (!this.pictureInfo.length) {
                    taskError.innerHTML = noPicInfo
                    this.taskIsError = true
                    return
                } else if (this.cameras.length == 1) {
                    taskError.innerHTML = pInvalid
                    this.taskIsError = true
                    return
                }
                if (!time) {
                    taskError.innerHTML = timeEmpty
                    this.taskIsError = true
                    return
                }
                if (!tValue) {
                    taskError.innerHTML = tEmpty
                    this.taskIsError = true
                    return
                } else {
                    if (tValue > 100 || tValue < 0) {
                        taskError.innerHTML = tInvalid
                        this.taskIsError = true
                        return
                    } else {
                        this.taskThreshold = tValue
                        this.taskIsError = false
                    }
                }
                if (value == 100) {
                    Object.assign(this.taskOptions, {
                        limit: value
                    })
                } else {
                    Object.assign(this.taskOptions, {
                        frequency: value
                    })
                }
                this.taskIsError = false
                Object.assign(this.taskOptions, {
                    'pic_info': this.pictureInfo,
                    threshold: this.taskThreshold,
                    interval: time,
                    'job_type': 4,
                    add: true
                })
                this.addPeer(this.taskOptions)
                this.fetchData()
            },
            search() {
                let formOptions = document.querySelector('[name=formOptions]')
                let startDate = document.querySelector('#startTime input').value
                let endDate = document.querySelector('#endTime input').value
                let threshold = document.querySelector('[name=threshold]').value
                let timeSearchError = document.querySelector('[name=timeSearchError]')
                let thresholdSearchError = document.querySelector('[name=thresholdSearchError]')
                let timeEmpty = '时间不能为空'
                let timeInvalid = '时间不合法'
                let tEmpty = '阈值不能为空'
                let tInvalid = '阈值范围1~100'
                let errorShow = document.querySelector('[name=errorShow]')
                let img = document.querySelector('.img-show')
                let imgEmpty = '请上传图片'

                if (img.style.display == 'none') {
                    errorShow.innerHTML = imgEmpty
                    this.camIsError = true
                    return
                }
                if (!threshold) {
                    thresholdSearchError.innerHTML = tEmpty
                    this.tErrorShow = true
                    return
                } else {
                    if (threshold > 100 || threshold < 0) {
                        thresholdSearchError.innerHTML = tInvalid
                        this.tErrorShow = true
                        return
                    }
                }
                if (!startDate || !endDate) {
                    timeSearchError.innerHTML = timeEmpty
                    this.timeErrorShow = true
                    return
                } else if (parseDateStrToTimestamp(startDate + ' 00:00') > parseDateStrToTimestamp(endDate + ' 00:00')) {
                    timeSearchError.innerHTML = timeInvalid
                    this.timeErrorShow = true
                    return
                }
                this.camIsError = false
                document.querySelector('[name=start_time]').value = parseDateStrToTimestamp(startDate + ' 00:00') / 1000
                document.querySelector('[name=end_time]').value = parseDateStrToTimestamp(endDate + ' 00:00') / 1000
                // let request = new XMLHttpRequest()

                // request.open('POST', this.getServices.SecurityPlus + 'search/search-capture')
                // request.withCredentials = true
                // request.onload = () => {
                //     if (request.status == 200) {
                //         let data = JSON.parse(request.response).data

                //         if (!data.length) {
                //             this.result = []
                //         } else {
                //             this.result = data
                //         }
                //     }
                // }
                // request.send(new FormData(formOptions))
                this.captureSearch(formOptions)
                this.taskIsError = false
            },
            checkChange(e) {
                let isChecked = e.currentTarget.checked
                let value = e.currentTarget.value
                let id = e.currentTarget.id
                let key = e.currentTarget.name

                this.cameras = []
                if (isChecked) {
                    this.tempPicInfo.push(key)
                    this.pictureInfo.push({
                        camera: id,
                        time: parseFloat(value)
                    })
                } else {
                    for (let i in this.tempPicInfo) {
                        if (this.tempPicInfo[i] == key) {
                            this.tempPicInfo.splice(i, 1)
                            this.pictureInfo.splice(i, 1)
                            break
                        }
                    }
                }
                for (let i in this.pictureInfo) {
                    if (this.cameras.indexOf(this.pictureInfo[i].camera) == -1) {
                        this.cameras.push(this.pictureInfo[i].camera)
                    }
                }
            },
            del(index) {
                let id = this.getPeer[index]['job_id']

                this.showDelConfirm.value = true
                this.index = id
            },
            confirmDel() {
                this.delCollision(this.index).then(() => {
                    this.fetchData()
                })
            },
            detail(index) {
                let id = this.getPeer[index]['job_id']

                this.$router.push({
                    name: URL.ANALYSIS.COLLISION_INFO,
                    params: {
                        id: id
                    }
                })
            },
            refresh(index) {
                let options = this.getPeer[index].condition

                options = Object.assign(options, {
                    add: false
                })
                this.addPeer(options).then(() => {
                    this.fetchData()
                })
            },
            changeStartDate(startDate) {
                let date = startDate ? startDate.split(' ')[0] + ' 00:00' : ''
                let start = formatDate((parseDateStrToTimestamp(date) / 1000 - 86400), 'Y-M-D')

                this.endLimit = [{
                    type: 'fromto',
                    from: start,
                    to: ''
                }]
                this.timeErrorShow = false
            },
            changeEndDate(endDate) {
                let date = endDate ? endDate.split(' ')[0] + ' 00:00' : ''
                let end = formatDate((parseDateStrToTimestamp(date) / 1000 + 86400), 'Y-M-D')

                this.startLimit = [{
                    type: 'fromto',
                    from: '',
                    to: end
                }]
                this.timeErrorShow = false
            },
            fileChange() {

            },
            upload() {

            },
            ...mapActions({
                fetchCollision: FETCH_COLLISION,
                addPeer: ADD_PEER,
                delCollision: DEL_COLLISION,
                captureSearch: CAPTURE_SEARCH
            }),
            fetchData() {
                this.fetchCollision(this.page)
            },
            pageEvent(page) {
                this.page = Object.assign(this.page, {
                    page: page
                })
                this.fetchData()
            }
        },
        computed: {
            ...mapGetters({
                getPeer: GET_PEER,
                getPage: GET_PAGE,
                getServices: GET_SERVICES,
                captureSearchResult: CAPTURE_SEARCH_RESULT
            })
        },
        created() {
            this.fetchData()
        },
        components: {
            TableComponent,
            PaginationComponent,
            DatepickerComponent,
            FileUploadComponent,
            ModuleComponent,
            CrumbsComponent,
            ConfirmComponent
        }
    }
</script>

<style scoped>
    .colContent{
        background: #1d2c3f;
        padding:50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        .optionCon{
            width: 100%;
            margin-bottom: 30px;
            .taskoptions{
                float: right;
                width: 40%;
                .form-group{
                    float: left;
                    width: 33.33%;
                    .form-control{
                        width: 80%;
                    }
                    select.form-control{
                        box-sizing: content-box;
                    }
                }
            }
        }
        .resultCon{
            width: 100%;
            margin-top: 30px;
        }
    }
    .content{
        display: flex;
        .col-3{
            flex: 1;
            padding: 0 10px;
        }
        .col-9{
            flex: 3;
            &.camCon{
                .item{
                    width: 40%;
                    overflow: hidden;
                }
                .to{
                    position: relative;
                    top: -11px;
                    margin-left: 0;
                }
            }
        }
        .form-group{
            display: flex;
            height: 45px;
            .title{
                display: inline-block;
                padding-top: 3px;
                margin-right: 15px;
                color: #fff;
                font-size: 14px;
                line-height: 26px;
                width: 65px;
            }
            .form-control{
                height: 28px;
                width: 50%;
                border-radius: 0;
                padding-left: 4px;
            }
            select.form-control{
                background-color: #fff;
                color: #000;
                box-sizing: content-box;
                padding-left: 4px;
                height: 28px;
                border-radius: 0;
            }
        }
        .to{
            color: #fff;
            margin-left: -7px;
            margin-right: 2px;
        }
        .item{
            width: 33.33%;
            display: inline-block;
            margin-right: 5px;
            .item-slt{
                width: 100%;
                color: #000;
                box-sizing: content-box;
                padding-left: 4px;
                height: 32px;
                border-radius: 0;
                -webkit-appearance: none;
                background: url(http://ourjs.github.io/static/2015/arrow.png) no-repeat scroll right center #fff;
            }
        }
        .camList, .dateRange{
            margin-top: 11px;
            overflow: auto;
            height: 100px;
            padding: 7px 2px;
            position: relative;
            border: 1px solid rgb(166, 166, 166);
            .label{
                border-radius: 3px;
                float: left;
                padding: 3px 7px;
                margin: 0 5px 5px 2px;
                color: #555;
                background-color: #eee;
                a{
                    margin-left: 3px;
                }
            }
        }
        .camList{
            margin-top: 0;
            height: 118px;
        }
        .card-items, .content-items{
            width: 100%;
            overflow: hidden;
        }
        .capture-group{
            width: 100%;
            color: #fff;
            margin: 0;
            padding: 5px 3px;
            background: #525a69;
        }
    }
    .statistics-title{
        span{
            line-height: 22px;
        }
    }
    .error{
        color: #ff1414;
    }
    .button-style{
        float: right;
        background: #3890de;
        border: 1px solid #2c679c;
        border-top-color: #3890ca;
        border-left-color: #3890ca;
        color: #FFF;
        border-radius: 2px;
        padding: 3px 25px;
        outline: none;
        cursor: pointer;
        margin-top: 1px;
    }
    .button-style.additem{
        float: none;
        margin-left: 10px;
    }
    .card{
        color: #fff;
        float: left;
        margin: 8px 8px;
        width: 158px;
        height: 198px;
        border: 1px solid #e2e2e2;
        text-align: center;
        position: relative;
        .checkbox{
            position: absolute;
            top: 3px;
            left: 3px;
            z-index: 5;
            outline: none;
        }
        div{
            height: 142px;
            position: relative;
            span.score{
                position: absolute;
                right: 12px;
                bottom: 4px;
                font-size: 12px;
                padding: 0 4px;
                border-radius: 2px;
                background-color: #f4b04f;
            }
        }
        img{
            width: 122px;
            height: 122px;
            margin: 10px auto 6px auto;
        }
        span{
            line-height: 20px;
            font-size: 14px;
        }
    }
    .no-result{
        color: #fff;
    }
</style>