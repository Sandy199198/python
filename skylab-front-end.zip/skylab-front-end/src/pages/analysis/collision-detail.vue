<template>
    <div class="colContent">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="resultCon">
            <TableComponent :columns="columnsDetail" :data="getCollisionDetailItems">
                <span v-for="(item, index) in this.getCollisionDetailItems" :slot="'element' + index" >
                    <img :src="item.path" :style="style">
                </span>
            </TableComponent>
            <a href="#" @click.prevent="showMore(getPage.cursor)" class="more" v-show="getPage.cursor">更多...</a>
        </div>
    </div>
</template>

<script>
    import URL from 'common/url'
    import TableComponent from '@nanyun/table'
    import PaginationComponent from '@nanyun/pagination'
    import {formatDate, parseDateStrToTimestamp, convertToSeconds} from 'common/utils'
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    import { ACTIONS } from 'common/config'
    import { FETCH_COLLISION_ITEMS, GET_COLLISION_DETAIL_ITEMS, SET_COLLISION_ITEMS, GET_PAGE} from 'store/modules/analysis'
    import CrumbsComponent from 'common/components/crumbs.vue'

    let fromPage

    export default {
        beforeRouteEnter(to, from, next) {
            fromPage = from
            next()
        },

        data() {
            return {
                style: {
                    width: '114px',
                    height: '114px'
                },
                columnsDetail: [{
                    title: '抓拍图',
                    type: 'element',
                }, {
                    title: '抓拍时间',
                    prop: 'timestamp',
                    handle: d => {
                        return formatDate(d, 'Y-M-D h:m')
                    }
                }, {
                    title: '相机名称',
                    prop: 'camera_name',
                    handle: d => {
                        return d ? d : '-'
                    }
                }, {
                    title: '比对值',
                    prop: 'score',
                    handle: d => {
                        return d ? parseFloat(d).toFixed(2) : '-'
                    }
                }],
                isShow: true,
                pathId: window.location.pathname.split('/')[3],
                group: window.location.pathname.split('/').length > 4 ? window.location.pathname.split('/')[4] : '',
                photo: window.location.pathname.split('/').length > 4 ? window.location.pathname.split('/')[5] : '',
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '研判详情页',
                    silent: true
                }]
            }
        },
        methods: {
            fetchData() {
                let options = {
                    id: this.pathId,
                    cusor: '',
                    group: this.group,
                    photo: this.photo
                }

                this.fetchCollisionItems(options)
            },
            ...mapActions({
                fetchCollisionItems: FETCH_COLLISION_ITEMS,
            }),
            showMore(index) {
                let options = {
                    id: this.pathId,
                    cusor: index,
                    group: this.group,
                    photo: this.photo
                }

                this.fetchCollisionItems(options)
            },
            detail(index) {
                let item = this.getCollisionDetailItems[index]
                let group = item.group
                let photo = item['photo_id']
                let params = {
                    id: this.pathId,
                    cusor: '',
                    group: group,
                    photo: photo
                }

                this.$router.push({
                    name: URL.ANALYSIS.COLLISION_DETAIL,
                    params: params
                })
            }
        },
        computed: {
            ...mapGetters({
                getCollisionDetailItems: GET_COLLISION_DETAIL_ITEMS,
                getPage: GET_PAGE
            })
        },
        created() {
            this.fetchData()

            if (fromPage.name) {
                this.crumbs.splice(1, 0, {
                    name: '任务展示',
                    path: {
                        name: fromPage.name,
                        params: fromPage.params
                    }
                })
            }
        },
        components: {
            TableComponent,
            PaginationComponent,
            CrumbsComponent
        }
    }
</script>

<style scoped>
    .colContent{
        background: #1d2c3f;
        padding:50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        .resultCon{
            width: 100%;
            margin-top: 15px;
            .more{
                text-align: center;
                border-radius: 3px;
                display: block;
                margin-top: 15px;
                color: #fff;
                width: 100%;
                font-size: 14px;
                line-height: 2;
                background: #3e485b;
            }
        }
    }
</style>