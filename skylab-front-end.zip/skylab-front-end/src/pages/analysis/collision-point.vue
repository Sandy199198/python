<template>
    <div class="colContent">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="optionCon">
            <ModuleComponent>
                <div class="statistics-title" slot="title">
                    <span>条件选择</span>
                    <span class="error" name="errorShow" v-show="camIsError"></span>
                    <a href="#" class="button-style" @click.prevent="addTask">新建任务</a>
                </div> 
                <div class="content" slot="content">
                    <div class="col-3">
                        <div class="form-group">
                            <span class="title">阈&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;值:</span>
                            <div class="col-9">
                                <input type="text" value="70" class="form-control" name="threshold">
                            </div>
                        </div>
                        <div class="form-group">
                            <span class="title">结果选择:</span>
                            <div class="col-9">
                                <select class="form-control" name="limit">
                                    <option value="100">出现频率前100</option>
                                    <option value="3">重复出现3次以上</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="camCon">
                            <span class="camtitle">相机选择:</span>
                            <div class="item">
                                <select class="item-slt" name="camSelect">
                                    <option v-for="option in getCameras" :value="option.id" v-text="option.name">{{option.name}}</option>
                                </select>
                            </div>
                            <a href="#" class="button-style additem" @click.prevent="addCam"><i class="fa fa-plus"></i>&nbsp;&nbsp;添加</a>
                        </div>
                        <div class="camList">
                            <p class="label" v-for="cam in camList">
                                <span class="camIcon"><i class="fa-camera fa"></i></span>
                                <span class="camName">{{cam.name}}</span>
                                <a href="#" @click.prevent="delCam(cam.id)"><i class="fa-times fa"></i></a>
                            </p>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="camCon">
                            <div class="item time-item">
                                <DatepickerComponent class="time-slt" :date="startTime" :limit="startLimit" :options="dateOptions" v-on:change="changeStartDate"></DatepickerComponent>
                            </div>
                            <span class="to">~</span>
                            <div class="item time-item">
                                <DatepickerComponent class="time-slt" :date="endTime" :limit="endLimit" :options="dateOptions" v-on:change="changeEndDate"></DatepickerComponent>
                            </div>
                        </div>
                    </div>
                </div>
            </ModuleComponent>
        </div>
        <div class="resultCon">
            <TableComponent :columns="columns" :data="getCollisionPoint">
                <span v-for="(item, index) in this.getCollisionPoint" :slot="'events' + index">
                    <a href="#" @click.prevent="detail(index)">详情</a>
                    <a href="#" @click.prevent="del(index)">删除</a>
                    <a href="#" @click.prevent="refresh(index)">重新执行</a>
                </span>
            </TableComponent>
            <div style="overflow:hidden">
                <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
            </div>
        </div>
        <ConfirmComponent :show="showDelConfirm"
            title="删除"
            :confirm="confirmDel"
        >
            <div slot="content">确定要删除当前任务吗？</div>
        </ConfirmComponent>
    </div>
</template>

<script>
    import URL from 'common/url'
    import TableComponent from '@nanyun/table'
    import ConfirmComponent from '@nanyun/confirm'
    import DatepickerComponent from 'common/components/datepicker.vue'
    import PaginationComponent from '@nanyun/pagination'
    import {formatDate, parseDateStrToTimestamp, convertToSeconds} from 'common/utils'
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    import { ACTIONS } from 'common/config'
    import {GET_CAMERAS, FETCH_CAMERAS } from 'store/modules/cameras'
    import {GET_COLLISION_POINT, FETCH_COLLISION, SET_COLLISION_POINT, GET_PAGE, ADD_COLLISION, DEL_COLLISION} from 'store/modules/analysis'
    import ModuleComponent from 'common/components/module.vue'
    import CrumbsComponent from 'common/components/crumbs.vue'

    export default {
        data() {
            return {
                columns: [{
                    title: '类型',
                    prop: 'job_type',
                    handle: d => {
                        return d == 2 ? '多地点分析' : '-'
                    }
                }, {
                    title: '开始时间',
                    prop: 'start_time',
                    handle: d => {
                        return formatDate(d, 'Y-M-D h:m')
                    }
                }, {
                    title: '操作',
                    type: 'events'
                }],
                camList: [],
                cameras: [],
                camIsError: false,
                period: [{
                    start: '',
                    end: ''
                }],
                startTime: {
                    time: ''
                },
                endTime: {
                    time: ''
                },
                startLimit: [],
                endLimit: [],
                dateOptions: {
                    type: 'min',
                    format: 'YYYY-MM-DD HH:mm',
                },
                taskOptions: {},
                page: {
                    'job_type': 2
                },
                showDelConfirm: {
                    value: false
                },
                index: '',
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '多地点分析',
                    silent: true
                }]
            }
        },
        methods: {
            addTask() {
                let value = document.querySelector('[name=limit]').value
                let tValue = document.querySelector('[name=threshold]').value
                let errorShow = document.querySelector('[name=errorShow]')
                let tEmpty = '阈值不能为空'
                let tInvalid = '阈值范围1~100'
                let camEmpty = '相机选择不能为空'
                let camOne = '请在选择一台相机'
                let dateEmpty = '时段选择不能为空'
                let dateInvalid = '时段选择不合法'

                if (!tValue) {
                    errorShow.innerHTML = tEmpty
                    this.camIsError = true
                    return
                } else {
                    if (tValue > 100 || tValue < 0) {
                        errorShow.innerHTML = tInvalid
                        this.camIsError = true
                        return
                    } else {
                        this.threshold = tValue
                        this.camIsError = false
                    }
                }
                if (value == 100) {
                    Object.assign(this.taskOptions, {
                        limit: value
                    })
                } else {
                    Object.assign(this.taskOptions, {
                        frequency: value
                    })
                }
                if (!this.cameras.length) {
                    errorShow.innerHTML = camEmpty
                    this.camIsError = true
                    return
                } else if (this.cameras.length == 1) {
                    errorShow.innerHTML = camOne
                    this.camIsError = true
                    return
                }
                if (!this.period[0].start || !this.period[0].end) {
                    errorShow.innerHTML = dateEmpty
                    this.camIsError = true
                    return
                } else if (this.period[0].start >= this.period[0].end) {
                    errorShow.innerHTML = dateInvalid
                    this.camIsError = true
                    return
                }
                this.camIsError = false
                Object.assign(this.taskOptions, {
                    threshold: this.threshold,
                    periods: this.period,
                    cameras: this.cameras,
                    'job_type': 2,
                    add: true
                })
                this.addCollisionPoint(this.taskOptions)
                this.fetchData()
            },
            delCam(id) {
                let index = this.cameras.indexOf(id)
                let camList = this.camList

                this.camIsError = false
                this.cameras.splice(index, 1)
                for (let i in camList) {
                    if (camList[i].id == id) {
                        camList.splice(i, 1)
                        break
                    }
                }
            },
            addCam() {
                let cam = document.querySelector('[name=camSelect]')
                let camName = cam.options[cam.selectedIndex].text
                let errorShow = document.querySelector('[name=errorShow]')
                let camEmpty = '相机选择不能为空'
                let camRepeat = '该相机已选择'

                if (cam.value) {
                    if (this.cameras.indexOf(cam.value) > -1) {
                        errorShow.innerHTML = camRepeat
                        this.camIsError = true
                    } else {
                        this.camIsError = false
                        this.camList.push({
                            id: cam.value,
                            name: camName
                        })
                        this.cameras.push(cam.value)
                    }
                } else {
                    errorShow.innerHTML = camEmpty
                    this.camIsError = true
                }
            },
            changeStartDate(startDate) {
                let date = startDate ? startDate.split(' ')[0] + ' 00:00' : ''
                let start = formatDate((parseDateStrToTimestamp(date) / 1000 - 86400), 'Y-M-D h:m')
                let end = formatDate((parseDateStrToTimestamp(date) / 1000 + 86400), 'Y-M-D h:m')

                this.endLimit = [{
                    type: 'fromto',
                    from: start,
                    to: end
                }]
                this.period[0].start = parseDateStrToTimestamp(startDate) / 1000
            },
            changeEndDate(endDate) {
                let date = endDate ? endDate.split(' ')[0] + ' 00:00' : ''
                let start = formatDate((parseDateStrToTimestamp(date) / 1000 - 86400), 'Y-M-D h:m')
                let end = formatDate((parseDateStrToTimestamp(date) / 1000 + 86400), 'Y-M-D h:m')

                this.startLimit = [{
                    type: 'fromto',
                    from: start,
                    to: end
                }]
                this.period[0].end = parseDateStrToTimestamp(endDate) / 1000
            },
            pageEvent(page) {
                this.page = Object.assign(this.page, {
                    page: page
                })
                this.fetchData()
            },
            del(index) {
                let id = this.getCollisionPoint[index]['job_id']

                this.showDelConfirm.value = true
                this.index = id
            },
            confirmDel() {
                this.delCollision(this.index).then(() => {
                    this.fetchData()
                })
            },
            detail(index) {
                let id = this.getCollisionPoint[index]['job_id']

                this.$router.push({
                    name: URL.ANALYSIS.COLLISION_INFO,
                    params: {
                        id: id
                    }
                })
            },
            refresh(index) {
                let options = this.getCollisionPoint[index].condition

                options = Object.assign(options, {
                    add: false
                })
                this.addCollisionPoint(options).then(() => {
                    this.fetchData()
                })
            },
            fetchData() {
                this.fetchCollision(this.page)
                this.fetchCameras()
            },
            ...mapActions({
                fetchCameras: FETCH_CAMERAS,
                fetchCollision: FETCH_COLLISION,
                addCollisionPoint: ADD_COLLISION,
                delCollision: DEL_COLLISION
            }),
        },
        computed: {
            ...mapGetters({
                getCollisionPoint: GET_COLLISION_POINT,
                getCameras: GET_CAMERAS,
                getPage: GET_PAGE
            })
        },
        created() {
            this.fetchData()
        },
        components: {
            TableComponent,
            PaginationComponent,
            DatepickerComponent,
            ModuleComponent,
            CrumbsComponent,
            ConfirmComponent
        }
    }
</script>

<style scoped>
    .colContent{
        background: #1d2c3f;
        padding:50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        .optionCon{
            width: 100%;
        }
        .resultCon{
            width: 100%;
            margin-top: 30px;
        }
    }
    .camtitle{
        color: #fff;
        margin-right: 15px;
        font-size: 14px;
    }
    .content{
        display: flex;
        .col-3{
            flex: 1;
            padding: 0 20px;
            box-sizing: border-box;
        }
        .col-9{
            flex: 3;
        }
        .form-group{
            display: flex;
            height: 45px;
            .title{
                display: inline-block;
                padding-top: 3px;
                margin-right: 15px;
                color: #fff;
                font-size: 14px;
                line-height: 26px;
                display: inline-block;
                width: 60px;
            }
            .form-control{
                height: 28px;
                width: 50%;
                border-radius: 0;
            }
            select.form-control{
                background-color: #fff;
                color: #000;
                box-sizing: content-box;
                padding-left: 12px;
                height: 28px;
                border-radius: 0;
            }
        }
        .to{
            color: #fff;
            position: relative;
            top: -11px;
            margin-left: -2px;
            margin-right: 2px;
        }
        .item{
            width: 33.33%;
            display: inline-block;
            margin-right: 5px;
            &.time-item{
                width: 45%;
                overflow: hidden;
            }
            .item-slt{
                width: 100%;
                color: #000;
                box-sizing: content-box;
                padding-left: 4px;
                height: 32px;
                border-radius: 0;
                -webkit-appearance: none;
                background: url(http://ourjs.github.io/static/2015/arrow.png) no-repeat scroll right center #fff;
            }
            .time-slt input.cov-datepicker{
                width: 100% !important;
                min-width: 90% !important;
                color: #000 !important;
                padding-left: 4px !important;
                height: 28px !important;
                border-radius: 0 !important;
            }
        }
        .camList, .dateRange{
            margin-top: 12px;
            overflow: auto;
            height: 100px;
            border: 1px solid rgb(166, 166, 166);
            .label{
                border-radius: 3px;
                float: left;
                padding: 3px 7px;
                color: #555;
                background-color: #eee;
                a{
                    margin-left: 3px;
                }
            }
        }
    }
    .statistics-title{
        span{
            line-height: 22px;
        }
        .error{
            color: #ff1414;
        }
    }
    .button-style{
        float: right;
        background: #3890de;
        border: 1px solid #2c679c;
        border-top-color: #3890ca;
        border-left-color: #3890ca;
        color: #FFF;
        border-radius: 2px;
        padding: 3px 10px;
        outline: none;
        cursor: pointer;
    }
    .button-style.additem{
        float: right;
        margin-top: 4px;
        margin-left: 20px;
    }
</style>