<template>
  <div class="server-config">
      <div class="table_content">
            <div class="content">
                <div class="condition">
                    <input type="text" class="input-style" placeholder="请输入名称" v-model="searchCaptureObj.name"/>
                    <a href="#" class="button-style search" @click.prevent="searchCapture">搜索</a>
                    <a href="#" class="button-style" @click.prevent="addCapture" style="float: right;">新建</a>
                </div>
                <TableComponent :data="getCaptureCore" :columns="columns">
                    <span v-for="(item, index) in this.getCaptureCore" :slot="'events' + index">
                        <a href="#" title="修改"  @click.prevent="editCapture(index)">修改</a>
                        &nbsp;&nbsp;
                        <a href="#" title="删除"  @click.prevent="delCapture(index)">删除</a>
                    </span>
                </TableComponent>
                <div style="overflow: hidden;">
                    <PaginationComponent :pageData="getCapturePage" v-on:pageClick="pageCaptureEvent" :pagesNumber="5"></PaginationComponent>
                </div>
            </div>
            <ConfirmComponent :show="editCaptureObj.show" :title="editCaptureObj.text" :confirm="editCaptureObj.confirm">
                <div slot="content">
                    <div class="panel-body capture-core-dialog" style="padding-left: -11px;">
                        <div class="form-group">
                            <label class="control-label col3">名称</label>
                            <div class="col9">
                                <input type="text" placeholder="必填" class="form-control form-input" v-model="coreCaptureData.name">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">IP</label>
                            <div class="col9">
                                <input type="text" placeholder="必填" class="form-control form-input" v-model="coreCaptureData.ip">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">PORT</label>
                            <div class="col9">
                                <input type="text" placeholder="必填" class="form-control form-input" v-model="coreCaptureData.port">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">备注</label>
                            <div class="col9">
                                <textarea class="form-control form-textarea" rows="3" v-model="coreCaptureData.remark"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
            <ConfirmComponent :show="deleteCaptureObj.show" :title="deleteCaptureObj.text" :confirm="deleteCaptureObj.confirm" :content="deleteCaptureObj.content">
            </ConfirmComponent>
        </div> 
  </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import TableComponent from '@nanyun/table'
import PaginationComponent from '@nanyun/pagination'
import ConfirmComponent from '@nanyun/confirm'
import URL from 'common/url'
import {GET_CAPTURE_CORE,
    FETCH_CAPTURE_CORE,
    ADD_CAPTURE_CORE,
    DEL_CAPTURE_CORE,
    SET_CAPTURE_CORE,
    GET_CAPTURE_PAGE,
    UPDATE_CAPTURE_CORE,
    SEARCH_CAPTURE_CORE,
} from 'store/modules/server_config'

export default {
    data() {
        return {
            coreCaptureData: {},
            searchCaptureObj: {
                name: '',
                page: ''
            },
            indexCapture: '',
            editCaptureObj: {
                autoClose: 10000,
                text: this.indexCapture ? '编辑服务器' : '新增服务器',
                show: {
                    value: false
                },
                confirm: () => {
                    if (this.indexCapture === '') {
                        this.addCaptureCore(this.coreCaptureData).then(() => {
                            this.fetchCaptureCore()
                        })
                    } else {
                        this.updateCaptureCore(this.coreCaptureData).then(() => {
                            this.fetchCaptureCore()
                        })
                    }
                }
            },
            deleteCaptureObj: {
                autoClose: 10000,
                text: '确认删除',
                content: '确定删除该抓拍服务器?',
                show: {
                    value: false
                },
                confirm: () => {
                    this.delCaptureCore(this.indexCapture).then(() => {
                        this.fetchCaptureCore()
                    })
                }
            },
            columns: [{
                title: '名称',
                prop: 'name'
            }, {
                title: 'IP',
                prop: 'ip',
            }, {
                title: 'PORT',
                prop: 'port',
            }, {
                title: '备注',
                prop: 'remark',
            }, {
                title: '操作',
                type: 'events'
            }]
        }
    },
    created() {
        this.fetchData()
    },
    computed: {
        ...mapGetters({
            getCaptureCore: GET_CAPTURE_CORE,
            getCapturePage: GET_CAPTURE_PAGE,
        }),
    },
    methods: {
        fetchData() {
            this.fetchCaptureCore()
        },
        ...mapActions({
            fetchCaptureCore: FETCH_CAPTURE_CORE,
            delCaptureCore: DEL_CAPTURE_CORE,
            addCaptureCore: ADD_CAPTURE_CORE,
            setCaptureCore: SET_CAPTURE_CORE,
            updateCaptureCore: UPDATE_CAPTURE_CORE,
            searchCaptureCore: SEARCH_CAPTURE_CORE,
        }),
        searchCapture() {
            this.searchCaptureCore(this.searchCaptureObj)
        },
        addCapture() {
            this.editCaptureObj.show.value = !this.editCaptureObj.show.value
            this.coreCaptureData = {}
            this.indexCapture = ''
        },
        editCapture(index) {
            this.editCaptureObj.show.value = !this.editCaptureObj.show.value
            this.coreCaptureData = Object.assign({}, this.getCaptureCore[index])
            this.indexCapture = this.coreCaptureData.id
        },
        delCapture(index) {
            this.deleteCaptureObj.show.value = !this.deleteCaptureObj.show.value
            this.coreCaptureData = Object.assign({}, this.getCaptureCore[index])
            this.indexCapture = this.coreCaptureData.id
        },
        pageCaptureEvent(page) {
            this.searchCaptureObj.page = page
            this.searchCaptureCore(this.searchCaptureObj)
        },
    },
    components: {
        TableComponent,
        PaginationComponent,
        ConfirmComponent
    }
}
</script>

<style scoped>
.server-config{
    height: 100%;
    box-sizing: border-box;
    min-height: 100%;
    width: 1300px;
    .table_content{
        background-image: linear-gradient(-180deg, #257B97 4%, #1C6483 99%);
        border: 1px solid #FFFFFF;
        border-radius: 14px;
        padding: 15px;
        margin-bottom: 20px;
        .head{
            color: #fff;
            font-size: 16px;
            margin: 0 0 10px 15px;
        }
        .content{
            background-image: linear-gradient(-180deg, #000304 2%, #002636 99%);
            border: 0 solid #FFFFFF;
            border-radius: 10px;
            padding: 20px;
            .condition{
                margin-top: 16px;
                margin-bottom: 15px;
                input{
                    height: 16px;
                }
                .btn{
                    display: inline-block;
                    color: #fff;
                    text-decoration: none;
                    padding-left: 32px;
                    padding-right: 32px;
                    margin-left: 17px;
                    background: #4990e2;
                    border-radius: 3px;
                    font-size: 12px;
                    line-height: 2;
                    &.search{
                        vertical-align: top;
                    }
                }
            }
            .form-select{
                width: 84%;
            }
            .minWidth{
                min-width:150px;
            }
        }
        .capture-core-dialog{
            height: 180px;
        }
    }
}
</style>
