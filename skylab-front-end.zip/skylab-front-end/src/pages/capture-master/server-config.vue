<template>
  <div class="server-config">
        <div class="table_content">
            <div class="content">
                <div class="condition">
                    <input type="text" class="input-style" placeholder="请输入名称" v-model="searchStorageObj.name"/>
                    <a href="#" class="button-style search" @click.prevent="searchStorage">搜索</a>
                    <a href="#" class="button-style" @click.prevent="addStorage" style="float: right;">新建</a>
                </div>
                <TableComponent :data="getStorageCore" :columns="columns">
                    <span v-for="(item, index) in this.getStorageCore" :slot="'events' + index">
                        <a href="#" title="修改"  @click.prevent="editStorage(index)">修改</a>
                        &nbsp;&nbsp;
                        <a href="#" title="删除"  @click.prevent="delStorage(index)">删除</a>
                    </span>
                </TableComponent>
                <div style="overflow: hidden;">
                    <PaginationComponent :pageData="getStoragePage" v-on:pageClick="pageStorageEvent" :pagesNumber="5"></PaginationComponent>
                </div>
            </div>
            <ConfirmComponent :show="editStorageObj.show" :title="editStorageObj.text" :confirm="editStorageObj.confirm">
                <div slot="content">
                    <div class="panel-body capture-core-dialog" style="padding-left: -11px;">
                        <div class="form-group">
                            <label class="control-label col3">名称</label>
                            <div class="col9">
                                <input type="text" placeholder="必填" class="form-control form-input" v-model="coreStorageData.name">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">IP</label>
                            <div class="col9">
                                <input type="text" placeholder="必填" class="form-control form-input" v-model="coreStorageData.ip">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">PORT</label>
                            <div class="col9">
                                <input type="text" placeholder="必填" class="form-control form-input" v-model="coreStorageData.port">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">备注</label>
                            <div class="col9">
                                <textarea class="form-control form-textarea" rows="3" v-model="coreStorageData.remark"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
            <ConfirmComponent :show="deleteStorageObj.show" :title="deleteStorageObj.text" :confirm="deleteStorageObj.confirm" :content="deleteStorageObj.content">
            </ConfirmComponent>
        </div> 
  </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import TableComponent from '@nanyun/table'
import PaginationComponent from '@nanyun/pagination'
import ConfirmComponent from '@nanyun/confirm'
import CrumbsComponent from 'common/components/crumbs.vue'
import URL from 'common/url'
import {
    GET_STORAGE_CORE,
    FETCH_STORAGE_CORE,
    ADD_STORAGE_CORE,
    DEL_STORAGE_CORE,
    SET_STORAGE_CORE,
    GET_STORAGE_PAGE,
    UPDATE_STORAGE_CORE,
    SEARCH_STORAGE_CORE
} from 'store/modules/server_config'

export default {
    data() {
        return {
            coreStorageData: {},
            searchStorageObj: {
                name: '',
                page: ''
            },
            indexStorage: '',
            editStorageObj: {
                autoClose: 10000,
                text: this.indexStorage ? '编辑服务器' : '新增服务器',
                show: {
                    value: false
                },
                confirm: () => {
                    if (this.indexStorage === '') {
                        this.addStorageCore(this.coreStorageData).then(() => {
                            this.fetchStorageCore()
                        })
                    } else {
                        this.updateStorageCore(this.coreStorageData).then(() => {
                            this.fetchStorageCore()
                        })
                    }
                }
            },
            deleteStorageObj: {
                autoClose: 10000,
                text: '确认删除',
                content: '确定删除该存储服务器?',
                show: {
                    value: false
                },
                confirm: () => {
                    this.delStorageCore(this.indexStorage).then(() => {
                        this.fetchStorageCore()
                    })
                }
            },
            columns: [{
                title: '名称',
                prop: 'name'
            }, {
                title: 'IP',
                prop: 'ip',
            }, {
                title: 'PORT',
                prop: 'port',
            }, {
                title: '备注',
                prop: 'remark',
            }, {
                title: '操作',
                type: 'events'
            }]
        }
    },
    created() {
        this.fetchData()
    },
    computed: {
        ...mapGetters({
            getStorageCore: GET_STORAGE_CORE,
            getStoragePage: GET_STORAGE_PAGE,
        }),
    },
    methods: {
        fetchData() {
            this.fetchStorageCore()
        },
        ...mapActions({
            fetchStorageCore: FETCH_STORAGE_CORE,
            delStorageCore: DEL_STORAGE_CORE,
            addStorageCore: ADD_STORAGE_CORE,
            setStorageCore: SET_STORAGE_CORE,
            updateStorageCore: UPDATE_STORAGE_CORE,
            searchStorageCore: SEARCH_STORAGE_CORE
        }),
        searchStorage() {
            this.searchStorageCore(this.searchStorageObj)
        },
        addStorage() {
            this.editStorageObj.show.value = !this.editStorageObj.show.value
            this.coreStorageData = {}
            this.indexStorage = ''
        },
        editStorage(index) {
            this.editStorageObj.show.value = !this.editStorageObj.show.value
            this.coreStorageData = Object.assign({}, this.getStorageCore[index])
            this.indexStorage = this.coreStorageData.id
        },
        delStorage(index) {
            this.deleteStorageObj.show.value = !this.deleteStorageObj.show.value
            this.coreStorageData = Object.assign({}, this.getStorageCore[index])
            this.indexStorage = this.coreStorageData.id
        },
        pageStorageEvent(page) {
            this.searchStorageObj.page = page
            this.searchStorageCore(this.searchStorageObj)
        }
    },
    components: {
        TableComponent,
        PaginationComponent,
        ConfirmComponent,
    }
}
</script>

<style scoped>
.server-config{
    height: 100%;
    box-sizing: border-box;
    min-height: 100%;
    width: 1300px;
    .table_content{
        background-image: linear-gradient(-180deg, #257B97 4%, #1C6483 99%);
        border: 1px solid #FFFFFF;
        border-radius: 14px;
        padding: 15px;
        margin-bottom: 20px;
        .head{
            color: #fff;
            font-size: 16px;
            margin: 0 0 10px 15px;
        }
        .content{
            background-image: linear-gradient(-180deg, #000304 2%, #002636 99%);
            border: 0 solid #FFFFFF;
            border-radius: 10px;
            padding: 20px;
            .condition{
                margin-top: 16px;
                margin-bottom: 15px;
                input{
                    height: 16px;
                }
                .btn{
                    display: inline-block;
                    color: #fff;
                    text-decoration: none;
                    padding-left: 32px;
                    padding-right: 32px;
                    margin-left: 17px;
                    background: #4990e2;
                    border-radius: 3px;
                    font-size: 12px;
                    line-height: 2;
                    &.search{
                        vertical-align: top;
                    }
                }
            }
            .form-select{
                width: 84%;
            }
            .minWidth{
                min-width:150px;
            }
        }
        .capture-core-dialog{
            height: 180px;
        }
    }
}
</style>
