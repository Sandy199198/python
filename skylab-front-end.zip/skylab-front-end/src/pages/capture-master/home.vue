<template>
  <div class="capture-master-home">
      <!--<div class="title">
          <span>点击相应图片进行配置</span>
      </div>-->
      <div class="capture">
        <div class="capture-content">
            <div class="camera-setting">
                <img src="../../images/camera-setting.png" @click.prevent="showCameraSetting" title="点击开始相机配置">
            </div>
            <div class="first-split"></div>
            <div class="capture-client">
                <img src="../../images/capture-client.png" @click.prevent="showCaptureClient" title="点击开始抓拍客户端配置">
            </div>
            <div class="video-server">
                <img src="../../images/video-server.png" @click.prevent="showMediaServer" title="点击开始视频服务器配置">
            </div>
            <div class="second-split"></div>
            <div class="capture-server">
                <img src="../../images/capture-server.png" @click.prevent="showCaptureServer" title="点击开始抓拍服务器配置">
            </div>
            <div class="distinguish-server">
                <img src="../../images/distinguish-server.png" @click.prevent="showDistinguishServer" title="点击开始识别服务器配置">
            </div>
            <div class="storage-server">
                <img src="../../images/storage-server.png" @click.prevent="showStorageServer" title="点击开始存储服务器配置">
            </div>
        </div>
        <div class="deployment">
            <img src="../../images/deployment.png" @click.prevent="showDeployment" title="点击开始布控配置">
        </div>
      </div>
        <DialogComponent :show="cameraSetting.show" :title="cameraSetting.text">
            <div slot="content">
                <CameraSetting></CameraSetting>
            </div>
        </DialogComponent>
        <DialogComponent :show="captureClient.show" :title="captureClient.text">
            <div slot="content">
                <ClientGroup></ClientGroup>
            </div>
        </DialogComponent>
        <DialogComponent :show="deployment.show" :title="deployment.text">
            <div slot="content">
                <Deployment></Deployment>
            </div>
        </DialogComponent>
        <DialogComponent :show="mediaServer.show" :title="mediaServer.text">
            <div slot="content">
                <MediaServer></MediaServer>
            </div>
        </DialogComponent>
        <DialogComponent :show="captureServer.show" :title="captureServer.text">
            <div slot="content">
                <CaptureServer></CaptureServer>
            </div>
        </DialogComponent>
        <DialogComponent :show="storageServer.show" :title="storageServer.text">
            <div slot="content">
                <StorageServer></StorageServer>
            </div>
        </DialogComponent>
        <DialogComponent :show="distinguishServer.show" :title="distinguishServer.text">
            <div slot="content">
                <DistinguishServer></DistinguishServer>
            </div>
        </DialogComponent>
  </div>
</template>

<script>
import DialogComponent from '@nanyun/dialog'
import CameraSetting from 'pages/capture-master/camera-setting.vue'
import ClientGroup from 'pages/capture-master/client-group.vue'
import Deployment from 'pages/capture-master/deployment.vue'
import CaptureServer from 'pages/capture-master/capture-server.vue'
import MediaServer from 'pages/capture-master/media-server.vue'
import StorageServer from 'pages/capture-master/server-config.vue'
import DistinguishServer from 'pages/gate-real-time/core.vue'
export default {
    data() {
        return {
            cameraSetting: {
                autoClose: 10000,
                text: '相机设置',
                show: {
                    value: false
                }
            },
            captureClient: {
                autoClose: 10000,
                text: '抓拍客户端',
                show: {
                    value: false
                }
            },
            mediaServer: {
                autoClose: 10000,
                text: '视频服务器',
                show: {
                    value: false
                }
            },
            captureServer: {
                autoClose: 10000,
                text: '抓拍服务器',
                show: {
                    value: false
                }
            },
            storageServer: {
                autoClose: 10000,
                text: '存储服务器',
                show: {
                    value: false
                }
            },
            deployment: {
                autoClose: 10000,
                text: '布控设置',
                show: {
                    value: false
                }
            },
            distinguishServer: {
                autoClose: 10000,
                text: '识别服务器',
                show: {
                    value: false
                }
            }
        }
    },
    methods: {
        showCameraSetting() {
            this.cameraSetting.show.value = !this.cameraSetting.show.value
        },
        showCaptureClient() {
            this.captureClient.show.value = !this.captureClient.show.value
        },
        showDeployment() {
            this.deployment.show.value = !this.deployment.show.value
        },
        showMediaServer() {
            this.mediaServer.show.value = !this.mediaServer.show.value
        },
        showCaptureServer() {
            this.captureServer.show.value = !this.captureServer.show.value
        },
        showStorageServer() {
            this.storageServer.show.value = !this.storageServer.show.value
        },
        showDistinguishServer() {
            this.distinguishServer.show.value = !this.distinguishServer.show.value
        }
    },
    components: {
        DialogComponent,
        CameraSetting,
        ClientGroup,
        Deployment,
        CaptureServer,
        MediaServer,
        StorageServer,
        DistinguishServer
    }
}
</script>

<style scoped>
.capture-master-home{
    height: 100%;
    padding: 50px 80px;
    box-sizing: border-box;
    min-height: 100%;
    width: 100%;
    /*.title{
        position: absolute;
        top: 123px;
        left: 40%;
        color: #fff;
        text-align:center;
    }*/
    .capture{
        position: relative;
        top: 50%;
        left: 50%;
        height: 600px;
        width: 1200px;
        margin-left: -600px;
        margin-top: -290px;
        .capture-content{
            border: 1px solid #54C7FC;
            border-radius: 100px;
            position: absolute;
            top: 0;
            left: 10px;
            width: 881px;
            height: 578px;
            box-sizing: border-box;
            overflow: hidden;
            .camera-setting{
                position: absolute;
                top: 223px;
                left: 57px;
            }
            .first-split{
                position: absolute;
                top: 125px;
                left: 257px;
                width: 46px;
                height: 350px;
                border: 1px solid #54C7FC;
                border-right: none;
            }
            .camera-setting::before { 
                content: ''; 
                position: absolute; 
                top: 60px; 
                left: 130px; 
                width: 70px; 
                height: 1px; 
                background: #54C7FC; 
            } 
            .capture-client{
                position: absolute;
                top: 60px;
                left: 304px;
            }
            .capture-client::before { 
                content: ''; 
                position: absolute; 
                top: 65px; 
                left: 130px; 
                width: 115px; 
                height: 1px; 
                background: #54C7FC; 
            }
            .second-split{
                position: absolute;
                top: 125px;
                left: 540px;
                width: 66px;
                height: 350px;
                border: 1px solid #54C7FC;
                border-right: none;
            }
            .video-server{
                position: absolute;
                top: 407px;
                left: 304px;
            }
            .capture-server{
                position: absolute;
                top: 60px;
                left: 608px;
            }
            .distinguish-server{
                position: absolute;
                top: 228px;
                left: 608px;
            }
            .distinguish-server::before{
                content: ''; 
                position: absolute; 
                top: 68px; 
                left: -68px; 
                width: 70px; 
                height: 1px; 
                background: #54C7FC; 
            }
            .storage-server{
                position: absolute;
                top: 407px;
                left: 608px;
            }
        }
        .deployment{
            position: absolute;
            top: 223px;
            left: 986px;
        }
        img{
            cursor: pointer;
            height: 130px;
            width: 130px;
        }
    }
}
</style>
