<template>
  <div class="server-config">
      <div class="table_content">
            <div class="head">
                <span>抓拍客户端组</span>
            </div>
            <div class="content">
                <div class="condition">
                    <input type="text" class="input-style" placeholder="请输入名称" v-model="searchClientGroupObj.name"/>
                    <a href="#" class="button-style search" @click.prevent="clientGroupSearch">搜索</a>
                    <a href="#" class="button-style" @click.prevent="clientGroupAdd" style="float: right;">新建</a>
                </div>
                <TableComponent :data="getClientGroup" :columns="columns">
                    <span v-for="(item, index) in getClientGroup" :slot="'hrefEvent' + index">
                        <span v-if="item.deployments && item.deployments.length">
                            <a href="#" @click="viewDeploymentList(item.deployments)">
                                {{item.deployments.length}}
                            </a>
                        </span>
                        <span v-else>0</span>
                    </span>
                    <span v-for="(item, index) in this.getClientGroup" :slot="'events' + index">
                        <a href="#" title="修改"  @click.prevent="editClientGroup(index)">修改</a>
                        &nbsp;&nbsp;
                        <a href="#" title="删除"  @click.prevent="clientGroupDel(index)">删除</a>
                    </span>
                </TableComponent>
                <div style="overflow: hidden;">
                    <PaginationComponent :pageData="getClientGroupPage" v-on:pageClick="pageClientGroupEvent" :pagesNumber="5"></PaginationComponent>
                </div>
            </div>
            <ConfirmComponent :show="editClientGroupObj.show" :title="editClientGroupObj.text" :confirm="editClientGroupObj.confirm">
                <div slot="content">
                    <div class="panel-body" style="padding-left: -11px;">
                        <div class="form-group">
                            <label class="control-label col3">名称</label>
                            <div class="col9">
                                <input type="text" placeholder="必填" class="form-control form-input" v-model="clientGroupData.name">
                            </div>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
            <ConfirmComponent :show="deleteClientGroupObj.show" :title="deleteClientGroupObj.text" :confirm="deleteClientGroupObj.confirm" :content="deleteClientGroupObj.content">
            </ConfirmComponent>
        </div> 

        <div class="table_content">
            <div class="head">
                <span>抓拍客户端</span>
            </div>
            <div class="content">
                <div class="condition">
                    <input type="text" class="input-style" placeholder="请输入名称" v-model="searchClientObj.name"/>
                    <a href="#" class="button-style search" @click.prevent="clientSearch">搜索</a>
                </div>
                <TableComponent :data="getClient" :columns="clientColumns">
                    <span v-for="(item, index) in getClient" :slot="'array' + index">
                        <span>{{item.capture_core_id && item.capture_core ? item.capture_core.ip + ':' + item.capture_core.port : '本地'}}</span>
                        <span v-for="i in deviceStatus">
                            <span v-if="item.status == i.value" :class="i.clsName">{{i.text}}</span>
                        </span>
                    </span>
                    <span v-for="(item, index) in getClient" :slot="'hrefEvent' + index">
                        <span v-if="item.cameras && item.cameras.length">
                            <a href="#" @click="viewCameraList(item.cameras)">
                                {{item.cameras.length}}
                            </a>
                        </span>
                        <span v-else>0</span>
                    </span>
                    <span v-for="(item, index) in getClient" :slot="'events' + index">
                        <a href="#" title="修改"  @click.prevent="editClient(index)">修改</a>
                        &nbsp;&nbsp;
                        <a href="#" title="删除"  @click.prevent="clientDel(index)">删除</a>
                    </span>
                </TableComponent>
                <div style="overflow: hidden;">
                    <PaginationComponent :pageData="getClientPage" v-on:pageClick="pageClientEvent" :pagesNumber="5"></PaginationComponent>
                </div>
            </div>
            <ConfirmComponent :show="editClientObj.show" :title="editClientObj.text" :confirm="editClientObj.confirm">
                <div slot="content">
                    <div class="panel-body client-dialog" style="padding-left: -11px;">
                        <div class="form-group">
                            <label class="control-label col3">名称</label>
                            <div class="col9">
                                <input type="text" placeholder="必填" class="form-control form-input" v-model="clientData.name">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">抓拍服务器</label>
                            <div class="col9">
                                <select v-model="clientData.capture_core_id" class="form-control form-select">
                                    <option value="">本地</option>
                                    <option v-for="option in getCaptureCore" :value="option.id">{{option.ip + ':' + option.port}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">存储服务器</label>
                            <div class="col9">
                                <select v-model="clientData.storage_server_id" class="form-control form-select">
                                    <option value="">--未选择--</option>
                                    <option v-for="option in getStorageCore" :value="option.id">{{option.ip + ':' + option.port}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">抓拍客户端组</label>
                            <div class="col9">
                                <select v-model="clientData.client_group_id" class="form-control form-select">
                                    <option value="">--未选择--</option>
                                    <option v-for="option in getClientGroup" :value="option.id">{{option.name}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">备注</label>
                            <div class="col9">
                                <textarea class="form-control form-textarea" rows="3" v-model="clientData.remark"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
            <ConfirmComponent :show="deleteClientObj.show" :title="deleteClientObj.text" :confirm="deleteClientObj.confirm" :content="deleteClientObj.content">
            </ConfirmComponent>
        </div>
        <DialogComponent :show="cameraObj.show" :title="cameraObj.text" :cancel="cameraObj.cancel">
            <div slot="content">
                <div class="panel-body" style="padding-left: -11px;margin-top: -20px">
                    <div class="all-export-list">
                        <div class="export_title">
                            <span>相机名称</span>
                            <span>布控名称</span>
                            <span>状态</span>
                        </div>
                        <div class="item" v-for="(item, index) in cameras">
                            <div>
                                {{item.name}}
                            </div>
                            <div>
                                {{item.deployment_name}}
                            </div>
                            <div class="video-status">
                                <span v-for="i in deviceStatus">
                                    <span v-if="item.status == i.value" :class="i.clsName">{{i.text}}</span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </DialogComponent>
        <DialogComponent :show="deploymentObj.show" :title="deploymentObj.text" :cancel="deploymentObj.cancel">
            <div slot="content">
                <div class="panel-body" style="padding-left: -11px;margin-top: -20px">
                    <div class="all-export-list">
                        <div class="export_title">
                            <span>名称</span>
                            <span>类型</span>
                            <span>备注</span>
                        </div>
                        <div class="item" v-for="(item, index) in deployments">
                            <div>
                                {{item.name}}
                            </div>
                            <div>
                                <span v-for="i in getDeployType">
                                    <span v-if="item.alarm_type == i.value">{{i.text}}</span>
                                </span>
                            </div>
                            <div>
                                {{item.remark || '-'}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </DialogComponent>
  </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import TableComponent from '@nanyun/table'
import PaginationComponent from '@nanyun/pagination'
import ConfirmComponent from '@nanyun/confirm'
import CrumbsComponent from 'common/components/crumbs.vue'
import DialogComponent from '@nanyun/dialog'
import URL from 'common/url'
import {GET_CLIENT_GROUP,
    FETCH_CLIENT_GROUP,
    ADD_CLIENT_GROUP,
    DEL_CLIENT_GROUP,
    SET_CLIENT_GROUP,
    GET_CLIENT_GROUP_PAGE,
    UPDATE_CLIENT_GROUP,
    SEARCH_CLIENT_GROUP,
    GET_CLIENT,
    FETCH_CLIENT,
    DEL_CLIENT,
    SET_CLIENT,
    GET_CLIENT_PAGE,
    UPDATE_CLIENT,
    SEARCH_CLIENT,
} from 'store/modules/client'
import {GET_CAPTURE_CORE,
    FETCH_CAPTURE_CORE,
    GET_STORAGE_CORE,
    FETCH_STORAGE_CORE
} from 'store/modules/server_config'
import {DEVICE_STATUS, DEPLOY_TYPE} from 'common/config'

export default {
    data() {
        return {
            crumbs: [{
                name: '首页',
                path: {
                    name: URL.HOME
                }
            }, {
                name: '服务器配置',
                silent: true
            }],
            clientGroupData: {},
            clientData: {},
            searchClientGroupObj: {
                name: '',
                page: ''
            },
            searchClientObj: {
                name: '',
                page: ''
            },
            indexClientGroup: '',
            indexClient: '',
            editClientGroupObj: {
                autoClose: 10000,
                text: this.indexClientGroup ? '编辑抓拍客户端组' : '新增抓拍客户端组',
                show: {
                    value: false
                },
                confirm: () => {
                    if (this.indexClientGroup === '') {
                        this.addClientGroup(this.clientGroupData).then(() => {
                            this.fetchClientGroup()
                        })
                    } else {
                        this.updateClientGroup(this.clientGroupData).then(() => {
                            this.fetchClientGroup()
                        })
                    }
                }
            },
            editClientObj: {
                autoClose: 10000,
                text: '编辑抓拍客户端',
                show: {
                    value: false
                },
                confirm: () => {
                    this.updateClient(this.clientData).then(() => {
                        this.fetchClient()
                    })
                }
            },
            deleteClientGroupObj: {
                autoClose: 10000,
                text: '确认删除',
                content: '确定删除该抓拍客户端组?',
                show: {
                    value: false
                },
                confirm: () => {
                    this.delClientGroup(this.indexClientGroup).then(() => {
                        this.fetchClientGroup()
                    })
                }
            },
            deleteClientObj: {
                autoClose: 10000,
                text: '确认删除',
                content: '确定删除该抓拍客户端?',
                show: {
                    value: false
                },
                confirm: () => {
                    this.delClient(this.indexClient).then(() => {
                        this.fetchClient()
                    })
                }
            },
            columns: [{
                title: '名称',
                prop: 'name'
            }, {
                title: '最大接入数',
                prop: 'max_cap',
            }, {
                title: '已接入',
                prop: 'used_cap',
            }, {
                title: '布控数',
                type: 'hrefEvent'
                // prop: 'deployments',
                // handle: d => {
                //     return d ? d.length : 0
                // }
            }, {
                title: '操作',
                type: 'events'
            }],
            clientColumns: [{
                title: '名称',
                prop: 'name'
            }, {
                title: '抓拍客户端组',
                prop: 'client_group_id',
                handle: d => {
                    return d ? d : '-'
                }
            }, {
                title: 'IP',
                prop: 'ip',
            }, {
                title: '抓拍服务器',
                prop: ['capture_core', 'capture_core_id'],
            }, {
                title: '存储服务器',
                prop: 'storage_server',
                handle: d => {
                    return d ? d.ip + ':' + d.port : '-'
                }
            }, {
                title: '心跳时间',
                prop: 'time_delta',
            }, {
                title: '相机列表',
                type: 'hrefEvent'
            }, {
                title: '备注',
                prop: 'remark',
                handle: d => {
                    return d ? d : '-'
                }
            }, {
                title: '操作',
                type: 'events'
            }],
            deviceStatus: DEVICE_STATUS,
            cameras: [],
            cameraObj: {
                autoClose: 10000,
                text: '相机列表',
                show: {
                    value: false
                },
                cancel: () => {
                    this.cameras = []
                }
            },
            deployments: [],
            deploymentObj: {
                autoClose: 10000,
                text: '布控列表',
                show: {
                    value: false
                },
                cancel: () => {
                    this.deployments = []
                }
            },
            getDeployType: DEPLOY_TYPE
        }
    },
    created() {
        this.fetchData()
    },
    computed: {
        ...mapGetters({
            getClientGroup: GET_CLIENT_GROUP,
            getClientGroupPage: GET_CLIENT_GROUP_PAGE,
            getClient: GET_CLIENT,
            getClientPage: GET_CLIENT_PAGE,
            getCaptureCore: GET_CAPTURE_CORE,
            getStorageCore: GET_STORAGE_CORE
        }),
    },
    methods: {
        fetchData() {
            this.fetchClientGroup()
            this.fetchClient()
            this.fetchCaptureCore()
            this.fetchStorageCore()
        },
        ...mapActions({
            fetchClientGroup: FETCH_CLIENT_GROUP,
            delClientGroup: DEL_CLIENT_GROUP,
            addClientGroup: ADD_CLIENT_GROUP,
            setClientGroup: SET_CLIENT_GROUP,
            updateClientGroup: UPDATE_CLIENT_GROUP,
            searchClientGroup: SEARCH_CLIENT_GROUP,
            fetchClient: FETCH_CLIENT,
            delClient: DEL_CLIENT,
            setClient: SET_CLIENT,
            updateClient: UPDATE_CLIENT,
            searchClient: SEARCH_CLIENT,
            fetchCaptureCore: FETCH_CAPTURE_CORE,
            fetchStorageCore: FETCH_STORAGE_CORE
        }),
        clientGroupSearch() {
            this.searchClientGroup(this.searchClientGroupObj)
        },
        clientSearch() {
            this.searchClient(this.searchClientObj)
        },
        clientGroupAdd() {
            this.editClientGroupObj.show.value = !this.editClientGroupObj.show.value
            this.clientGroupData = {}
            this.indexClientGroup = ''
        },
        editClientGroup(index) {
            this.editClientGroupObj.show.value = !this.editClientGroupObj.show.value
            this.clientGroupData = Object.assign({}, this.getClientGroup[index])
            this.indexClientGroup = this.clientGroupData.id
        },
        editClient(index) {
            this.editClientObj.show.value = !this.editClientObj.show.value
            if (!this.getClient[index].capture_core_id) {
                this.getClient[index]['capture_core_id'] = ''
            }
            if (!this.getClient[index].storage_server_id) {
                this.getClient[index]['storage_server_id'] = ''
            }
            if (!this.getClient[index].client_group_id) {
                this.getClient[index]['client_group_id'] = ''
            }
            this.clientData = Object.assign({}, this.getClient[index])
            this.indexClient = this.clientData.id
        },
        clientGroupDel(index) {
            this.deleteClientGroupObj.show.value = !this.deleteClientGroupObj.show.value
            this.clientGroupData = Object.assign({}, this.getClientGroup[index])
            this.indexClientGroup = this.clientGroupData.id
        },
        clientDel(index) {
            this.deleteClientObj.show.value = !this.deleteClientObj.show.value
            this.clientData = Object.assign({}, this.getClientCore[index])
            this.indexClient = this.clientData.id
        },
        pageClientGroupEvent(page) {
            this.searchClientGroupObj.page = page
            this.searchClientGroupCore(this.searchClientGroupObj)
        },
        pageClientEvent(page) {
            this.searchClientObj.page = page
            this.searchClient(this.searchClientObj)
        },
        viewCameraList(cameras) {
            this.cameras = cameras
            this.cameraObj.show.value = !this.cameraObj.show.value
        },
        viewDeploymentList(deployments) {
            this.deployments = deployments
            this.deploymentObj.show.value = !this.deploymentObj.show.value
        },
    },
    components: {
        TableComponent,
        PaginationComponent,
        ConfirmComponent,
        CrumbsComponent,
        DialogComponent
    }
}
</script>

<style scoped>
.server-config{
    height: 100%;
    box-sizing: border-box;
    min-height: 550px;
    width: 1300px;
    .table_content{
        background-image: linear-gradient(-180deg, #257B97 4%, #1C6483 99%);
        border: 1px solid #FFFFFF;
        border-radius: 14px;
        padding: 15px;
        margin-bottom: 20px;
        .head{
            color: #fff;
            font-size: 16px;
            margin: 0 0 10px 15px;
        }
        .content{
            background-image: linear-gradient(-180deg, #000304 2%, #002636 99%);
            border: 0 solid #FFFFFF;
            border-radius: 10px;
            padding: 20px;
            .condition{
                margin-top: 16px;
                margin-bottom: 15px;
                input{
                    height: 16px;
                }
                .btn{
                    display: inline-block;
                    color: #fff;
                    text-decoration: none;
                    padding-left: 32px;
                    padding-right: 32px;
                    margin-left: 17px;
                    background: #4990e2;
                    border-radius: 3px;
                    font-size: 12px;
                    line-height: 2;
                    &.search{
                        vertical-align: top;
                    }
                }
            }
        }
        .client-dialog{
            height: 230px;
        }
        .form-select{
            width: 84%;
        }
        .success{
            border-radius: 3px;
            padding: 2px 4px;
            background: #5ebd5e;
            color: #fff;
        }
        .danger{
            border-radius: 3px;
            padding: 2px 4px;
            background: #e66454;
            color: #fff;
        }
        .primary{
            border-radius: 3px;
            padding: 2px 4px;
            background: #b0b0b0;
            color: #fff;
        }
    }
}
</style>
