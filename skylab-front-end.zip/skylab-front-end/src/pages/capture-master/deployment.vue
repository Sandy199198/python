<template>
  <div class="server-config">
        <div class="table_content">
            <div class="content">
                <div class="condition">
                    <input type="text" class="input-style" placeholder="请输入名称" v-model="searchObj.name"/>
                    <a href="#" class="button-style search" @click.prevent="deploymentSearch">搜索</a>
                    <a href="#" class="button-style" @click.prevent="deploymentAdd" style="float: right;">新建</a>
                </div>
                <TableComponent :data="getDeployment" :columns="columns">
                    <span v-for="(item, index) in getDeployment" :slot="'hrefEvent' + index">
                        <span v-if="item.cameras.length">
                            <a href="#" @click="viewCameraList(item.cameras)">{{item.cameras.length}}</a>
                        </span>
                        <span v-else>
                            0
                        </span>
                    </span>
                    <span v-for="(item, index) in getDeployment" :slot="'events' + index">
                        <a href="#" title="修改"  @click.prevent="editDeployment(index)">修改</a>
                        &nbsp;&nbsp;
                        <a href="#" title="删除"  @click.prevent="deploymentDel(index)">删除</a>
                    </span>
                </TableComponent>
                <div style="overflow: hidden;">
                    <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
                </div>
            </div>
            <ConfirmComponent :show="editObj.show" :title="editObj.text" :confirm="editObj.confirm">
                <div slot="content">
                    <div class="panel-body client-dialog" style="padding-left: -11px;">
                        <div class="form-group">
                            <label class="control-label col3">名称</label>
                            <div class="col9">
                                <input type="text" placeholder="必填" class="form-control form-input" v-model="deploymentData.name">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">布控类型</label>
                            <div class="col9">
                                <select v-model="deploymentData.alarm_type" class="form-control form-select">
                                    <option v-for="option in deployType" :value="option.value">{{option.text}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">抓拍客户端组</label>
                            <div class="col9">
                                <select v-model="deploymentData.client_group_id" class="form-control form-select">
                                    <option value="">--未选择--</option>
                                    <option v-for="option in getClientGroup" :value="option.id">{{option.name}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">抓拍模式</label>
                            <div class="col9">
                                <select v-model="deploymentData.crop" class="form-control form-select">
                                    <option v-for="option in deviceCrop" :value="option.value">{{option.text}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">抓拍质量</label>
                            <div class="col9">
                                <input type="text" placeholder="必填 范围(0,1)" class="form-control form-input" v-model="deploymentData.blurness">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">最小抓拍人脸</label>
                            <div class="col9">
                                <input type="text" placeholder="必填" class="form-control form-input" v-model="deploymentData.facemin">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">抓拍间隔(ms)</label>
                            <div class="col9">
                                <input type="text" placeholder="必填" class="form-control form-input" v-model="deploymentData.interval">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">所属分局</label>
                            <div class="col9">
                                <select v-model="deploymentData.user_group_id" class="form-control form-select">
                                    <option v-for="option in getUserGroup" :value="option.id">{{option.name}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group group-div">
                            <label class="control-label col3">底库</label>
                            <div class="col9">
                                <div class="group-content">
                                    <div class="item" v-for="(item, index) in getGroup">
                                        <div class="video-name">
                                            <input type="checkbox" :id="index" :value="item.id" @change="changeGroup" :checked="isCheck(item.id, deploymentData.groups)"/>
                                            <label :for="index">{{item.name}}</label>
                                        </div>
                                        <div class="video-status">
                                            <input type="text" placeholder="阈值为1-100" class="form-control form-input" :id="'thread_'+ item.id" :value="getThread(item.id, deploymentData.groups)">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group error" v-if="errorShow">
                            <p>底库不能为空且阈值范围为1-100</p>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">备注</label>
                            <div class="col9">
                                <textarea class="form-control form-textarea" rows="3" v-model="deploymentData.remark"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
            <ConfirmComponent :show="deleteObj.show" :title="deleteObj.text" :confirm="deleteObj.confirm" :content="deleteObj.content">
            </ConfirmComponent>
        </div>
        <DialogComponent :show="cameraObj.show" :title="cameraObj.text" :cancel="cameraObj.cancel">
            <div slot="content">
                <div class="panel-body" style="padding-left: -11px;margin-top: -20px">
                    <div class="all-export-list">
                        <div class="export_title">
                            <span>相机名称</span>
                            <span>ip</span>
                            <span>port</span>
                            <span>状态</span>
                        </div>
                        <div class="item" v-for="(item, index) in cameras">
                            <div>
                                {{item.name}}
                            </div>
                            <div>
                                {{item.ip}}
                            </div>
                            <div>
                                {{item.port}}
                            </div>
                            <div class="video-status">
                                <span v-for="i in deviceStatus">
                                    <span v-if="item.status == i.value" :class="i.clsName">{{i.text}}</span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </DialogComponent>
  </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import TableComponent from '@nanyun/table'
import PaginationComponent from '@nanyun/pagination'
import DialogComponent from '@nanyun/dialog'
import ConfirmComponent from '@nanyun/confirm'
import CrumbsComponent from 'common/components/crumbs.vue'
import URL from 'common/url'
import {GET_CLIENT_GROUP, FETCH_CLIENT_GROUP} from 'store/modules/client'
import {GET_DEPLOYMENT,
    FETCH_DEPLOYMENT,
    ADD_DEPLOYMENT,
    DEL_DEPLOYMENT,
    SET_DEPLOYMENT,
    GET_PAGE,
    UPDATE_DEPLOYMENT,
    SEARCH_DEPLOYMENT,
} from 'store/modules/deployment'
import {DEPLOY_TYPE, DEVICE_CROP, DEVICE_STATUS} from 'common/config'
import {GET_GROUP, FETCH_GROUP} from 'store/modules/group'
import {GET_USER_GROUP_LIST, FETCH_USER_GROUP_LIST} from 'store/modules/user_group_info'

export default {
    data() {
        return {
            crumbs: [{
                name: '首页',
                path: {
                    name: URL.HOME
                }
            }, {
                name: '布控配置',
                silent: true
            }],
            deploymentData: {},
            searchObj: {
                name: '',
                page: ''
            },
            index: '',
            errorShow: false,
            editObj: {
                autoClose: 10000,
                text: this.index ? '编辑布控' : '新增布控',
                show: {
                    value: false
                },
                confirm: () => {
                    let groups = []

                    if (!this.groupIds.length) {
                        this.errorShow = true
                        this.editObj.show.value = false
                        return
                    }
                    for (let id of this.groupIds) {
                        let threshold = document.getElementById('thread_' + id).value

                        if (threshold < 1 || threshold > 100) {
                            this.errorShow = true
                            this.editObj.show.value = false
                            return
                        }
                        groups.push({
                            id,
                            threshold
                        })
                    }
                    this.deploymentData.groups = groups
                    if (this.index === '') {
                        this.addDeployment(this.deploymentData).then(() => {
                            this.fetchDeployment()
                        })
                    } else {
                        this.updateDeployment(this.deploymentData).then(() => {
                            this.fetchDeployment()
                        })
                    }
                }
            },
            deleteObj: {
                autoClose: 10000,
                text: '确认删除',
                content: '确定删除该抓布控配置?',
                show: {
                    value: false
                },
                confirm: () => {
                    this.delDeployment(this.index).then(() => {
                        this.fetchDeployment()
                    })
                }
            },
            columns: [{
                title: '名称',
                prop: 'name'
            }, {
                title: '布控类型',
                prop: 'alarm_type',
                handle: d => {
                    let name = '-'

                    this.deployType.forEach(function (type) {
                        if (type.value == d) {
                            name = type.text
                        }
                    })
                    return name
                }
            }, {
                title: '抓拍客户端组',
                prop: 'client_group_id',
                handle: d => {
                    let name = '-'

                    this.getClientGroup.forEach(function (group) {
                        if (group.id == d) {
                            name = group.name
                        }
                    })
                    return name
                }
            }, {
                title: '抓拍模式',
                prop: 'crop',
                handle: d => {
                    let name = '-'

                    this.deviceCrop.forEach(function (crop) {
                        if (crop.value == d) {
                            name = crop.text
                        }
                    })
                    return name
                }
            }, {
                title: '抓拍质量',
                prop: 'blurness',
            }, {
                title: '最小抓拍人脸',
                prop: 'facemin',
            }, {
                title: '抓拍间隔',
                prop: 'interval',
                handle: d => {
                    return d ? d + 'ms' : '0ms'
                }
            }, {
                title: '底库',
                prop: 'groups',
                handle: d => {
                    let name = '无相关底库'

                    if (!d || d.length == 0) {
                        return name
                    }
                    if (d && d.length == 1) {
                        this.getGroup.forEach(function (group) {
                            if (group.id == d[0].group_id) {
                                name = group.name
                            }
                        })
                        return name
                    } else {
                        this.getGroup.forEach(function (group) {
                            if (group.id == d[0].group_id) {
                                name = group.name + '等' + d.length + '个底库'
                            }
                        })
                        return name
                    }
                }
            }, {
                title: '相机个数',
                type: 'hrefEvent'
            }, {
                title: '所属分局',
                prop: 'user_group_id',
                handle: d => {
                    let name = '-'

                    this.getUserGroup.forEach(function (group) {
                        if (group.id == d) {
                            name = group.name
                        }
                    })
                    return name
                }
            }, {
                title: '备注',
                prop: 'remark',
                handle: d => {
                    return d ? d : '-'
                }
            }, {
                title: '操作',
                type: 'events'
            }],
            deployType: DEPLOY_TYPE,
            deviceCrop: DEVICE_CROP,
            deviceStatus: DEVICE_STATUS,
            groupIds: [],
            cameras: [],
            cameraObj: {
                autoClose: 10000,
                text: '相机列表',
                show: {
                    value: false
                },
                cancel: () => {
                    this.cameras = []
                }
            },
        }
    },
    created() {
        this.fetchData()
    },
    computed: {
        ...mapGetters({
            getClientGroup: GET_CLIENT_GROUP,
            getDeployment: GET_DEPLOYMENT,
            getPage: GET_PAGE,
            getGroup: GET_GROUP,
            getUserGroup: GET_USER_GROUP_LIST
        }),
    },
    methods: {
        fetchData() {
            this.fetchGroup()
            this.fetchClientGroup()
            this.fetchUserGroup()
            this.fetchDeployment()
        },
        ...mapActions({
            fetchClientGroup: FETCH_CLIENT_GROUP,
            fetchDeployment: FETCH_DEPLOYMENT,
            delDeployment: DEL_DEPLOYMENT,
            setDeployment: SET_DEPLOYMENT,
            addDeployment: ADD_DEPLOYMENT,
            updateDeployment: UPDATE_DEPLOYMENT,
            searchDeployment: SEARCH_DEPLOYMENT,
            fetchGroup: FETCH_GROUP,
            fetchUserGroup: FETCH_USER_GROUP_LIST
        }),
        deploymentSearch() {
            this.searchDeployment(this.searchObj)
        },
        deploymentAdd() {
            this.editObj.show.value = !this.editObj.show.value
            this.groupIds = []
            this.deploymentData = {}
            this.deploymentData['alarm_type'] = 0
            this.deploymentData['client_group_id'] = ''
            this.deploymentData['crop'] = 'face,body,full'
            this.deploymentData['blurness'] = 0.6
            this.deploymentData['facemin'] = 48
            this.deploymentData['interval'] = 1000
            this.deploymentData['user_group_id'] = this.getUserGroup[0].id
            this.index = ''
        },
        editDeployment(index) {
            this.groupIds = []
            this.editObj.show.value = !this.editObj.show.value
            if (!this.getDeployment[index].client_group_id) {
                this.getDeployment[index]['client_group_id'] = ''
            }
            this.deploymentData = Object.assign({}, this.getDeployment[index])
            let groups = this.deploymentData.groups

            if (groups && groups.length) {
                for (let group of groups) {
                    this.groupIds.push(group.group_id)
                }
            }
            this.index = this.deploymentData.id
        },
        deploymentDel(index) {
            this.deleteObj.show.value = !this.deleteObj.show.value
            this.deploymentData = Object.assign({}, this.getDeployment[index])
            this.index = this.deploymentData.id
        },
        pageEvent(page) {
            this.searchObj.page = page
            this.searchDeployment(this.searchObj)
        },
        changeGroup(e) {
            let val = e.target.value, index = this.groupIds.indexOf(parseInt(val))

            if (e.target.checked) {
                this.groupIds.push(val)
            } else {
                this.groupIds.splice(index, 1)
            }
        },
        isCheck(id, groups) {
            if (groups && groups.length) {
                for (let group of groups) {
                    if (group.group_id == id) {
                        return true
                    }
                }
            }
            return false
        },
        getThread(id, groups) {
            let threshold = ''

            if (groups && groups.length) {
                for (let group of groups) {
                    if (group.group_id == id) {
                        threshold = group.threshold
                        break
                    }
                }
            }
            return threshold
        },
        viewCameraList(cameras) {
            this.cameras = cameras
            this.cameraObj.show.value = !this.cameraObj.show.value
        }
    },
    components: {
        TableComponent,
        PaginationComponent,
        ConfirmComponent,
        CrumbsComponent,
        DialogComponent
    }
}
</script>

<style scoped>
.server-config{
    height: 100%;
    box-sizing: border-box;
    min-height: 100%;
    width: 1300px;
    .table_content{
        background-image: linear-gradient(-180deg, #257B97 4%, #1C6483 99%);
        border: 1px solid #FFFFFF;
        border-radius: 14px;
        padding: 15px;
        margin-bottom: 20px;
        .head{
            color: #fff;
            font-size: 16px;
            margin: 0 0 10px 15px;
        }
        .content{
            background-image: linear-gradient(-180deg, #000304 2%, #002636 99%);
            border: 0 solid #FFFFFF;
            border-radius: 10px;
            padding: 20px;
            .condition{
                margin-top: 16px;
                margin-bottom: 15px;
                input{
                    height: 16px;
                }
                .btn{
                    display: inline-block;
                    color: #fff;
                    text-decoration: none;
                    padding-left: 32px;
                    padding-right: 32px;
                    margin-left: 17px;
                    background: #4990e2;
                    border-radius: 3px;
                    font-size: 12px;
                    line-height: 2;
                    &.search{
                        vertical-align: top;
                    }
                }
            }
        }
        .success{
            border-radius: 3px;
            padding: 2px 4px;
            background: #5ebd5e;
            color: #fff;
        }
        .danger{
            border-radius: 3px;
            padding: 2px 4px;
            background: #e66454;
            color: #fff;
        }
        .primary{
            border-radius: 3px;
            padding: 2px 4px;
            background: #b0b0b0;
            color: #fff;
        }
        .client-dialog{
            height: 580px;
            width: 500px;
            .form-control{
                width: 300px;
            }
            .form-select{
                width: 326px;
            }
            .group-div{
                line-height:178px;
                height:178px;
                .group-content{
                    line-height: 178px;
                    height: 178px;
                    overflow-y: auto;
                    border-radius: 3px;
                    padding-left: 5px;
                    border: 1px solid #d6d6d6;
                    margin-bottom: 10px;
                    width: 320px;
                    .item{
                        overflow: hidden;
                        line-height: 40px;
                        .video-name{
                            float: left;
                            width: 160px;
                            white-space: nowrap;
                            overflow: hidden;
                            margin-left: 2px;
                            display: inline-block;
                            text-overflow: ellipsis;
                        }
                        .video-status{
                            float: left;
                        }
                    }
                    .form-input{
                        width: 100px;
                    }
                }
            }
            .error{
                margin-left: 125px;
                color: red;
                height: 20px;
            }
        }
    }
}
</style>
