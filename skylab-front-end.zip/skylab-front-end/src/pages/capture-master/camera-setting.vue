<template>
    <div class="camara_setting">
        <div class="table_content">
            <div class="condition">
                相机名称：
                <input type="text" placeholder="请输入名称" name="searchName" class="input-style minWidth" v-model="searchName"/>
                <a href="#" @click.prevent="search()" class="button-style">搜&nbsp;索</a>
                <a href="#" @click.prevent="add" class="button-style" style="float:right">新&nbsp;建</a>
            </div>
            <TableComponent :data="getCameraList" :columns="columns">
                <span v-for="(item, index) in getCameraList" :slot="'array' + index">
                    <span>{{item.name}}</span>/
                    <span>{{item.location ? item.location : '-'}}</span>
                </span>
                <span v-for="(item, index) in getCameraList" :slot="'element' + index">
                    <span v-for="i in deviceStatus">
                        <span v-if="item.status == i.value" :class="i.clsName">{{i.text}}</span>
                    </span>
                </span>
                <span v-for="(item, index) in getCameraList" :slot="'switch' + index">
                    <toggle-button :value="item.deploy_switch" :color="{checked: '#76b564', unchecked: '#b0b0b0'}" :sync="true" :labels="true" @change="onChangeEventHandler(item)"/>
                </span>
                <span v-for="(item, index) in this.getCameraList" :slot="'events' + index">
                    <a href="#" @click.prevent="edit(index)">编辑</a>
                    <a href="#" @click.prevent="del(index)">删除</a>
                </span>
            </TableComponent>
            <div style="overflow:hidden">
                <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
            </div>
            <ConfirmComponent :show="deleteObj.show" :title="deleteObj.text" :content="deleteObj.content" :confirm="deleteObj.confirm"> 
            </ConfirmComponent>
            <ConfirmComponent :show="addObj.show" :title="addObj.text" :confirm="addObj.confirm"> 
                <div slot="content">
                    <div class="camera-content">
                        <!--<div class="panel-body" style="padding-top:-11px;">
                            <div class="form-group video-div">
                                11111
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">摄像头名称</label>
                                <div class="col9 simple">
                                    <input type="text" name="name" placeholder="必填" class="form-control form-input" v-model="cameraData.name"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">摄像头坐标</label>
                                <div class="col9 simple">
                                    <input type="text" name="name" placeholder="必填" class="form-control form-input" v-model="cameraData.latlng"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">摄像头位置</label>
                                <div class="col9 simple">
                                    <input type="text" name="name" placeholder="必填" class="form-control form-input" v-model="cameraData.location"/>
                                </div>
                            </div>
                        </div>-->
                        <div class="panel-body camera-div" style="padding-top:-11px;">
                            <div class="form-group">
                                <label class="control-label col3">摄像头名称</label>
                                <div class="col9 simple">
                                    <input type="text" name="name" placeholder="必填" class="form-control form-input" v-model="cameraData.name" v-if="this.index === ''"/>
                                    <input type="text" name="name" placeholder="必填" class="form-control form-input" v-model="cameraData.name" @change="changeCameraName" v-else/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">摄像头坐标</label>
                                <div class="col9 simple">
                                    <input type="text" name="name" placeholder="必填" class="form-control form-input input-ip" readonly v-model="cameraData.latlng"/>
                                    &nbsp;
                                    <a href="#" @click.prevent="setLatlng()" class="button-style">设置坐标</a>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">摄像头位置</label>
                                <div class="col9 simple">
                                    <input type="text" name="name" placeholder="必填" class="form-control form-input" v-model="cameraData.location" v-if="this.index === ''"/>
                                    <input type="text" name="name" placeholder="必填" class="form-control form-input" v-model="cameraData.location" @change="changeCameraName" v-else/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">摄像头</label>
                                <div class="col9 simple">
                                    <input type="text" name="name" placeholder="ip" class="form-control form-input input-ip" v-model="cameraData.ip"/> :
                                    <input type="text" name="name" placeholder="port" class="form-control form-input input-port" v-model="cameraData.port"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">视频流地址</label>
                                <div class="col9 simple">
                                    <input type="text" name="name" placeholder="必填" class="form-control form-input" v-model="cameraData.src"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">所属分局</label>
                                <div class="col9 simple">
                                    <select v-model="cameraData.user_group_id" class="form-control form-select">
                                        <option v-for="option in getUserGroup" :value="option.id">{{option.name}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">布控配置</label>
                                <div class="col9 simple">
                                    <select v-model="cameraData.deployment_id" class="form-control form-select">
                                        <option value="">--未选择--</option>
                                        <option v-for="option in getDeployment" :value="option.id">{{option.name}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">视频配置</label>
                                <div class="col9 simple">
                                    <select v-model="cameraData.media_server_id" class="form-control form-select">
                                        <option value="">--未选择--</option>
                                        <option v-for="option in getMediaCore" :value="option.id">{{option.name}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">相机类型</label>
                                <div class="col9 simple">
                                    <select v-model="cameraData.camera_type" class="form-control form-select" @change="selectCameraType">
                                        <option v-for="option in cameraType" :value="option.value">{{option.text}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group" v-if="isHKCamera.value">
                                <label class="control-label col3">用户名</label>
                                <div class="col9 simple">
                                    <input type="text" name="name" placeholder="选填" class="form-control form-input" v-model="cameraData.username"/>
                                </div>
                            </div>
                            <div class="form-group" v-if="isHKCamera.value">
                                <label class="control-label col3">密码</label>
                                <div class="col9 simple">
                                    <input type="text" name="name" placeholder="选填" class="form-control form-input" v-model="cameraData.password"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
            <PanelComponent :show="olDialog.show" title="设置坐标" name="mapDiv">
                <div slot="content" class="map-bg">
                    <a href="#" class="dialog-close-button" @click.prevent="closeMap"><i class="fa fa-times"></i></a>
                </div>
            </PanelComponent>
            <ConfirmComponent :show="showCoverConfirm.show" :title="showCoverConfirm.text" :content="showCoverConfirm.content" :confirm="showCoverConfirm.confirm" :cancel="showCoverConfirm.cancel"> 
            </ConfirmComponent>
        </div>
    </div>
</template>

<script>
    import ol from 'openlayers'
    import 'openlayers/css/ol.css'
    import TableComponent from '@nanyun/table'
    import ConfirmComponent from '@nanyun/confirm'
    import DialogComponent from '@nanyun/dialog'
    import PaginationComponent from '@nanyun/pagination'
    import {GET_CAMERA_LIST, FETCH_CAMERA_LIST, DEL_CAMERA, ADD_CAMERA, SET_CAMERA, GET_PAGE} from 'store/modules/camera_setting'
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    import CrumbsComponent from 'common/components/crumbs.vue'
    import URL from 'common/url'
    import {DEVICE_STATUS, CAMERA_TYPE, DEFAULT_CENTER} from 'common/config'
    import {GET_USER_GROUP_LIST, FETCH_USER_GROUP_LIST} from 'store/modules/user_group_info'
    import ToggleButton from 'common/components/switch-button.vue'
    import {GET_DEPLOYMENT, FETCH_DEPLOYMENT} from 'store/modules/deployment'
    import {GET_MEDIA_CORE, FETCH_MEDIA_CORE} from 'store/modules/server_config'
    import {GET_SERVICES} from 'store/modules/common'
    import PanelComponent from '@nanyun/panel'
    import {setmapSymbol} from 'common/utils'
    
    let map

    export default{
        data() {
            return {
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '相机配置',
                    silent: true
                }],
                columns: [{
                    title: '名称/位置',
                    prop: ['name', 'location'],
                    width: '210px'
                }, {
                    title: '坐标',
                    prop: 'latlng',
                    handle: d => {
                        return d ? d.split(',')[0] + '/' + d.split(',')[1] : '-'
                    }
                }, {
                    title: 'IP地址',
                    prop: 'ip',
                    handle: d => {
                        return d ? d : '-'
                    }
                }, {
                    title: '视频地址',
                    prop: 'src',
                    handle: d => {
                        return d ? d : '-'
                    }
                }, {
                    title: '布控配置',
                    prop: 'deployment',
                    handle: d => {
                        return d ? d.name : '-'
                    }
                }, {
                    title: '相机状态',
                    prop: 'status',
                    type: 'element'
                }, {
                    title: '布控状态',
                    type: 'switch'
                }, {
                    title: '相机类型',
                    prop: 'camera_type',
                    handle: d => {
                        for (let type of this.cameraType) {
                            if (type.value == d) {
                                return type.text
                            }
                        }
                        return '-'
                    }
                }, {
                    title: '所属分局',
                    prop: 'user_group_id',
                    handle: d => {
                        for (let group of this.getUserGroup) {
                            if (group.id == d) {
                                return group.name
                            }
                        }
                        return '-'
                    }
                }, {
                    title: '操作',
                    type: 'events'
                }],
                deleteObj: {
                    autoClose: 10000,
                    text: '确认删除',
                    content: '确定删除该相机?',
                    show: {
                        value: false
                    },
                    confirm: () => {
                        this.delCamera(this.getCameraList[this.index])
                    }
                },
                addObj: {
                    autoClose: 10000,
                    text: '新建相机',
                    show: {
                        value: false
                    },
                    confirm: () => {
                        if (this.index === '') {
                            this.addCamera(this.cameraData).then(() => {
                                this.fetchCameraList()
                            })
                        } else {
                            if (this.cameraInfoChange) {
                                this.showCoverConfirm.show.value = true
                                this.addObj.show.value = false
                            } else {
                                this.cameraData['cover'] = 'true'
                                this.setCamera(this.cameraData).then(() => {
                                    this.fetchCameraList()
                                })
                            }
                        }
                    }
                },
                olDialog: {
                    autoClose: 100001,
                    show: {
                        value: false
                    }
                },
                index: '',
                cameraData: {},
                deviceStatus: DEVICE_STATUS,
                cameraType: CAMERA_TYPE,
                isHKCamera: {
                    value: false
                },
                cameraInfoChange: false,
                showCoverConfirm: {
                    autoClose: 10001,
                    text: '确认信息',
                    content: '相机名称/位置已修改,是否修改已关联该相机的抓拍及告警记录?',
                    show: {
                        value: false
                    },
                    confirm: () => {
                        this.cameraData['cover'] = 'true'
                        this.setCamera(this.cameraData).then(() => {
                            this.fetchCameraList()
                        })
                        this.addObj.show.value = !this.addObj.show.value
                    },
                    cancel: () => {
                        this.cameraData['cover'] = 'false'
                        this.setCamera(this.cameraData).then(() => {
                            this.fetchCameraList()
                        })
                        this.addObj.show.value = !this.addObj.show.value
                    }
                }
            }
        },

        created() {
            this.fetchData()
        },

        computed: {
            ...mapGetters({
                getCameraList: GET_CAMERA_LIST,
                getPage: GET_PAGE,
                getUserGroup: GET_USER_GROUP_LIST,
                getDeployment: GET_DEPLOYMENT,
                getMediaCore: GET_MEDIA_CORE,
                getServices: GET_SERVICES
            })
        },

        methods: {
            fetchData() {
                this.fetchUserGroup()
                this.fetchDeployment()
                this.fetchMediaCore()
                this.fetchCameraList(this.cameraData)
            },
            ...mapActions({
                fetchCameraList: FETCH_CAMERA_LIST,
                fetchUserGroup: FETCH_USER_GROUP_LIST,
                delCamera: DEL_CAMERA,
                addCamera: ADD_CAMERA,
                setCamera: SET_CAMERA,
                fetchDeployment: FETCH_DEPLOYMENT,
                fetchMediaCore: FETCH_MEDIA_CORE
            }),
            edit(index) {
                this.addObj.show.value = !this.addObj.show.value
                this.cameraData = Object.assign({}, this.getCameraList[index])
                let cameraType = this.cameraData.camera_type

                if (cameraType == 2) {
                    this.isHKCamera.value = true
                } else {
                    this.isHKCamera.value = false
                }
                this.cameraInfoChange = false
                this.index = index
            },
            del(index) {
                this.deleteObj.show.value = !this.deleteObj.show.value
                this.cameraData = this.getCameraList[index]
                this.index = index
            },
            add() {
                this.addObj.show.value = !this.addObj.show.value
                this.cameraData = {}
                this.cameraData['user_group_id'] = this.getUserGroup[0].id
                this.cameraData['deployment_id'] = ''
                this.cameraData['media_server_id'] = ''
                this.cameraData['camera_type'] = 0
                this.cameraData['latlng'] = DEFAULT_CENTER.toString()
                this.isHKCamera.value = false
                this.cameraInfoChange = false
                this.index = ''
            },
            search() {
                this.cameraData = {
                    name: this.searchName
                }
                this.fetchData()
            },
            pageEvent(page) {
                this.cameraData = {
                    name: this.searchName,
                    page: page,
                    size: this.getPage.size
                }
                this.fetchData()
            },
            onChangeEventHandler(camera) {
                camera['deploy_switch'] = !camera.deploy_switch
                camera.cover = true
                this.setCamera(camera)
            },
            setLatlng() {
                this.olDialog.show.value = !this.olDialog.show.value
                let mapDiv = document.querySelector('[name=mapDiv]')
                let mapObj = document.createElement('div')
                let latlng = []
                let symbolOverlay

                if (this.cameraData.latlng) {
                    latlng.push(parseFloat(this.cameraData.latlng.split(',')[0]))
                    latlng.push(parseFloat(this.cameraData.latlng.split(',')[1]))
                } else {
                    latlng = DEFAULT_CENTER
                }
                mapObj.id = 'gismap'
                mapDiv.append(mapObj)
                let obj =  document.getElementById('gismap')

                obj.style.width = '690px'
                obj.style.height = '388px'
                obj.style.position = 'absolute'
                obj.style.left = '50%'
                obj.style.top = '50%'
                obj.style.marginLeft = '-346px'
                obj.style.marginTop = '-176px'
                obj.style.zIndex = '10001'
                setTimeout( () => {
                    map = new ol.Map({
                        target: 'gismap',
                        layers: [
                            new ol.layer.Tile({
                                source: new ol.source.XYZ({
                                    url: `${this.getServices.GisServer}{z}/{x}/{y}.png`
                                })
                            })
                        ],
                        controls: ol.control.defaults().extend([
                            // new ol.control.MousePosition(),
                            new ol.control.ZoomSlider(),
                            new ol.control.Zoom()
                        ]),
                        view: new ol.View({
                            center: latlng,
                            maxZoom: 15,
                            zoom: 10
                        })
                    })
                    setTimeout( () => {
                        setmapSymbol({
                            ol,
                            map,
                            latlng
                        })
                    }, 100)
                    map.on('singleclick', e => {
                        let latlng = e.coordinate
                        let view = map.getView()

                        this.cameraData.latlng = latlng.toString()
                        setmapSymbol({
                            ol,
                            map,
                            latlng
                        })
                        view.setCenter(latlng)
                        map.render()
                    })
                }, 1000)
            },
            closeMap() {
                let gismap = document.getElementById('gismap')

                gismap.remove()
                this.olDialog.show.value = !this.olDialog.show.value
            },
            selectCameraType(e) {
                let cameraType = e.target.value

                if (cameraType == 2) {
                    this.isHKCamera.value = true
                } else {
                    this.isHKCamera.value = false
                }
            },
            changeCameraName() {
                this.cameraInfoChange = true
            }
        },
        components: {
            TableComponent,
            ConfirmComponent,
            PaginationComponent,
            CrumbsComponent,
            ToggleButton,
            DialogComponent,
            PanelComponent
        }
    }
</script>

<style scoped>
    .camara_setting{
        height: 100%;
        box-sizing: border-box;
        min-height: 550px;
        width: 1300px;
        .table_content{
            width:100%;
            .condition {
                color:#fff;
                margin-bottom: 30px;
                input{
                    margin-right:20px;
                }
            }
        }
        .panel-body{
            height: 100px;
        }
        .success{
            border-radius: 3px;
            padding: 2px 4px;
            background: #5ebd5e;
            color: #fff;
        }
        .danger{
            border-radius: 3px;
            padding: 2px 4px;
            background: #e66454;
            color: #fff;
        }
        .primary{
            border-radius: 3px;
            padding: 2px 4px;
            background: #b0b0b0;
            color: #fff;
        }
        .camera-content{
            height: 100%;
            color: #fff;
            width: 500px;
            .panel-body{
                flex: 1;
                margin: 5px;
                height: 100%;
            }
            .video-div{
                height: 200px;
                border: 1px solid #fff;
                margin: 10px;
            }
            .form-select{
                width: 284px;
            }
            .input-ip{
                width: 150px;
            }
            .input-port{
                width: 70px;
            }
        }
        .map-bg{
            position: relative;
            padding: 10px;
            width: 710px;
            height: 424px;
            background: #257B97;
            margin: 0 auto;
            display: block;
            &.is-open{
                display: block;
            }
        }
    }
</style>