<template>
    <div class="gate-statistics">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="selector-wrapper">
            <div class="selector">
                选择摄像头: 
                <!--<select class="form-control" @change="go()" v-model="selectedCamera">
                    <option :value="option.name" v-for="option in getCameras">{{option.name}}</option>
                </select>-->
                &nbsp;&nbsp;
                <CameraSelectorComponent :list="getCameras" :value="selectedCamera" :callback="syncValue"></CameraSelectorComponent>&nbsp;&nbsp;
                <!-- <button class="button-style" @click.prevent="go">切换</button> -->
            </div>
            <button class="button-style" @click.prevent="alarmDetail">查看{{currentCamera}}告警详情</button>
        </div>
        <div class="top-chart">
            <IntervalComponent :chartData="getIntervalData"></IntervalComponent>
        </div>
        <div class="period">
            <ModuleComponent>
                <div slot="title" class="period-header">信息统计
                    <PeriodButtonComponent :select="selectPeriod"></PeriodButtonComponent>
                </div>
                <div slot="content" class="period-content">
                    <div class="chart">
                        <PeriodComponent :chartData="getPeriodData"></PeriodComponent>
                    </div>
                    <div class="chart">
                        <TableComponent :data="getLastDaysTableData" :columns="getLastDaysTableColumnData"></TableComponent>
                    </div>
                </div>
            </ModuleComponent>
        </div>
    </div>
</template>

<script>
    import {
        mapGetters,
        mapMutations,
        mapActions } from 'vuex'
    import { getInitialDate, WEEK, MONTH } from 'common/utils'
    import URL from 'common/url'
    import IntervalComponent from 'pages/gate-statistics/charts/interval_chart.vue'
    import TableComponent from '@nanyun/table'
    import ModuleComponent from 'common/components/module.vue'
    import PeriodComponent from 'pages/gate-statistics/charts/period-chart.vue'
    import PeriodButtonComponent from 'common/components/period-button.vue'
    import CameraSelectorComponent from 'common/components/camera-selector.vue'
    import {
        GET_CAMERAS,
        FETCH_CAMERAS
    } from 'store/modules/cameras'
    import {
        GET_ALL_BRANCHS,
        GET_INTERVAL_DATA,
        GET_PERIOD_DATA,
        GET_LAST_DAYS_TABLE_DATA,
        GET_LAST_DAYS_TABLE_COLUMN_DATA,
        CLEAR_INTERVAL_DATA,
        CLEAR_PERIOD_DATA,
        FETCH_ALL_BRANCHS,
        FETCH_CAMERA_INTERVAL_DATA,
        FETCH_CAMERA_PERIOD_DATA } from 'store/modules/citywide_info'
    import { GET_SERVICES } from 'store/modules/common'
    import CrumbsComponent from 'common/components/crumbs.vue'

    export default {

        data() {
            return {
                selectedCamera: '',
                currentCamera: '',
                selectedPeriod: WEEK,
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '市局汇总',
                    path: {
                        name: URL.GATE.GATE_STATISTICS
                    }
                }, {
                    name: '分局',
                    silent: true
                }, {
                    name: '摄像头',
                    silent: true
                }]
            }
        },

        created() {
            this.fetchData()
            this.interval = setInterval(() => {
                this.fetchIntervalData()
            }, 10000)
        },

        computed: {
            ...mapGetters({
                getCameras: GET_CAMERAS,
                getIntervalData: GET_INTERVAL_DATA,
                getAllBranchs: GET_ALL_BRANCHS,
                getPeriodData: GET_PERIOD_DATA,
                getLastDaysTableData: GET_LAST_DAYS_TABLE_DATA,
                getLastDaysTableColumnData: GET_LAST_DAYS_TABLE_COLUMN_DATA,
                getServices: GET_SERVICES
            }),
            getPeriodNumber() {
                switch (this.selectedPeriod) {
                    case WEEK:
                        return 7
                    case MONTH:
                        return 30
                }
            },
            getCurrentBrach() {
                for (let camera of this.getCameras) {
                    if (camera.name == this.selectedCamera) {
                        for (let branch of this.getAllBranchs) {
                            if (camera.user_group_id == branch.id) return branch.name
                        }
                    }
                }
                return ''
            }
        },

        watch: {
            $route() {
                this.fetchData()
            },
            selectedPeriod() {
                this.fetchData()
            }
        },

        methods: {
            alarmDetail() {
                if (Object.is(this.selectedCamera, undefined)) return
                this.$router.push({
                    name: URL.GATE_REAL_TIME.ALARM_HISTORY,
                    params: {
                        cameraName: this.selectedCamera
                    }
                })
                //window.open(`alarm-history#camera_name=${this.selectedCamera}`)
                //window.open(`${this.getServices.SecurityPlus}monitor/alarm-history#l6_camera_name=${this.selectedCamera}`)
            },

            fetchData() {
                Promise.all([this.fetchCameras(), this.fetchAllBranchs()]).then(() => {
                    let { start: periodStart, end: periodEnd } = getInitialDate({seconds: this.selectedPeriod, hours: 0})
                    let name = this.$route.params.camera || this.getCameras[0].name
                    let id = this.getCameraId(name)

                    this.selectedCamera = name
                    this.currentCamera = name

                    this.fetchCameraPeriodData({
                        start: periodStart,
                        end: periodEnd,
                        id,
                        number: this.getPeriodNumber
                    })

                    this.fetchIntervalData()

                    this.crumbs.splice(this.crumbs.length - 2, 2, {
                        name: this.getCurrentBrach,
                        path: {
                            name: URL.GATE.BRANCH_STAT,
                            params: {
                                branch: this.getCurrentBrach
                            }
                        }
                    }, {
                        name,
                        silent: true
                    })
                })
            },

            fetchIntervalData() {
                let { start: intervalStart, end: intervalEnd } = getInitialDate()
                let id = this.getCameraId(this.$route.params.camera) || this.getCameras[0].camera_id
                let name = this.$route.params.camera || this.getCameras[0].name

                this.fetchCameraIntervalData({
                    start: intervalStart,
                    end: intervalEnd,
                    id,
                    name
                })
            },

            getCameraId(name) {
                for (let [index, camera] of this.getCameras.entries()) {
                    if (name == camera.name) {
                        return camera.id
                    }
                }
            },

            selectPeriod(period) {
                this.selectedPeriod = period
            },

            syncValue(value) {
                let valid = false
                let oldCamera = this.selectedCamera

                this.selectedCamera = value
                for (let camera of this.getCameras) {
                    if (camera.name == this.selectedCamera) {
                        valid = true
                        break
                    }
                }

                if (!valid) {
                    this.selectedCamera = oldCamera
                    return false
                } else {
                    this.go()
                }
            },

            go() {
                if (Object.is(this.selectedCamera, undefined)) return
                this.$router.push({
                    name: URL.GATE.CAMERA_STAT,
                    params: {
                        camera: this.selectedCamera
                    }
                })
            },

            ...mapActions({
                fetchCameraIntervalData: FETCH_CAMERA_INTERVAL_DATA,
                fetchCameraPeriodData: FETCH_CAMERA_PERIOD_DATA,
                fetchAllBranchs: FETCH_ALL_BRANCHS,
                fetchCameras: FETCH_CAMERAS
            }),

            ...mapMutations({
                clearIntervalData: CLEAR_INTERVAL_DATA,
                clearPeriodData: CLEAR_PERIOD_DATA
            })
        },

        destroyed() {
            clearInterval(this.interval)
            this.clearIntervalData()
            this.clearPeriodData()
        },

        components: {
            IntervalComponent,
            CrumbsComponent,
            TableComponent,
            PeriodComponent,
            PeriodButtonComponent,
            ModuleComponent,
            CameraSelectorComponent
        }
    }
</script>

<style scoped>
    .gate-statistics{
        padding:50px 80px;
        box-sizing: border-box;
        .top-chart{
            margin-top:30px;
            background-color: #323c4e;
        }
        .selector-wrapper {
            display: flex;
            justify-content: space-between;
            .selector{
                color: #FFF;
                font-size: 14px;
                line-height: 25px;
                width: 420px;
            }
        }
        .period{
            margin-top:30px;
            .period-header{
                display: flex;   
                justify-content: space-between;
            }
            .period-content{
                height: 240px;
                display: flex;
                justify-content: space-between;
                padding:30px 0;
                .chart{
                    flex:0 0 48%;
                }
            }
        }
    }
</style>