<template>
    <Highcharts :style="style" :themeType="themeType" :theme="theme" :data="chartData" :update="update"></Highcharts>
</template>

<script>
    import Highcharts, { THEME_TYPE } from '@nanyun/highcharts'
    import themeStyle from 'common/chart-style'
    import Immutable from 'immutable'
    import { mapActions, mapGetters } from 'vuex'
    import { getInitialDate } from 'common/utils'

    export default {
        props: {
            chartData: {
                type: Object,
                required: true
            }
        },

        data() {
            return {
                themeType: THEME_TYPE.DARK_UNICA,
                style: {
                    width: '100%',
                    height: '300px',
                    backgroundImage: 'linear-gradient(-180deg, #000304 4%, #002636 99%)'
                },
                theme: {
                    chart: {
                        backgroundColor: 'rgba(0,0,0,0)'
                    }
                },
                reRender: true,
                prevCategories: [],
                prevSeriesNum: 0

            }
        },

        created() {
            this.reRender = true
        },

        watch: {
            $route() {
                this.reRender = true
            }
        },

        methods: {
            update(chart, data, render) {
                if (this.reRender) {
                    render()
                    this.reRender = false
                    this.prevCategories = data.xAxis.categories
                    this.prevSeriesNum = data.series.length
                } else {
                    if (Immutable.List(data.xAxis.categories).equals(Immutable.List(this.prevCategories.slice(this.prevCategories.length - data.xAxis.categories.length))) && this.prevSeriesNum == data.series.length) return

                    let supplement = chart.xAxis[0].categories.length - data.xAxis.categories.length + 1
                    let categories = Array.from({
                        length: supplement
                    }).fill('').concat(data.xAxis.categories)

                    chart.update({
                        xAxis: {
                            categories: categories
                        }
                    })

                    for (let [index, s] of data.series.entries()) {
                        if (chart.series[index]) {
                            chart.series[index].removePoint(0)
                            chart.series[index].addPoint(s.data[s.data.length - 1])
                        } else {
                            chart.addSeries(s)
                        }
                    }

                    this.prevCategories = categories
                    this.prevSeriesNum = data.series.length
                }
            }
        },

        components: {
            Highcharts
        }
    }
</script>

<style></style>