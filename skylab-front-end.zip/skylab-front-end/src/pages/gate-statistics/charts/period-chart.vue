<template>
    <Highcharts :style="style" :themeType="themeType" :theme="theme" :data="chartData"></Highcharts>
</template>

<script>
    import Vue from 'vue'
    import Highcharts, { THEME_TYPE } from '@nanyun/highcharts'
    import themeStyle from 'common/chart-style'

    export default {

        props: {
            chartData: {
                type: Object,
                default() {
                    return {}
                }
            }
        },

        data() {
            return {
                themeType: THEME_TYPE.DARK_UNICA,
                theme: {
                    chart: {
                        backgroundColor: 'rgba(0,0,0,0)'
                    }
                },
                style: {
                    width: '100%',
                    height: '100%',
                    // backgroundImage: 'linear-gradient(-180deg, #000304 4%, #002636 99%)'
                }
            }
        },

        components: {
            Highcharts
        }
    }
</script>

<style> </style>