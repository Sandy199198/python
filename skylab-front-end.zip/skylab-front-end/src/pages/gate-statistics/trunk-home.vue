<template>
    <div class="gate-statistics">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="interval">
            <IntervalComponent :chartData="getIntervalData"></IntervalComponent>
        </div>
        <div class="period">
            <ModuleComponent>
                <div slot="title" class="period-header">信息统计
                    <PeriodButtonComponent :select="selectPeriod"></PeriodButtonComponent>
                </div>
                <div slot="content" class="period-content">
                    <div class="chart">
                        <PeriodComponent :chartData="getPeriodData"></PeriodComponent>
                    </div>
                    <div class="chart">
                        <TableComponent :data="getLastDaysTableData" :columns="getLastDaysTableColumnData"></TableComponent>
                    </div>
                </div>
            </ModuleComponent>
        </div>
        <div class="info-table">
            <TableComponent :columns="getTableColumnData" :data="getTableData">
                <span v-for="(item, index) in getTableData" :slot="'events' + index">
                    <a href="#" @click.prevent="goToBranch(item.name)">
                        查看汇总
                    </a>
                </span>
            </TableComponent>
        </div>
    </div>
</template>

<script>
    import {
        mapGetters,
        mapMutations,
        mapActions } from 'vuex'

    import { getInitialDate, WEEK, MONTH } from 'common/utils'
    import URL from 'common/url'
    import IntervalComponent from 'pages/gate-statistics/charts/interval_chart.vue'
    import PeriodComponent from 'pages/gate-statistics/charts/period-chart.vue'
    import TableComponent from '@nanyun/table'
    import ModuleComponent from 'common/components/module.vue'
    import PeriodButtonComponent from 'common/components/period-button.vue'
    import {
        GET_INTERVAL_DATA,
        GET_PERIOD_DATA,
        GET_LAST_DAYS_TABLE_DATA,
        GET_LAST_DAYS_TABLE_COLUMN_DATA,
        GET_TABLE_DATA,
        GET_TABLE_COLUMN_DATA,
        CLEAR_INTERVAL_DATA,
        CLEAR_PERIOD_DATA,
        FETCH_ALL_BRANCHS,
        FETCH_TRUNK_TABLE_DATA,
        FETCH_TRUNK_INTERVAL_DATA,
        FETCH_TRUNK_PERIOD_DATA } from 'store/modules/citywide_info'
    import CrumbsComponent from 'common/components/crumbs.vue'

    export default {

        data() {
            return {
                selectedBranch: '',
                selectedPeriod: WEEK,
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '市局汇总',
                    silent: true
                }]
            }
        },

        created() {
            this.fetchData()
            this.interval = setInterval(() => {
                this.fetchIntervalData()
            }, 10000)
        },

        computed: {
            ...mapGetters({
                getIntervalData: GET_INTERVAL_DATA,
                getPeriodData: GET_PERIOD_DATA,
                getLastDaysTableData: GET_LAST_DAYS_TABLE_DATA,
                getLastDaysTableColumnData: GET_LAST_DAYS_TABLE_COLUMN_DATA,
                getTableData: GET_TABLE_DATA,
                getTableColumnData: GET_TABLE_COLUMN_DATA
            }),
            getPeriodNumber() {
                switch (this.selectedPeriod) {
                    case WEEK:
                        return 7
                    case MONTH:
                        return 30
                }
            }
        },

        watch: {
            selectedPeriod() {
                this.fetchData()
            }
        },

        methods: {
            fetchData() {
                this.fetchAllBranchs().then(() => {
                    let { start: periodStart, end: periodEnd } = getInitialDate({seconds: this.selectedPeriod, hours: 0})

                    this.fetchTrunkPeriodData({
                        start: periodStart,
                        end: periodEnd,
                        number: this.getPeriodNumber
                    })

                    this.fetchIntervalData()

                    this.fetchTrunkTableData()
                })
            },

            fetchIntervalData() {
                let { start: intervalStart, end: intervalEnd } = getInitialDate()

                this.fetchTrunkIntervalData({
                    start: intervalStart,
                    end: intervalEnd
                })
            },

            selectPeriod(period) {
                this.selectedPeriod = period
            },

            goToBranch(branch) {
                this.$router.push({
                    name: URL.GATE.BRANCH_STAT,
                    params: {
                        branch
                    }
                })
            },

            ...mapActions({
                fetchTrunkIntervalData: FETCH_TRUNK_INTERVAL_DATA,
                fetchTrunkPeriodData: FETCH_TRUNK_PERIOD_DATA,
                fetchTrunkTableData: FETCH_TRUNK_TABLE_DATA,
                fetchAllBranchs: FETCH_ALL_BRANCHS
            }),

            ...mapMutations({
                clearIntervalData: CLEAR_INTERVAL_DATA,
                clearPeriodData: CLEAR_PERIOD_DATA
            })
        },

        destroyed() {
            clearInterval(this.interval)
            this.clearIntervalData()
            this.clearPeriodData()
        },

        components: {
            IntervalComponent,
            TableComponent,
            PeriodComponent,
            PeriodButtonComponent,
            ModuleComponent,
            CrumbsComponent
        }
    }
</script>

<style scoped>
    .gate-statistics{
        padding:50px 80px;
        box-sizing: border-box;
        .interval{
            margin-top:30px;
            background-color: #323c4e;
        }
        .period{
            margin-top:30px;
            .period-header{
                display: flex;   
                justify-content: space-between;
            }
            .period-content{
                height: 240px;
                display: flex;
                justify-content: space-between;
                padding:30px 0;
                .chart{
                    flex:0 0 48%;
                }
            }
        }
        .info-table{
            margin-top:30px;
        }
    }
</style>