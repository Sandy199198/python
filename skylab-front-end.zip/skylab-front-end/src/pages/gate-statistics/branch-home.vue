<template>
    <div class="gate-statistics">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="selector-wrapper">
            <div class="selector">
                选择分局: 
                <select class="form-control" @change="go()" v-model="selectedBranch">
                    <option :value="option.name" v-for="option in getAllBranchs">{{option.name}}</option>
                </select>
            </div>
        </div>
        <div class="top-chart">
            <IntervalComponent :chartData="getIntervalData"></IntervalComponent>
        </div>
        <div class="period">
            <ModuleComponent>
                <div slot="title" class="period-header">信息统计
                    <PeriodButtonComponent :select="selectPeriod"></PeriodButtonComponent>
                </div>
                <div slot="content" class="period-content">
                    <div class="chart">
                        <PeriodComponent :chartData="getPeriodData"></PeriodComponent>
                    </div>
                    <div class="chart">
                        <TableComponent :data="getLastDaysTableData" :columns="getLastDaysTableColumnData"></TableComponent>
                    </div>
                </div>
            </ModuleComponent>
        </div>
        <div class="info-table">
            <TableComponent :columns="getTableColumnData" :data="getTableData">
                <span v-for="(item, index) in getTableData" :slot="'events' + index">
                    <a href="#" @click.prevent="goToCamera(item.name)">
                        查看汇总
                    </a>
                </span>
            </TableComponent>
        </div>
    </div>
</template>

<script>
    import {
        mapGetters,
        mapMutations,
        mapActions } from 'vuex'
    import { getInitialDate, WEEK, MONTH } from 'common/utils'
    import URL from 'common/url'
    import IntervalComponent from 'pages/gate-statistics/charts/interval_chart.vue'
    import TableComponent from '@nanyun/table'
    import ModuleComponent from 'common/components/module.vue'
    import PeriodComponent from 'pages/gate-statistics/charts/period-chart.vue'
    import PeriodButtonComponent from 'common/components/period-button.vue'
    import { FETCH_CAMERAS } from 'store/modules/cameras'
    import {
        GET_ALL_BRANCHS,
        GET_BRANCH_MAP,
        GET_INTERVAL_DATA,
        GET_PERIOD_DATA,
        GET_LAST_DAYS_TABLE_DATA,
        GET_LAST_DAYS_TABLE_COLUMN_DATA,
        GET_TABLE_DATA,
        GET_TABLE_COLUMN_DATA,
        CLEAR_INTERVAL_DATA,
        CLEAR_PERIOD_DATA,
        FETCH_ALL_BRANCHS,
        FETCH_BRANCH_TABLE_DATA,
        FETCH_BRANCH_INTERVAL_DATA,
        FETCH_BRANCH_PERIOD_DATA } from 'store/modules/citywide_info'
    import CrumbsComponent from 'common/components/crumbs.vue'

    export default {

        data() {
            return {
                selectedBranch: '',
                selectedPeriod: WEEK,
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '市局汇总',
                    path: {
                        name: URL.GATE.GATE_STATISTICS
                    }
                }, {
                    name: '分局',
                    silent: true
                }]
            }
        },

        created() {
            this.fetchData()
            this.interval = setInterval(() => {
                this.fetchIntervalData()
            }, 10000)
        },

        computed: {
            ...mapGetters({
                getIntervalData: GET_INTERVAL_DATA,
                getPeriodData: GET_PERIOD_DATA,
                getAllBranchs: GET_ALL_BRANCHS,
                getBranchMap: GET_BRANCH_MAP,
                getLastDaysTableData: GET_LAST_DAYS_TABLE_DATA,
                getLastDaysTableColumnData: GET_LAST_DAYS_TABLE_COLUMN_DATA,
                getTableData: GET_TABLE_DATA,
                getTableColumnData: GET_TABLE_COLUMN_DATA
            }),
            getPeriodNumber() {
                switch (this.selectedPeriod) {
                    case WEEK:
                        return 7
                    case MONTH:
                        return 30
                }
            }
        },

        watch: {
            $route() {
                this.fetchData()
            },
            selectedPeriod() {
                this.fetchData()
            }
        },

        methods: {
            getNameAndId() {
                let name = this.$route.params.branch || this.getAllBranchs[0].name
                let id = this.getBranchMap[name]

                return [name, id]
            },

            fetchData() {
                this.fetchCameras(true).then(() => {
                    let { start: periodStart, end: periodEnd } = getInitialDate({seconds: this.selectedPeriod, hours: 0})
                    let [name, id] = this.getNameAndId()

                    this.fetchBranchPeriodData({
                        start: periodStart,
                        end: periodEnd,
                        id: id,
                        number: this.getPeriodNumber,
                        name
                    })

                    this.fetchIntervalData()

                    this.fetchBranchTableData(id)

                    this.selectedBranch = name

                    this.crumbs.splice(this.crumbs.length - 1, 1, {
                        name,
                        silent: true
                    })
                })
            },

            fetchIntervalData() {
                let { start: intervalStart, end: intervalEnd } = getInitialDate()
                let [name, id] = this.getNameAndId()

                this.fetchBranchIntervalData({
                    start: intervalStart,
                    end: intervalEnd,
                    id: id,
                    name
                })

            },


            selectPeriod(period) {
                this.selectedPeriod = period
            },

            go() {
                if (Object.is(this.selectedBranch, undefined)) return
                this.$router.push({
                    name: URL.GATE.BRANCH_STAT,
                    params: {
                        branch: this.selectedBranch
                    }
                })
            },

            goToCamera(camera) {
                this.$router.push({
                    name: URL.GATE.CAMERA_STAT,
                    params: {
                        camera
                    }
                })
            },

            ...mapActions({
                fetchBranchIntervalData: FETCH_BRANCH_INTERVAL_DATA,
                fetchBranchPeriodData: FETCH_BRANCH_PERIOD_DATA,
                fetchAllBranchs: FETCH_ALL_BRANCHS,
                fetchBranchTableData: FETCH_BRANCH_TABLE_DATA,
                fetchCameras: FETCH_CAMERAS
            }),

            ...mapMutations({
                clearIntervalData: CLEAR_INTERVAL_DATA,
                clearPeriodData: CLEAR_PERIOD_DATA
            })
        },

        destroyed() {
            clearInterval(this.interval)
            this.clearIntervalData()
            this.clearPeriodData()
        },

        components: {
            IntervalComponent,
            CrumbsComponent,
            TableComponent,
            PeriodComponent,
            PeriodButtonComponent,
            ModuleComponent
        }
    }
</script>

<style scoped>
    .gate-statistics{
        padding:50px 80px;
        box-sizing: border-box;
        .top-chart{
            margin-top:30px;
            background-color: #323c4e;
        }
        .selector{
            color: #FFF;
            font-size: 14px;
            line-height: 25px;
            width: 300px;
            select{
                margin-left:10px;
            }
        }
        .period{
            margin-top:30px;
            .period-header{
                display: flex;   
                justify-content: space-between;
            }
            .period-content{
                height: 240px;
                display: flex;
                justify-content: space-between;
                padding:30px 0;
                .chart{
                    flex:0 0 48%;
                }
            }
        }
        .info-table{
            margin-top:30px;
        }
    }
</style>
