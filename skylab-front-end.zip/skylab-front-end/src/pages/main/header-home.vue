<template>
    <div class="header">
        <div class="logo">
            <a href="#">
                <img src="../../images/logo.png" height="50px"/>
            </a>
        </div>
        <h1>
            智能人像大数据云平台
        </h1>
        <UserInfoComponent></UserInfoComponent>
    </div>
</template>

<script>
    import UserInfoComponent from 'common/components/user-info.vue'

    export default {
        components: {
            UserInfoComponent
        }
    }
</script>

<style scoped>
.header{
    position: relative;
    color:#FFF;
    height: 85px;
    line-height: 85px;
    text-align: center;
    background:-moz-linear-gradient(top, #020c16, rgba(0, 34, 51, 0.5));
    background: -webkit-gradient(linear, 0 0, 0 bottom, from(#020c16), to(rgba(0, 34, 51, 0.5)));
    box-shadow: 0 3px 10px rgb(14,27,41);
    h1 {
        margin:0;
        padding:0;
        font-size:36px;
        a{
            color:#FFF;
        }
    }
    .logo{
        position: absolute;
        top: 50%;
        left: 0px;
        margin-top: -25px;
    }
}
</style>