<template>
    <div class="login" :style="height">
        <div class="login-content">
            <h1>智能人像大数据云平台</h1>
            <p><label for="username">用户名</label><input type="text" v-focus="p" autocomplete="off" id="username" @keyup.enter="usernameEnter" v-model="username"></p>
            <p><label ref="password" for="password">密　码</label><input id="password" v-focus="p" autocomplete="off" @keyup.enter="passwordEnter" type="password" v-model="password"></p>
            <div class="button">
                <button class="button-style" @click="submit">登　录</button>
            </div>
        </div>
    </div> 
</template>

<script>
    import { LOGIN } from 'store/modules/auth'
    import URL from 'common/url'
    import { mapActions } from 'vuex'

    export default {
        data() {
            return {
                username: '',
                password: '',
                height: {}
            }
        },
        created() {
            this.height = {
                height: document.documentElement.clientHeight + 'px',
                overflow: 'hidden'
            }
        },
        methods: {
            innerLogin() {
                this.login({
                    username: this.username,
                    password: this.password
                }).then(userId => {
                    this.redirect(userId)
                })
            },
            submit(e) {
                e.preventDefault()
                this.innerLogin()
            },
            usernameEnter() {
                this.$refs.password.focus()
            },
            passwordEnter() {
                this.innerLogin()
            },
            redirect(userId) {
                if (this.$route.query.redirect) {
                    let redirect = decodeURIComponent(this.$route.query.redirect)

                    redirect += redirect.indexOf('?') != -1 ? `&user_id=${userId}` : `?user_id=${userId}`
                    window.location.href = redirect
                } else if (this.$route.params.redirect) {
                    let { name, query, params } = this.$route.params.redirect

                    this.$router.push({
                        name,
                        query,
                        params
                    })
                } else {
                    this.$router.push({
                        name: URL.HOME
                    })
                }
            },
            ...mapActions({
                login: LOGIN,
            })
        }
    }
</script>

<style>
    .login {
        position: absolute;
        top:0;
        left:0;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        background: url('../../images/bg.png') center center;
        background-size: 100% 100%;
        h1{
            font-size:35px;
            color:#FFF;
            text-align: center;
            margin-bottom: 50px;
        }
        .login-content{
            width:500px;
            height: 300px;
            margin-top:-100px;
            p{
                transition: all .5s ease;
                color:#FFF;
                font-size:16px;
                margin:10px 50px;
                background: rgba(80,227,194,0.30);
                border: 1px solid rgba(255,255,255,0.50);
                box-shadow: 0 1px 2px 0 rgba(0,0,0,0.50);
                border-radius: 8px;
                color: #FFFFFF;
                letter-spacing: 0;
                text-shadow: 0 3px 5px rgba(0,0,0,0.50);
                label{
                    display: inline-block;
                    width:80px;
                    height: 30px;
                    padding-left: 10px;
                }
                input{
                    color:#FFF;
                    width:300px;
                    height: 30px;
                    border:0 none;
                    background: transparent;
                    outline: none;
                }
            }
            p.focus{
                border-bottom-color: #FFF;
            }
            .button{
                text-align: center;
                margin-top:50px;
                button{
                    background: rgba(80,227,194,0.30);
                    border: 1px solid rgba(255,255,255,0.50);
                    box-shadow: 0 1px 2px 0 rgba(0,0,0,0.50);
                    border-radius: 8px;
                    padding:8px 50px;
                    font-size:16px;
                    border: none;
                    color: #FFFFFF;
                    letter-spacing: 0;
                    text-shadow: 0 3px 5px rgba(0,0,0,0.50);
                }
            }
        }
    }
</style>