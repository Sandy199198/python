<template>
    <div :style="height">
        <span>页面不存在</span>
    </div>
</template>

<script>
    export default {
        created() {
            this.height = {
                height: document.documentElement.clientHeight + 'px',
                overflow: 'hidden'
            }
        }
    }
</script>

<style scoped>
    div{
        position: absolute;
        top:0;
        left:0;
        width: 100%;
        font-size:88px;
        background: #182c41;
        color:#FFF;
        display: flex;
        justify-content: center;
        align-items: center;
    } 
</style>