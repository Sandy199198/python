<template>
    <div id="container">
        <transition name="header" mode="out-in">
            <!--<HeaderHomeComponent class="header-z-index" v-if="isHome"></HeaderHomeComponent>-->
            <HeaderMainComponent class="header-z-index" v-if="isMain"></HeaderMainComponent>
        </transition>
        <div class="menu" v-if="isMain"  @mouseover="showMenu()" @mouseleave="hideMenu()">
            <div class="arrow" v-if="!menuShow">
                <img src="../../images/menu_arrow.png">
            </div>
            <transition name="slide-fade">
                <ul class="menu" v-if="menuShow">
                    <li><a href="#" :class="current(URL.HOME)" @click.prevent="go(URL.HOME)" title="首页" :style="menuStyle"><img src="../../images/menu_home.png" alt="首页" :style="imgStyle"></a></li>
                    <li><a href="#" :class="current(URL.GIS)" @click.prevent="go(URL.GIS,{cameraId:undefined})" title="地图" :style="menuStyle"><img src="../../images/menu_gis.png" alt="地图" :style="imgStyle"></a></li>
                    <li>
                        <a href="#" :class="current(URL.GATE_REAL_TIME)" @click.prevent="go(URL.GATE_REAL_TIME.REAL_TIME)" @mouseover="showSubMenu('realtime')" @mouseleave="hideSubMenu()" title="人脸实时" :style="menuStyle"><img src="../../images/menu_realtime.png" alt="人脸实时" :style="imgStyle"></a>
                        <ul class="submenu" :class="{'is-open': menu.realtimeSubM}" @mouseover="showSubMenu('realtime')" @mouseleave="hideSubMenu()" :style="subMenuStyle">
                            <li><a href="#" :class="current(URL.GATE_REAL_TIME.REAL_TIME)" @click.prevent="go(URL.GATE_REAL_TIME.REAL_TIME)">实时监控</a></li>
                            <li><a href="#" :class="current(URL.GATE_REAL_TIME.CAPTURE_HISTORY)" @click.prevent="go(URL.GATE_REAL_TIME.CAPTURE_HISTORY)">抓拍历史</a></li>
                            <li><a href="#" :class="current(URL.GATE_REAL_TIME.ALARM_HISTORY)" @click.prevent="go(URL.GATE_REAL_TIME.ALARM_HISTORY)">告警历史</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" :class="current(URL.GATE)" @click.prevent="go(URL.GATE.GATE_STATISTICS)" @mouseover="showSubMenu('gate')" @mouseleave="hideSubMenu()" title="实时汇总" :style="menuStyle"><img src="../../images/menu_statistics.png" alt="实时汇总" :style="imgStyle"></a>
                        <ul class="submenu" :class="{'is-open': menu.gateSubM}" @mouseover="showSubMenu('gate')" @mouseleave="hideSubMenu()" :style="subMenuStyle">
                            <li><a href="#" :class="current(URL.GATE.GATE_STATISTICS)" @click.prevent="go(URL.GATE.GATE_STATISTICS)">市局汇总</a></li>
                            <!--<li><a href="#" :class="current(URL.GATE.BRANCH_STATISTICS)" @click.prevent="go(URL.GATE.BRANCH_STATISTICS)">比对信息</a></li>-->
                            <li><a href="#" :class="current(URL.GATE.BRANCH_STAT)" @click.prevent="go(URL.GATE.BRANCH_STAT)">分局汇总</a></li>
                            <li><a href="#" :class="current(URL.GATE.CAMERA_STAT)" @click.prevent="go(URL.GATE.CAMERA_STAT)">摄像头汇总</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" :class="current(URL.MANAGE)" @click.prevent="go(URL.MANAGE.GROUP_SETTING)" @mouseover="showSubMenu('manage')" @mouseleave="hideSubMenu()" title="底库管理" :style="menuStyle"><img src="../../images/menu_group.png" alt="底库管理" :style="imgStyle"></a>
                        <ul class="submenu" :class="{'is-open': menu.manageSubM}" @mouseover="showSubMenu('manage')" @mouseleave="hideSubMenu()" :style="subMenuStyle">
                            <li><a href="#" :class="current(URL.MANAGE.GROUP_SETTING)" @click.prevent="go(URL.MANAGE.GROUP_SETTING)">底库配置</a></li>
                            <li><a href="#" :class="current(URL.MANAGE.MEMBER_INFO)" @click.prevent="go(URL.MANAGE.MEMBER_INFO)">底库人员配置</a></li>
                            <li><a href="#" :class="current(URL.MANAGE.PHOTO_MANAGE)" @click.prevent="go(URL.MANAGE.PHOTO_MANAGE)">照片管理</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" :class="current(URL.SEARCH)" @click.prevent="go(URL.SEARCH.IMG_SEARCH)" @mouseover="showSubMenu('search')" @mouseleave="hideSubMenu()" title="图片检索" :style="menuStyle"><img src="../../images/menu_staticSearch.png" alt="图片检索" :style="imgStyle"></a>
                        <ul class="submenu" :class="{'is-open': menu.searchSubM}" @mouseover="showSubMenu('search')" @mouseleave="hideSubMenu()" :style="subMenuStyle">
                            <li v-if="!getServices.PKStatus"><a href="#" :class="current(URL.SEARCH.IMG_SEARCH)" @click.prevent="go(URL.SEARCH.IMG_SEARCH)">图像检索</a></li>
                            <!--<li><a href="#" :class="current(URL.SEARCH.CAPTURE_SEARCH)" @click.prevent="go(URL.SEARCH.CAPTURE_SEARCH)">抓拍检索</a></li>-->
                            <li><a href="#" :class="current(URL.SEARCH.VIDEO_SEARCH)" @click.prevent="go(URL.SEARCH.VIDEO_SEARCH)">视频检索</a></li>
                        </ul>
                    </li>
                    <!--<li>
                        <a href="#" :class="current(URL.ANALYSIS)" @click.prevent="go('')" @mouseover="showSubMenu(subMTitles.analysis)" @mouseleave="hideSubMenu()">人脸研判</a>
                        <ul class="submenu" :class="{'is-open': menu.analysisSubM}" @mouseover="showSubMenu(subMTitles.analysis)" @mouseleave="hideSubMenu()">
                            <li><a href="#" :class="current(URL.ANALYSIS.COLLISION_POINTS)" @click.prevent="go(URL.ANALYSIS.COLLISION_POINTS)">多地点分析</a></li>
                            <li><a href="#" :class="current(URL.ANALYSIS.COLLISION_TIME)" @click.prevent="go(URL.ANALYSIS.COLLISION_TIME)">多时段分析</a></li>
                            <li><a href="#" :class="current(URL.ANALYSIS.COLLISION)" @click.prevent="go(URL.ANALYSIS.COLLISION)">碰撞检测</a></li>
                            <li><a href="#" :class="current(URL.ANALYSIS.PEER)" @click.prevent="go(URL.ANALYSIS.PEER)">同行分析</a></li>
                            <li><a href="#" :class="current(URL.ANALYSIS.FREQUENCY)" @click.prevent="go(URL.ANALYSIS.FREQUENCY)">频次检测</a></li>
                        </ul>
                    </li>-->
                    <!--<li>
                        <a href="javascript:;" :class="current(URL.ACCESS)" @mouseover="showSubMenu('access')" @mouseleave="hideSubMenu()">系统接入</a>
                        <ul class="submenu" :class="{'is-open': menu.accessSubM}" @mouseover="showSubMenu('access')" @mouseleave="hideSubMenu()">
                            <li><a href="#" :class="current(URL.ACCESS.SYSTEM_ACCESS)" @click.prevent="go(URL.ACCESS.SYSTEM_ACCESS)">系统汇总</a></li>
                            <li v-for="system in getAllSystems">
                                <a href="#" :class="current(URL.ACCESS.SYSTEM_DETAIL, ['application', system.name])" @click.prevent="go(URL.ACCESS.SYSTEM_DETAIL, {application: system.name})">{{system.name}}</a>
                            </li>
                        </ul>
                    </li>-->
                    <!--<li><a href="#" :class="current(URL.DETERMINATION)" @click.prevent="go(URL.DETERMINATION)">人像研判</a></li>-->
                    <li>
                        <a href="javascript:;" :class="current(URL.RESOURCE)" @click.prevent="go(URL.RESOURCE.RESOURCE_CITYWIDE_SERVER)" @mouseover="showSubMenu('resource')" @mouseleave="hideSubMenu()" title="服务器监控" :style="menuStyle"><img src="../../images/menu_resource.png" alt="服务器监控" :style="imgStyle"></a>
                        <ul class="submenu" :class="{'is-open': menu.resourceSubM}" @mouseover="showSubMenu('resource')" @mouseleave="hideSubMenu()" :style="subMenuStyle">
                            <!--<li><a href="#" :class="current(URL.RESOURCE.RESOURCE_SERVER)" @click.prevent="go(URL.RESOURCE.RESOURCE_SERVER)">服务器监控</a></li>
                            <li><a href="#" :class="current(URL.RESOURCE.RESOURCE_SERVICE)" @click.prevent="go(URL.RESOURCE.RESOURCE_SERVICE)">服务监控</a></li>-->
                            <li><a href="#" :class="current(URL.RESOURCE.RESOURCE_CITYWIDE_SERVER)" @click.prevent="go(URL.RESOURCE.RESOURCE_CITYWIDE_SERVER)">市局服务器监控</a></li>
                            <li><a href="#" :class="current(URL.RESOURCE.RESOURCE_BRANCH_SERVER)" @click.prevent="go(URL.RESOURCE.RESOURCE_BRANCH_SERVER)">分局服务器监控</a></li>
                            <li><a href="#" :class="current(URL.RESOURCE.RESOURCE_SERVER)" @click.prevent="go(URL.RESOURCE.RESOURCE_SERVER)">服务器监控</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" :class="current(URL.SYSTEM)" @click.prevent="go(URL.SYSTEM.SYSTEM_MANAGE)" @mouseover="showSubMenu('system')" @mouseleave="hideSubMenu()" title="系统管理" :style="menuStyle"><img src="../../images/menu_system.png" alt="系统管理" :style="imgStyle"></a>
                        <ul class="submenu" :class="{'is-open': menu.systemSubM}" @mouseover="showSubMenu('system')" @mouseleave="hideSubMenu()" :style="subMenuStyle">
                            <li><a href="#" :class="current(URL.SYSTEM.SYSTEM_MANAGE)" @click.prevent="go(URL.SYSTEM.SYSTEM_MANAGE)">系统监控</a></li>
                            <li><a href="#" :class="current(URL.SYSTEM.USER)" @click.prevent="go(URL.SYSTEM.USER)">用户管理</a></li>
                            <li><a href="#" :class="current(URL.SYSTEM.GROUP)" @click.prevent="go(URL.SYSTEM.GROUP)">用户组管理</a></li>
                            <li><a href="#" :class="current(URL.SYSTEM.LOG)" @click.prevent="go(URL.SYSTEM.LOG)">日志管理</a></li>
                            <!--<li><a href="#" :class="current(URL.SYSTEM.CORE)" @click.prevent="go(URL.SYSTEM.CORE)">识别CORE</a></li>-->
                            <!--<li><a href="#" :class="current(URL.SYSTEM.SYSTEM_SETTING)" @click.prevent="go(URL.SYSTEM.SYSTEM_SETTING)">系统设置</a></li>-->
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" :class="current(URL.CAPTURE_MASTER)" @click.prevent="go(URL.CAPTURE_MASTER.HOME)" @mouseover="showSubMenu('capture')" @mouseleave="hideSubMenu()" title="抓拍管理" :style="menuStyle"><img src="../../images/menu_captureMaster.png" alt="抓拍管理" :style="imgStyle"></a>
                        <!--<ul class="submenu" :class="{'is-open': menu.captureSubM}" @mouseover="showSubMenu('capture')" @mouseleave="hideSubMenu()" :style="subMenuStyle">
                            <li><a href="#" :class="current(URL.CAPTURE_MASTER.HOME)" @click.prevent="go(URL.CAPTURE_MASTER.HOME)">抓拍管理</a></li>
                            <li><a href="#" :class="current(URL.CAPTURE_MASTER.SERVER_CONFIG)" @click.prevent="go(URL.CAPTURE_MASTER.SERVER_CONFIG)">服务器配置</a></li>
                            <li><a href="#" :class="current(URL.CAPTURE_MASTER.CAMERA_SETTING)" @click.prevent="go(URL.CAPTURE_MASTER.CAMERA_SETTING)">相机配置</a></li>
                            <li><a href="#" :class="current(URL.CAPTURE_MASTER.CLIENT_GROUP)" @click.prevent="go(URL.CAPTURE_MASTER.CLIENT_GROUP)">抓拍客户端</a></li>
                            <li><a href="#" :class="current(URL.CAPTURE_MASTER.DEPLOYMENT)" @click.prevent="go(URL.CAPTURE_MASTER.DEPLOYMENT)">布控管理</a></li>
                        </ul>-->
                    </li>
                </ul>
            </transition>
        </div>
        <slot></slot>
        <div class="loading">
            <div class="spinner">
                <div class="rect1"></div>
                <div class="rect2"></div>
                <div class="rect3"></div>
                <div class="rect4"></div>
                <div class="rect5"></div>
            </div>
        </div>
        <AlertComponent :show="showAlarm" :confirm="closeDialog" :cancel="closeDialog">
            <div slot="title">提示</div>
            <div slot="content">{{getGlobalAlarmMessage}}</div>
        </AlertComponent>
        <div class="prompt">
            <transition-group tag="ul" name="prompt">
                <PromptComponent v-for="(prompt,index) in this.getInnerPrompt" :data="prompt.data" :key="prompt.key" :index="index" :type="prompt.type" :text="prompt.text" :go="goPrompt" :close="delPrompt"></PromptComponent>
            </transition-group>
        </div>
    </div>
</template>

<script>
import URL from 'common/url'
import HeaderHomeComponent from 'pages/main/header-home.vue'
import HeaderMainComponent from 'pages/main/header-main.vue'
import AlertComponent from '@nanyun/alert'
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import {
    ALARM,
    USER_OPERATION,
    MARKED_ALARM,
    DISABLE_ERROR,
    DISCONNECT_WEB_SOCKET,
    DEL_PROMPT,
    CLEAR_PROMPT,
    GET_GLOBAL_ALARM_MESSAGE,
    GET_PROMPT,
    WEB_SOCKET,
    GET_SERVICES,
    GET_GLOBAL_ALARM_DISPLAY } from 'store/modules/common'
import { GET_USER_INFO } from 'store/modules/auth'


let PromptComponent = {
    template: `
        <li>
            <div>
                <a href="#" :class="linkClassName" @click.prevent="go(type,data)">
                    <i class="fa" :class="iconClassName"></i>
                    <span>{{text}}</span>
                </a>
            </div>
            <a href="#" @click.prevent="innerClose" class="close"><i class="fa fa-times"></i></a>
        </li>
    `,
    props: {
        type: {
            type: String,
            required: true
        },
        data: {
            type: Object,
            required: true
        },
        text: {
            type: String,
            required: true,
        },
        close: {
            type: Function,
            default() {}
        },
        go: {
            type: Function,
            default() {}
        },
        index: {
            type: Number,
            required: true
        }
    },
    data() {
        return {
            linkClassName: {
                'operation': this.type == USER_OPERATION,
                'alarm': this.type == ALARM,
                'marked-alarm': this.type == MARKED_ALARM
            },
            iconClassName: {
                'fa-thumb-tack': this.type == USER_OPERATION,
                'fa-question-circle': this.type == ALARM,
                'fa-warning': this.type == MARKED_ALARM
            }
        }
    },
    methods: {
        innerClose() {
            this.close(this.index)
        }
    }
}


export default {
    data() {
        return {
            connected: false,
            showAlarm: {
                value: false
            },
            showPrompt: false,
            menu: {
                resourceSubM: false,
                systemSubM: false,
                gateSubM: false,
                analysisSubM: false,
                accessSubM: false,
                realtimeSubM: false,
                searchSubM: false,
                manageSubM: false,
                captureSubM: false,
            },
            URL,
            subMTitles: {
                resource: 'resource',
                gate: 'gate',
                system: 'system',
                analysis: 'analysis',
                realtime: 'realtime',
                manage: 'manage',
                search: 'search',
                capture: 'capture'
            },
            userInfoStyle: {
                marginTop: '-35px'
            },
            menuShow: false,
            imgStyle: {
                height: '30px',
                width: '30px'
            },
            menuStyle: {
                lineHeight: '40px',
                padding: '5px 0',
                width: '40px',
                height: '40px',
                borderRadius: '20px'
            },
            subMenuStyle: {
                left: '50px'
            }
        }
    },
    components: {
        HeaderHomeComponent,
        HeaderMainComponent,
        PromptComponent,
        AlertComponent
    },
    mounted() {
        this.setMenuSize()
    },
    computed: {
        isHome() {
            return this.$route.name == URL.HOME
        },
        isMain() {
            return this.$route.path.indexOf('main') != -1 && this.$route.name != URL.NOT_FOUND || this.$route.name == URL.HOME
        },
        getInnerPrompt() {
            if (this.$route.name == URL.GIS) {
                return []
            } else {
                return this.getPrompt
            }
        },
        ...mapGetters({
            getGlobalAlarmMessage: GET_GLOBAL_ALARM_MESSAGE,
            getGlobalAlarmDisplay: GET_GLOBAL_ALARM_DISPLAY,
            getUserInfo: GET_USER_INFO,
            getPrompt: GET_PROMPT,
            getServices: GET_SERVICES
        })
    },
    watch: {
        $route() {
            if ('user_group' in this.getUserInfo) {
                if (this.$route.name == URL.GIS) {
                    this.clearPrompt()
                }
                this.webSocket(this.getUserInfo.user_group.cid)
            } else {
                this.clearPrompt()
                this.disconnectWebSocket()
            }
        },
        getGlobalAlarmDisplay(val) {
            this.showAlarm.value = val
        }
    },
    methods: {
        setMenuSize() {
            let winHeight = document.documentElement.clientHeight

            if (winHeight > 1000) {
                this.imgStyle = {
                    height: '50px',
                    width: '50px',
                }
                this.menuStyle = {
                    lineHeight: '50px',
                    // padding: '2px 0',
                    width: '50px',
                    height: '50px',
                    borderRadius: '25px'
                },
                this.subMenuStyle = {
                    left: '60px'
                }
            } else if (winHeight > 750 && winHeight <= 1000) {
                this.imgStyle = {
                    height: '40px',
                    width: '40px'
                }
                this.menuStyle = {
                    lineHeight: '50px',
                    padding: '6px 0',
                    width: '50px',
                    height: '50px',
                    borderRadius: '25px'
                },
                this.subMenuStyle = {
                    left: '60px'
                }
            }
        },
        closeDialog() {
            this.$store.commit({
                type: DISABLE_ERROR
            }, {
                slient: true
            })
        },
        goPrompt(type, data) {
            switch (type) {
                case ALARM:
                    this.$router.push({
                        name: URL.GIS,
                        params: {
                            cameraId: data.camera_id
                        }
                    })
                    break
                case USER_OPERATION:
                    this.clearPrompt()
                    this.$router.push({
                        name: URL.SYSTEM.LOG,
                        query: {
                            name: data.real_name
                        }
                    })
                    break
                case MARKED_ALARM:
                    window.open(`${this.getServices.Skylab}/monitor/alarm-history#l6_marked=1`)
                    break
            }
        },
        ...mapMutations({
            delPrompt: DEL_PROMPT,
            clearPrompt: CLEAR_PROMPT,
            disconnectWebSocket: DISCONNECT_WEB_SOCKET
        }),
        ...mapActions({
            webSocket: WEB_SOCKET
        }),
        current(name, params) {
            let className = {
                current: false
            }

            if (typeof name === 'string') {
                className.current = this.$route.name == name
            } else {
                for (let i in name) {
                    if (this.$route.name == name[i]) {
                        className.current = true
                    }
                }
            }

            if (className.current && params) {
                if (params[0] in this.$route.params) {
                    className.current = this.$route.params[params[0]] == params[1]
                } else {
                    className.current = false
                }
            }

            return className
        },
        go(name, params) {
            this.hideSubMenu()
            this.$router.push({
                name,
                params
            })
        },
        goHome() {
            this.$router.push({
                path: '/home',
                name: URL.HOME
            })
        },
        showSubMenu(name) {
            switch (name) {
                case this.subMTitles.resource:
                    this.menu.resourceSubM = true
                    break
                case this.subMTitles.system:
                    this.menu.systemSubM = true
                    break
                case this.subMTitles.gate:
                    this.menu.gateSubM = true
                    break
                case this.subMTitles.analysis:
                    this.menu.analysisSubM = true
                    break
                case 'access':
                    this.menu.accessSubM = true
                    break
                case 'realtime':
                    this.menu.realtimeSubM = true
                    break
                case this.subMTitles.search:
                    this.menu.searchSubM = true
                    break
                case this.subMTitles.manage:
                    this.menu.manageSubM = true
                    break
                case this.subMTitles.capture:
                    this.menu.captureSubM = true
                    break
                default:
                    break
            }
        },
        hideSubMenu() {
            for (let i in this.menu) {
                this.menu[i] = false
            }
        },
        showMenu() {
            if (!this.menuShow) {
                this.menuShow = true
            }
        },
        hideMenu() {
            if (this.menuShow) {
                this.menuShow = false
            }
        }
    }
}

</script>

<style scoped>
    .header-z-index{
        z-index:1000;
    }
    .loading{
        position:absolute;
        top:50%;
        left:50%;
        z-index:-1;
        color:#FFF;
        font-size:50px;
        margin-left:-25pxpx;
        margin-top:-120px;
    }

    .spinner {
        margin: 100px auto;
        width: 50px;
        height: 40px;
        text-align: center;
        font-size: 10px;
    }

    .spinner > div {
        background-color: #FFF;
        height: 100%;
        width: 6px;
        display: inline-block;

        -webkit-animation: sk-stretchdelay 1.2s infinite ease-in-out;
        animation: sk-stretchdelay 1.2s infinite ease-in-out;
    }

    .spinner .rect2 {
        -webkit-animation-delay: -1.1s;
        animation-delay: -1.1s;
    }

    .spinner .rect3 {
        -webkit-animation-delay: -1.0s;
        animation-delay: -1.0s;
    }

    .spinner .rect4 {
        -webkit-animation-delay: -0.9s;
        animation-delay: -0.9s;
    }

    .spinner .rect5 {
        -webkit-animation-delay: -0.8s;
        animation-delay: -0.8s;
    }

    @-webkit-keyframes sk-stretchdelay {
        0%, 40%, 100% { -webkit-transform: scaleY(0.4) }  
        20% { -webkit-transform: scaleY(1.0) }
    }

    @keyframes sk-stretchdelay {
        0%, 40%, 100% { 
            transform: scaleY(0.4);
            -webkit-transform: scaleY(0.4);
        }  20% { 
            transform: scaleY(1.0);
            -webkit-transform: scaleY(1.0);
        }
    }
    .arrow{
        position: fixed;
        top: 40%;
        z-index: 1000;
        curosr: pointer;
        width: 100px;
        height: auto;
        -webkit-animation: arrow 1s infinite;
        >img{
            width:150px;
            height: 150px;
        }
    }
    @-webkit-keyframes arrow {
        0% {
            opacity:1;
            -webkit-transform:translate(-10px, 0)
        }
        20% {
            opacity:0.8;
            -webkit-transform:translate(-5px, 0)
        }
        40% {
            opacity:0.6;
            -webkit-transform:translate(0px, 0)
        }
        60% {
            opacity:0.4;
            -webkit-transform:translate(6px, 0)
        }
        80% {
            opacity:0.2;
            -webkit-transform:translate(8px, 0)
        }
        100% {
            opacity:0;
            -webkit-transform:translate(10px, 0)
        }
    }
    ul.menu{
        position: fixed;
        top: 120px;
        width: 50px;
        height: auto;
        left: 10px;
        z-index: 1000;
        &>li>a{
            transition: all .4s ease-out;
            /*display: inline-block;*/
            /*line-height: 80px;
            padding: 10px 0;
            width: 80px;
            height: 80px;*/
            box-sizing: border-box;
            font-size: 18px;
            color:#fff;
            margin-bottom: 10px;
            /*opacity: 0.7;*/
            text-align: center;
            border-right:3px solid transparent;
            background: #00344a;
            /*border-radius: 40px;*/
            &:hover{
                transform: scale(1.4); 
                color:#FFF;
            }
            /*>img{
                height: 60px;
                width: 60px;
            }*/
        }
        &>li>a.active,&>li>a.current{
            color: #FFF;
            background: #008BC8;
            /*border-color: #81C3F3  */
        }
        &>li{
           flex: 1; 
           position: relative;
           display: flex;
        }
    }
    ul.submenu{
        position: absolute;
        /*top: 43px;*/
        /*left: 100px;*/
        width: 100px;
        transform-origin: center top;
        transform: scaleY(0);
        transition: all .075s ease-out;
        border:1px solid #666;
        border-top: 0 none;
        border-radius: 5px;
        background:-moz-linear-gradient(top, #024965, rgba(0, 34, 51, 0.5));
        background: -webkit-gradient(linear, 0 0, 0 bottom, from(#024965), to(rgba(0, 34, 51, 0.5)));
        &>li{
            width: 100%;
        }
        a{
            padding: 10px 0;
            width: 100%;
            height: 100%;
            display: inline-block;
            box-sizing: border-box;
            font-size: 14px;
            color:#aaa;
            /*background-color: #102435;*/
            text-align: center;
            &:hover{
                background-color: #1e3044;
                color: #fff;
            }
            &.current{
                color: #ffffff;
                background-color: #1e3044;
            }
        }
    }
    ul.submenu.is-open{
        display: block;
        transform: scaleY(1);
        transition: all .075s ease-out;
    }
    .slide-fade-enter-active {
        transition: all .3s ease;
     }
     .slide-fade-leave-active {
         transition: all .5s cubic-bezier(1.0, 0.5, 0.8, 1.0);
     }
     .slide-fade-enter, .slide-fade-leave-active {
         transform: translateX(-10px);
         opacity: 0;
     }
</style>