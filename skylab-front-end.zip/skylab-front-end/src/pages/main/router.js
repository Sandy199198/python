import VueRouter from 'vue-router'

import URL from 'common/url'

import LoginComponent from 'pages/main/login.vue'
// import SkeletonComponent from 'pages/main/skeleton.vue'
import ContainerComponent from 'pages/main/container.vue'
import NotFoundComponent from 'pages/main/404.vue'
import HomeComponent from 'pages/home/home.vue'
import GateRealTimeComponent from 'pages/gate-real-time/gate-real-time.vue'
import GisComponent from 'pages/gis/gis.vue'
import GateStatisticsComponent from 'pages/gate-statistics/trunk-home.vue'
import BranchStatComponent from 'pages/gate-statistics/branch-home.vue'
import CameraStatComponent from 'pages/gate-statistics/camera-home.vue'
import SystemAccessComponent from 'pages/system-access/system-access.vue'
import SystemDetailComponent from 'pages/system-access/system-detail.vue'
import DeterminationComponent from 'pages/determination/determination.vue'
import ResourceServiceComponent from 'pages/resource/resource-service.vue'
import ResourceServerComponent from 'pages/resource/resource-server.vue'
import ResourceCitywideServerComponent from 'pages/resource/resource-citywide-server.vue'
import ResourceBranchServerComponent from 'pages/resource/resource-branch-server.vue'
import SystemManageComponent from 'pages/system-manage/system-manage.vue'
import UserManageComponent from 'pages/users/user-manage.vue'
import UserGroupManageComponent from 'pages/users/userGroup-manage.vue'
import LogManageComponent from 'pages/system-manage/system-logs-manage.vue'
import CollisionPointComponent from 'pages/analysis/collision-point.vue'
import CollisionTimeComponent from 'pages/analysis/collision-time.vue'
import CollisionComponent from 'pages/analysis/collision.vue'
import PeerComponent from 'pages/analysis/peer.vue'
import FrequencyComponent from 'pages/analysis/frequency.vue'
import CollisionInfoComponent from 'pages/analysis/collision-info.vue'
import CollisionDetailComponent from 'pages/analysis/collision-detail.vue'
import RealTime from 'pages/gate-real-time/real-time.vue'
import CaptureHistory from 'pages/gate-real-time/capture-history.vue'
import AlarmHistory from 'pages/gate-real-time/alarm-history.vue'
import GroupSetting from 'pages/gate-real-time/group-setting.vue'
import MemberInfo from 'pages/gate-real-time/member-info.vue'
import ImgSearch from 'pages/gate-real-time/img-search.vue'
import CaptureSearch from 'pages/gate-real-time/capture-search.vue'
import VideoSearch from 'pages/gate-real-time/video-search.vue'
import AlarmVideoSearch from 'pages/gate-real-time/alarm-video-search.vue'
import CaptureVideoSearch from 'pages/gate-real-time/capture-video-search.vue'
import Core from 'pages/gate-real-time/core.vue'
import SystemSetting from 'pages/gate-real-time/system-setting.vue'
import DeploySetting from 'pages/cheat/deploy-setting.vue'
import PhotoManage from 'pages/gate-real-time/photo-manage.vue'
import ServerConfig from 'pages/capture-master/server-config.vue'
import CameraSetting from 'pages/capture-master/camera-setting.vue'
import ClientGroup from 'pages/capture-master/client-group.vue'
import Deployment from 'pages/capture-master/deployment.vue'
import ImageFilter from 'pages/gate-real-time/image-filter.vue'
import captureMasterHome from 'pages/capture-master/home.vue'
import ImageCrop from 'pages/gate-real-time/image-crop.vue'
import ImageCropResult from 'pages/gate-real-time/image-crop-manage.vue'

const routes = [{
    path: '/',
    name: URL.ROOT,
    redirect: '/home'
}, {
    path: '/login',
    name: URL.LOGIN,
    component: LoginComponent
}, {
    path: '/home',
    name: URL.HOME,
    component: HomeComponent
}, {
    path: '/main',
    component: ContainerComponent,
    redirect: '/main/gis',
    children: [{
        path: 'gis/:cameraId?',
        name: URL.GIS,
        component: GisComponent
    }, {
        path: 'gate-statistics',
        name: URL.GATE.GATE_STATISTICS,
        component: GateStatisticsComponent
    }, {
        path: 'banch-stat/:branch?',
        name: URL.GATE.BRANCH_STAT,
        component: BranchStatComponent
    }, {
        path: 'camera-stat/:camera?',
        name: URL.GATE.CAMERA_STAT,
        component: CameraStatComponent
    }, {
        path: 'system-access',
        name: URL.ACCESS.SYSTEM_ACCESS,
        component: SystemAccessComponent
    }, {
        path: 'system-access/system-detail/:application',
        name: URL.ACCESS.SYSTEM_DETAIL,
        component: SystemDetailComponent
    }, {
        path: 'determination',
        name: URL.DETERMINATION,
        component: DeterminationComponent
    }, {
        path: 'resource-service',
        name: URL.RESOURCE.RESOURCE_SERVICE,
        component: ResourceServiceComponent
    }, {
        path: 'resource-server/:machine?',
        name: URL.RESOURCE.RESOURCE_SERVER,
        component: ResourceServerComponent
    }, {
        path: 'resource-citywide-server',
        name: URL.RESOURCE.RESOURCE_CITYWIDE_SERVER,
        component: ResourceCitywideServerComponent
    }, {
        path: 'resource-branch-server/:branch?',
        name: URL.RESOURCE.RESOURCE_BRANCH_SERVER,
        component: ResourceBranchServerComponent
    }, {
        path: 'system-manage',
        name: URL.SYSTEM.SYSTEM_MANAGE,
        component: SystemManageComponent
    }, {
        path: 'user',
        name: URL.SYSTEM.USER,
        component: UserManageComponent
    }, {
        path: 'group',
        name: URL.SYSTEM.GROUP,
        component: UserGroupManageComponent
    }, {
        path: 'log',
        name: URL.SYSTEM.LOG,
        component: LogManageComponent
    }, {
        path: 'collision-point',
        name: URL.ANALYSIS.COLLISION_POINTS,
        component: CollisionPointComponent
    }, {
        path: 'collision-time',
        name: URL.ANALYSIS.COLLISION_TIME,
        component: CollisionTimeComponent
    }, {
        path: 'collision',
        name: URL.ANALYSIS.COLLISION,
        component: CollisionComponent
    }, {
        path: 'peer',
        name: URL.ANALYSIS.PEER,
        component: PeerComponent
    }, {
        path: 'frequency',
        name: URL.ANALYSIS.FREQUENCY,
        component: FrequencyComponent
    }, {
        path: 'collision-info/:id',
        name: URL.ANALYSIS.COLLISION_INFO,
        component: CollisionInfoComponent
    }, {
        path: 'collision-detail/:id/:group/:photo',
        name: URL.ANALYSIS.COLLISION_DETAIL,
        component: CollisionDetailComponent
    }, {
        path: 'core',
        name: URL.SYSTEM.CORE,
        component: Core,
    }, {
        path: 'system-setting',
        name: URL.SYSTEM.SYSTEM_SETTING,
        component: SystemSetting
    }, {
        path: 'group-setting',
        name: URL.MANAGE.GROUP_SETTING,
        component: GroupSetting
    }, {
        path: 'member-info',
        name: URL.MANAGE.MEMBER_INFO,
        component: MemberInfo
    }, {
        path: 'photo-manage',
        name: URL.MANAGE.PHOTO_MANAGE,
        component: PhotoManage
    }, {
        path: 'img-search',
        name: URL.SEARCH.IMG_SEARCH,
        component: ImgSearch
    }, {
        path: 'capture-search',
        name: URL.SEARCH.CAPTURE_SEARCH,
        component: CaptureSearch
    }, {
        path: 'video-search',
        name: URL.SEARCH.VIDEO_SEARCH,
        component: VideoSearch
    }, {
        path: 'real-time',
        name: URL.GATE_REAL_TIME.REAL_TIME,
        component: RealTime,
    }, {
        path: 'capture-history',
        name: URL.GATE_REAL_TIME.CAPTURE_HISTORY,
        component: CaptureHistory
    }, {
        path: 'alarm-history',
        name: URL.GATE_REAL_TIME.ALARM_HISTORY,
        component: AlarmHistory
    }, {
        path: 'alarm-video-search/:id',
        name: URL.SEARCH.ALARM_VIDEO_SEARCH,
        component: AlarmVideoSearch
    }, {
        path: 'capture-video-search/:id',
        name: URL.SEARCH.CAPTURE_VIDEO_SEARCH,
        component: CaptureVideoSearch
    }, {
        path: 'deploy-setting',
        name: URL.CHEAT.DEPLOY_SETTING,
        component: DeploySetting
    }, {
        path: 'server-config',
        name: URL.CAPTURE_MASTER.SERVER_CONFIG,
        component: ServerConfig,
    }, {
        path: 'camera-setting',
        name: URL.CAPTURE_MASTER.CAMERA_SETTING,
        component: CameraSetting,
    }, {
        path: 'client-group',
        name: URL.CAPTURE_MASTER.CLIENT_GROUP,
        component: ClientGroup
    }, {
        path: 'deployment',
        name: URL.CAPTURE_MASTER.DEPLOYMENT,
        component: Deployment
    }, {
        path: 'image-filter',
        name: URL.MANAGE.IMAGE_FILTER,
        component: ImageFilter
    }, {
        path: 'capture-master-home',
        name: URL.CAPTURE_MASTER.HOME,
        component: captureMasterHome
    }, {
        path: 'image-crop',
        name: URL.MANAGE.IMAGE_CROP,
        component: ImageCrop
    }, {
        path: 'image-crop-result',
        name: URL.MANAGE.IMAGE_CROP_RESULT,
        component: ImageCropResult
    }]
}, {
    path: '*',
    name: URL.NOT_FOUND,
    component: NotFoundComponent
}]

export default new VueRouter({
    mode: 'history',
    routes
})
