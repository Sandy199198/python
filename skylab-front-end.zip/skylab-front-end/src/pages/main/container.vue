<template>
    <div class="container" :style="contentHeightStyle">
        <transition name="page" mode="out-in">
            <router-view></router-view>
        </transition>
    </div>
</template>

<script>
    import { computeSize } from 'common/utils'
    import { SET_HEIGHT } from 'store/modules/common'
    import {
        mapMutations,
        mapGetters } from 'vuex'

    export default {
        mixins: [computeSize],

        watch: {
            $route() {
                this.$el.scrollTop = 0
            }
        },

        beforeMount() {
            this.setHeight(parseInt(this.contentHeightStyle.height))
        },

        methods: {
            ...mapMutations({
                setHeight: SET_HEIGHT
            })
        }
    }
</script>

<style scoped> 
.container{
    background: url('../../images/background.png') center center;
 	background-size:100% 100%;
}
</style>