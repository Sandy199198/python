<template>
    <div class="header">
        <div class="logo">
            <a href="#" @click.prevent="goHome">
                <img src="../../images/logo.png" height="50px;"/>
            </a>
        </div>
        <h2>
            智能人像大数据云平台
        </h2>
        <UserInfoComponent></UserInfoComponent>
    </div>
</template>

<script>
import URL from 'common/url'
import UserInfoComponent from 'common/components/user-info.vue'
import {
    mapGetters,
    mapActions } from 'vuex'
import {
    GET_ALL_SYSTEMS,
    FETCH_ALL_SYSTEMS } from 'store/modules/system'
import {GET_SERVICES, FETCH_SERVICES} from 'store/modules/common'

export default {
    methods: {
        goHome() {
            this.$router.push({
                path: '/home',
                name: URL.HOME
            })
        }
    },
    components: {
        UserInfoComponent
    }
}
</script>

<style scoped>
.header{
    box-shadow: 0 3px 10px rgb(14,27,41);
    position: relative;
    background:-moz-linear-gradient(top, #020c16, rgba(0, 34, 51, 0.5));
    background: -webkit-gradient(linear, 0 0, 0 bottom, from(#020c16), to(rgba(0, 34, 51, 0.5)));
    h2{
        margin: 0;
        padding: 20px 0;
        font-size: 32px;
        color:#FFF;
        text-align: center;
    }
    .logo{
        position: absolute;
        top: 50%;
        left: 0px;
        margin-top: -25px;
    }
}
</style>