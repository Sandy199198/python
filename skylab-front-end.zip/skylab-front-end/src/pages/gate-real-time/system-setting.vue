<template>
    <div class="system-setting">
        <div class="table_content">
            <div class="result">
                <div class="title">
                    抓拍CORE设置
                    <span role="groupErr" class="error"></span>
                </div>
                <div class="condition">
                    <form name="captureOpt">
                        <div class="condition-con">
                            <div> 
                                <span class="condition-item-title col3">CORE服务器HOST</span>
                                <input type="text" class="col9" name="CAPTURE_CORE_SERVER_HOST" v-model="getSetting.CAPTURE_CORE_SERVER_HOST">
                            </div>
                            <div>
                                <span class="condition-item-title col3">CORE服务器PORT</span>
                                <input type="text" class="col9" name="CAPTURE_CORE_SERVER_PORT" v-model="getSetting.CAPTURE_CORE_SERVER_PORT">
                            </div>
                            <div>
                                <a href="#" @click.prevent="captureSubmit" class="button-style btn">确定</a>
                                <span class="success" v-show="isCapture">保存成功</span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="result">
                <div class="title">
                    研判CORE设置
                    <span role="groupErr" class="error"></span>
                </div>
                <div class="condition">
                    <form name="analysisOpt">
                        <div class="condition-con">
                            <div> 
                                <span class="condition-item-title col3">CORE服务器HOST</span>
                                <input type="text" class="col9" name="JUDGED_CORE_SERVER_HOST" v-model="getSetting.JUDGED_CORE_SERVER_HOSTPORT">
                            </div>
                            <div>
                                <span class="condition-item-title col3">CORE服务器PORT</span>
                                <input type="text" class="col9" name="JUDGED_CORE_SERVER_PORT" v-model="getSetting.JUDGED_CORE_SERVER_PORT">
                            </div>
                            <div>
                                <a href="#" @click.prevent="analysisSubmit" class="button-style btn">确定</a>
                                <span class="success" v-show="isAnalysis">保存成功</span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="result">
                <div class="title">
                    实时通知设置
                    <span role="groupErr" class="error"></span>
                </div>
                <div class="condition">
                    <form name="noticeOpt">
                        <div class="condition-con">
                            <div> 
                                <span class="condition-item-title col3">实时通知转发的HTTP接口</span>
                                <input type="text" class="col9" name="NOTIFY_URL" v-model="getSetting.NOTIFY_URL">
                            </div>
                            <div>
                                <span class="condition-item-title col3">实时通知转发的WS接口</span>
                                <input type="text" class="col9" name="NOTIFY_WS_BASE_URL" v-model="getSetting.NOTIFY_WS_BASE_URL">
                            </div>
                            <div>
                                <a href="#" @click.prevent="noticeSubmit" class="button-style btn">确定</a>
                                <span class="success" v-show="isNotice">保存成功</span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="result">
                <div class="title">
                    其它设置
                </div>
                <div class="condition">
                    <form name="captchaOpt">
                        <div class="condition-con">
                            <div> 
                                <span class="condition-item-title col3">是否开启登录验证码</span>
                                <select v-model="getSetting.CAPTCHA" name="CAPTCHA" class="select">
                                    <option :value="item.value" v-for="item in setting">{{item.text}}</option>
                                </select>
                            </div>
                            <div>
                                <a href="#" @click.prevent="captchaSubmit" class="button-style btn">确定</a>
                                <span class="success" v-show="isCaptcha">保存成功</span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import { SETTING } from 'common/config'
import {GET_SETTING, SET_SETTING, FETCH_SETTING} from 'store/modules/core'

export default {
    data() {
        return {
            setting: SETTING,
            isCaptcha: false,
            isCapture: false,
            isAnalysis: false,
            isNotice: false
        }
    },
    created() {
        this.fetchData()
    },
    computed: {
        ...mapGetters({
            getSetting: GET_SETTING,
        }),
    },
    methods: {
        fetchData() {
            this.fetchSetting()
        },
        ...mapActions({
            setSetting: SET_SETTING,
            fetchSetting: FETCH_SETTING
        }),
        noticeSubmit() {
            let options = document.querySelector('[name=noticeOpt]')

            this.setSetting(options).then(() => {
                this.isNotice = true
            })
            setTimeout(() => {
                this.isNotice = false
            }, 3000)
        },
        analysisSubmit() {
            let options = document.querySelector('[name=analysisOpt]')

            this.setSetting(options).then(() => {
                this.isAnalysis = true
            })
            setTimeout(() => {
                this.isAnalysis = false
            }, 3000)
        },
        captureSubmit() {
            let options = document.querySelector('[name=captureOpt]')

            this.setSetting(options).then(() => {
                this.isCapture = true
            })
            setTimeout(() => {
                this.isCapture = false
            }, 3000)
        },
        captchaSubmit() {
            let options = document.querySelector('[name=captchaOpt]')

            this.setSetting(options).then(() => {
                this.isCaptcha = true
            })
            setTimeout(() => {
                this.isCaptcha = false
            }, 3000)
        },
    }
}
</script>

<style scoped>
.system-setting{
    height: 100%;
    padding: 50px 80px;
    box-sizing: border-box;
    min-height: 100%;
    width: 100%;
    /*margin: 20px 55px 70px 25px;*/
    .condition{
        margin-top: 16px;
        margin-bottom: 15px;
        input{
            height: 16px;
        }
        .btn{
            text-decoration: none;
            margin-left: 17px;
            &.search{
                vertical-align: top;
            }
        }
    }
    .form-group{
        height: 40px;
        position: relative;
        margin-left: -11px;
        margin-right: -11px;
    }
    .col3{
        width: 25%;
        float: left;
        min-height: 1px;
    }
    .col9{
        width:70%;
        float:left;
        min-height: 1px;
    }
    .control-label{
        padding-right: 15px;
        padding-top: 5px;
        text-align: right;
    }
    lable{
        line-height: 32px;
        display: inline-block;
        margin-bottom: 5px;
    }
    .form-select{
        width: 84%;
    }
    .minWidth{
        min-width:150px;
    }
}
.table_content{
    margin: 0 auto;
    width: 75%;
}
.result{
    font-size: 14px;
    line-height: 50px;
    color: #fff;
    margin-bottom: 20px;
    .title{
        padding-left: 10px;
        background-image: linear-gradient(-180deg, #003F54 4%, #00283A 99%);
        border: 1px solid #00CBF9;
        border-bottom: none;
        border-top-left-radius: 7px;
        border-top-right-radius: 7px;
        .error{
            color: crimson;
            margin-left: 5px;
            display: none;
        }
    }
    .condition{
        font-size: 12px;
        line-height: 24px;
        padding: 20px 10px 10px 10px;
        margin-top: 0;
        background-image: linear-gradient(-180deg, #000304 4%, #002636 99%);
        border: 1px solid #00CBF9;
        border-top: none;
        border-bottom-left-radius: 7px;
        border-bottom-right-radius: 7px;
        .condition-con{
            width: 70%;
            margin: 0 auto;
            &>div{
                height: 40px;
            }
        }
        .condition-item-title{
            display: inline-block;
            padding-right: 5px;
            text-align: right;
            line-height: 30px;
        }
        input{
            max-width: 400px;
            box-sizing: border-box;
            padding-left: 6px;
            height: 30px;
            border: 1px solid #717a83;
            background: #163C4C;
            border: 1px solid #FFFFFF;
            box-shadow: 0 2px 4px 0 rgba(0,0,0,0.50);
            border-radius: 8px;
            outline: none;
            color: #FFF;
            padding: 3px 5px;
        }
        select {
            border: 1px solid #FFFFFF;
            box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.5);
            border-radius: 8px;
            outline: none;
            color: #FFF;
            padding: 3px 5px;
            height: 30px;
            width: 200px;
            padding-left: 6px;
            background: url(/image/arrow-down.png) right center no-repeat #163C4C;

        }
        .time-slt{
            width: 200px;
            display: inline-block;
        }
        .btn{
            margin-left: calc( 25% + 5px);
        }
        .success{
            background: #5ebd5e;
            color: #fff;
            font-size: 11px;
            line-height: 24px;
            text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.2);
            padding: 0 6px;
            display: inline-block;
            font-weight: 600;
            border-radius: 3px;
        }
        .group-select{
            height: 30px;
        }
        .img-con{
            width: 100%;
            height: 142px;
            line-height: 18px;
            padding: 4px 0;
            position: relative;
        }
        &.group-content{
            flex-wrap: wrap;
            .group-select{
                flex: 1;
            }
        }
        &.img-content{
            padding: 0;
        }
    }
}
</style>