<template>
    <div class="details">
        <div class="capture-details">
            <div class="capture-head">
                抓拍信息
            </div>
            <div class="capture-body">
                <div class="form-group-div" style="height:220px;">
                    <div class="img-div">
                        <img :src="data.face" @click.prevent="viewImage(data.face)"></img>
                        <!--<span>脸部抓拍</span>-->
                    </div>
                    <div class="img-div">
                        <img :src="data.body || data.face" @click.prevent="viewImage(data.body || data.face)"></img>
                        <!--<span>整体抓拍</span>-->
                    </div>
                </div>
                <div class="form-group-div">
                    <div class="imageText">
                        <span>脸部抓拍</span>
                    </div>
                    <div class="imageText">
                        <span>整体抓拍</span>
                    </div>
                </div>
                <div class="form-group-div" v-if="data.from == 'alarm'">
                    <label>视频</label>
                    <div class="col8">
                        <a href="#" class="video_label" v-if="data.video_path" @click.prevent="replay(data.video_path)">
                            <i class="fa fa-play-circle"></i>&nbsp;&nbsp;
                            视频回放
                        </a>
                        <div v-else class="video_label">视频回放正在生成，请等待...</div>
                    </div> 
                </div>
                <div class="form-group-div">
                    <label>编号</label>
                    <div class="col8">
                        <input type="text"  class="input-style custom" :value="data.id" disabled/> 
                    </div> 
                </div>
                <div class="form-group-div">
                    <label>时间</label>
                    <div class="col8">
                        <input type="text"  class="input-style custom" :value="data.timestamp | formatDate" disabled/> 
                    </div> 
                </div>
                <div class="form-group-div">
                    <label>地点</label>
                    <div class="col8">
                        <input type="text"  class="input-style custom" :value="data.camera_location" disabled/> 
                    </div> 
                </div>
                <div class="form-group-div">
                    <label>detectID</label>
                    <div class="col8">
                        <input type="text"  class="input-style custom" :value="data.detectID" disabled/> 
                    </div> 
                </div>
                <div class="form-group-div">
                    <label>quality</label>
                    <div class="col8">
                        <input type="text"  class="input-style custom" :value="data.quality" disabled/> 
                    </div> 
                </div>
            </div>
        </div>
        <div class="alarm-details">
            <div class="capture-head">
                匹配信息
            </div>
            <div v-if="data.photos.length">
                <div class="image-content">
                    <div class="image-info" v-for="(key, index) in data.photos.slice(0,3)">
                        <a href="#" @click.prevent="selectPhoto(key, index)">
                            <img :src="key.path" width="100px" height="100px" v-if="index==0" role="photo_0"></img>
                            <img :src="key.path" width="100px" height="100px" v-if="index==1" role="photo_1"></img>
                            <img :src="key.path" width="100px" height="100px" v-if="index==2" role="photo_2"></img>
                            <span class="score">{{key ? key.score.toFixed(2) : '-'}}</span>
                        </a>
                    </div>
                </div>
                <div class="group-info">
                    <SubjectInfoComponent :data="subjectData"></SubjectInfoComponent>
                </div>
            </div>
            <div v-else style="text-align:center;margin-top:30%;">
                <i class="fa fa-exclamation-circle">&nbsp;暂无匹配信息</i>
            </div>
        </div>
        <DialogComponent :show="showDetails" title="视频回放">
            <div slot="content">
                <ReplayVideoComponent :src="src"></ReplayVideoComponent>
            </div>
        </DialogComponent>
        <DialogComponent :show="viewBigImage" title="查看原图">
            <div slot="content">
                <div style="text-align: center">
                    <img :src="imageSrc"></img>
                </div>
            </div>
        </DialogComponent>    
    </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import DialogComponent from '@nanyun/dialog'
import SubjectInfoComponent from 'pages/gate-real-time/subject-info.vue'
import ReplayVideoComponent from 'pages/gate-real-time/video-replay.vue'

export default {
    props: {
        data: {
            type: Object,
            default: {}
        }
    },
    data() {
        return {
            subjectData: {},
            showDetails: {
                value: false
            },
            src: '',
            viewBigImage: {
                value: false
            },
            imageSrc: ''
        }
    },
    created() {
        this.subjectData = this.data.photos ? this.data.photos[0] : {}
    },
    mounted() {
        if (document.querySelector('[role=photo_0]')) {
            document.querySelector('[role=photo_0]').className = 'active'
        }
    },
    methods: {
        selectPhoto(subject, index) {
            let photo0 = document.querySelector('[role=photo_0]')
            let photo1 = document.querySelector('[role=photo_1]')
            let photo2 = document.querySelector('[role=photo_2]')

            switch (index) {
                case 0 :
                    photo0.className = 'active'
                    if (photo1) {
                        photo1.className = ''
                    }
                    if (photo2) {
                        photo2.className = ''
                    }
                    break
                case 1 :
                    photo1.className = 'active'
                    photo0.className = ''
                    if (photo2) {
                        photo2.className = ''
                    }
                    break
                case 2 :
                    photo0.className = ''
                    photo1.className = ''
                    photo2.className = 'active'
                    break
            }
            this.subjectData = subject
        },
        replay(src) {
            this.showDetails.value = true
            this.src = src
        },
        viewImage(src) {
            this.viewBigImage.value = true
            this.imageSrc = src
        }
    },
    components: {
        DialogComponent,
        SubjectInfoComponent,
        ReplayVideoComponent
    }
}
</script>

<style scoped>
    .details{
        height: 100%;
        color: #fff;
        display: flex;
        .capture-details{
            flex:1;
            border: 1px solid #cfcfcf;
            width: 350px;
            box-shadow: none;
            border-radius: 7px;
            margin-right:5px;
            padding: 0 15px 15px;
            background-image: linear-gradient(-180deg, #000304 2%, #002636 99%);
        }
        .alarm-details{
            flex:1;
            height: 450px;
            border: 1px solid #cfcfcf;
            width: 350px;
            box-shadow: none;
            border-radius: 7px;
            background-image: linear-gradient(-180deg, #000304 2%, #002636 99%);
            .image-content{
                display:flex;
                margin-top:10px;
                .image-info{
                    padding-left:8px;
                    position: relative;
                    height: 110px;
                    .active{
                        border:3px solid #00CBF9;
                    }
                    .score{
                        color:#fff;
                        position: absolute;
                        right: 2px;
                        bottom: 10px;
                        padding: 2px 3px;
                        opacity: 0.8;
                        background: #F6A623;
                        border-radius: 12px;
                    }
                }
            },
            .group-info{
                padding: 0 15px 15px;
                margin: 0;
            }
        }
        .capture-head{
            padding: 9px 10px 7px 10px;
            border-bottom: 2px solid #ececec;
            font-size: 14px;
        }
        .capture-body{
            padding: 0 15px 15px;
            margin: 0;
        }
        .form-group-div{
            margin-bottom: 0!important;
            margin-top:10px;
            .img-div{
                width:150px;
                float: left;
                margin: 0px auto;
                height: 217px;
                overflow: hidden;
                text-align:center;
                background: rgba(255,255,255,0.30);
                border: 0 solid #FFFFFF;
                position:relative;
                margin-right:8px;
                text-align: center;
                display: -webkit-box;
                -webkit-box-align: center;
                -webkit-box-pack: center;
                display: -moz-box;
                -moz-box-align: center;
                -moz-box-pack: center;
                display: -o-box;
                -o-box-align: center;
                -o-box-pack: center;
                display: -ms-box;
                -ms-box-align: center;
                -ms-box-pack: center;
                display: box;
                box-align: center;
                box-pack: center;
                cursor: pointer;
                >img{
                    padding: 7px;
                    max-height: 200px;
                    max-width: 130px;
                    vertical-align:middle;
                }
            }
            .imageText{
                width:150px;
                float: left;
                margin-top: 2px;
                text-align:center;
            }
            >label{
                width: 25%;
                float: left;
                position: relative;
                min-height: 1px;
                padding-left: 5px;
                padding-right: 5px;
                margin-top:10px;
            }
            .video_label{
                background: #b0b0b0;
                color: #fff;
                font-size: 11px;
                text-shadow: 0 -1px 0 rgba(0, 0, 0, 0.2);
                padding: 0 6px;
                display: inline-block;
                font-weight: 600;
                text-align: center;
                white-space: nowrap;
                vertical-align: baseline;
                border-radius: .25em;
                height:30px;
                line-height:30px;
                width:96%;
            }
            .col8{
                width: 70%;
                float: left;
                margin-top:5px;
            }
            .input-style{
                padding: 3px 12px;
                font-size: 13px;
                line-height: 1.42857143;
                color: #555555;
                background-image: none;
                cursor: not-allowed;
                background-color: #eeeeee;
                opacity: 1;
            }
        }
    }
</style>