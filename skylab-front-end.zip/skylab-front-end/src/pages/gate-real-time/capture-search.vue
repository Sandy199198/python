<template>
    <div class="img-search">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <h4>检索条件</h4>
        <form class="search-option" name="formDate">
            <div class="result">
                <div class="title">
                    条件选择<span role="groupErr" class="error"></span>
                </div>
                <div class="condition">
                    <input type="text" name="start_time" style="display: none;" />
                    <input type="text" name="end_time" style="display: none;" />
                    <div class="condition-con">
                        <div>
                            <span class="condition-item-title">阈&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;值</span>
                            <input type="text" :value="threshold" name="threshold" />
                        </div>
                        <div>
                            <span class="condition-item-title">结果选择</span>
                            <select name="limit">
                                <option :value="item.value" v-for="item in resultValueList">{{item.text}}</option>
                            </select>
                        </div>
                        <div>
                            <span class="condition-item-title">时&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;间</span>
                            <DatepickerComponent class="time-slt" :date="startTime" :limit="startLimit" :options="dateOptions" v-on:change="changeStartDate"></DatepickerComponent>
                            <span>~</span>
                            <DatepickerComponent class="time-slt" :date="endTime" :limit="endLimit" :options="dateOptions" v-on:change="changeEndDate"></DatepickerComponent>
                        </div>
                    </div>
                </div>
            </div>
            <div class="select-img">
                <div class="title">
                    图片选择<span role="imgErr" class="error">请上传图片</span>
                </div>
                <div class="condition img-content">
                    <div class="img-con">
                        <FileUploadComponent></FileUploadComponent>
                    </div>
                </div>
            </div>
        </form>
        <div class="search-btn-content">
            <a href="#" class="button-style search" @click.prevent="search">开始检索</a>
        </div>
        <h4>检测结果<span v-if="resultLengthShow">共{{resultLength}}条</span></h4>
        <div class="search-content">
            <div class="search-result" v-for="(item, index) in getCaptureSearch">
                <div class="result-title">{{item.capture_group}}</div>
                <div v-for="(key, i) in item.captures">
                    <ImgCard :data="key" v-on:callback="importGroup" :mode="imgCardMode" :idIndex="index + '_' + i"></ImgCard>
                </div>
            </div>
        </div> 
        <ConfirmComponent :show="editObj.show" :title="editObj.text" class="dialog-con" :confirm="editObj.confirm">
            <div slot="content">
                <div class="panel-body new-member" style="padding-top:-11px;">
                    <CaptureAlarmPutinComponent :data="importObj" :groups="getGroup"></CaptureAlarmPutinComponent>
                </div>
            </div>
        </ConfirmComponent> 
    </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import FileUploadComponent from 'common/components/upload.vue'
import {CAPTURE_RESULT} from 'common/config'
import ConfirmComponent from '@nanyun/confirm'
import DatepickerComponent from 'common/components/datepicker.vue'
import {formatDate, parseDateStrToTimestamp, convertToSeconds} from 'common/utils'
import {GET_CAPTURE_SEARCH, FETCH_CAPTURE_SEARCH} from 'store/modules/search'
import { GENDER, CERTTYPE, CRIMINALRECORD, LABEL } from 'common/config'
import {GET_GROUP, FETCH_GROUP} from 'store/modules/group'
import {ADD_MEMBER} from 'store/modules/member'
import CaptureAlarmPutinComponent from 'common/components/capture-alarm-putin.vue'
import ImgCard from 'common/components/img-card.vue'
import CrumbsComponent from 'common/components/crumbs.vue'
import URL from 'common/url'

export default {
    data() {
        return {
            crumbs: [{
                name: '首页',
                path: {
                    name: URL.HOME
                }
            }, {
                name: '抓拍检索',
                slient: true
            }],
            resultValueList: CAPTURE_RESULT,
            startTime: {
                time: ''
            },
            endTime: {
                time: ''
            },
            startLimit: [],
            endLimit: [],
            dateOptions: {
                type: 'day',
                format: 'YYYY-MM-DD',
            },
            threshold: '70',
            bulkItems: {
                gender: GENDER,
                certType: CERTTYPE,
                crmRecord: CRIMINALRECORD,
                label: LABEL
            },
            editObj: {
                autoClose: 10000,
                text: '照片详情',
                show: {
                    value: false
                },
                confirm: () => {
                    this.importObj.fromCapture = true
                    this.importObj.timestamp = this.memberData.timestamp
                    this.addMember(this.importObj)
                }
            },
            memberData: {},
            importObj: {},
            resultLength: 0,
            resultLengthShow: false,
            imgCardMode: 'capture'
        }
    },
    computed: {
        ...mapGetters({
            getCaptureSearch: GET_CAPTURE_SEARCH,
            getGroup: GET_GROUP,
        }),
    },
    created() {
        this.fetchGroup()
    },
    methods: {
        ...mapActions({
            fetchCaptureSearch: FETCH_CAPTURE_SEARCH,
            fetchGroup: FETCH_GROUP,
            addMember: ADD_MEMBER
        }),
        changeStartDate(startDate) {
            let date = startDate ? startDate + ' 00:00' : ''
            let start = formatDate((parseDateStrToTimestamp(date) / 1000 - 86400), 'Y-M-D')
            let end = formatDate((parseDateStrToTimestamp(date) / 1000 + 86400), 'Y-M-D')

            this.endLimit = [{
                type: 'fromto',
                from: start,
                to: ''
            }]
            document.querySelector('[name=start_time]').value = parseDateStrToTimestamp(date) / 1000
        },
        changeEndDate(endDate) {
            let date = endDate ? endDate + ' 00:00' : ''
            let start = formatDate((parseDateStrToTimestamp(date) / 1000 - 86400), 'Y-M-D')
            let end = formatDate((parseDateStrToTimestamp(date) / 1000 + 86400), 'Y-M-D')

            this.startLimit = [{
                type: 'fromto',
                from: '',
                to: end
            }]
            document.querySelector('[name=end_time]').value = parseDateStrToTimestamp(date) / 1000
        },
        search() {
            let formDate = document.querySelector('[name=formDate]')
            let groupErr = document.querySelector('[role=groupErr]')
            let threshold = document.querySelector('[name=threshold]')
            let startTime = document.querySelector('[name=start_time]')
            let endTime = document.querySelector('[name=end_time]')
            let imgErr = document.querySelector('[role=imgErr]')
            let img = document.querySelector('.img-show')
            let thErr = '请输入阈值'
            let timeErr = '请选择时间'

            if (!threshold.value) {
                groupErr.innerHTML = thErr
                groupErr.style.display = 'inline-block'
                return
            }
            if (!startTime.value || !endTime.value) {
                groupErr.innerHTML = timeErr
                groupErr.style.display = 'inline-block'
                return
            }
            groupErr.style.display = 'none'
            if (img.style.display == 'none') {
                imgErr.style.display = 'inline-block'
                return
            }
            imgErr.style.display = 'none'
            this.resultLength = 0
            this.fetchCaptureSearch(formDate).then(() => {
                this.getCaptureSearch.map(item => {
                    this.resultLength += item.captures.length
                })
                this.resultLengthShow = true
            })
        },
        importGroup(arr) {
            this.memberData = Object.assign({}, this.getCaptureSearch[arr[0]].captures[arr[1]])
            this.importObj = Object.assign({}, {
                path: this.memberData.path,
                'group_id': this.getGroup[0].id,
                gender: this.bulkItems.gender[0].value,
                'cert_type': this.bulkItems.certType[0].value,
                'criminal_record': this.bulkItems.crmRecord[0].value,
                label: this.bulkItems.label[0].value,
                remark: '',
                name: ''
            })
            this.editObj.show.value = !this.editObj.show.value
        }
    },
    components: {
        FileUploadComponent,
        DatepickerComponent,
        ConfirmComponent,
        CaptureAlarmPutinComponent,
        ImgCard,
        CrumbsComponent
    }
}
</script>

<style scoped>
h4{
    font-size: 14px;
    line-height: 24px;
    span{
        font-size: 12px;
        color: #efefef;
        margin-left: 5px;
    }
}
.img-search{
    color: #fff;
    width: 100%;
    padding: 50px 80px;
    box-sizing: border-box;
    min-height: 100%;
}
.search-option{
    width: 100%;
    display: flex;
    font-size: 14px;
    line-height: 50px;
    background-image: linear-gradient(-180deg, #003F54 4%, #00283A 99%);
    border: 1px solid #00CBF9;
    border-radius: 7px;
    &>div{
        flex: 1; 
        border-right: 1px solid #003F54;
        &:last-child{
            border-right: none;
        }
    }
    .title{
        padding-left: 10px;
        .error{
            color: crimson;
            margin-left: 5px;
            display: none;
        }
    }
    .condition{
        font-size: 12px;
        line-height: 24px;
        padding: 20px 10px 10px 10px;
        background-image: linear-gradient(-180deg, #000304 4%, #002636 99%);
        border-bottom-left-radius: 7px;
        border-bottom-right-radius: 7px;
        .condition-con{
            width: 476px;
            margin: 0 auto;
            &>div{
                height: 40px;
            }
        }
        .condition-item-title{
            display: inline-block;
            width: 50px;
            text-align: justify;
        }
        input{
            width: 200px;
            box-sizing: border-box;
            padding-left: 6px;
            height: 30px;
            background: #163C4C;
            border: 1px solid #FFFFFF;
            box-shadow: 0 2px 4px 0 rgba(0,0,0,0.50);
            border-radius: 8px;
            outline: none;
            color: #FFF;
            padding: 3px 5px;
        }
        select {
            border: 1px solid #FFFFFF;
            box-shadow: 0 2px 4px 0 rgba(0,0,0,0.50);
            border-radius: 8px;
            outline: none;
            color: #FFF;
            padding: 3px 5px;
            height: 30px;
            width: 200px;
            padding-left: 6px;
            background: url(../../images/arrow-down.png) right center no-repeat #163C4C;
        }
        .time-slt{
            width: 200px;
            display: inline-block;
        }
        .group-select{
            height: 30px;
        }
        .img-con{
            width: 100%;
            height: 142px;
            line-height: 18px;
            padding: 4px 0;
            position: relative;
        }
        &.group-content{
            flex-wrap: wrap;
            .group-select{
                flex: 1;
            }
        }
        &.img-content{
            padding: 0;
        }
    }
}
.search-btn-content{
    margin-top: 20px;
    text-align: right;
}
.btn{
    display: inline-block;
    color: #fff;
    text-decoration: none;
    width: 90px;
    height: 30px;
    text-align: center;
    margin-left: 5px;
    background: #4990e2;
    border-radius: 3px;
    font-size: 12px;
    line-height: 30px;
    &.search{
        vertical-align: top;
        margin-left: 0;
    }
}
.dialog-con{
    color: #000;
}
.panel-body.new-member{
    display: flex;
    width: 620px;
    color: #000;
    .member-img{
        position: relative;
        width: 50%;
        height: 338px;
        background: #f0f0f0;
        border: 1px solid #d6d6d6;
        &:after{
            display:inline-block;
            width:0;
            height:100%;
            vertical-align:middle;
            content:'';
        }
        .thumbnail{
            float: left;
            width: 33%;
            height: 30%;
            margin-top: 5px;
            position: relative;
        }
        img{
            max-width: 100%;
            max-height: 100%;
            display: inline-block;
            vertical-align: middle;
        }
    }
    .member-items{
        width: 50%;
    }
    .col9{
        width:70%;
        float:left;
        min-height: 1px;
        &.bulk-info-check{
            display: flex;
            div{
                flex: 1;
                line-height: 24px;
            }
        }
    }
    .form-select{
        width: 86%;
    }
    .success-title{
        font-size:16px;
        font-weight:bold;
        line-height:32px;
    }
    .form-group-info{
        text-align: center;
        width: 100%;
        .left-tag{
            margin-right: 20px;
        }
    }
    input:disabled, select:disabled, textarea:disabled{
        cursor: not-allowed;
        background-color: #eeeeee;
    }
}
.search-content{
    width: 100%;
    min-height: 250px;
    overflow: hidden;
    padding: 10px;
    box-sizing: border-box;
    background-image: linear-gradient(-180deg, #000304 4%, #002636 99%);
    border: 1px solid #00CBF9;
    border-radius: 7px;
    .result-title{
        line-height: 28px;
        background: #424b5a;
        margin-top: -10px;
        margin-bottom: 10px;
        margin-left: -10px;
        padding-left: 10px;
        margin-right: -10px; 
    }
    .search-result{
        min-height: 300px;
    }
}
</style>