<template>
    <div class="alarm-history">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="alarm-content">
            <TableComponent :data="getImageFilterList" :columns="columns">
                <span v-for="(item, index) in getImageFilterList" :slot="'photos' + index">
                    <span v-if="item.files && item.files.length">
                        <div class="result-item" v-for="(n, i) in item.files">
                            <div class="item-score">
                                <img :src="'http://192.168.0.10:10100/' + n" alt="" :class="selected.indexOf(n) != -1 ? 'active' : ''" @click="selectImage(n)" @mouseover="showImage(n)" @mouseleave="hideImage(n)">
                            </div>
                        </div>
                    </span>
                </span>
            </TableComponent>
        </div>
        <div style="margin-top:10px;">
            <a href="#" class="button-style" @click="del">删除</a>
        </div>
        <div style="overflow:hidden">
            <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
        </div>
        <div v-show="showBigImage" class="bigImage">
            <img :src="bigImageSrc">
        </div>
    </div>
</template>

<script>
    import PaginationComponent from '@nanyun/pagination'
    import {GET_IMAGE_FILTER_LIST,
            FETCH_IMAGE_FILTER_LIST,
            DELETE_IMAGE_FILTER,
            GET_PAGE } from 'store/modules/image_filter'
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    import CrumbsComponent from 'common/components/crumbs.vue'
    import URL from 'common/url'
    import TableComponent from '@nanyun/table'
    import PanelComponent from '@nanyun/panel'

    export default {
        data() {
            return {
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '图片过滤',
                    silent: true
                }],
                columns: [{
                    title: '文件夹',
                    prop: 'dir'
                }, {
                    title: '图像',
                    type: 'img',
                    prop: 'photos'
                }],
                alarmData: {},
                selected: [],
                showBigImage: false,
                bigImageSrc: '',
            }
        },
        created() {
            this.fetchData()
        },

        computed: {
            ...mapGetters({
                getImageFilterList: GET_IMAGE_FILTER_LIST,
                getPage: GET_PAGE,
            })
        },

        methods: {
            fetchData() {
                this.fetchImageFilterList(this.alarmData)
            },
            ...mapActions({
                fetchImageFilterList: FETCH_IMAGE_FILTER_LIST,
                delImageFilter: DELETE_IMAGE_FILTER,
            }),
            ...mapMutations({
                // clearAlarmHistoryList: CLEAR_ALARM_HISTORY_LIST
            }),
            pageEvent(page) {
                this.selected = []
                this.alarmData.page = page
                this.fetchData()
            },
            del() {
                if (!this.selected.length) {
                    return
                }
                for (let name of this.selected) {
                    this.delImageFilter(name).then(() => {
                        this.fetchData()
                    })
                }
            },
            selectImage(name) {
                let index = this.selected.indexOf(name)

                if (index != -1) {
                    this.selected.splice(index, 1)
                } else {
                    this.selected.push(name)
                }
            },
            showImage(name) {
                this.showBigImage = true
                this.bigImageSrc = 'http://192.168.0.10:10100/' + name
            },
            hideImage(name) {
                this.showBigImage = false
                this.bigImageSrc = ''
            }
        },
        components: {
            PaginationComponent,
            CrumbsComponent,
            TableComponent,
            PanelComponent
        },
        destroyed() {
            // this.clearAlarmHistoryList()
        }
    }
</script>

<style scoped>
    .alarm-history{
        padding: 50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        .table_content{
            width:100%;
            height: 60px;
            .condition {
                color:#fff;
                padding: 0 4px;
                &>div{
                    float: left;
                }
                .datepicker{
                    display:inline-block;
                    margin: 0 22px 10px 0;
                }
            }
            input, select{
                margin-right:10px;
                margin-bottom:10px;
                min-width: 192px;
            }
            input.custom{
                min-width: 180px;
            }
        }
        .alarm-content{
            margin-top:20px;
            >span{
                color:#fff;
                padding: 0 4px 5px 5px;
            }
            .capture-item{
                width: 130px;
                height: 180px;
                padding: 4px;
                border: 1px solid #717982;
                margin-left: 10%;
                .item-score{
                    position: relative;
                    height: 110px;
                    cursor: pointer;
                    >img{
                        max-width: 130px;
                        max-height: 180px;
                    }
                }
                .item-info{
                    margin-top: 10px;
                    text-align: center;
                    >p{
                        font-family: '宋体';
                        font-size:12px;
                        text-overflow:ellipsis;
                        white-space:nowrap;
                        overflow:hidden;
                        margin: 2px 0 2px 0;
                        .button-style{
                            padding: 5px;
                        }
                    }
                }
            }
            .result-item{
                width: 130px;
                height: 180px;
                float: left;
                padding: 4px;
                /*border: 1px solid #717982;*/
                margin:3px;
                .item-score{
                    position: relative;
                    height: 110px;
                    cursor: pointer;
                    .score{
                        position: absolute;
                        right: 20px;
                        bottom: 2px;
                        padding: 2px 3px;
                        border-radius: 3px;
                        background-color: #cd5d40;
                    }
                    .active{
                        border: 4px solid red;
                    }
                    img{
                        max-height: 175px;
                        max-width: 120px;
                    }
                }
                .item-info{
                    margin-top: 10px;
                    text-align: center;
                    >p{
                        font-family: '宋体';
                        font-size:12px;
                        text-overflow:ellipsis;
                        white-space:nowrap;
                        overflow:hidden;
                        margin: 0;
                        line-height: 20px;
                        .button-style{
                            padding: 0 5px 0 5px;
                        }
                    }
                }
            }
        }
        .minWidth{
            min-width:200px;
        }
    }
    .nodata{
        text-align: center;
    }
    p.no-video{
        font-size: 16px;
        color: #fff;
    }
    .all-export-list{
        width: 100%;
        height: 250px;
        overflow: auto;
        .export_title{
            display: flex;
            border-bottom: 1px solid #fff;
            text-align: center;
            >span{
                flex: 1;
                padding: 3px;
            }
        }
        .item{
            overflow: hidden;
            line-height: 28px;
            display: flex;
            text-align: center;
            >div{
                flex: 1;
                padding: 3px;
            }
            .video-status{
                >a{
                    color: #fff;
                }
                .success{
                    border-radius: 3px;
                    padding: 2px 4px;
                    color: #fff;
                    background: #5ebd5e;
                }
                .primary{
                    border-radius: 3px;
                    padding: 2px 4px;
                    color: #fff;
                    background: #1d89cf;
                }
                .danger{
                    border-radius: 3px;
                    padding: 2px 4px;
                    color: #fff;
                    background: #e66454;
                }
                .warning{
                    border-radius: 3px;
                    padding: 2px 4px;
                    color: #fff;
                    background: #efaf65;
                }
            }
        }
    }
    .bigImage{
        height: auto;
        width: auto;
        border: 1px solid #fff;
        position: fixed;
        z-index: 100000;
        top: 10%;
        right: 82px;
        img{
            max-height: 1000px;
            max-width: 1000px;
        }
    }
</style>