<template>
    <div class="alarms">
        <div class="alarms-header">
            <div class="alarm-pic-header">
                告警音频次
                <select class="select input-style" name="alarmStatus" ref="select" @change.prevent="changeAlarmStatus()">
                    <option v-for="option in alarmStatus" :value="option.value">{{option.text}}</option>
                </select>
            </div>
            <div class="alarm-pic-header">
                <input  type="checkbox" @click="alarmAll()" name="alarmAll" ref="alarmAll">
                <label for="name" slot="label">全局告警</label>
            </div>
            <div class="alarm-info-header">
                <a href="#" @click.prevent="goAlarmHistory()">
                    查看历史
                </a>
            </div>
        </div>
        <transition-group name="alarm-list" tag="ul" mode="out-in" v-if="alarms.length">
            <li v-for="alarm of alarms" :key="alarm.id">
                <div v-if="alarm.type">
                    <div class="alarm-content">
                        <div class="alarm-pic">
                            <img :src="alarm.face" alt="" width="88" height="88">
                            <span>抓拍图</span> 
                        </div>
                        <div class="alarm-pass-info">
                            <p :title="alarm.camera_name">相机名称: <span>{{alarm.camera_name || '-'}}</span></p>
                            <p :title="alarm.camera_location">相机位置: <span>{{alarm.camera_location || '-'}}</span></p>
                            <p>告警时间: <span>{{alarm.timestamp | formatDate}}<span></p>
                            <p>告警类型: <span>通过告警<span></p>
                        </div>
                    </div>
                </div>
                <div v-else>
                    <div class="alarm-content">
                        <div class="alarm-pic">
                            <img :src="alarm.face" alt="" width="88" height="88">
                            <span>抓拍图</span> 
                        </div>
                        <div class="alarm-info">
                            <p>{{alarm.photos[0].score.toFixed(2)}}</p>
                        </div>
                        <div class="alarm-pic">
                            <img :src="alarm.photos[0].path" alt="" width="88" height="88">
                            <span>比对图</span> 
                        </div>
                    </div>
                    <div class="alarm-info">
                        <p :title="alarm.photos[0].subject.name">姓名: {{alarm.photos[0].subject.name}}</p>
                        <p :title="alarm.photos[0].subject.cert_id">身份证: {{alarm.photos[0].subject.cert_id || '-'}}</p>
                        <p :title="alarm.camera_name">相机名称: {{alarm.camera_name || '-'}}</p>
                        <p>告警时间: {{alarm.timestamp | formatDate}}</p>
                        <button class="button-style" @click.prevent="viewAlarmDetails(alarm)">查看详情</button>
                    </div>
                </div>
            </li>
        </transition-group>
        <div class="nodata" v-else>暂无告警数据</div>
    </div>    
</template>

<script>
    export default {
        props: {
            alarms: {
                type: Array,
                default() {
                    return []
                }
            },
            alarmStatus: {
                type: Array,
                default() {
                    return []
                }
            }
        },
        mounted() {
            let alarmAll = localStorage.getItem('alarmAll')
            let alarmStatus = localStorage.getItem('alarmStatus')

            if (alarmAll == 'true') {
                this.$refs.alarmAll.checked = true
            }
            if (!alarmStatus) {
                alarmStatus = 0
                localStorage.setItem('alarmStatus', 0)
            }
            this.$refs.select.value = alarmStatus
        },
        methods: {
            alarmAll() {
                localStorage.setItem('alarmAll', this.$refs.alarmAll.checked)
            },
            goAlarmHistory() {
                this.$emit('viewMoreAlarms')
            },
            viewAlarmDetails(alarm) {
                alarm.from = 'alarm'
                this.$emit('openDetailDialog', alarm)
            },
            changeAlarmStatus() {
                localStorage.setItem('alarmStatus', this.$refs.select.value)
            }
        }
    }
</script>

<style scoped>
    .alarms {
        color: #FFF;
        box-sizing: border-box;
        position: relative;
        overflow: hidden;
        padding: 40px 0 0;
        height:100%;
        .nodata{
            position:absolute;
            text-align:center;
            top:50%;
            left: 40%;
        }
        .alarms-header{
            width: 96%;
            position: absolute;
            top: 10px;
            display:flex;
            >div{
                height: 30px;
                line-height: 30px;
                text-align: center;
            }
            .alarm-pic-header{
                margin-left: 15px;
                .input-style{
                    min-width: 120px;
                }
            }
            .alarm-info-header{
                flex:1;
                text-align:right;
                >a{
                    color:#e56544;
                }
            }
        }
        ul{
            position: absolute;
            left: 5%;
            top: 8%;
            width: 90%;
            height:90%;
            padding:0 20px;
            box-sizing: border-box;
            overflow-y: auto;
            overflow-x: hidden;
            background: rgba(255,255,255,0.10);
            border: 1px solid rgba(255,255,255,0.40);
            box-shadow: 0 2px 5px 0 rgba(0,0,0,0.50);
            border-radius: 20px;
            li{
                display:list-item;
                .alarm-content{
                    display: flex;
                    border-bottom:1px solid #777;
                    .alarm-pic{
                        width:92px;
                        height:110px;
                        text-align: center;
                        padding:1px;
                        overflow:hidden;
                        margin:10px 2px;
                        box-sizing: border-box;
                        border-radius: 2px;
                        >img{
                            border:1px solid #eee;
                        }
                    }
                    .alarm-pass-info{
                        width:192px;
                        height:110px;
                        text-align: left;
                        padding:1px;
                        overflow:hidden;
                        margin:2px;
                        box-sizing: border-box;
                        border-radius: 2px;
                        p{
                            font-family: '宋体';
                            font-size:12px;
                        }
                        /* span{
                            color: #A4D3EE;
                        } */
                    }
                    .alarm-info{
                        flex: 1;
                        text-align:center;
                        border:0;
                        justify-content: center;
                        width: 100%;
                        p{
                            font-family: '宋体';
                            font-size:1.2vw;
                            text-overflow:ellipsis;
                            position: relative;
                            top: 25%;
                            color:#e56544;
                            white-space:nowrap;
                            overflow:hidden;
                        }
                    }
                }
                .alarm-info{
                    font-family: '宋体';
                    font-size:12px;
                    text-overflow:ellipsis;
                    border-bottom:1px solid #555;
                    white-space:nowrap;
                    overflow:hidden;
                    button{
                        margin-left:40%;
                        margin-bottom: 5px;
                    }
                }
            }
        }
    }
</style>