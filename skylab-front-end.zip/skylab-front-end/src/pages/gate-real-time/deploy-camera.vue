<template>
    <div class="deploy-cameras">
        <div class="branch-wrapper" v-if="deploys.length">
            <ul class="branch">
                <li v-for="info in deploys">
                    <a href="#" :title="info.name" @click.prevent="selectDeploy(info.id)">
                        <i class="fa" :class="getCurrentClassName(info.id)"></i>
                        {{info.name}}
                    </a>
                    <ul class="camera" v-if="isCurrentBranch(info.id)">
                        <li v-for="camera in info.cameras" :class="selected(camera)">
                            <a href="#" :title="camera.name" @click.prevent="go(camera)" :class="selected(camera)">
                                <i class="fa fa-video-camera"></i>
                                {{camera.name}}
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
        <div style="text-align:center" v-else>暂无数据</div>
    </div>
</template>

<script>
    import {FETCH_CAMERA} from 'store/modules/realtime'
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    export default {

        props: {
            deploys: {
                type: Array,
                default: function () {
                    return []
                }
            },
            selectedCameraId: {
                type: Number,
                default: -1
            }
        },

        data() {
            return {
                branchStates: {}
            }
        },

        watch: {
            branchs() {
                for (let info of this.deploys) {
                    if (this.currentBranchName == info.id) {
                        this.branchStates[info.id] = true
                    } else {
                        this.branchStates[info.id] = false
                    }
                }
            }
        },

        computed: {
            currentBranchName() {
                if (this.deploys.length) {
                    for (let branch of this.deploys) {
                        for (let camera of branch.cameras) {
                            if (this.selectedCameraId == camera.id) {
                                return branch.branch
                            }
                        }
                    }
                    return ''
                } else {
                    return ''
                }
            }
        },

        methods: {
            getCurrentClassName(deployId) {
                let current = this.isCurrentBranch(deployId)

                return {
                    'fa-minus-square': current,
                    'fa-plus-square': !current,
                }
            },

            isCurrentBranch(deployId) {
                return this.branchStates[deployId]
            },

            selectDeploy(deployId) {
                let oldValue = this.branchStates[deployId]

                this.branchStates = Object.assign({}, this.branchStates, {
                    [deployId]: !oldValue
                })
                if (deployId) {
                    this.fetchCamera(deployId)
                }
            },

            selected(camera) {
                return {
                    selected: camera ? camera.id == this.selectedCameraId : false
                }
            },

            go(camera) {
                this.$emit('selection', camera)
            },

            ...mapActions({
                fetchCamera: FETCH_CAMERA
            }),
        }

    }
</script>

<style scoped>
.deploy-cameras {
    color: #4083a9;
    position: relative;
    opacity: 0.8;
    background-image: linear-gradient(-180deg, #000304 4%, #002636 99%);
    border: 0 solid #FFFFFF;
    border-radius: 7px;
    padding: 10px;
    .title{
        padding:0 10px;
        box-sizing: border-box;
        width: 100%;
        position: absolute;
        h3{
            margin:0 auto;
            width: 100%;
            padding-top:10px;
            border-bottom: 1px solid #777;
            height: 30px;
            line-height: 30px;
        }
    }
    .branch-wrapper{
        height: 100%;
        box-sizing: border-box;
    }
    .branch{
        height: 100%;
        overflow-y: auto;
        >li{
            >a{
                color:#fff;
                display: inline-block;
                width: 100%;
                box-sizing: border-box;
                padding: 10px 0 5px 20px;
                overflow:hidden;
                text-overflow: ellipsis;
                white-space:nowrap;
                i{
                    margin-right: 6px
                }
            }   
        } 
    }
    .camera {
        >li{
            >a {
                color:#fff;
                display: inline-block;
                width: 100%;
                padding: 6px 0 6px 40px;
                box-sizing: border-box;
                overflow:hidden;
                text-overflow: ellipsis;
                white-space:nowrap;
                i{
                    margin-right: 10px;
                }
                &:hover{
                    color:#4083a9;
                }
            }
            >a.selected {
                box-shadow: inset 0 0 5px #111;
                color:#4083a9;
                background: #182c41;
            }
        }
    }
}
</style>