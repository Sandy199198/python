<template>
    <div class="video-search">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <h4>检索条件<span class="tips">(支持视频批量上传)</span></h4>
        <div class="search-option">
            <div class="result">
                <div class="title">
                    <span class="tab-item" @click.prevent="changeTab('isAlarm')" :class="{'active': isAlarm}">识别告警</span>
                    <span class="tab-item last" @click.prevent="changeTab()" :class="{'active': !isAlarm}">只抓拍人脸</span>
                    <span role="infoErr" class="error" style="display: none;"></span>
                </div>
                <div class="result-con" v-if="isAlarm">
                    <div class="condition">
                        <div class="condition-con" v-if="!getServices.PKStatus">
                            <span class="condition-item-title">阈&nbsp;&nbsp;值&nbsp;&nbsp;</span>
                            <input type="text" name="threshold" class="input-style" />
                        </div>
                        <div class="condition-con" style="height:60px;">
                            <span class="condition-item-title">底&nbsp;&nbsp;库&nbsp;&nbsp;</span>
                            <div class="group-content">
                                <div class="group-select" v-for="(group, index) in getGroup">
                                    <input type="checkbox" :id="'group' + index" :value="group.id" name="groups" v-on:change="changeGroup">
                                    <label :for="'group' + index">{{group.name}}</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--<div class="condition">
                        <div class="condition-con">
                            <span class="condition-item-title">底&nbsp;&nbsp;库&nbsp;&nbsp;</span>
                            <div class="group-content">
                                <div class="group-select" v-for="(group, index) in getGroup">
                                    <input type="checkbox" :id="'group' + index" :value="group.id" name="groups" v-on:change="changeGroup">
                                    <label :for="'group' + index">{{group.name}}</label>
                                </div>
                            </div>
                        </div>
                    </div>-->
                </div>
                <div class="result-con" v-else>
                    <div class="condition">
                        <div class="condition-con storage">
                            <span class="condition-item-title">入库名称</span>
                            <input type="text" name="group_name" class="input-style groupname" />
                            <p class="info">若抓拍人脸需要入库，请在输入框中填上入库的名称。名称中可以使用“$id”来代替视频的ID,“$name”来代替视频的名称，如offline_video_$name
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="select-img">
                <div class="title">
                    选择视频文件[<a href="#" class="more" @click.prevent="more">选择已有视频</a>]<span class="error" role="videoErr" style="display: none;">请选择或上传视频</span>
                    <a href="#" class="chosemore" @click.prevent="choseMore">更多条件</a>
                </div>
                <div class="condition img-content">
                    <div class="img-con">
                        <FileUploadComponent v-on:changeFile="changeVideoUpload" :videoList="fileVideoList" v-on:delFileItem="deleteFileItem"></FileUploadComponent>
                    </div>
                </div>
            </div>
        </div>
        <div class="search-btn-content">
            <a href="#" class="button-style search" @click.prevent="search">开始检索</a>
        </div>
        <h4>检测结果</h4>  
        <div class="search-result">
            <TableComponent :columns="columns" :data="getVideoList">
                <span v-for="(item, index) in getVideoList" :slot="'element' + index">
                    <span v-for="i in videoStatus">
                        <span v-if="item.status == i.value" :class="i.clsName">{{i.text}}</span>
                    </span>
                </span>
                <span v-for="(item, index) in getVideoList" :slot="'events' + index">
                    <span v-if="item.status == 2">
                        <a href="#" @click.prevent="goCapture(index)">抓拍</a>
                        &nbsp;&nbsp;
                        <a href="#" @click.prevent="goAlarm(index)">告警</a>
                        &nbsp;&nbsp;
                        <a href="#" @click.prevent="reupdate(index)">重新执行</a>
                    </span>
                    <span v-else-if="item.status == 3">
                        <a href="#"  @click.prevent="reupdate(index)">重新识别</a>
                    </span>
                    <span v-else>-</span>
                </span>
            </TableComponent>
        </div>
        <div style="overflow: hidden;">
            <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
        </div>
        <ConfirmComponent :show="moreVideoObj.show" :title="moreVideoObj.text" :confirm="moreVideoObj.confirm">
            <div slot="content">
                <div class="panel-body" style="padding-left: -11px;margin-top: -20px" v-if="getAllVideoList.length">
                    <p><i class="fa fa-exclamation-circle"></i>请选择视频</p>
                    <div class="all-video-list">
                        <div class="item" v-for="(item, index) in getAllVideoList">
                            <div class="video-checkbox">
                                <input type="checkbox" :id="index" :value="item.id" v-on:change="changeVids">
                            </div>
                            <div class="video-name">
                                <label :for="index">{{item.filename}}</label>
                            </div>
                            <div class="video-status">
                                <span v-for="i in videoStatus">
                                    <span v-if="item.status == i.value" :class="i.clsName">{{i.text}}</span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-body nodata" style="padding-left: -11px;" v-else>
                    <p class="no-video">暂无视频</p>
                </div>
            </div>
        </ConfirmComponent>
        <ConfirmComponent :show="moreTipsObj.show" :title="moreTipsObj.text" :confirm="moreTipsObj.confirm" :cancel="moreTips.cancel">
            <div slot="content">
                <div class="panel-body" style="padding-left: -11px;">
                    <div class="form-group">
                        <label class="control-label col3">抓拍模式</label>
                        <div class="col9">
                            <select name="crop" class="form-control form-select" v-model="itemsObj.crop">
                                <option :value="item.value" v-for="item in corp">{{item.text}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col3">视频类型</label>
                        <div class="col9">
                            <select name="video_type" class="form-control form-select" v-model="itemsObj.video_type">
                                <option :value="item.value" v-for="item in videoType">{{item.text}}</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col3">抓拍模糊度</label>
                        <div class="col9">
                            <input type="text" name="blurness" placeholder="必填 范围(0,1)" class="form-control form-input" v-model="itemsObj.blurness"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col3">翻滚角(roll)</label>
                        <div class="col9">
                            <input type="text" name="roll" placeholder="必填 范围(-180,180)" class="form-control form-input" v-model="itemsObj.roll"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col3">偏航角(yaw)</label>
                        <div class="col9">
                            <input type="text" name="yaw" placeholder="必填 范围(-180,180)" class="form-control form-input" v-model="itemsObj.yaw"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col3">俯仰角(pitch)</label>
                        <div class="col9">
                            <input type="text" name="pitch" placeholder="必填 范围(-90,90)" class="form-control form-input" v-model="itemsObj.pitch"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col3">最小抓拍人脸</label>
                        <div class="col9">
                            <input type="text" name="facemin" placeholder="必填" class="form-control form-input" v-model="itemsObj.facemin"/>
                        </div>
                    </div>
                </div>
            </div>
        </ConfirmComponent>
        <div class="progress" v-bind:style="getProgress.show">
            <span>正在上传视频，请勿刷新或关闭网页...</span><br/>
            <div class="progress-bg">
                <div class="progress-bar" v-bind:style="getProgress.style">
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import URL from 'common/url'
import {RESULT, VIDEO_STATUS, CORP, VIDEOTYPE} from 'common/config'
import TableComponent from '@nanyun/table'
import FileUploadComponent from 'common/components/video-upload.vue'
import PaginationComponent from '@nanyun/pagination'
import ConfirmComponent from '@nanyun/confirm'
import {GET_GROUP, FETCH_GROUP} from 'store/modules/group'
import {formatDate, parseDateStrToTimestamp, convertToSeconds} from 'common/utils'
import {GET_VIDEO_LIST, GET_ALL_VIDEO_LIST, FETCH_VIDEO_LIST, GET_PAGE, SEARCH_VIDEO_LIST, SEARCH_VIDEO, REUPDATE_SEARCH_VIDEO, GET_PROGRESS, PROGRESS} from 'store/modules/search'
import {GET_SERVICES, FETCH_SERVICES} from 'store/modules/common'
import CrumbsComponent from 'common/components/crumbs.vue'

export default {
    data() {
        return {
            crumbs: [{
                name: '首页',
                path: {
                    name: URL.HOME
                }
            }, {
                name: '视频检索',
                slient: true
            }],
            resultValueList: RESULT,
            corp: CORP,
            videoType: VIDEOTYPE,
            videoStatus: VIDEO_STATUS,
            size: 10,
            moreVideoObj: {
                autoClose: 10000,
                text: '视频列表',
                show: {
                    value: false
                },
                confirm: () => {
                    for (let i in this.ids) {
                        let data = Object.assign({}, this.getAllVideoList[this.ids[i]])

                        this.fileVideoList.push(data)
                    }
                }
            },
            isAlarm: true,
            fileVideoList: [],
            groups: [],
            vids: [],
            ids: [],
            delay: 300,
            intervalTime: 5000,
            moreTips: {
                'video_type': '0',
                blurness: 0.5,
                facemin: 48,
                roll: 20,
                yaw: 20,
                pitch: 20,
                crop: 'face,body'
            },
            moreTipsObj: {
                autoClose: 10000,
                text: '更多条件',
                show: {
                    value: false
                },
                cancel: () => {
                    this.itemsObj = Object.assign({}, this.moreTips)
                }
            },
            isPk: true
        }
    },
    computed: {
        ...mapGetters({
            getGroup: GET_GROUP,
            getPage: GET_PAGE,
            getVideoList: GET_VIDEO_LIST,
            getAllVideoList: GET_ALL_VIDEO_LIST,
            getProgress: GET_PROGRESS,
            getServices: GET_SERVICES
        }),
        itemsObj() {
            return Object.assign({}, this.moreTips)
        },
        columns() {
            return this.getServices.PKStatus ? [{
                title: '文件名',
                prop: 'filename',
            }, {
                title: '底库',
                prop: 'groups',
                handle: d => {
                    if (d.length == 1) {
                        return d[0].name
                    } else if (d.length > 1) {
                        return d[0].name + '等' + d.length + '个底库'
                    } else {
                        return '无底库'
                    }
                }
            }, {
                title: '上传时间',
                prop: 'timestamp',
                handle: d => {
                    return formatDate(d, 'Y-M-D h:m')
                }
            }, {
                title: '完成时间',
                prop: 'finish_timestamp',
                handle: d => {
                    if (!d) {
                        return '-'
                    } else {
                        return formatDate(d, 'Y-M-D h:m')
                    }
                }
            }, {
                title: '识别结果',
                prop: 'status',
                type: 'element'
            }, {
                title: '查看结果',
                type: 'events'
            }] : [{
                title: '文件名',
                prop: 'filename',
            }, {
                title: '阈值',
                prop: 'threshold'
            }, {
                title: '底库',
                prop: 'groups',
                handle: d => {
                    if (d.length == 1) {
                        return d[0].name
                    } else if (d.length > 1) {
                        return d[0].name + '等' + d.length + '个底库'
                    } else {
                        return '无底库'
                    }
                }
            }, {
                title: '上传时间',
                prop: 'timestamp',
                handle: d => {
                    return formatDate(d, 'Y-M-D h:m')
                }
            }, {
                title: '完成时间',
                prop: 'finish_timestamp',
                handle: d => {
                    if (!d) {
                        return '-'
                    } else {
                        return formatDate(d, 'Y-M-D h:m')
                    }
                }
            }, {
                title: '识别结果',
                prop: 'status',
                type: 'element'
            }, {
                title: '查看结果',
                type: 'events'
            }]
        }
    },
    created() {
        this.fetchData()
        this.fetchVideoList()
        // setTimeout(() => {
        //     this.interval = setInterval(() => {
        //         this.fetchVideoList()
        //     }, this.intervalTime)
        // }, this.delay)
    },
    methods: {
        fetchData() {
            this.fetchGroup()
            this.fetchVideoList(1000)
            this.fetchServices()
        },
        ...mapActions({
            fetchGroup: FETCH_GROUP,
            fetchVideoList: FETCH_VIDEO_LIST,
            searchVideoList: SEARCH_VIDEO_LIST,
            searchVideo: SEARCH_VIDEO,
            reupdateSearchVideo: REUPDATE_SEARCH_VIDEO,
            progress: PROGRESS,
            fetchServices: FETCH_SERVICES
        }),
        isNotEmpty(obj) {
            for (let name in obj) {
                return true
            }
            return false
        },
        more() {
            // this.size = 1000
            this.moreVideoObj.show.value = !this.moreVideoObj.show.value
            // this.fetchVideoList(this.size)
        },
        pageEvent(page) {
            clearInterval(this.interval)
            this.size = 10
            this.searchVideoList(page)
        },
        changeTab(tab) {
            switch (tab) {
                case 'isAlarm':
                    this.isAlarm = true
                    break
                default:
                    this.isAlarm = false
                    break
            }
        },
        changeGroup(e) {
            let val = e.target.value, index = this.groups.indexOf(val)

            if (index > -1) {
                this.groups.splice(index, 1)
            } else {
                this.groups.push(val)
            }
        },
        changeVids(e) {
            let val = e.target.value, index = this.vids.indexOf(val), id = e.target.id, key = this.ids.indexOf(id)

            if (index > -1) {
                this.vids.splice(index, 1)
                this.ids.splice(key, 1)
            } else {
                this.vids.push(val)
                this.ids.push(id)
            }
        },
        changeVideoUpload(arr) {
            for (let i = 0; i < arr.length; i++) {
                this.fileVideoList.push(arr[i])
            }
        },
        deleteFileItem(index) {
            this.vids.splice(index, 1)
            this.ids.splice(index, 1)
            this.fileVideoList.splice(index, 1)
        },
        search() {
            let infoErr = document.querySelector('[role=infoErr]')
            let fileErr = document.querySelector('[role=videoErr]')
            let storageText = '请输入入库名称'
            let thrText = '请输入阈值'
            let groupText = '请选择底库'

            if (this.isAlarm) {
                let thValue = document.querySelector('[name=threshold]') && document.querySelector('[name=threshold]').value

                if (!thValue && !this.getServices.PKStatus) {
                    infoErr.innerHTML = thrText
                    infoErr.style.display = 'inline-block'
                    return
                }
                if (!this.groups.length) {
                    infoErr.innerHTML = groupText
                    infoErr.style.display = 'inline-block'
                    return
                }
            } else {
                let groupName = document.querySelector('[name=group_name]').value

                if (!groupName) {
                    infoErr.innerHTML = storageText
                    infoErr.style.display = 'inline-block'
                    return
                }
            }
            if (!this.fileVideoList.length) {
                fileErr.style.display = 'inline-block'
                return
            }
            infoErr.style.display = 'none'
            fileErr.style.display = 'none'

            for (let i in this.fileVideoList) {
                let options = new FormData(), file = (this.fileVideoList[i].type == 'video/mp4' ? this.fileVideoList[i] : null)
                let thValue = document.querySelector('[name=threshold]') ? document.querySelector('[name=threshold]').value : 0
                let groupName = document.querySelector('[name=group_name]') ? document.querySelector('[name=group_name]').value : ''

                options.append('videos', file)
                options.append('vids', this.vids.toString())
                options.append('groups', this.groups.toString())
                if (!this.getServices.PKStatus) {
                    options.append('threshold', thValue)
                }
                options.append('group_name', groupName)
                for (let j in this.itemsObj) {
                    options.append(j, this.itemsObj[j])
                }
                this.searchVideo(options)
                this.vids = []
                this.ids = []
            }
            setTimeout(() => {
                this.interval = setInterval(() => {
                    this.fetchVideoList()
                }, this.intervalTime)
            }, this.delay)
            this.fileVideoList = []
            // this.itemsObj = Object.assign({}, this.moreTips)
        },
        reupdate(index) {
            let id = this.getVideoList[index].id

            this.reupdateSearchVideo(id)
            setTimeout(() => {
                this.interval = setInterval(() => {
                    this.fetchVideoList()
                }, this.intervalTime)
            }, 0)
        },
        goCapture(index) {
            let params = {
                id: this.getVideoList[index].id,
            }

            this.$router.push({
                name: URL.SEARCH.CAPTURE_VIDEO_SEARCH,
                params: params
            })
        },
        goAlarm(index) {
            let params = {
                id: this.getVideoList[index].id,
            }

            this.$router.push({
                name: URL.SEARCH.ALARM_VIDEO_SEARCH,
                params: params
            })
        },
        choseMore() {
            this.moreTipsObj.show.value = !this.moreTipsObj.show.value
        }
    },
    beforeDestroy() {
        clearInterval(this.interval)
    },
    destroyed() {
        clearInterval(this.interval)
    },
    components: {
        FileUploadComponent,
        TableComponent,
        PaginationComponent,
        ConfirmComponent,
        CrumbsComponent
    }
}
</script>

<style scoped>
h4{
    font-size: 14px;
    line-height: 24px;
    color: #fff;
    .tips{
        color: #9fa3ab;
        margin-left: 5px;
    }
}
.video-search{
    width: 100%;
    padding: 50px 80px;
    box-sizing: border-box;
    min-height: 100%;
    position: relative;
}
.result-con{
    /*padding: 20px 0;
    height: 88px;*/
}
.search-option{
    width: 100%;
    display: flex;
    font-size: 14px;
    line-height: 50px;
    color: #fff;
    background-image: linear-gradient(-180deg, #003F54 4%, #00283A 99%);
    border: 1px solid #00CBF9;
    border-radius: 7px;
    &>div{
        flex: 1; 
        border-right: 1px solid #003F54;
        &:last-child{
            border-right: none;
        }
    }
    .title{
        padding-left: 10px;
        .more{
            color: #81C3F3;
        }
        .chosemore{
            color: #f4b04f;
            float: right;
            margin-right: 10px;
            text-decoration: underline;
        }
        .error{
            color: crimson;
            margin-left: 5px;
            display: none;
        }
        .tab-item{
            padding-left: 15px;
            padding-right: 15px;
            line-height: 50px;
            display: inline-block;
            cursor: pointer;
            border-top-left-radius: 7px;
            &:first-child{
                margin-left: -10px;
            }
            &.last{
                margin-left: -10px;
            }
            &.active{
                background: #033141;
            }
        }
    }
    .condition{
        text-align: left;
        font-size: 12px;
        line-height: 30px;
        background-image: linear-gradient(-180deg, #000304 4%, #002636 99%);
        border-bottom-left-radius: 7px;
        border-bottom-right-radius: 7px;
        height: 140px;
        input.input-style{
            width: 200px;
            box-sizing: border-box;
            padding-left: 6px;
            height: 30px;
        }
        .condition-con{
            text-align: left;
            display: flex;
            width: 400px;
            margin: 0 auto;
            padding: 10px;
            height: 40px;
            &.storage{
                display: block;
                width: 450px;
                .groupname{
                    width: 330px;
                }
                p.info{
                    color: #4c91df;
                    line-height: 14px;
                    padding-left: 40px;
                }
            }
        }
        .group-select{
            height: 30px;
        }
        .img-con{
            width: 100%;
            height: 120px;
            line-height: 18px;
            position: relative;
        }
        .group-content{
            width: 360px;
            min-height: 30px;
            max-height: 60px;
            overflow: auto;
            .group-select{
                float: left;
                width: 25%;
                input{
                    float: left;
                    margin-top: 10px;
                }
                label{
                    white-space: nowrap;
                    overflow: hidden;
                    width: 80%;
                    margin-left: 2px;
                    display: inline-block;
                    text-overflow: ellipsis;
                }
            }
        }
        &.img-content{
            padding: 0;
        }
    }
}
.progress{
    position: absolute;
    top: 0;
    right: 80px;
    background: #FFF;
    padding: 0 5px 10px;
    margin: 5px 10px;
    border: 5px solid #5ebd5e;
    border-radius: 5px;
    width: 220px;
    height: 26px;
    span{
        font-size: 12px;
        line-height: 18px;
    }
    .progress-bg{
        background: rgba(0,0,0,.06);
    }
    .progress-bar{
        margin-top: 7px;
        height: 2px;
        background: #5ebd5e;
    }
}
.search-btn-content{
    margin-top: 20px;
    text-align: right;
}
.btn{
    display: inline-block;
    color: #fff;
    text-decoration: none;
    width: 90px;
    height: 30px;
    text-align: center;
    margin-left: 5px;
    background: #4990e2;
    border-radius: 3px;
    font-size: 12px;
    line-height: 30px;
    &.search{
        vertical-align: top;
        margin-left: 0;
    }
}
.search-content{
    width: 100%;
    min-height: 250px;
    background-color: #343d4e;
    display: flex;
    padding: 10px;
    box-sizing: border-box;
}
.nodata{
    text-align: center;
}
p.no-video{
    font-size: 16px;
    color: #fff;
}
.all-video-list{
    width: 100%;
    height: 230px;
    overflow: auto;
    border: 1px solid #ccc;
    .item{
        overflow: hidden;
        line-height: 28px;
        .video-checkbox{
            float: left;
            width: 10px;
            margin-left: 10px;
        }
        .video-name{
            float: left;
            white-space: nowrap;
            overflow: hidden;
            width: 80%;
            margin-left: 2px;
            display: inline-block;
            text-overflow: ellipsis;
        }
        .video-status{
            float: left;
            .success{
                margin-right: 5px;
                border-radius: 3px;
                padding: 2px 4px;
                background: #5ebd5e;
                color: #fff;
            }
        }
    }
}
.form-select{
    width: 84%;
}
.success{
    border-radius: 3px;
    padding: 2px 4px;
    background: #5ebd5e;
    color: #fff;
}
.danger{
    border-radius: 3px;
    padding: 2px 4px;
    background: #e66454;
    color: #fff;
}
.warning{
    border-radius: 3px;
    padding: 2px 4px;
    background: #f4b04f;
    color: #fff;
}
</style>