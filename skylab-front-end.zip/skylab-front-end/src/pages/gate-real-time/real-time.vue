<template>
    <div class="realtime">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="realtime_content">
        <div class="camera-group" role="monitor">
            <div class="deploy-camera" :style="itemStyle">
                <div class="col6 camera" id="camera1" ref="camera1">
                    <div class="row">
                        <div class="camera-panel">
                            <div class="head-title">
                                <button role="cam1" class="button-style" @click.prevent="selectCamera('1')">选择摄像头</button>
                                <input type="hidden" role="camValue1">
                                <select class="select input-style" name="resolution1" @change.prevent="changeResolution('1')">
                                    <option v-for="option in resolutions" :value="option.value">{{option.text}}</option>
                                </select>
                                <a href="#" class="clear-style" @click.prevent="clearCamera('1')"><i class="fa fa-times-circle"></i></a>
                                <a href="#" class="clear-style" @click.prevent="changeCameraSize('1')"><i class="fa fa-expand"></i></a>
                                <a href="#" class="clear-style" @click.prevent="refreshVideo('1')"><i class="fa fa-refresh"></i></a>
                            </div>
                            <div class="camera-body">
                                <RtmpPlayerComponent :options="playerOptions1" style="margin:1px 0 0 1px;">
                                </RtmpPlayerComponent>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col6 camera" id="camera2" ref="camera2">
                    <div class="row">
                        <div class="camera-panel">
                            <div class="head-title">
                                <button role="cam2" class="button-style" @click.prevent="selectCamera('2')">选择摄像头</button>
                                <input type="hidden" role="camValue2">
                                <select class="select input-style" name="resolution2" @change.prevent="changeResolution('2')">
                                    <option v-for="option in resolutions" :value="option.value">{{option.text}}</option>
                                </select>
                                <a href="#" class="clear-style" @click.prevent="clearCamera('2')"><i class="fa fa-times-circle"></i></a>
                                <a href="#" class="clear-style" @click.prevent="changeCameraSize('2')"><i class="fa fa-expand"></i></a>
                                <a href="#" class="clear-style" @click.prevent="refreshVideo('2')"><i class="fa fa-refresh"></i></a>
                            </div>
                            <div class="camera-body">
                                 <RtmpPlayerComponent :options="playerOptions2" style="margin:1px 0 0 1px;">
                                </RtmpPlayerComponent>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="deploy-camera" :style="itemStyle">
                <div class="col6 camera" id="camera3" ref="camera3">
                    <div class="row">
                        <div class="camera-panel">
                            <div class="head-title">
                                <button role="cam3" class="button-style" @click.prevent="selectCamera('3')">选择摄像头</button>
                                <input type="hidden" role="camValue3">
                                <select class="select input-style" name="resolution3" @change.prevent="changeResolution('3')">
                                    <option v-for="option in resolutions" :value="option.value">{{option.text}}</option>
                                </select>
                                <a href="#" class="clear-style" @click.prevent="clearCamera('3')"><i class="fa fa-times-circle"></i></a>
                                <a href="#" class="clear-style" @click.prevent="changeCameraSize('3')"><i class="fa fa-expand"></i></a>
                                <a href="#" class="clear-style" @click.prevent="refreshVideo('3')"><i class="fa fa-refresh"></i></a>
                            </div>
                            <div class="camera-body">
                                <RtmpPlayerComponent :options="playerOptions3" style="margin:1px 0 0 1px;">
                                </RtmpPlayerComponent>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col6 camera" id="camera4" ref="camera4">
                    <div class="row">
                        <div class="camera-panel">
                            <div class="head-title">
                                <button role="cam4" class="button-style" @click.prevent="selectCamera('4')">选择摄像头</button>
                                <input type="hidden" role="camValue4">
                                <select class="select input-style" name="resolution4" @change.prevent="changeResolution('4')">
                                    <option v-for="option in resolutions" :value="option.value">{{option.text}}</option>
                                </select>
                                <a href="#" class="clear-style" @click.prevent="clearCamera('4')"><i class="fa fa-times-circle"></i></a>
                                <a href="#" class="clear-style" @click.prevent="changeCameraSize('4')"><i class="fa fa-expand"></i></a>
                                <a href="#" class="clear-style" @click.prevent="refreshVideo('4')"><i class="fa fa-refresh"></i></a>
                            </div>
                            <div class="camera-body">
                                <RtmpPlayerComponent :options="playerOptions4" style="margin:1px 0 0 1px;">
                                </RtmpPlayerComponent>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <ConfirmComponent :show="showInfoConfirm" title="选择相机" :confirm="submitCameraInfo" :cancel="cancelCameraInfo">
            <div slot="content">
                <deployCameraComponent :deploys="getCameraConfigList" :selectedCameraId="selectedCameraId" v-on:selection="playVideo"></deployCameraComponent>
            </div>
        </ConfirmComponent>
        <div class="alarm" :style="alarmStyle">
            <RealTimeAlarmComponent :alarms="realtimeAlarmData" :alarmStatus="alarmStatus" v-on:openDetailDialog="openDetailDialog" v-on:viewMoreAlarms="viewMoreAlarms"></RealTimeAlarmComponent>
        </div>
    </div>
    <div class="capture-content">
        <RealTimeCaptureComponent :captures="realtimeCaptureData" v-on:openDetailDialog="openDetailDialog"></RealTimeCaptureComponent>
    </div>
    <audio ref="audio" autoplay></audio>  
     <DialogComponent :show="showDetails" title="查看详情">
            <div slot="content">
                <AlarmDetails :data="alarmDialogData"></AlarmDetails>
            </div>
    </DialogComponent>     
    </div>
</template>

<script>
    import {GET_HEIGHT, SET_HEIGHT, GET_SERVICES } from 'store/modules/common'
    import {mapActions, mapGetters, mapMutations } from 'vuex'
    import ConfirmComponent from '@nanyun/confirm'
    import DialogComponent from '@nanyun/dialog'
    import deployCameraComponent from 'pages/gate-real-time/deploy-camera.vue'
    import {FETCH_CAMERA_CONFIG_LIST, GET_CAMERA_CONFIG_LIST} from 'store/modules/realtime'
    import {GET_CAMERAS, FETCH_CAMERAS } from 'store/modules/cameras'
    import { RESOLUTIONS, ALARM_STATUS} from 'common/config'
    import RealTimeAlarmComponent from 'pages/gate-real-time/real-time-alarms.vue'
    import RealTimeCaptureComponent from 'pages/gate-real-time/real-time-captures.vue'
    import {GET_REALTIME_CAPTURES, GET_REALTIME_ALARMS, GET_REALTIME_ALARM, GET_REALTIME_CAPTURE, SET_CAPTURE} from 'store/modules/alarms'
    import {ALARM, ALARM_WEB_SOCKET, DISCONNECT_ALARM_WEB_SOCKET, VIDEO_WEB_SOCKET, DISCONNECT_VIDEO_WEB_SOCKET, GET_VIDEO_URL, SET_VIDEO_URL} from 'store/modules/common'
    import mp3 from 'medias/alarm.mp3'
    import CrumbsComponent from 'common/components/crumbs.vue'
    import URL from 'common/url'
    import AlarmDetails from 'pages/gate-real-time/alarm-details.vue'
    import {GET_CAPTURE_HISTORY_LIST, FETCH_CAPTURE_HISTORY_LIST} from 'store/modules/capture_history'
    import {GET_ALARM_HISTORY_LIST, FETCH_ALARM_HISTORY_LIST} from 'store/modules/alarm_history'
    import RtmpPlayerComponent from 'common/components/rtmpPlayer.vue'

    let cameraPromise

    export default{
        data() {
            return {
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '实时监控',
                    silent: true
                }],
                showInfoConfirm: {
                    value: false
                },
                showDetails: {
                    value: false
                },
                selectedCameraId: -1,
                camIndex: 0,
                resolutions: RESOLUTIONS,
                alarmStatus: ALARM_STATUS,
                viewLevel: 0,
                originWidth: 0,
                alarmDialogData: {},
                realtimeCaptureData: [],
                realtimeAlarmData: [],
                selectedCameraNames: [],
                playerOptions1: {
                    width: 364,
                    sources: [{
                        type: 'rtmp/flv',
                        src: '#'
                    }],
                    muted: false
                },
                playerOptions2: {
                    width: 364,
                    sources: [{
                        type: 'rtmp/flv',
                        src: '#'
                    }],
                    muted: false
                },
                playerOptions3: {
                    width: 364,
                    sources: [{
                        type: 'rtmp/flv',
                        src: '#'
                    }],
                    muted: false
                },
                playerOptions4: {
                    width: 364,
                    sources: [{
                        type: 'rtmp/flv',
                        src: '#'
                    }],
                    muted: false
                },
                itemStyle: {
                    height: 208 + 'px'
                },
                alarmStyle: {
                    height: 400 + 'px'
                }
            }
        },
        computed: {
            ...mapGetters({
                getWinHeight: GET_HEIGHT,
                getServices: GET_SERVICES,
                getCameraConfigList: GET_CAMERA_CONFIG_LIST,
                getCameras: GET_CAMERAS,
                getRealtimeCaptures: GET_REALTIME_CAPTURES,
                getRealtimeAlarms: GET_REALTIME_ALARMS,
                getRealtimeAlarm: GET_REALTIME_ALARM,
                getRealtimeCapture: GET_REALTIME_CAPTURE,
                getCaputreHistoryList: GET_CAPTURE_HISTORY_LIST,
                getAlarmHistoryList: GET_ALARM_HISTORY_LIST,
                getVideoUrl: GET_VIDEO_URL
            }),
        },
        created() {
            cameraPromise = Promise.all([this.fetchCameras(true), this.fetchCaptureHistoryList(), this.fetchAlarmHistoryList(), new Promise((resolve, reject) => {
                setTimeout(() => {
                    resolve()
                }, 600)
            })])
        },
        watch: {
            getRealtimeAlarm(alarm) {
                let list = this.realtimeAlarmData

                if (localStorage.getItem('alarmStatus') == '1') {
                    this.$refs.audio.loop = true
                } else {
                    this.$refs.audio.loop = false
                }
                this.$refs.audio.src = mp3
                list.unshift(alarm)
                if (list && list.length > 10) {
                    list = list.slice(0, 10)
                }
                this.realtimeAlarmData = list
            },
            getRealtimeCapture(info) {
                let externalData = this.realtimeCaptureData
                let merge = false

                // for (let i = 0, l = externalData.length; i < l; i++) {
                //     if ((externalData[i].camera_name + '_' + externalData[i].track_id) == (info.camera_name + '_' + info.track_id)) {
                //         if (+new Date() - externalData[i].updateTimestamp < 5000) {
                //             return
                //         }
                //         externalData[i].updateTimestamp = +new Date()
                //         externalData[i].faces = (info.face ? [info.face] : [info.body]).concat(externalData[i].faces || [])
                //         externalData[i].face = info.face
                //         externalData[i].body = info.body
                //         externalData[i].photos = info.photos
                //         //externalData[i].is_alarm = info.is_alarm
                //         //externalData[i].capture_ids.push(info.id)
                //         merge = true
                //         break
                //     }
                // }
                if (!merge) {
                    if (!info.face) {
                        info.faces = [info.body]
                    } else {
                        info.faces = [info.face]
                        //info.capture_ids = [info.id]
                        info.updateTimestamp = +new Date()
                    }
                    externalData.unshift(info)
                }

                if (externalData && externalData.length > 30) {
                    externalData = externalData.slice(0, 30)
                }
                this.realtimeCaptureData = externalData
            }
        },
        mounted() {
            this.initCameraSize()
            cameraPromise.then(() => {
                this.renderResolutionSelect()
                this.initAlarmWs()
                setTimeout( () => { this.initCapturesAndAlarms() }, 3000)
            })
        },
        methods: {
            initCapturesAndAlarms() {
                for (let capture of this.getCaputreHistoryList) {
                    for (let i of this.selectedCameraNames) {
                        if (i == capture.camera_name) {
                            this.realtimeCaptureData.push(capture)
                            break
                        }
                    }
                }
                for (let alarm of this.getAlarmHistoryList) {
                    for (let i of this.selectedCameraNames) {
                        if (i == alarm.camera_name) {
                            this.realtimeAlarmData.push(alarm)
                            break
                        }
                    }
                }
            },
            filterCameraName(cameraName) {
                if (this.selectedCameraNames.length) {
                    for (let i of this.selectedCameraNames) {
                        if (i != cameraName ) {
                            this.selectedCameraNames.push(cameraName)
                        }
                    }
                } else {
                    this.selectedCameraNames.push(cameraName)
                }
            },
            selectCamera(camIndex) {
                let camId = document.querySelector('[role=camValue' + camIndex + ']').value

                this.selectedCameraId = -1
                if (camId) {
                    this.selectedCameraId = parseInt(camId)
                }
                this.camIndex = camIndex
                this.fetchCameraConfigList().then(() => {
                    this.showInfoConfirm.value = true
                })
            },
            clearCamera(camIndex) {
                let key = 'camera_' + camIndex
                let camId = document.querySelector('[role=camValue' + camIndex + ']').value

                localStorage.removeItem(key)
                document.querySelector('[role=cam' + camIndex + ']').innerHTML = '选择摄像头'
                document.querySelector('[role=camValue' + camIndex + ']').value = -1
                this.setVideoUrl({
                    data: {
                        push: ''
                    },
                    camIndex: parseInt(camIndex)
                })
                switch (parseInt(camIndex)) {
                    case 1 :
                        this.playerOptions1.sources[0].src = '#'
                        break
                    case 2 :
                        this.playerOptions2.sources[0].src = '#'
                        break
                    case 3 :
                        this.playerOptions3.sources[0].src = '#'
                        break
                    case 4 :
                        this.playerOptions4.sources[0].src = '#'
                        break
                }
                this.disconnectAlarmWebSocket()
                this.initAlarmWs('reload')
            },
            renderResolutionSelect() {
                for (let i = 1; i <= 4; i++) {
                    let key = 'resolution_' + i
                    let resolution = localStorage.getItem(key)

                    if (!resolution) {
                        resolution = 'sd'
                    }
                    document.querySelector('[name=resolution' + i + ']').value = resolution
                }
            },
            initCameraSize() {
                let obj = document.getElementById('camera1')
                let width = obj.clientWidth
                let height = parseInt(width) * 9 / 16

                this.itemStyle = {
                    height: `${height + 45}px`
                }
                this.alarmStyle = {
                    height: `${(height + 42) * 2}px`
                }
                for (let i = 1; i <= 4; i++) {
                    let obj = document.getElementById('camera' + i)
                    let width = obj.clientWidth
                    let height = obj.clientHeight - 34

                    switch (i) {
                        case 1 :
                            this.playerOptions1.width = width
                            break
                        case 2 :
                            this.playerOptions2.width = width
                            break
                        case 3 :
                            this.playerOptions3.width = width
                            break
                        case 4 :
                            this.playerOptions4.width = width
                            break
                    }
                }
            },
            playVideo(camera, index) {
                if (!index) {
                    index = this.camIndex
                }
                let alarmObj = {
                    camIndex: index,
                    cid: camera.id
                }

                if (this.selectedCameraId != -1) {
                    this.disconnectAlarmWebSocket(this.selectedCameraId)
                }
                this.alarmWebSocket(alarmObj)
                document.querySelector('[role=cam' + index + ']').innerHTML = camera.name
                document.querySelector('[role=camValue' + index + ']').value = camera.id
                localStorage.setItem('camera_' + index, camera.id)
                this.showInfoConfirm.value = false
                this.openVideoWs(camera, index)
            },
            openVideoWs(camera, index) {
                let resolution = document.querySelector('[name=resolution' + index + ']').value
                let wsUrl = `ws://${camera.media_server ? camera.media_server.ip : '127.0.0.1'}:${camera.media_server ? camera.media_server.port : '8099'}/monitor/?id=${camera.id}&src=${camera.src}&protocol=rtmp&resolution=${resolution || 'sd'}&tcp=true`
                let obj = {
                    url: wsUrl,
                    camIndex: index
                }

                this.videoWebSocket(obj)
                setTimeout( () => {
                    let videoUrl = this.getVideoUrl[index - 1]

                    if (!videoUrl) {
                        return
                    }
                    switch (parseInt(index)) {
                        case 1 :
                            this.playerOptions1.sources[0].src = this.getVideoUrl[index - 1]
                            break
                        case 2 :
                            this.playerOptions2.sources[0].src = this.getVideoUrl[index - 1]
                            break
                        case 3 :
                            this.playerOptions3.sources[0].src = this.getVideoUrl[index - 1]
                            break
                        case 4 :
                            this.playerOptions4.sources[0].src = this.getVideoUrl[index - 1]
                            break
                    }
                }, 3000)
            },
            initAlarmWs(type) {
                for (let i = 1; i <= 4; i++) {
                    let key = 'camera_' + i
                    let cameraId = localStorage.getItem(key)

                    if (cameraId) {
                        for (let camera of this.getCameras) {
                            if (camera.id == cameraId) {
                                this.camIndex = i
                                if (type == 'reload') {
                                    this.alarmWebSocket({
                                        camIndex: i,
                                        cid: camera.id
                                    })
                                } else {
                                    this.playVideo(camera, i)
                                    this.filterCameraName(camera.name)
                                }
                            }
                        }
                    }
                }
            },
            openDetailDialog(details) {
                this.alarmDialogData = details
                this.$refs.audio.src = ''
                this.showDetails.value = true
            },
            viewMoreAlarms() {
                this.$refs.audio.src = ''
                window.open(`alarm-history`)
            },
            changeResolution(camIndex) {
                let resolution = document.querySelector('[name=resolution' + camIndex + ']').value
                let key = 'resolution_' + camIndex
                let camId = document.querySelector('[role=camValue' + camIndex + ']').value

                localStorage.setItem(key, resolution)
                if (!camId) {
                    return
                }
                for (let camera of this.getCameras) {
                    if (camera.id == camId) {
                        this.playVideo(camera, camIndex)
                    }
                }
            },
            changeCameraSize(camIndex) {
                localStorage.setItem('viewLevel', this.viewLevel)
                this.resizeCameraSize(camIndex, this.viewLevel)
                this.viewLevel += 1
                if (this.viewLevel >= 3) this.viewLevel = 0
            },
            refreshVideo(cameraIndex) {
                switch (parseInt(cameraIndex)) {
                    case 1:
                        this.playerOptions1.muted = !this.playerOptions1.muted
                        break
                    case 2:
                        this.playerOptions2.muted = !this.playerOptions2.muted
                        break
                    case 3:
                        this.playerOptions3.muted = !this.playerOptions3.muted
                        break
                    case 4:
                        this.playerOptions4.muted = !this.playerOptions4.muted
                        break
                }
            },
            resizeCameraSize(camIndex, viewLevel) {
                let ele = document.getElementById('camera' + camIndex).childNodes[0]
                //let expand = ele.childNodes[0].childNodes[6].childNodes[0]
                let monitorEle = document.querySelector('[role=monitor]')
                let obj = document.getElementById('camera' + camIndex)
                let width = obj.clientWidth
                let height = obj.clientHeight

                switch (viewLevel) {
                    case 0 :
                        ele.className = 'real-time-big ' + ele.className
                        ele.style.width = parseInt(width) * 2 + 8 + 'px'
                        ele.style.height = parseInt(height) * 2 + 10 + 'px'
                        switch (parseInt(camIndex)) {
                            case 1 :
                                this.originWidth = this.playerOptions1.width
                                this.playerOptions1.width = ele.style.width
                                break
                            case 2 :
                                this.originWidth = this.playerOptions2.width
                                this.playerOptions2.width = ele.style.width
                                break
                            case 3 :
                                this.originWidth = this.playerOptions3.width
                                this.playerOptions3.width = ele.style.width
                                break
                            case 4 :
                                this.originWidth = this.playerOptions4.width
                                this.playerOptions4.width = ele.style.width
                                break
                        }
                        break
                    case 1 :
                        //expand.className = expand.className.replace(new RegExp('(\\s|^)' + 'fa-expand' + '(\\s|$)'), ' fa-compress')
                        ele.className = ele.className.replace(new RegExp('(\\s|^)' + 'real-time-big' + '(\\s|$)'), '')
                        ele.className = 'real-time-full ' + ele.className
                        switch (parseInt(camIndex)) {
                            case 1 :
                                this.playerOptions1.width = document.documentElement.clientWidth
                                break
                            case 2 :
                                this.playerOptions2.width = document.documentElement.clientWidth
                                break
                            case 3 :
                                this.playerOptions3.width = document.documentElement.clientWidth
                                break
                            case 4 :
                                this.playerOptions4.width = document.documentElement.clientWidth
                                break
                        }
                        break
                    case 2 :
                        //expand.className = expand.className.replace(new RegExp('(\\s|^)' + 'fa-compress' + '(\\s|$)'), ' fa-expand')
                        ele.className = ele.className.replace(new RegExp('(\\s|^)' + 'real-time-full' + '(\\s|$)'), '')
                        ele.style.width = 'auto'
                        ele.style.height = '100%'
                        switch (parseInt(camIndex)) {
                            case 1 :
                                this.playerOptions1.width = this.originWidth
                                break
                            case 2 :
                                this.playerOptions2.width = this.originWidth
                                break
                            case 3 :
                                this.playerOptions3.width = this.originWidth
                                break
                            case 4 :
                                this.playerOptions4.width = this.originWidth
                                break
                        }
                        break
                }
            },
            ...mapActions({
                fetchCameraConfigList: FETCH_CAMERA_CONFIG_LIST,
                fetchCameras: FETCH_CAMERAS,
                alarmWebSocket: ALARM_WEB_SOCKET,
                videoWebSocket: VIDEO_WEB_SOCKET,
                fetchCaptureHistoryList: FETCH_CAPTURE_HISTORY_LIST,
                fetchAlarmHistoryList: FETCH_ALARM_HISTORY_LIST
            }),
            ...mapMutations({
                setCapture: SET_CAPTURE,
                disconnectAlarmWebSocket: DISCONNECT_ALARM_WEB_SOCKET,
                disconnectVideoWebSocket: DISCONNECT_VIDEO_WEB_SOCKET,
                setVideoUrl: SET_VIDEO_URL
            })
        },
        beforeDestroy() {
            this.disconnectAlarmWebSocket(),
            this.disconnectVideoWebSocket()
        },
        components: {
            ConfirmComponent,
            deployCameraComponent,
            RealTimeAlarmComponent,
            RealTimeCaptureComponent,
            CrumbsComponent,
            AlarmDetails,
            RtmpPlayerComponent,
            DialogComponent
        }
    }
</script>

<style scoped>
    .realtime{
        padding: 50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        .realtime_content{
            margin-top:10px;
            .camera-group{
                width:66.6%;
                position: relative;
                float:left;
                .deploy-camera {
                    overflow:hidden;
                    height: 251px;
                    margin-bottom: 1px;
                    margin-left:5px;
                    .col6{
                        width:49%;
                        float:left;
                        position: static;
                        height: 100%;
                        min-height: 1px;
                        padding-left: 11px;
                        padding-right: 11px;
                    }
                    .camera{
                        overflow: hidden;
                        height: 98%;
                        padding: 0;
                        margin: 2px;
                        line-height: 0;
                        border:1px solid #00CBF9;
                        border-radius: 7px;
                        background-image: linear-gradient(-180deg, #003F54 4%, #00283A 99%);
                        .row{
                            height: 100%;
                            width: auto;
                            /*margin-left: -11px;*/
                            /*margin-right: -11px;*/
                            .camera-panel{
                                border: 0 none;
                                position: relative;
                                box-shadow: none;
                                border-radius: 2px;
                                .head-title{
                                    height:34px;
                                    border-bottom: 1px solid #343d4e;
                                    z-index:100;
                                    .button-style{
                                        margin-top:5px;
                                        padding: 3px 8px;
                                        margin-left:5px;
                                    }
                                    .clear-style{
                                        float: right;
                                        font-size: 18px;
                                        color: #FFF;
                                        padding: 3px 8px;
                                        margin-top: 5px;
                                    }
                                    .input-style{
                                        min-width:100px;
                                    }
                                }
                            }
                        }
                    }
                    .real-time-big{
                        position : absolute;
                        top : 2px;
                        z-index : 999;
                        background-image: linear-gradient(-180deg, #003F54 4%, #00283A 99%);
                        left:7px;
                        overflow: hidden;
                        border: 1px solid #00CBF9;
                        border-radius: 7px;
                    }
                    .real-time-full{
                        position : fixed;
                        width : auto !important;
                        height : auto !important;
                        top : 0;
                        left : 0;
                        right : 0;
                        bottom : 0;
                        z-index : 10000;
                        background-image: linear-gradient(-180deg, #003F54 4%, #00283A 99%);
                        overflow: hidden;
                        border: 1px solid #00CBF9;
                        border-radius: 7px;
                    }
                }
                
            }
            .alarm{
                width:33.2%;
                height: 500px;
                overflow:hidden;
                position: relative;
                float:left;
                background-image: linear-gradient(-180deg, rgba(3,162,214,0.30) 0%, rgba(0,115,166,0.30) 100%);
                border: 1px solid #00CBF9;
                border-radius: 8px;
            }
        }
        .capture-content{
            height: 280px;
            overflow-y: auto;
            overflow-x: hidden;
            width:99.7%;
            margin:0px 0 5px 7px;
        }
    }
</style>