<template>
    <div class="member-info">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="table_content">
            <!--<div class="condition">
                <input type="text" class="input-style" placeholder="请输入姓名" v-model="searchObj.name"/>
                <input type="text" class="input-style" placeholder="请输入证件号码" v-model="searchObj.cert_id"/>
            </div>-->
            <div class="condition">
                <!--<select name="sex" v-model="searchObj.gender">
                    <option value="">性别/不限</option>
                    <option :value="item.value" v-for="item in bulkItems.gender">{{item.text}}</option>
                </select>
                <select name="record" v-model="searchObj.criminalRecord">
                    <option value="">案底/不限</option>
                    <option :value="item.value" v-for="item in bulkItems.crmRecord">{{item.text}}</option>
                </select>
                <select name="id" v-model="searchObj.label">
                    <option value="">身份类型/不限</option>
                    <option :value="item.value" v-for="item in bulkItems.certType">{{item.text}}</option>
                </select>-->
                <select name="group" v-model="searchObj.groupId">
                    <option value="">底库/不限</option>
                    <option :value="item.id" v-for="item in getGroup">{{item.name}}</option>
                </select>
                <a href="#" class="button-style search" @click.prevent="search">搜索</a>
                <!--<a href="#" class="button-style" @click.prevent="bulk" style="float: right;">批量新建</a>-->
                <!--<a href="#" class="button-style" @click.prevent="add" style="float: right;">新建</a>-->
            </div>
            <TableComponent :data="getPhoto" :columns="columns" :trHeight="style.height">
                <span v-for="(item, index) in getPhoto" :slot="'array' + index">
                    <span>{{item.name}}</span><br>
                    <span>证件号: {{item.cert_id ? item.cert_id : '-'}}</span>
                </span>
                <span v-for="(item, index) in getPhoto" :slot="'photos' + index">
                    <span v-if="item.path ">
                        <img :src="item.path" @click.prevent="viewImage(item.path)" title="查看原图" :style="style.imgStyle">
                    </span>
                    <span v-else><i class="fa fa-warning"></i>暂无图片</span>
                </span>
                <span v-for="(item, index) in getPhoto" :slot="'events' + index">
                    <a href="#" title="重新入库"  @click.prevent="addGroup(item)">重新入库</a>
                    <!--&nbsp;&nbsp;-->
                    <!--<a href="#" title="删除"  @click.prevent="del(index)">删除</a>-->
                </span>
            </TableComponent>
            <div>
                <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
            </div>
            <ConfirmComponent :show="deleteObj.show" :title="deleteObj.text" :confirm="deleteObj.confirm" :content="deleteObj.content">
            </ConfirmComponent>
            <DialogComponent :show="viewBigImage" title="查看原图">
                <div slot="content">
                    <div style="text-align: center">
                        <img :src="imageSrc"></img>
                    </div>
                </div>
            </DialogComponent>
            <ConfirmComponent :show="importGroup" title="入库" :confirm="submitImport" :cancel="cancelGroup">
                <div slot="content">
                    <CaptureAlarmPutinComponent :data="importObj" :groups="getGroup"></CaptureAlarmPutinComponent>
                </div>
            </ConfirmComponent>
        </div>    
    </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import TableComponent from '@nanyun/table'
import PaginationComponent from '@nanyun/pagination'
import DialogComponent from '@nanyun/dialog'
import ConfirmComponent from '@nanyun/confirm'
import {verifyCertId, verifyGender} from 'common/utils'
import { GENDER, CERTTYPE, CRIMINALRECORD, LABEL } from 'common/config'
import {GET_PHOTO, FETCH_PHOTO, DEL_PHOTO, GET_PHOTO_PAGE, ADD_MEMBER} from 'store/modules/member'
import {GET_GROUP, FETCH_GROUP} from 'store/modules/group'
import CrumbsComponent from 'common/components/crumbs.vue'
import URL from 'common/url'
import CaptureAlarmPutinComponent from 'common/components/capture-alarm-putin.vue'

export default {
    data() {
        return {
            crumbs: [{
                name: '首页',
                path: {
                    name: URL.HOME
                }
            }, {
                name: '照片管理',
                slient: true
            }],
            memberData: {},
            searchObj: {
                certId: '',
                criminalRecord: '',
                label: '',
                groupId: '',
                gender: ''
            },
            style: {
                imgStyle: {
                    width: 'auto',
                    height: '110px',
                    marginRight: '5px',
                    maxWidth: '100%',
                    cursor: 'pointer'
                },
                height: '124px'
            },
            columns: [{
                title: '图像预览',
                type: 'img',
                width: '320px',
                prop: 'photos'
            }, {
                title: '姓名/证件号',
                prop: ['name', 'cert_id'],
                width: '210px',
            }, {
                title: '底库',
                prop: 'group',
                handle: d => {
                    if (typeof d === 'object') {
                        return d.name
                    }
                }
            }, {
                title: '性别',
                prop: 'subject',
                handle: d => {
                    if (d.gender == 0) {
                        return '未知'
                    } else if (d.gender == 1) {
                        return '男'
                    } else {
                        return '女'
                    }
                }
            }, {
                title: '案底',
                prop: 'subject',
                handle: d => {
                    if (d.criminal_record == 0) {
                        return '未知'
                    } else if (d.criminal_record == 1) {
                        return '无'
                    } else {
                        return '有'
                    }
                }
            }, {
                title: '身份类型',
                prop: 'subject',
                handle: d => {
                    if (d.label == 0) {
                        return '未知'
                    } else if (d.label == 1) {
                        return '普通人员'
                    } else {
                        return '可疑人员'
                    }
                }
            }, {
                title: '备注',
                prop: 'remark',
                handle: d => {
                    if (!d) {
                        return '-'
                    } else {
                        return d
                    }
                }
            }, {
                title: '操作',
                type: 'events'
            }],
            index: '',
            path: '',
            imgList: [],
            deleteObj: {
                autoClose: 10000,
                text: '确认删除',
                content: '确定删除该照片?',
                show: {
                    value: false
                },
                confirm: () => {
                    this.delMember(this.index).then(() => {
                        this.fetchMember()
                    })
                }
            },
            viewBigImage: {
                value: false
            },
            imageSrc: '',
            importGroup: {
                value: false
            },
            importObj: {},
            bulkItems: {
                gender: GENDER,
                certType: CERTTYPE,
                crmRecord: CRIMINALRECORD,
                label: LABEL
            },
        }
    },
    created() {
        this.fetchData()
    },
    computed: {
        ...mapGetters({
            getGroup: GET_GROUP,
            getPage: GET_PHOTO_PAGE,
            getPhoto: GET_PHOTO,
        }),
    },
    methods: {
        fetchData() {
            let groupId = this.$route.params.groupId
            let obj = {}

            if (groupId) {
                obj = {
                    'group_id': groupId
                }
                this.searchObj.groupId = groupId
            }
            this.fetchGroup()
            this.fetchMember(obj)
        },
        ...mapActions({
            fetchGroup: FETCH_GROUP,
            fetchMember: FETCH_PHOTO,
            delMember: DEL_PHOTO,
            addMember: ADD_MEMBER
        }),
        // ...mapMutations({
        //     clearBulkUploadError: CLEAR_BULK_UPLOAD_ERROR
        // }),
        search() {
            this.fetchMember(this.searchObj)
        },
        del(index) {
            this.deleteObj.show.value = !this.deleteObj.show.value
            this.memberData = Object.assign({}, this.getPhoto[index])
            this.index = this.memberData.id
        },
        pageEvent(page) {
            this.searchObj.page = page
            this.fetchMember(this.searchObj)
        },
        viewImage(src) {
            this.viewBigImage.value = true
            this.imageSrc = src
        },
        addGroup(photo) {
            this.importGroup.value = !this.importGroup.value
            this.memberData = Object.assign({}, photo)
            console.log(this.memberData)
            this.importObj = Object.assign({}, {
                path: this.memberData.path,
                'group_id': this.memberData.group_id || this.getGroup[0].id,
                gender: this.memberData.subject.gender || this.bulkItems.gender[0].value,
                'cert_type': this.memberData.subject.cert_type || this.bulkItems.certType[0].value,
                'criminal_record': this.memberData.subject.criminal_record || this.bulkItems.crmRecord[0].value,
                label: this.memberData.subject.label || this.bulkItems.label[0].value,
                remark: '',
                name: ''
            })
            console.log(this.importObj)
        },
        submitImport() {
            // this.importObj.fromCapture = true
            this.importObj.timestamp = this.memberData.timestamp
            this.addMember(this.importObj)
        },
    },
    components: {
        TableComponent,
        PaginationComponent,
        DialogComponent,
        ConfirmComponent,
        CrumbsComponent,
        CaptureAlarmPutinComponent
    }
}
</script>

<style scoped>
    @keyframes rotate{
        0%{-webkit-transform:rotate(0);transform:rotate(0)}
        50%{-webkit-transform:rotate(180deg);transform:rotate(180deg)}
        100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}
    }
    .member-info{
        height: 100%;
        width: 100%;
        padding: 50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        form{
            height: 100%;
        }
        .condition{
            margin-top: 16px;
            margin-bottom: 15px;
            input{
                /*border-radius: 4px;*/
                height: 30px;
                width: 200px;
                box-sizing: border-box;
                background: #163C4C;
                border: 1px solid #FFFFFF;
                box-shadow: 0 2px 4px 0 rgba(0,0,0,0.50);
                border-radius: 8px;
                outline: none;
                color: #FFF;
                padding: 3px 5px;
            }
            select {
                border: 1px solid #FFFFFF;
                box-shadow: 0 2px 4px 0 rgba(0,0,0,0.50);
                border-radius: 8px;
                outline: none;
                color: #FFF;
                padding: 3px 5px;
                height: 30px;
                width: 200px;
                padding-left: 6px;
                background: url(../../images/arrow-down.png) right center no-repeat #163C4C;
            }
        }
        .btn{
            display: inline-block;
            color: #fff;
            text-decoration: none;
            width: 90px;
            height: 30px;
            text-align: center;
            margin-left: 5px;
            background: #4990e2;
            border-radius: 3px;
            font-size: 12px;
            line-height: 30px;
            &.search{
                vertical-align: top;
                margin-left: 0;
            }
            &.bulkbtn{
                height: 24px;
                line-height: 24px;
                margin-left: 0;
                color: #FFF;
                outline: none;
                cursor: pointer;
                background-image: linear-gradient(-180deg, #0082AC 0%, #008BC8 100%);
                border: 1px solid #FFFFFF;
                box-shadow: 0 1px 2px 0 #50E3C2;
                border-radius: 8px;
            }
        }
        .fileupload{
            position: absolute;
            width: 100px;
            height: 24px;
            opacity: 0;
        }
        .panel-body.new-member{
            display: flex;
            width: 620px;
            opacity: 0.8;
            background-image: linear-gradient(-180deg, #000304 4%, #002636 99%);
            border: 0 solid #FFFFFF;
            border-radius: 7px;
            padding: 10px;
            .member-img{
                flex: 1;
                position: relative;
                width: 100%;
                height: 338px;
                background: #f0f0f0;
                border: 1px solid #d6d6d6;
                .thumbnail{
                    float: left;
                    width: 33%;
                    height: 30%;
                    margin-top: 12px;
                    position: relative;
                }
                img{
                    max-width: 100%;
                    max-height: 100%;
                }
            }
            .member-items{
                flex: 1;
            }
        }
        .bulkcontainer{
            opacity: 0.8;
            background-image: linear-gradient(-180deg, #000304 4%, #002636 99%);
            border: 0 solid #FFFFFF;
            border-radius: 7px;
            padding: 10px;
        }
        .uploadtips{
            line-height: 18px;
            margin-bottom: 10px;
            color: #39b3d7;
            .text-primary{
                color: #39b3d7;
            }
            i{
                margin-right: 5px;
            }
            span,.text-sky{
                color: #39b3d7;
            }
        }
        .col9{
            width:70%;
            float:left;
            min-height: 1px;
            &.bulk-info-check{
                display: flex;
                div{
                    flex: 1;
                    line-height: 24px;
                    color: #fff;
                }
            }
        }
        .form-select{
            width: 86%;
        }
        .minWidth{
            min-width:150px;
        }
        .success-title{
            font-size:16px;
            font-weight:bold;
            line-height:32px;
        }
        .form-group-info{
            text-align: center;
            width: 100%;
            .left-tag{
                margin-right: 20px;
            }
        }
        .success-info{
            display: flex;
        }
        .fail-table{
            text-align: left;
        }
        .panel-body.bulkcontainer{
            width: 420px;
            &>div{
                width: 100%;
            }
        }
        .loading>div{
            border-radius: 100%;
            margin: 2px;
            border: 2px solid #4990e2;
            border-bottom-color: transparent;
            height: 26px;
            width: 26px;
            background: 0 0!important;
            display: inline-block;
            -webkit-animation: rotate .75s 0s linear infinite;
            animation: rotate .75s 0s linear infinite;
        }
        .img-more{
            float: right;
            /*height: 110px;*/
            line-height: 110px;
            color: #5ab5f1;
            font-size: 16px;
        }
        .panel-body.img-show-list{
            width: 380px;
            display: inline-flex;
            flex-wrap: wrap;
            align-content: flex-start;
            .img-show-item{
                flex: 1;
                img{
                    width: 90px;
                    height: 110px;
                }
            }
        }
    }
</style>