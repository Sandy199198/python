<template>
    <div class="alarm-history">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="alarm-content">
            <TableComponent :data="getImageCropResult" :columns="columns">
                <span v-for="(item, index) in getImageCropResult" :slot="'photos' + index">
                    <span v-if="item.result && item.result.length">
                        <div class="result-item" v-for="(n, i) in item.result">
                            <div class="item-score">
                                <img :src="n.path" alt="" :class="selected.indexOf(n.id) != -1 ? 'active' : ''" @click="selectImage(n.id)"  @mouseover="showImage(n)" @mouseleave="hideImage(n)">
                            </div>
                        </div>
                    </span>
                </span>
            </TableComponent>
        </div>
         <div style="margin-top:10px;">
            <a href="#" class="button-style" @click="del">删除</a>
        </div>
        <div style="overflow:hidden">
            <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
        </div>
        <div v-show="showBigImage" class="bigImage">
            <img :src="bigImageSrc">
        </div>
    </div>
</template>

<script>
    import PaginationComponent from '@nanyun/pagination'
    import {GET_IMAGE_CROP_RESULT,
            FETCH_IMAGE_CROP_RESULT,
            GET_RESULT_PAGE,
            CLEAR_IMAGE_CROP_RESULT,
            DEL_IMAGE_CROP_RESULT } from 'store/modules/image_crop'
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    import CrumbsComponent from 'common/components/crumbs.vue'
    import URL from 'common/url'
    import TableComponent from '@nanyun/table'
    import PanelComponent from '@nanyun/panel'
    import { formatDate } from 'common/utils'

    export default {
        data() {
            return {
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '裁剪图片管理',
                    silent: true
                }],
                columns: [{
                    title: '裁剪时间',
                    prop: 'mark_time',
                    handle: d => {
                        return formatDate(d, 'Y-M-D h:m')
                    }
                }, {
                    title: '图像',
                    type: 'img',
                    prop: 'photos'
                }],
                resultData: {},
                showBigImage: false,
                bigImageSrc: '',
                selected: [],
            }
        },
        created() {
            this.fetchData()
        },

        computed: {
            ...mapGetters({
                getImageCropResult: GET_IMAGE_CROP_RESULT,
                getPage: GET_RESULT_PAGE,
            })
        },

        methods: {
            fetchData() {
                this.fetchImageCropResult(this.resultData)
            },
            ...mapActions({
                fetchImageCropResult: FETCH_IMAGE_CROP_RESULT,
                delImageCropResult: DEL_IMAGE_CROP_RESULT
            }),
            ...mapMutations({
                clearImageCropResult: CLEAR_IMAGE_CROP_RESULT
            }),
            pageEvent(page) {
                this.selected = []
                this.resultData.page = page
                this.fetchData()
            },
            showImage(obj) {
                this.showBigImage = true
                this.bigImageSrc = obj.path
            },
            hideImage(obj) {
                this.showBigImage = false
                this.bigImageSrc = ''
            },
            del() {
                if (!this.selected.length) {
                    return
                }
                for (let id of this.selected) {
                    this.delImageCropResult(id).then(() => {
                        this.fetchData()
                    })
                }
            },
            selectImage(id) {
                let index = this.selected.indexOf(id)

                if (index != -1) {
                    this.selected.splice(index, 1)
                } else {
                    this.selected.push(id)
                }
            },
        },
        components: {
            PaginationComponent,
            CrumbsComponent,
            TableComponent,
            PanelComponent
        },
        destroyed() {
            this.clearImageCropResult()
        }
    }
</script>

<style scoped>
    .alarm-history{
        padding: 50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        .table_content{
            width:100%;
            height: 60px;
            .condition {
                color:#fff;
                padding: 0 4px;
                &>div{
                    float: left;
                }
                .datepicker{
                    display:inline-block;
                    margin: 0 22px 10px 0;
                }
            }
            input, select{
                margin-right:10px;
                margin-bottom:10px;
                min-width: 192px;
            }
            input.custom{
                min-width: 180px;
            }
        }
        .alarm-content{
            margin-top:20px;
            >span{
                color:#fff;
                padding: 0 4px 5px 5px;
            }
            .capture-item{
                width: 130px;
                height: 180px;
                padding: 4px;
                border: 1px solid #717982;
                margin-left: 10%;
                .item-score{
                    position: relative;
                    height: 110px;
                    cursor: pointer;
                    >img{
                        max-width: 130px;
                        max-height: 180px;
                    }
                }
                .item-info{
                    margin-top: 10px;
                    text-align: center;
                    >p{
                        font-family: '宋体';
                        font-size:12px;
                        text-overflow:ellipsis;
                        white-space:nowrap;
                        overflow:hidden;
                        margin: 2px 0 2px 0;
                        .button-style{
                            padding: 5px;
                        }
                    }
                }
            }
            .result-item{
                width: 130px;
                height: 180px;
                float: left;
                padding: 4px;
                /*border: 1px solid #717982;*/
                margin:3px;
                .item-score{
                    position: relative;
                    height: 110px;
                    cursor: pointer;
                    .score{
                        position: absolute;
                        right: 20px;
                        bottom: 2px;
                        padding: 2px 3px;
                        border-radius: 3px;
                        background-color: #cd5d40;
                    }
                    .active{
                        border: 4px solid red;
                    }
                    img{
                        max-height: 175px;
                        max-width: 120px;
                    }
                }
                .item-info{
                    margin-top: 10px;
                    text-align: center;
                    >p{
                        font-family: '宋体';
                        font-size:12px;
                        text-overflow:ellipsis;
                        white-space:nowrap;
                        overflow:hidden;
                        margin: 0;
                        line-height: 20px;
                        .button-style{
                            padding: 0 5px 0 5px;
                        }
                    }
                }
            }
        }
        .minWidth{
            min-width:200px;
        }
    }
    .nodata{
        text-align: center;
    }
    p.no-video{
        font-size: 16px;
        color: #fff;
    }
    .all-export-list{
        width: 100%;
        height: 250px;
        overflow: auto;
        .export_title{
            display: flex;
            border-bottom: 1px solid #fff;
            text-align: center;
            >span{
                flex: 1;
                padding: 3px;
            }
        }
        .item{
            overflow: hidden;
            line-height: 28px;
            display: flex;
            text-align: center;
            >div{
                flex: 1;
                padding: 3px;
            }
            .video-status{
                >a{
                    color: #fff;
                }
                .success{
                    border-radius: 3px;
                    padding: 2px 4px;
                    color: #fff;
                    background: #5ebd5e;
                }
                .primary{
                    border-radius: 3px;
                    padding: 2px 4px;
                    color: #fff;
                    background: #1d89cf;
                }
                .danger{
                    border-radius: 3px;
                    padding: 2px 4px;
                    color: #fff;
                    background: #e66454;
                }
                .warning{
                    border-radius: 3px;
                    padding: 2px 4px;
                    color: #fff;
                    background: #efaf65;
                }
            }
        }
    }
    .bigImage{
        height: auto;
        width: auto;
        border: 1px solid #fff;
        position: fixed;
        z-index: 100000;
        top: 10%;
        right: 82px;
        img{
            max-height: 1000px;
            max-width: 1000px;
        }
    }
</style>