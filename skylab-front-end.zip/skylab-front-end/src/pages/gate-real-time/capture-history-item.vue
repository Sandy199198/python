<template>
    <div class="captures">
        <transition-group name="alarm-list" tag="ul" mode="out-in" v-if="captures.length">
            <li v-for="capture of captures" :key="capture.id"> 
                <div class="capture-content">
                    <div class="capture-pic" :class="capture.is_alarm ? 'alarmBorder' : ''">
                        <div class="img-area">
                            <img :src="capture.face" alt="" @click.prevent="viewAlarmDetails(capture)">
                        </div>
                        <p :title="capture.camera_name">{{capture.camera_name}}</p>
                        <p :title="capture.camera_location">{{capture.camera_location || '-'}}</p>
                        <p>{{capture.timestamp | formatDate}}</p>
                        <p>
                            <a href="#" class="button-style" @click.prevent="addToGroup(capture)"><i class="fa fa-share-square"></i>入库</a>
                        </p>
                    </div>
                </div>
            </li>
        </transition-group>
        <div class="nodata" v-else>暂无抓拍数据</div>
    </div>    
</template>

<script>
    import {GET_SERVICES } from 'store/modules/common'
    import {mapGetters } from 'vuex'
    export default {
        props: {
            captures: {
                type: Array,
                default() {
                    return []
                }
            }
        },
        computed: {
            ...mapGetters({
                getServices: GET_SERVICES
            })
        },
        methods: {
            goCaptureHistory() {
                window.open(`${this.getServices.Skylab}monitor/capture-history`)
            },
            viewAlarmDetails(capture) {
                this.$emit('openDetailDialog', capture)
            },
            addToGroup(capture) {
                this.$emit('addToGroup', capture)
            }
        }
    }
</script>

<style scoped>
    .captures {
        color: #FFF;
        box-sizing: border-box;
        position: relative;
        overflow: hidden;
        height:100%;
        .nodata{
            text-align:center;
            margin-top: 100px;
        }
        ul{
            height:100%;
            box-sizing: border-box;
            overflow-y: auto;
            li{
                display:list-item;
                float: left;
                .capture-content{
                    display: flex;
                    .capture-pic{
                        position:relative;
                        height:200px;
                        width: 130px;
                        text-align: center;
                        overflow:hidden;
                        margin:2px 5px;
                        box-sizing: border-box;
                        border-radius: 2px;
                        cursor:pointer;
                        border: 1px solid #717982;
                        .img-area{
                            height: 120px;
                            width: 128px;
                            text-align: center;
                            display: -webkit-box;
                            -webkit-box-align: center;
                            -webkit-box-pack: center;
                            display: -moz-box;
                            -moz-box-align: center;
                            -moz-box-pack: center;
                            display: -o-box;
                            -o-box-align: center;
                            -o-box-pack: center;
                            display: -ms-box;
                            -ms-box-align: center;
                            -ms-box-pack: center;
                            display: box;
                            box-align: center;
                            box-pack: center;
                            >img{
                                max-width: 120px;
                                max-height: 110px;
                            }
                        }
                        >p{
                            font-family: '宋体';
                            font-size:12px;
                            text-overflow:ellipsis;
                            white-space:nowrap;
                            overflow:hidden;
                            margin: 2px 0 2px 0;
                            .button-style{
                                line-height: 26px;
                                padding: 0 5px 0 5px;
                            }
                        }
                    }
                    .alarmBorder{
                        border: 1px solid #ff0000;
                    }
                }
            }
        }
    }
</style>