<template>
    <div class="capture">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="table_content">
            <div class="condition">
                <div>
                    人员姓名：
                    <input type="text" placeholder="请输入人员姓名" ref="personName"  class="input-style custom" v-model="personName"/>   
                </div>
                <div style="display:flex">
                    <label style="margin-top:4px;">相机名称：</label>
                    <AutoCompleteComponent :cameraObj="cameraNameObj" :data="getCameras" v-on:selection="selection"></AutoCompleteComponent>
                </div>
                <div style="display:flex;margin-left:18px;">
                    <label style="margin-top:4px;">相机位置：</label>
                    <AutoCompleteComponent :cameraObj="cameraLocationObj" :data="getCameras" v-on:selection="selection"></AutoCompleteComponent>
                </div>
                <div>
                    底库名称：
                    <select name="group" ref="group" class="select input-style">
                        <option value="">底库/不限</option>
                        <option :value="item.id" v-for="item in getGroup">{{item.name}}</option>
                    </select>
                </div>
                <div>
                    证件号码：
                    <input type="text" placeholder="请输入证件号" ref="certId"  class="input-style custom" v-model="certId"/>   
                </div>
                <div>
                    开始时间：
                    <DatepickerComponent :date="startTime" :limit="startLimit" v-on:change="changeStartDate" :options="dateOptions" class="datepicker"></DatepickerComponent>
                </div>
                <div>
                    结束时间：
                    <DatepickerComponent :date="endTime" :limit="endLimit" v-on:change="changeEndDate" :options="dateOptions" class="datepicker"></DatepickerComponent>
                </div>
                <a href="#" @click.prevent="search()" class="button-style" style="float:right">搜&nbsp;索</a>
            </div>
        </div>
        <div class="capture-content">
            <span>
                抓拍数：{{getPage.total_count || 0}} 条
            </span>
            <CaptureHistoryItemComponent :captures="getCaptureHistoryList" v-on:openDetailDialog="openDetailDialog" v-on:addToGroup="addToGroup"></CaptureHistoryItemComponent>
        </div>
        <div style="overflow:hidden">
            <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
        </div>
        <DialogComponent :show="showDetails" title="查看详情">
            <div slot="content">
                <AlarmDetails :data="alarmDialogData"></AlarmDetails>
            </div>
        </DialogComponent>
        <ConfirmComponent :show="importGroup" title="入库" :confirm="submitImport" :cancel="cancelGroup">
            <div slot="content">
                <CaptureAlarmPutinComponent :data="importObj" :groups="getGroup"></CaptureAlarmPutinComponent>
            </div>
        </ConfirmComponent>
    </div>  
</template>

<script>
    import ConfirmComponent from '@nanyun/confirm'
    import DialogComponent from '@nanyun/dialog'
    import PaginationComponent from '@nanyun/pagination'
    import {GET_CAPTURE_HISTORY_LIST, FETCH_CAPTURE_HISTORY_LIST, GET_PAGE, CLEAR_CAPTURE_HISTORY_LIST} from 'store/modules/capture_history'
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    import CaptureHistoryItemComponent from 'pages/gate-real-time/capture-history-item.vue'
    import DatepickerComponent from 'common/components/datepicker.vue'
    import {formatDate, parseDateStrToTimestamp, convertToSeconds, convertDoubleNumber} from 'common/utils'
    import {GET_GROUP, FETCH_GROUP} from 'store/modules/group'
    import CrumbsComponent from 'common/components/crumbs.vue'
    import URL from 'common/url'
    import AlarmDetails from 'pages/gate-real-time/alarm-details.vue'
    import AutoCompleteComponent from 'common/components/autocomplete.vue'
    import {
        GET_CAMERAS,
        FETCH_CAMERAS
    } from 'store/modules/cameras'
    import CaptureAlarmPutinComponent from 'common/components/capture-alarm-putin.vue'
    import {ADD_MEMBER} from 'store/modules/member'
    import { GENDER, CERTTYPE, CRIMINALRECORD, LABEL } from 'common/config'

    export default {
        data() {
            return {
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '抓拍历史',
                    silent: true
                }],
                index: '',
                personName: '',
                cameraName: '',
                cameraLocation: '',
                group: '',
                certId: '',
                startTime: {
                    time: ''
                },
                endTime: {
                    time: ''
                },
                startLimit: [],
                endLimit: [],
                limitEndDate: '',
                limitStartDate: '',
                dateOptions: {
                    type: 'min',
                    format: 'YYYY-MM-DD HH:mm',
                },
                captureData: {},
                showDetails: {
                    value: false
                },
                alarmDialogData: {},
                cameraNameObj: {
                    placeholder: '请输入相机名称',
                    type: 'name'
                },
                cameraLocationObj: {
                    placeholder: '请输入相机位置',
                    type: 'location'
                },
                importGroup: {
                    value: false
                },
                importObj: {},
                bulkItems: {
                    gender: GENDER,
                    certType: CERTTYPE,
                    crmRecord: CRIMINALRECORD,
                    label: LABEL
                },
                memberData: {},
            }
        },

        created() {
            this.fetchGroup()
            this.fetchData('default')
            this.fetchCameras()
        },

        computed: {
            ...mapGetters({
                getCaptureHistoryList: GET_CAPTURE_HISTORY_LIST,
                getPage: GET_PAGE,
                getGroup: GET_GROUP,
                getCameras: GET_CAMERAS
            }),
        },
        methods: {
            fetchData(type) {
                if (type) {
                    let now = new Date()
                    let endDataTime = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1)
                    let limitStartDate = new Date(+endDataTime - 30 * 24 * 60 * 60 * 1000) //一个月开始日期

                    this.startTime.time = limitStartDate.getFullYear() + '-' + convertDoubleNumber(limitStartDate.getMonth() + 1) + '-' + convertDoubleNumber(limitStartDate.getDate()) + ' 00:00'
                    this.endTime.time = endDataTime.getFullYear() + '-' + convertDoubleNumber(endDataTime.getMonth() + 1) + '-' + convertDoubleNumber(endDataTime.getDate()) + ' 00:00'
                    //限制日期只能选择1个月
                    this.limitEndDate = endDataTime.getFullYear() + '-' + convertDoubleNumber(endDataTime.getMonth() + 1) + '-' + convertDoubleNumber(endDataTime.getDate() + 1)
                    this.limitStartDate = limitStartDate.getFullYear() + '-' + convertDoubleNumber(limitStartDate.getMonth() + 1) + '-' + convertDoubleNumber(limitStartDate.getDate())
                    this.endLimit = [{
                        type: 'fromto',
                        from: this.startTime.time,
                        to: this.limitEndDate
                    }]
                    this.startLimit = [{
                        type: 'fromto',
                        from: this.limitStartDate,
                        to: this.endTime.time
                    }]
                    this.captureData = {
                        startTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.startTime.time + ' 00:00:00'))),
                        endTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.endTime.time + ' 00:00:00')))
                    }
                }
                this.fetchCaptureHistoryList(this.captureData)
            },
            ...mapActions({
                fetchCaptureHistoryList: FETCH_CAPTURE_HISTORY_LIST,
                fetchGroup: FETCH_GROUP,
                fetchCameras: FETCH_CAMERAS,
                addMember: ADD_MEMBER
            }),
            ...mapMutations({
                clearCaptureHistoryList: CLEAR_CAPTURE_HISTORY_LIST
            }),
            search() {
                this.captureData = {
                    name: this.$refs.personName.value,
                    cameraName: this.cameraName,
                    location: this.cameraLocation,
                    certId: this.$refs.certId.value,
                    group: this.$refs.group.value,
                    startTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.startTime.time + ' 00:00:00'))),
                    endTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.endTime.time + ' 00:00:00')))
                }
                this.fetchData()
            },
            pageEvent(page) {
                this.captureData.page = page
                this.fetchData()
            },
            openDetailDialog(capture) {
                this.alarmDialogData = capture
                this.showDetails.value = true
            },
            addToGroup(capture) {
                this.importGroup.value = true
                this.memberData = Object.assign({}, capture)
                this.importObj = Object.assign({}, {
                    path: this.memberData.face,
                    'group_id': this.getGroup[0].id,
                    gender: this.bulkItems.gender[0].value,
                    'cert_type': this.bulkItems.certType[0].value,
                    'criminal_record': this.bulkItems.crmRecord[0].value,
                    label: this.bulkItems.label[0].value,
                    remark: '',
                    name: ''
                })
            },
            submitImport() {
                this.importObj.fromCapture = true
                this.importObj.timestamp = this.memberData.timestamp
                this.addMember(this.importObj)
            },
            changeStartDate(startDate) {
                this.endLimit = [{
                    type: 'fromto',
                    from: startDate,
                    to: this.limitEndDate
                }]
            },
            changeEndDate(endDate) {
                this.startLimit = [{
                    type: 'fromto',
                    from: this.limitStartDate,
                    to: endDate
                }]
            },
            selection(value, type) {
                if (type == 'name') {
                    this.cameraName = value
                }
                if (type == 'location') {
                    this.cameraLocation = value
                }
            }
        },
        components: {
            ConfirmComponent,
            PaginationComponent,
            CaptureHistoryItemComponent,
            DatepickerComponent,
            CrumbsComponent,
            AlarmDetails,
            AutoCompleteComponent,
            CaptureAlarmPutinComponent,
            DialogComponent
        },
        destroyed() {
            this.clearCaptureHistoryList()
        }
    }
</script>

<style scoped>
    .capture{
        padding: 50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        .table_content{
            width:100%;
            height: 60px;
            .condition {
                color:#fff;
                padding: 0 4px;
                &>div{
                    float: left;
                }
                .datepicker{
                    display:inline-block;
                    margin: 0 22px 10px 0;
                }
            }
            input, select{
                margin-right:10px;
                margin-bottom:10px;
            }
            input.custom{
                min-width: 180px;
            }
        }
        .capture-content{
            margin-top:20px;
            >span{
                color:#fff;
                padding: 0 4px 5px 5px;
            }
        }
        .minWidth{
            min-width:200px;
        }
    }
</style>