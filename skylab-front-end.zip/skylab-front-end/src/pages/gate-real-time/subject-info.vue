<template>
    <div>
        <div class="form-group-div">
            <label>姓名</label>
            <div class="col8">
                <input type="text"  class="input-style custom" :value="data.subject.name" disabled/> 
            </div> 
        </div>
        <div class="form-group-div">
            <label>性别</label>
            <div class="col8">
                <input type="text"  class="input-style custom" :value="getGender" disabled/> 
            </div>  
        </div>
        <div class="form-group-div">
            <label>标记</label>
            <div class="col8">
                <input type="text"  class="input-style custom" :value="getSubjectLabel" disabled/> 
            </div>
        </div>
        <div class="form-group-div">
            <label>证件类型</label>
            <div class="col8">
                <input type="text"  class="input-style custom" :value="getIdentityInfo" disabled/> 
            </div>  
        </div>
        <div class="form-group-div">
            <label>证件号码</label>
            <div class="col8">
                <input type="text"  class="input-style custom" :value="data.subject.cert_id" disabled/> 
            </div> 
        </div>
        <div class="form-group-div">
            <label>底库</label>
            <div class="col8">
                <input type="text"  class="input-style custom" :value="data.group.name" disabled/> 
            </div>
        </div>
        <div class="form-group-div">
            <label>案底</label>
            <div class="col8">
                <input type="text"  class="input-style custom" :value="getCriminalRecord" disabled/> 
            </div>  
        </div>
        <div class="form-group-div">
            <label>备注</label>
            <div class="col8">
                <input type="text"  class="input-style custom" :value="data.subject.remark" disabled/> 
            </div>   
        </div>
    </div>
</template>
<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'

export default {
    props: {
        data: {
            type: Object,
            default: {}
        }
    },
    data() {
        return {
            num: 1111
        }
    },
    computed: {
        getGender: function () {
            let msg = {}

            msg[0] = '未知'
            msg[1] = '男'
            msg[2] = '女'
            return msg[this.data.subject.gender]
        },
        getSubjectLabel: function () {
            let msg = {}

            msg[0] = '未知'
            msg[1] = '普通人员'
            msg[2] = '可疑人员'
            return msg[this.data.subject.label]
        },
        getIdentityInfo: function () {
            let msg = {}

            msg[0] = '未知'
            msg[1] = '身份证'
            msg[2] = '护照'
            msg[3] = '军官证'
            return msg[this.data.subject.cert_type]
        },
        getCriminalRecord: function () {
            let msg = {}

            msg[0] = '未知'
            msg[1] = '无'
            msg[2] = '有'
            return msg[this.data.subject.criminal_record]
        }
    }
}
</script>
<style scoped>
    .form-group-div{
        margin-bottom: 0!important;
        margin-top:10px;
        >label{
            width: 25%;
            float: left;
            position: relative;
            min-height: 1px;
            padding-left: 5px;
            padding-right: 5px;
            margin-top:10px;
        }
        .col8{
            width: 70%;
            float: left;
            margin-top:5px;
        }
        .input-style{
            padding: 3px 12px;
            font-size: 13px;
            line-height: 1.42857143;
            color: #555555;
            background-image: none;
            /*border: 1px solid #d6d6d6;*/
            /*border-radius: 2px;*/
            cursor: not-allowed;
            background-color: #eeeeee;
            /*opacity: 1;*/
        }
    }
</style>