<template>
    <div>
        <video width="720" height="405" style="background: #555;" autoplay="true">
            <source :src="src" ref="video" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    </div>
</template>
<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'

export default {
    props: {
        src: {
            type: String,
            default: ''
        }
    },
    data() {
        return {}
    }
}
</script>
<style scoped>
</style>