<template>
    <div class="capture-video-search">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="table_content">
            <div class="condition">
                <select name="video" v-model="searchObj.id" class="select input-style">
                    <option value="">视频不限</option>
                    <option :value="item.id" v-for="item in getAllVideoList">{{item.filename}}</option>
                </select>
                <DatepickerComponent class="datepicker" :date="startTime" :limit="startLimit" :options="dateOptions" v-on:change="changeStartDate"></DatepickerComponent>
                <span>~</span>
                <DatepickerComponent class="datepicker" :date="endTime" :limit="endLimit" :options="dateOptions" v-on:change="changeEndDate"></DatepickerComponent>
                <a href="#" class="button-style" @click.prevent="search" style="padding:1px 25px;">搜索</a>
            </div>
            <TableComponent :data="getCaptureVideoSearch" :columns="columns" :trHeight="style.height">
                <span v-for="(item, index) in getCaptureVideoSearch" :slot="'element' + index" class="table-img-con">
                    <img :src="item.face" @click.prevent="viewImage(item.face)">
                </span>
                <span v-for="(item, index) in getCaptureVideoSearch" :slot="'events' + index">
                    <a href="#" @click.prevent="detail(item)">详情</a>
                </span>
            </TableComponent>
            <div>
                <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
            </div>
            <DialogComponent :show="editObj.show" :title="editObj.text">
                <div slot="content">
                    <AlarmDetails :data="alarmDialogData"></AlarmDetails>
                </div>
            </DialogComponent>
            <DialogComponent :show="viewBigImage" title="查看原图">
                <div slot="content">
                    <div style="text-align: center">
                        <img :src="imageSrc"></img>
                    </div>
                </div>
            </DialogComponent>
        </div>    
    </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import TableComponent from '@nanyun/table'
import PaginationComponent from '@nanyun/pagination'
import DialogComponent from '@nanyun/dialog'
import ConfirmComponent from '@nanyun/confirm'
import DatepickerComponent from 'common/components/datepicker.vue'
import {formatDate, parseDateStrToTimestamp, convertToSeconds} from 'common/utils'
import { GENDER, CERTTYPE, CRIMINALRECORD, LABEL } from 'common/config'
import {GET_ALL_VIDEO_LIST, FETCH_VIDEO_LIST, GET_PAGE, SEARCH_VIDEO, FETCH_CAPTURE_VIDEO_SEARCH, GET_CAPTURE_VIDEO_SEARCH} from 'store/modules/search'
import CrumbsComponent from 'common/components/crumbs.vue'
import URL from 'common/url'
import AlarmDetails from 'pages/gate-real-time/alarm-details.vue'

export default {
    data() {
        return {
            crumbs: [{
                name: '离线视频',
                path: {
                    name: URL.SEARCH.VIDEO_SEARCH
                }
            }, {
                name: '离线视频抓拍',
                silent: true
            }],
            startTime: {
                time: ''
            },
            endTime: {
                time: ''
            },
            startLimit: [],
            endLimit: [],
            dateOptions: {
                type: 'day',
                format: 'YYYY-MM-DD',
            },
            searchObj: {
                id: window.location.pathname.split('/')[3],
                page: 1
            },
            style: {
                imgStyle: {
                    width: '90px',
                    height: '110px',
                    marginRight: '5px',
                },
                height: '124px'
            },
            columns: [{
                title: '图像预览',
                type: 'element',
                width: '200px',
                prop: 'face'
            }, {
                title: '视频名称',
                prop: 'video',
                handle: d => {
                    return d.filename
                }
            }, {
                title: '识别时间',
                prop: 'timestamp',
                handle: d => {
                    return formatDate(d, 'Y-M-D h:m')
                }
            }, {
                title: '操作',
                type: 'events'
            }],
            path: '',
            editObj: {
                autoClose: 10000,
                text: '抓拍详情',
                show: {
                    value: false
                },
            },
            defaultObj: {
                gender: GENDER,
                label: LABEL,
                criminalRecord: CRIMINALRECORD,
                certType: CERTTYPE
            },
            alarmDialogData: {},
            viewBigImage: {
                value: false
            },
            imageSrc: ''
        }
    },
    created() {
        this.fetchData()
        this.fetchVideoList(1000)
    },
    computed: {
        ...mapGetters({
            getPage: GET_PAGE,
            getAllVideoList: GET_ALL_VIDEO_LIST,
            getCaptureVideoSearch: GET_CAPTURE_VIDEO_SEARCH
        }),
    },
    methods: {
        fetchData() {
            let now = new Date(), endTime = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1), startTime   = new Date(+endTime - 2678400000)

            this.searchObj['start_time'] = convertToSeconds(startTime)
            this.searchObj['end_time'] = convertToSeconds(endTime)
            this.startTime.time = formatDate(convertToSeconds(startTime), 'Y-M-D')
            this.endTime.time = formatDate(convertToSeconds(endTime), 'Y-M-D')
            this.startLimit = [{
                type: 'fromto',
                from: '',
                to: this.endTime.time
            }]
            this.endLimit = [{
                type: 'fromto',
                from: this.startTime,
                to: ''
            }]
            this.fetchCaptureVideoSearch(this.searchObj)
        },
        ...mapActions({
            fetchVideoList: FETCH_VIDEO_LIST,
            fetchCaptureVideoSearch: FETCH_CAPTURE_VIDEO_SEARCH
        }),
        search() {
            this.fetchCaptureVideoSearch(this.searchObj)
        },
        detail(capture) {
            this.alarmDialogData = capture
            this.editObj.show.value = !this.editObj.show.value
        },
        parseNumToString(obj, d) {
            obj.map((item) => {
                if (item.value == d) {
                    return item.text
                }
            })
        },
        pageEvent(page) {
            this.searchObj.page = page
            this.fetchCaptureVideoSearch(this.searchObj)
        },
        changeStartDate(startDate) {
            let date = startDate ? startDate + ' 00:00' : ''
            let start = formatDate((parseDateStrToTimestamp(date) / 1000 - 86400), 'Y-M-D')
            let end = formatDate((parseDateStrToTimestamp(date) / 1000 + 86400), 'Y-M-D')

            this.endLimit = [{
                type: 'fromto',
                from: start,
                to: ''
            }]
            this.searchObj['start_time'] = parseDateStrToTimestamp(date) / 1000
        },
        changeEndDate(endDate) {
            let date = endDate ? endDate + ' 00:00' : ''
            let start = formatDate((parseDateStrToTimestamp(date) / 1000 - 86400), 'Y-M-D')
            let end = formatDate((parseDateStrToTimestamp(date) / 1000 + 86400), 'Y-M-D')

            this.startLimit = [{
                type: 'fromto',
                from: '',
                to: end
            }]
            this.searchObj['end_time'] = parseDateStrToTimestamp(date) / 1000
        },
        viewImage(src) {
            this.viewBigImage.value = true
            this.imageSrc = src
        }
    },
    components: {
        TableComponent,
        PaginationComponent,
        DialogComponent,
        ConfirmComponent,
        DatepickerComponent,
        CrumbsComponent,
        AlarmDetails
    }
}
</script>

<style scoped>
    .capture-video-search{
        height: 100%;
        width: 100%;
        padding: 50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        .datepicker{
            display: inline-block;
        }
        .condition{
            margin-top: 16px;
            margin-bottom: 15px;
            color: #fff;
        }
        .table-img-con{
            display: inline-block;
            width: 100px;
            height: 120px;
            margin-top: 4px;
            margin-bottom: 4px;
            cursor: pointer;
            &:after{
                display:inline-block;
                width:0;
                height:100%;
                vertical-align:middle;
                content:'';
            }
            img{
                max-width: 100%;
                max-height: 100%;
                display:inline-block;
                vertical-align:middle;
            }
        }
        .fail-table{
            text-align: left;
        }
    }
</style>