<template>
    <div class="alarm-history">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="table_content">
            <div class="condition">
                <div>
                    人员姓名：
                    <input type="text" placeholder="请输入人员姓名" ref="personName"  class="input-style custom" v-model="personName"/>   
                </div>
                <div style="display:flex">
                    <label style="margin-top:4px;">相机名称：</label>
                    <AutoCompleteComponent :cameraObj="cameraNameObj" :data="getCameras" v-on:selection="selection"></AutoCompleteComponent>
                </div>
                <div style="display:flex;margin-left:4px;margin-right:5px;">
                    <label style="margin-top:4px;">相机位置：</label>
                    <AutoCompleteComponent :cameraObj="cameraLocationObj" :data="getCameras" v-on:selection="selection"></AutoCompleteComponent>
                </div>
                <div>
                    底库名称：
                    <select name="group" ref="group" class="select input-style">
                        <option value="">底库/不限</option>
                        <option :value="item.id" v-for="item in getGroup">{{item.name}}</option>
                    </select>
                </div>
                <div>
                    处理状态：
                    <select name="marked" ref="marked" class="select input-style">
                        <option value="">处理状态/不限</option>
                        <option v-for="option in marks" :value="option.value">{{option.text}}</option>
                    </select>
                </div>
                <div>
                    证件号码：
                    <input type="text" placeholder="请输入证件号" ref="certId"  class="input-style custom" v-model="certId"/>   
                </div>
                <div>
                    开始时间：
                    <DatepickerComponent :date="startTime" :limit="startLimit" v-on:change="changeStartDate" :options="dateOptions" class="datepicker"></DatepickerComponent>
                </div>
                <div style="margin-left:-12px;">
                    结束时间：
                    <DatepickerComponent :date="endTime" :limit="endLimit" v-on:change="changeEndDate" :options="dateOptions" class="datepicker"></DatepickerComponent>
                </div>
                <a href="#" @click.prevent="search()" class="button-style" style="float:right">搜&nbsp;索</a>
                <a href="#" @click.prevent="exportResult()" class="button-style" style="float:right">导&nbsp;出</a>
                <a href="#" @click.prevent="exportHistory()" class="button-style" style="float:right">导出历史</a>
            </div>
        </div>
        <div class="alarm-content">
            <span>
                告警数：{{getPage.total_count || 0}} 条
            </span>
            <TableComponent :data="getAlarmHistoryList" :columns="columns">
                <span v-for="(item, index) in getAlarmHistoryList" :slot="'face' + index">
                    <div class="capture-item" >
                        <div class="item-score" @click.prevent="openDetailDialog(item)">
                            <img :src="item.face" alt="">
                        </div>
                        <div class="item-info">
                            <p :title="item.camera_name">{{item.camera_name}}</p>
                            <p :title="item.camera_location">{{item.camera_location}}</p>
                            <p>
                                <a href="#" class="button-style" @click.prevent="addToGroup(item)"><i class="fa fa-share-square"></i>入库</a>
                            </p>
                        </div>
                    </div>
                </span>
                <span v-for="(item, index) in getAlarmHistoryList" :slot="'photos' + index">
                    <span v-if="item.photos && item.photos.length">
                        <div class="result-item" v-for="(n, i) in item.photos">
                            <div class="item-score">
                                <img :src="n.path" alt="" :class="[i == item.marked ? 'active' : '']" @click.prevent="viewImage(n.path)">
                                <span class="score">{{n ? n.score.toFixed(2) : '-'}}</span>
                            </div>
                            <div class="item-info">
                                <p :title="n ? n.subject.name : '-'">{{n ? n.subject.name : '-'}}/{{n.subject.cert_id? n.subject.cert_id : '-'}}</p>
                                <p :title="n ? n.group.name : '-'">{{n ? n.group.name : '-'}}</p>
                                <p>
                                    <a v-if="i != item.marked" href="#" class="button-style" @click.prevent="markPhoto(item.id, i)"><i class="fa fa-bookmark-o"></i>标记</a>
                                    <a v-else href="#" class="button-style" @click.prevent="markPhoto(item.id, -1)"><i class="fa fa-bookmark-o"></i>取消</a>
                                </p>
                            </div>
                        </div>
                    </span>
                    <span v-else><i class="fa fa-warning"></i>暂未比对图片</span>
                </span>
                <span v-for="(item, index) in this.getAlarmHistoryList" :slot="'events' + index">
                    <a href="#" @click.prevent="del(item)">删除</a>
                </span>
            </TableComponent>
        </div>
        <div style="overflow:hidden">
            <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
        </div>
        <DialogComponent :show="showDetails" title="查看详情">
            <div slot="content">
                <AlarmDetails :data="alarmDialogData"></AlarmDetails>
            </div>
        </DialogComponent>   
        <ConfirmComponent :show="deleteObj.show" :title="deleteObj.text" :content="deleteObj.content" :confirm="deleteObj.confirm"> 
        </ConfirmComponent>
        <ConfirmComponent :show="importGroup" title="入库" :confirm="submitImport" :cancel="cancelGroup">
            <div slot="content">
                <CaptureAlarmPutinComponent :data="importObj" :groups="getGroup"></CaptureAlarmPutinComponent>
            </div>
        </ConfirmComponent>
        <DialogComponent :show="viewBigImage" title="查看原图">
            <div slot="content">
                <div style="text-align: center">
                    <img :src="imageSrc"></img>
                </div>
            </div>
        </DialogComponent>
        <DialogComponent :show="exportObj.show" :title="exportObj.text" :cancel="exportObj.cancel">
            <div slot="content">
                <div class="panel-body" style="padding-left: -11px;margin-top: -20px" v-if="getExportAlarmHistoryList.length">
                    <div class="all-export-list">
                        <div class="export_title">
                            <span>任务时间</span>
                            <span>任务状态</span>
                            <span>操作</span>
                        </div>
                        <div class="item" v-for="(item, index) in getExportAlarmHistoryList">
                            <div>
                                {{item.timestamp | formatDate}}
                            </div>
                            <div class="video-status">
                                <span v-for="i in exportStatus">
                                    <span v-if="item.status == i.value" :class="i.clsName">{{i.text}}</span>
                                </span>
                            </div>
                            <div class="video-status">
                                <a href="#" v-if="item.status == 2" title="下载" @click.prevent="downloadExcel(item.path)"><i class="fa fa-download"></i></a>
                                <span v-else>-</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-body nodata" style="padding-left: -11px;" v-else>
                    <p class="no-video">暂无导出任务</p>
                </div>
            </div>
        </DialogComponent>
    </div>
</template>

<script>
    import ConfirmComponent from '@nanyun/confirm'
    import DialogComponent from '@nanyun/dialog'
    import PaginationComponent from '@nanyun/pagination'
    import {GET_ALARM_HISTORY_LIST,
            FETCH_ALARM_HISTORY_LIST,
            DELETE_ALARM_HISTORY,
            MARKED_ALARM_HISTORY,
            GET_PAGE,
            CLEAR_ALARM_HISTORY_LIST,
            EXPORT_ALARM_HISTORY,
            FETCH_EXPORT_ALARM_HISTORY_LIST,
            GET_EXPORT_ALARM_HISTORY_LIST} from 'store/modules/alarm_history'
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    import DatepickerComponent from 'common/components/datepicker.vue'
    import {formatDate, parseDateStrToTimestamp, convertToSeconds, convertDoubleNumber} from 'common/utils'
    import {GET_GROUP, FETCH_GROUP} from 'store/modules/group'
    import CrumbsComponent from 'common/components/crumbs.vue'
    import URL from 'common/url'
    import TableComponent from '@nanyun/table'
    import { MARKS } from 'common/config'
    import AlarmDetails from 'pages/gate-real-time/alarm-details.vue'
    import AutoCompleteComponent from 'common/components/autocomplete.vue'
    import {
        GET_CAMERAS,
        FETCH_CAMERAS
    } from 'store/modules/cameras'
    import { GET_SERVICES } from 'store/modules/common'
    import CaptureAlarmPutinComponent from 'common/components/capture-alarm-putin.vue'
    import {ADD_MEMBER} from 'store/modules/member'
    import { GENDER, CERTTYPE, CRIMINALRECORD, LABEL, EXPORT_STATUS} from 'common/config'

    export default {
        data() {
            return {
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '告警历史',
                    silent: true
                }],
                columns: [{
                    title: '抓拍图像',
                    type: 'img',
                    width: '200px',
                    prop: 'face'
                }, {
                    title: '比对图像',
                    type: 'img',
                    prop: 'photos'
                }, {
                    title: '告警时间',
                    prop: 'timestamp',
                    handle: d => {
                        return formatDate(d, 'Y-M-D h:m')
                    }
                }, {
                    title: '操作',
                    type: 'events'
                }],
                index: '',
                personName: '',
                cameraName: '',
                cameraLocation: '',
                group: '',
                certId: '',
                marked: '',
                startTime: {
                    time: ''
                },
                endTime: {
                    time: ''
                },
                startLimit: [],
                endLimit: [],
                limitEndDate: '',
                limitStartDate: '',
                dateOptions: {
                    type: 'min',
                    format: 'YYYY-MM-DD HH:mm',
                },
                alarmData: {},
                showDetails: {
                    value: false
                },
                marks: MARKS,
                alarmDialogData: {},
                cameraNameObj: {
                    placeholder: '请输入相机名称',
                    type: 'name',
                    selected: ''
                },
                cameraLocationObj: {
                    placeholder: '请输入相机位置',
                    type: 'location',
                    selected: ''
                },
                alarmObj: {},
                deleteObj: {
                    autoClose: 10000,
                    text: '确认删除',
                    content: '确定删除该条报警记录?',
                    show: {
                        value: false
                    },
                    confirm: () => {
                        this.delAlarm(this.alarmObj)
                    }
                },
                importGroup: {
                    value: false
                },
                importObj: {},
                bulkItems: {
                    gender: GENDER,
                    certType: CERTTYPE,
                    crmRecord: CRIMINALRECORD,
                    label: LABEL
                },
                memberData: {},
                viewBigImage: {
                    value: false
                },
                imageSrc: '',
                exportObj: {
                    autoClose: 10000,
                    text: '导出任务列表',
                    show: {
                        value: false
                    },
                    cancel: () => {
                        clearInterval(this.interval)
                    }
                },
                exportStatus: EXPORT_STATUS
            }
        },
        created() {
            this.fetchData('default')
            this.fetchCameras()
            this.fetchExportAlarmHistoryList()
        },

        computed: {
            ...mapGetters({
                getAlarmHistoryList: GET_ALARM_HISTORY_LIST,
                getPage: GET_PAGE,
                getGroup: GET_GROUP,
                getCameras: GET_CAMERAS,
                getServices: GET_SERVICES,
                getExportAlarmHistoryList: GET_EXPORT_ALARM_HISTORY_LIST
            })
        },

        methods: {
            fetchData(type) {
                this.fetchGroup()
                if (type) {
                    let cameraName = this.$route.params.cameraName
                    let now = new Date()
                    let endDataTime = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1)
                    let limitStartDate = new Date(+endDataTime - 30 * 24 * 60 * 60 * 1000) //一个月开始日期

                    this.startTime.time = limitStartDate.getFullYear() + '-' + convertDoubleNumber(limitStartDate.getMonth() + 1) + '-' + convertDoubleNumber(limitStartDate.getDate()) + ' 00:00'
                    this.endTime.time = endDataTime.getFullYear() + '-' + convertDoubleNumber(endDataTime.getMonth() + 1) + '-' + convertDoubleNumber(endDataTime.getDate()) + ' 00:00'
                    //限制日期只能选择1个月
                    this.limitEndDate = endDataTime.getFullYear() + '-' + convertDoubleNumber(endDataTime.getMonth() + 1) + '-' + convertDoubleNumber(endDataTime.getDate() + 1)
                    this.limitStartDate = limitStartDate.getFullYear() + '-' + convertDoubleNumber(limitStartDate.getMonth() + 1) + '-' + convertDoubleNumber(limitStartDate.getDate())
                    this.endLimit = [{
                        type: 'fromto',
                        from: this.startTime.time,
                        to: this.limitEndDate
                    }]
                    this.startLimit = [{
                        type: 'fromto',
                        from: this.limitStartDate,
                        to: this.endTime.time
                    }]
                    if (cameraName) {
                        this.cameraName = cameraName
                        this.cameraNameObj.selected = cameraName
                    }
                    this.alarmData = {
                        startTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.startTime.time + ' 00:00:00'))),
                        endTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.endTime.time + ' 00:00:00'))),
                        cameraName: cameraName
                    }
                }
                this.fetchAlarmHistoryList(this.alarmData)
            },
            ...mapActions({
                fetchAlarmHistoryList: FETCH_ALARM_HISTORY_LIST,
                fetchGroup: FETCH_GROUP,
                fetchCameras: FETCH_CAMERAS,
                delAlarm: DELETE_ALARM_HISTORY,
                markAlarm: MARKED_ALARM_HISTORY,
                addMember: ADD_MEMBER,
                exportAlarmHistory: EXPORT_ALARM_HISTORY,
                fetchExportAlarmHistoryList: FETCH_EXPORT_ALARM_HISTORY_LIST
            }),
            ...mapMutations({
                clearAlarmHistoryList: CLEAR_ALARM_HISTORY_LIST
            }),
            search() {
                this.alarmData = {
                    name: this.$refs.personName.value,
                    cameraName: this.cameraName,
                    location: this.cameraLocation,
                    certId: this.$refs.certId.value,
                    group: this.$refs.group.value,
                    marked: this.$refs.marked.value,
                    startTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.startTime.time + ' 00:00:00'))),
                    endTime: convertToSeconds(new Date(parseDateStrToTimestamp(this.endTime.time + ' 00:00:00')))
                }
                this.fetchData()
            },
            exportResult() {
                clearInterval(this.interval)
                this.exportAlarmHistory(this.alarmData)
                this.exportObj.show.value = !this.exportObj.show.value
                this.interval = setInterval(() => {
                    this.fetchExportAlarmHistoryList()
                }, 5000)
            },
            exportHistory() {
                clearInterval(this.interval)
                this.fetchExportAlarmHistoryList()
                this.exportObj.show.value = !this.exportObj.show.value
                this.interval = setInterval(() => {
                    this.fetchExportAlarmHistoryList()
                }, 5000)
            },
            pageEvent(page) {
                this.alarmData.page = page
                this.fetchData()
            },
            openDetailDialog(alarm) {
                alarm.from = 'alarm'
                this.alarmDialogData = alarm
                this.showDetails.value = true
            },
            addToGroup(alarm) {
                this.importGroup.value = true
                this.memberData = Object.assign({}, alarm)
                this.importObj = Object.assign({}, {
                    path: this.memberData.face,
                    'group_id': this.getGroup[0].id,
                    gender: this.bulkItems.gender[0].value,
                    'cert_type': this.bulkItems.certType[0].value,
                    'criminal_record': this.bulkItems.crmRecord[0].value,
                    label: this.bulkItems.label[0].value,
                    remark: '',
                    name: ''
                })
            },
            submitImport() {
                this.importObj.fromCapture = false
                this.importObj.timestamp = this.memberData.timestamp
                this.addMember(this.importObj)
            },
            changeStartDate(startDate) {
                this.endLimit = [{
                    type: 'fromto',
                    from: startDate,
                    to: this.limitEndDate
                }]
            },
            changeEndDate(endDate) {
                this.startLimit = [{
                    type: 'fromto',
                    from: this.limitStartDate,
                    to: endDate
                }]
            },
            selection(value, type) {
                if (type == 'name') {
                    this.cameraName = value
                }
                if (type == 'location') {
                    this.cameraLocation = value
                }
            },
            del(alarm) {
                this.deleteObj.show.value = !this.deleteObj.show.value
                this.alarmObj = alarm
            },
            markPhoto(id, index) {
                let obj = {
                    id,
                    markIndex: index
                }

                Promise.all([this.markAlarm(obj), new Promise((resolve, reject) => {
                    setTimeout(() => {
                        this.fetchData()
                    }, 600)
                })])
            },
            viewImage(src) {
                this.viewBigImage.value = true
                this.imageSrc = src
            },
            downloadExcel(path) {
                let arr = path.split('/')
                let url = `${this.getServices.Skylab}`

                arr.shift()
                window.open(url + arr.join('/'))
            },
        },
        components: {
            ConfirmComponent,
            PaginationComponent,
            DatepickerComponent,
            CrumbsComponent,
            TableComponent,
            AlarmDetails,
            AutoCompleteComponent,
            CaptureAlarmPutinComponent,
            DialogComponent
        },
        destroyed() {
            this.clearAlarmHistoryList()
        }
    }
</script>

<style scoped>
    .alarm-history{
        padding: 50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        .table_content{
            width:100%;
            height: 60px;
            .condition {
                color:#fff;
                padding: 0 4px;
                &>div{
                    float: left;
                }
                .datepicker{
                    display:inline-block;
                    margin: 0 22px 10px 0;
                }
            }
            input, select{
                margin-right:10px;
                margin-bottom:10px;
                min-width: 192px;
            }
            input.custom{
                min-width: 180px;
            }
        }
        .alarm-content{
            margin-top:20px;
            >span{
                color:#fff;
                padding: 0 4px 5px 5px;
            }
            .capture-item{
                width: 130px;
                height: 180px;
                padding: 4px;
                border: 1px solid #717982;
                margin-left: 10%;
                .item-score{
                    position: relative;
                    height: 110px;
                    cursor: pointer;
                    >img{
                        max-width: 130px;
                        max-height: 110px;
                    }
                }
                .item-info{
                    margin-top: 10px;
                    text-align: center;
                    >p{
                        font-family: '宋体';
                        font-size:12px;
                        text-overflow:ellipsis;
                        white-space:nowrap;
                        overflow:hidden;
                        margin: 2px 0 2px 0;
                        .button-style{
                            padding: 5px;
                        }
                    }
                }
            }
            .result-item{
                width: 130px;
                height: 180px;
                float: left;
                padding: 4px;
                border: 1px solid #717982;
                margin:3px;
                .item-score{
                    position: relative;
                    height: 110px;
                    cursor: pointer;
                    .score{
                        position: absolute;
                        right: 20px;
                        bottom: 2px;
                        padding: 2px 3px;
                        border-radius: 3px;
                        background-color: #cd5d40;
                    }
                    .active{
                        border: 1px solid red;
                    }
                    img{
                        max-height: 110px;
                        max-width: 130px;
                    }
                }
                .item-info{
                    margin-top: 10px;
                    text-align: center;
                    >p{
                        font-family: '宋体';
                        font-size:12px;
                        text-overflow:ellipsis;
                        white-space:nowrap;
                        overflow:hidden;
                        margin: 0;
                        line-height: 20px;
                        .button-style{
                            padding: 0 5px 0 5px;
                        }
                    }
                }
            }
        }
        .minWidth{
            min-width:200px;
        }
    }
    .nodata{
        text-align: center;
    }
    p.no-video{
        font-size: 16px;
        color: #fff;
    }
    .all-export-list{
        width: 100%;
        height: 250px;
        overflow: auto;
        .export_title{
            display: flex;
            border-bottom: 1px solid #fff;
            text-align: center;
            >span{
                flex: 1;
                padding: 3px;
            }
        }
        .item{
            overflow: hidden;
            line-height: 28px;
            display: flex;
            text-align: center;
            >div{
                flex: 1;
                padding: 3px;
            }
            .video-status{
                >a{
                    color: #fff;
                }
                .success{
                    border-radius: 3px;
                    padding: 2px 4px;
                    color: #fff;
                    background: #5ebd5e;
                }
                .primary{
                    border-radius: 3px;
                    padding: 2px 4px;
                    color: #fff;
                    background: #1d89cf;
                }
                .danger{
                    border-radius: 3px;
                    padding: 2px 4px;
                    color: #fff;
                    background: #e66454;
                }
                .warning{
                    border-radius: 3px;
                    padding: 2px 4px;
                    color: #fff;
                    background: #efaf65;
                }
            }
        }
    }
</style>