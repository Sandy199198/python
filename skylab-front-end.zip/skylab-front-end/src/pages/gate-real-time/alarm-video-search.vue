<template>
    <div class="capture-video-search">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="table_content">
            <div class="condition">
                <select name="video" v-model="searchObj.id" class="input-style select">
                    <option value="">视频不限</option>
                    <option :value="item.id" v-for="item in getAllVideoList">{{item.filename}}</option>
                </select>
                <DatepickerComponent class="datepicker" :date="startTime" :limit="startLimit" :options="dateOptions" v-on:change="changeStartDate"></DatepickerComponent>
                <span>~</span>
                <DatepickerComponent class="datepicker" :date="endTime" :limit="endLimit" :options="dateOptions" v-on:change="changeEndDate"></DatepickerComponent>
                <a href="#" class="button-style" @click.prevent="search" style="padding:1px 25px;">搜&nbsp;索</a>
                <a href="#" class="button-style" @click.prevent="exportEvent" style="float: right;">导&nbsp;出</a>
                <a href="#" class="button-style" @click.prevent="exportHistory" style="float: right;">导出历史</a>
            </div>
            <div class="condition">
                <span>共{{getPage.total_count || 0}}条</span>
            </div>
            <TableComponent :data="getAlarmVideoSearch" :columns="columns" :trHeight="style.height">
                <span v-for="(item, index) in getAlarmVideoSearch" :slot="'face' + index" class="table-img-con">
                    <img :src="item.face">
                </span>
                <span v-for="(item, index) in getAlarmVideoSearch" :slot="'photos' + index" class="table-img-con">
                    <img :src="item.photos[0].path">
                </span>
                <span v-for="(item, index) in getAlarmVideoSearch" :slot="'array' + index">
                    <span>{{item.photos[0].subject.name}}</span><br>
                    <span>证件号: {{item.photos[0].subject.cert_id ? item.photos[0].subject.cert_id : '-'}}</span>
                </span>
                <span v-for="(item, index) in getAlarmVideoSearch" :slot="'element' + index">
                    <a href="#" @click.prevent="playVideo(index)" class="play" :id="item.pts">
                        <i class="fa fa-play-circle"></i>&nbsp;&nbsp;播放
                    </a>
                </span>
                <span v-for="(item, index) in getAlarmVideoSearch" :slot="'events' + index">
                    <a href="#" @click.prevent="detail(item)">详情</a>
                </span>
            </TableComponent>
            <div>
                <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
            </div>
            <DialogComponent :show="editObj.show" :title="editObj.text">
                <div slot="content">
                    <AlarmDetails :data="alarmDialogData"></AlarmDetails>
                </div>
            </DialogComponent>
            <DialogComponent :show="exportObj.show" :title="exportObj.text" :cancel="exportObj.cancel">
                <div slot="content">
                    <div class="panel-body new-member">
                        <div class="member-items">
                            <ul>
                                <li>
                                    <span>任务时间</span>
                                    <span>任务状态</span>
                                    <span>操作</span>
                                </li>
                                <li>
                                    <div>
                                        <span v-if="getExportAlarmVideo.timestamp">{{getExportAlarmVideo.timestamp | formatDate}}</span>
                                        <span v-else>-</span>
                                    </div>
                                    <div>
                                        <span :class="{'success': getExportAlarmVideo.status == 2, 'warning': getExportAlarmVideo.status < 2, 'danger': getExportAlarmVideo.status == 3}" v-if="getExportAlarmVideo.status_desc">{{getExportAlarmVideo.status_desc}}</span>
                                        <span v-else>-</span>
                                    </div>
                                    <div>
                                        <span v-if="getExportAlarmVideo.status != 2">-</span>
                                        <span v-else><a href="#" class="export" @click.prevent="downloadExcel(getExportAlarmVideo.path)"><i class="fa fa-download"></i></a></span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </DialogComponent>
            <DialogComponent :show="exportHistoryObj.show" :title="exportHistoryObj.text" :cancel="exportHistoryObj.cancel">
                <div slot="content">
                    <div class="panel-body new-member">
                        <div class="member-items">
                            <ul>
                                <li>
                                    <span>任务时间</span>
                                    <span>任务状态</span>
                                    <span>操作</span>
                                </li>
                                <li v-for="(item, index) in this.getExportAlarmVideoHistory">
                                    <div><span>{{item.timestamp | formatDate}}</span></div>
                                    <div>
                                        <span :class="{'success': item.status == 2, 'warning': item.status < 2, 'danger': item.status == 3}">{{item.status_desc}}</span>
                                    </div>
                                    <div>
                                        <span v-if="item.status != 2">-</span>
                                        <span v-else><a href="#" class="export" @click.prevent="downloadExcel(item.path)"><i class="fa fa-download"></i></a></span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </DialogComponent>
            <PanelComponent :show="videoPlay.show" name="videoplay" :id="videoPlay.show.value">
                <div slot="content" class="video-bg">
                    <a href="#" class="dialog-close-button" @click.prevent="closeVideo"><i class="fa fa-times"></i></a>
                </div>
            </PanelComponent>
        </div>    
    </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import TableComponent from '@nanyun/table'
import PaginationComponent from '@nanyun/pagination'
import DialogComponent from '@nanyun/dialog'
import ConfirmComponent from '@nanyun/confirm'
import PanelComponent from '@nanyun/panel'
import DatepickerComponent from 'common/components/datepicker.vue'
import TabImgComponent from 'common/components/tab-img.vue'
import FaceInfo from 'common/components/face-info.vue'
import {formatDate, parseDateStrToTimestamp, convertToSeconds, videoTimestamp} from 'common/utils'
import { GENDER, CERTTYPE, CRIMINALRECORD, LABEL } from 'common/config'
import {GET_ALL_VIDEO_LIST, FETCH_VIDEO_LIST, GET_PAGE, EXPORT_ALARM_VIDEO, GET_EXPORT_ALARM_VIDEO, FETCH_ALARM_VIDEO_SEARCH, GET_ALARM_VIDEO_SEARCH, GET_ALARM_VIDEO_ITEM, SET_ALARM_VIDEO_ITEM, GET_EXPORT_ALARM_VIDEO_HISTORY} from 'store/modules/search'
import { GET_SERVICES } from 'store/modules/common'
import CrumbsComponent from 'common/components/crumbs.vue'
import URL from 'common/url'
import AlarmDetails from 'pages/gate-real-time/alarm-details.vue'

export default {
    data() {
        return {
            crumbs: [{
                name: '离线视频',
                path: {
                    name: URL.SEARCH.VIDEO_SEARCH
                }
            }, {
                name: '离线视频告警',
                silent: true
            }],
            videoPlay: {
                autoClose: 10000,
                show: {
                    value: false
                }
            },
            startTime: {
                time: ''
            },
            endTime: {
                time: ''
            },
            startLimit: [],
            endLimit: [],
            dateOptions: {
                type: 'day',
                format: 'YYYY-MM-DD',
            },
            searchObj: {
                id: window.location.pathname.split('/')[3],
                page: 1
            },
            style: {
                imgStyle: {
                    width: '90px',
                    height: '110px',
                    marginRight: '5px',
                },
                height: '124px'
            },
            columns: [{
                title: '抓拍图像',
                type: 'img',
                width: '200px',
                prop: 'face'
            }, {
                title: '比对图像',
                type: 'img',
                width: '200px',
                prop: 'photos',
            }, {
                title: '姓名/证件号',
                prop: ['photos', 'photos'],
            }, {
                title: '底库',
                prop: 'photos',
                handle: d => {
                    if (d.length == 0) {
                        return '-'
                    } else {
                        return d[0].group.name
                    }
                }
            }, {
                title: '比对值',
                prop: 'photos',
                handle: d => {
                    if (d.length == 0) {
                        return '-'
                    } else {
                        return d[0].score.toFixed(2)
                    }
                }
            }, {
                title: '视频名称',
                prop: 'video',
                handle: d => {
                    return d.filename
                }
            }, {
                title: '识别时间',
                prop: 'timestamp',
                handle: d => {
                    return formatDate(d, 'Y-M-D h:m')
                }
            }, {
                title: '视频时间戳',
                prop: 'pts',
                handle: d => {
                    return videoTimestamp(d)
                }
            }, {
                title: '告警视频',
                prop: 'video',
                type: 'element'
            }, {
                title: '操作',
                type: 'events'
            }],
            path: '',
            editObj: {
                autoClose: 10000,
                text: '抓拍详情',
                show: {
                    value: false
                },
            },
            exportObj: {
                autoClose: 10000,
                text: '查看导出信息',
                show: {
                    value: false
                },
                cancel: d => {
                    clearInterval(this.interval)
                }
            },
            exportHistoryObj: {
                autoClose: 10000,
                text: '查看导出历史',
                show: {
                    value: false
                },
                cancel: d => {
                    clearInterval(this.interval)
                }
            },
            defaultObj: {
                gender: GENDER,
                label: LABEL,
                criminalRecord: CRIMINALRECORD,
                certType: CERTTYPE
            },
            exportAlarm: {},
            alarmObjItem: {
                type: 2
            },
            exportAlarmHistory: {
                type: 2
            },
            intervalTime: 3000,
            videoPlayObj: {},
            alarmDialogData: {}
        }
    },
    created() {
        this.fetchData()
        this.fetchVideoList(1000)
    },
    computed: {
        ...mapGetters({
            getPage: GET_PAGE,
            getAllVideoList: GET_ALL_VIDEO_LIST,
            getAlarmVideoSearch: GET_ALARM_VIDEO_SEARCH,
            getExportAlarmVideo: GET_EXPORT_ALARM_VIDEO,
            getAlarmVideoItem: GET_ALARM_VIDEO_ITEM,
            getExportAlarmVideoHistory: GET_EXPORT_ALARM_VIDEO_HISTORY,
            getServices: GET_SERVICES
        }),
    },
    methods: {
        fetchData() {
            let now = new Date(), endTime = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1), startTime   = new Date(+endTime - 2678400000)

            this.searchObj['start_time'] = convertToSeconds(startTime)
            this.searchObj['end_time'] = convertToSeconds(endTime)
            this.startTime.time = formatDate(convertToSeconds(startTime), 'Y-M-D')
            this.endTime.time = formatDate(convertToSeconds(endTime), 'Y-M-D')
            this.startLimit = [{
                type: 'fromto',
                from: '',
                to: this.endTime.time
            }]
            this.endLimit = [{
                type: 'fromto',
                from: this.startTime,
                to: ''
            }]
            this.fetchAlarmVideoSearch(this.searchObj)
        },
        ...mapActions({
            fetchVideoList: FETCH_VIDEO_LIST,
            fetchAlarmVideoSearch: FETCH_ALARM_VIDEO_SEARCH,
            exportAlarmVideo: EXPORT_ALARM_VIDEO,
            setAlarmVideoItem: SET_ALARM_VIDEO_ITEM,
        }),
        search() {
            this.fetchAlarmVideoSearch(this.searchObj)
        },
        detail(alarm) {
            this.alarmDialogData = alarm
            this.editObj.show.value = !this.editObj.show.value
        },
        pageEvent(page) {
            this.searchObj.page = page
            this.fetchAlarmVideoSearch(this.searchObj)
        },
        changeStartDate(startDate) {
            let date = startDate ? startDate + ' 00:00' : ''
            let start = formatDate((parseDateStrToTimestamp(date) / 1000 - 86400), 'Y-M-D')
            let end = formatDate((parseDateStrToTimestamp(date) / 1000 + 86400), 'Y-M-D')

            this.endLimit = [{
                type: 'fromto',
                from: start,
                to: ''
            }]
            this.searchObj['start_time'] = parseDateStrToTimestamp(date) / 1000
        },
        playVideo(index) {
            this.videoPlayObj = Object.assign({}, this.getAlarmVideoSearch[index].video)
            this.videoPlayObj.pts = this.getAlarmVideoSearch[index].pts
            this.videoPlay.show.value = !this.videoPlay.show.value
            let videoObj = document.querySelector('[name=videoplay]')
            let video = document.createElement('video')
            let source = document.createElement('source')

            video.innerHTML = `<source type="video/mp4" src="${this.videoPlayObj.path}">`
            videoObj.append(video)
            let videoElem = videoObj.querySelector('video')

            videoElem.controls = 'controls'
            videoElem.width = 690
            videoElem.height = 388
            videoElem.style.position = 'absolute'
            videoElem.style.left = '50%'
            videoElem.style.top = '50%'
            videoElem.style.marginLeft = '-346px'
            videoElem.style.marginTop = '-176px'
            videoElem.style.zIndex = '100'
            videoElem.src = this.videoPlayObj.path
            videoElem.autoplay = true
            videoElem.currentTime = this.videoPlayObj.pts
        },
        closeVideo() {
            let videoObj = document.querySelector('[name=videoplay]')
            let video = videoObj.querySelector('video')

            video.remove()
            this.videoPlay.show.value = !this.videoPlay.show.value
        },
        changeEndDate(endDate) {
            let date = endDate ? endDate + ' 00:00' : ''
            let start = formatDate((parseDateStrToTimestamp(date) / 1000 - 86400), 'Y-M-D')
            let end = formatDate((parseDateStrToTimestamp(date) / 1000 + 86400), 'Y-M-D')

            this.startLimit = [{
                type: 'fromto',
                from: '',
                to: end
            }]
            this.searchObj['end_time'] = parseDateStrToTimestamp(date) / 1000
        },
        exportEvent() {
            clearInterval(this.interval)
            this.alarmObjItem = Object.assign({}, {})
            for (let i in this.searchObj) {
                if (i != 'page') {
                    this.alarmObjItem[i] = this.searchObj[i]
                }
            }
            this.alarmObjItem.type = 2
            this.setAlarmVideoItem(this.alarmObjItem).then(() => {
                for (let i in this.getAlarmVideoItem) {
                    if (i == 'id') {
                        this.exportAlarm['task_id'] = this.getAlarmVideoItem[i]
                    }
                }
            })
            this.exportObj.show.value = !this.exportObj.show.value
            this.exportAlarm.size = 100
            this.exportAlarm.type = 2
            setTimeout(() => {
                this.interval = setInterval(() => {
                    this.exportAlarmVideo(this.exportAlarm)
                }, this.intervalTime)
            }, 500)
        },
        exportHistory() {
            clearInterval(this.interval)
            this.exportHistoryObj.show.value = !this.exportHistoryObj.show.value
            this.exportAlarmHistory.size = 100
            this.exportAlarmVideo(this.exportAlarmHistory)
            setTimeout(() => {
                this.interval = setInterval(() => {
                    this.exportAlarmVideo(this.exportAlarmHistory)
                }, this.intervalTime)
            }, 500)
        },
        downloadExcel(path) {
            let arr = path.split('/')
            let url = `${this.getServices.Skylab}`

            arr.shift()
            window.open(url + arr.join('/'))
        },
    },
    components: {
        TableComponent,
        PaginationComponent,
        DialogComponent,
        ConfirmComponent,
        DatepickerComponent,
        PanelComponent,
        TabImgComponent,
        FaceInfo,
        CrumbsComponent,
        AlarmDetails
    }
}
</script>

<style scoped>
.capture-video-search{
    height: 100%;
    width: 100%;
    padding: 50px 80px;
    box-sizing: border-box;
    min-height: 100%;
    .condition{
        margin-top: 16px;
        margin-bottom: 15px;
        color: #fff;
        .datepicker{
            display:inline-block;
        }
        .select{
            width: 250px;
        }
    }
    .play{
        display: inline-block;
        width: 70px;
        height: 32px;
        color: #fff;
        background: #737880;
        text-align: center;
        line-height: 32px;
        border-radius: 3px;
    }
    .panel-body.new-member{
        width: 420px;
        margin-top:-11px;
        &.edit-member{
            width: 844px;
            display: flex;
            .member-items{
                flex: 1;
                &.last{
                    margin-left: 10px;
                }
            }
        }
        .member-items{
            border: 1px solid #ececec;
            ul{
                display: block;
                height: 330px;
                overflow: auto;
            }
            li{
                display: flex;
                text-align: center;
                line-height: 30px;
                &:first-child{
                    border-bottom: 1px solid #ececed;
                }
                &>span{
                    flex: 1;
                    line-height: 28px;
                }
                &>div{
                    flex: 1;
                }
                a{
                    background: #4990e2;
                    line-height: 24px;
                    padding-left: 6px;
                    padding-right: 6px;
                    color: #fff;
                    border-radius: 2px;
                }
            }
            p{
                margin: 0 0 10px 0;
                line-height: 28px;
                padding-left: 5px;
                font-size: 14px;
                background: #fafafa;
                border-bottom: 1px solid #ececec;
            }
            .img-con{
                display: flex;                 
                &>div{
                    flex: 1;
                    padding: 5px 10px 15px 10px;
                    text-align: center;
                    .thumbnail{
                        width: 190px;
                        height: 230px;
                        background: #eee;
                        &:after{
                            display:inline-block;
                            width:0;
                            height:100%;
                            vertical-align:middle;
                            content:'';
                        }
                    }
                    span{
                        line-height: 24px;
                    }
                }
                img{
                    max-width: 100%;
                    max-height: 100%;
                    display: inline-block;
                    vertical-align: middle;
                }
            }
            .match-img-items{
                padding-left: 3px;
                margin-bottom: 10px;
                a{
                    display: inline-block;
                    width: 110px;
                    position: relative;
                    height: 110px;
                    color: #fff;
                    margin: 0 12px;
                    background: #eee;
                    opacity: 0.5;
                    &:hover{
                        opacity: 1;
                    }
                    &.active{
                        opacity: 1;
                        .mask{
                            display: block;
                        }
                    }
                    img{
                        width: 100%;
                        height: 100%;
                    }
                    span{
                        background: #f4b04f;
                        height: 16px;
                        line-height: 16px;
                        position: absolute;
                        bottom: 3px;
                        right: 3px;
                        border-radius: 3px;
                    }
                    .mask{
                        width: 104px;
                        height: 104px;
                        position: absolute;
                        top: 0;
                        left: 0;
                        display: none;
                        border: 3px solid #3E8FE0;
                    }
                }
            }
            .match-items{
                transition: all 0.2s;
                opacity: 1;
                &.fade{
                    opacity: 0;
                }
            }
        }
        input:disabled{
            cursor: not-allowed;
            background-color: #eeeeee;
        }
    }
    .table-img-con{
        display: inline-block;
        width: 100px;
        height: 120px;
        margin-top: 4px;
        margin-bottom: 4px;
        &:after{
            display:inline-block;
            width:0;
            height:100%;
            vertical-align:middle;
            content:'';
        }
        img{
            max-width: 100%;
            max-height: 100%;
            display:inline-block;
            vertical-align:middle;
        }
    }
    .form-group{
        height: 40px;
        position: relative;
        margin-left: -11px;
        margin-right: -11px;
    }
    .col3{
        width: 25%;
        float: left;
        min-height: 1px;
    }
    .col9{
        width:70%;
        float:left;
        min-height: 1px;
        &.bulk-info-check{
            display: flex;
            div{
                flex: 1;
                line-height: 24px;
            }
        }
    }
    .control-label{
        padding-right: 15px;
        padding-top: 5px;
        text-align: right;
    }
    lable{
        line-height: 32px;
        display: inline-block;
        margin-bottom: 5px;
    }
    .form-select{
        width: 86%;
    }
    .minWidth{
        min-width:150px;
    }
    .form-group-info{
        text-align: center;
        width: 100%;
        .left-tag{
            margin-right: 20px;
        }
    }
    .fail-table{
        text-align: left;
    }
}
.success{
    border-radius: 3px;
    padding: 2px 4px;
    background: #5ebd5e;
    color: #fff;
}
.danger{
    border-radius: 3px;
    padding: 2px 4px;
    background: #e66454;
    color: #fff;
}
.warning{
    border-radius: 3px;
    padding: 2px 4px;
    background: #f4b04f;
    color: #fff;
}
.video-bg{
    position: relative;
    padding: 10px;
    width: 710px;
    height: 424px;
    background: #257B97;
    margin: 0 auto;
    display: block;
    &.is-open{
        display: block;
    }
}
</style>