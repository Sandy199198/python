<template>
    <div class="captures">
        <div class="captures-header">
            <div class="capture-pic-header">
                <i class="fa fa-camera"></i>&nbsp;人脸抓拍
            </div>
            <div class="capture-title-info">
                <i class="fa fa-exclamation-circle"></i>&nbsp;只显示最新的30张抓拍图片,点击照片可以查看详情。
            </div>
            <div class="capture-info-header">
                <a href="#" @click.prevent="goCaptureHistory()">
                    查看历史
                </a>
            </div>
        </div>
        <transition-group name="alarm-list" tag="ul" mode="out-in" v-if="captures.length">
            <li v-for="capture of captures" :key="capture.id"> 
                <div class="capture-content">
                    <div class="capture-pic" @click.prevent="viewAlarmDetails(capture)">
                        <img :src="capture.face" alt="" width="88" height="88">
                        <span>{{capture.camera_location}}</span>
                    </div>
                </div>
            </li>
        </transition-group>
        <div class="nodata" v-else>暂无抓拍数据</div>
    </div>    
</template>

<script>
    import {GET_SERVICES } from 'store/modules/common'
    import {mapGetters } from 'vuex'
    export default {
        props: {
            captures: {
                type: Array,
                default() {
                    return []
                }
            }
        },
        computed: {
            ...mapGetters({
                getServices: GET_SERVICES
            })
        },
        methods: {
            goCaptureHistory() {
                window.open(`capture-history`)
            },
            viewAlarmDetails(capture) {
                this.$emit('openDetailDialog', capture)
            }
        }
    }
</script>

<style scoped>
    .captures {
        color: #FFF;
        box-sizing: border-box;
        padding: 40px 10px 0;
        position: relative;
        overflow: hidden;
        height:100%;
        background-image: linear-gradient(-180deg, rgba(3,162,214,0.30) 0%, rgba(0,115,166,0.30) 100%);
        border: 1px solid #00CBF9;
        border-radius: 8px;
        .nodata{
            text-align:center;
            margin-top: 100px;
        }
        .captures-header{
            /*background: rgba(50,60,78,1);*/
            width: 98%;
            position: absolute;
            top: 10px;
            left: 1%;
            display:flex;
            /*border-bottom: 1px solid #777;*/
            >div{
                height: 30px;
                line-height: 30px;
                text-align: center;
            }
            .capture-pic-header{
                width:90px;
            }
            .capture-title-info{
                color:#39b3d7;
            }
            .capture-info-header{
                flex:1;
                text-align:right;
                padding-right:10px;
                >a{
                    color:#e56544;
                }
            }
        }
        ul{
            /*background: rgba(50,60,78,1);*/
            height:99%;
            padding:10px;
            box-sizing: border-box;
            overflow-y: auto;
            background: rgba(255,255,255,0.10);
            border: 1px solid rgba(255,255,255,0.40);
            box-shadow: 0 2px 5px 0 rgba(0,0,0,0.50);
            border-radius: 20px;
            li{
                display:list-item;
                float: left;
                .capture-content{
                    display: flex;
                    .capture-pic{
                        width:92px;
                        height:110px;
                        text-align: center;
                        padding:1px;
                        overflow:hidden;
                        margin:2px 2px;
                        box-sizing: border-box;
                        border-radius: 2px;
                        cursor:pointer;
                        >img{
                            border:1px solid #eee;
                        }
                        >span{
                            font-family: '宋体';
                            font-size:12px;
                            text-overflow:ellipsis;
                            white-space:nowrap;
                            overflow:hidden;
                        }
                    }
                }
            }
        }
    }
</style>