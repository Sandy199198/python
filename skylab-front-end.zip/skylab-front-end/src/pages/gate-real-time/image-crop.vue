<template>
    <div class="alarm-history">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="table_content">
            <div class="condition">
                <div>
                    人物序号：
                    <input type="text" placeholder="请输入人物序号" ref="startId"  class="input-style custom"/>   
                </div>
                <a href="#" @click.prevent="search()" class="button-style">搜&nbsp;索</a>
            </div>
        </div>
        <div class="alarm-content">
            <span style="color:#fff;">当前人物序号：{{getImageCropList && getImageCropList.length && getImageCropList[0].id}}</span>
            <TableComponent :data="getImageCropList" :columns="columns">
                <span v-for="(item, index) in getImageCropList" :slot="'photos' + index">
                    <span v-if="item.photos && item.photos.length">
                        <div class="result-item" v-for="(n, i) in item.photos">
                            <div class="item-score">
                                <CropperComponent :img="n.path" :id="n.id" v-on:storeArea = "storeROI" :groupId="item.id"></CropperComponent>
                            </div>
                        </div>
                    </span>
                </span>
            </TableComponent>
        </div>
        <div style="margin-top:10px;">
            <a href="#" class="button-style" @click.prevent="view">预览</a>
        </div>
        <div style="overflow:hidden">
            <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
        </div>
        <ConfirmComponent :show="previewObj.show" :title="previewObj.title" :confirm="previewObj.confirm">
            <div slot="content">
                <ul>
                    <li v-for="(item, index) in getImageCropPreview.mark_rlt">
                        <img :src="item.path">
                        <p>
                            <input type="checkbox" :id="item.id" name="glass" v-on:change="changeGlass">
                            <label :for="item.id">眼镜</label>
                        </p>
                        <p>
                            <select name="rotate" v-on:change="changeRotate" :id="item.id">
                                <option :value="item.value" v-for="item in rotates">{{item.text}}</option>
                            </select>
                        </p>
                    </li>
                </ul>
                <select name="sex" ref="sex" style="margin-left: 20px;">
                    <option :value="item.value" v-for="item in gender">{{item.text}}</option>
                </select>
            </div>
        </ConfirmComponent>
    </div>
</template>

<script>
    import PaginationComponent from '@nanyun/pagination'
    import {GET_IMAGE_CROP_LIST,
            FETCH_IMAGE_CROP_LIST,
            MARK_IMAGE_CROP,
            GET_PAGE,
            CLEAR_IMAGE_CROP_LIST,
            PUT_IMAGE_CROP_PREVIEW,
            GET_IMAGE_CROP_PREVIEW,
            CLEAR_IMAGE_CROP_PREVIEW } from 'store/modules/image_crop'
    import { mapActions, mapGetters, mapMutations} from 'vuex'
    import CrumbsComponent from 'common/components/crumbs.vue'
    import URL from 'common/url'
    import TableComponent from '@nanyun/table'
    import PanelComponent from '@nanyun/panel'
    import ConfirmComponent from '@nanyun/confirm'
    import CropperComponent from 'common/components/image-cropper.vue'
    import { GENDER_CROP, ROTATE } from 'common/config'

    export default {
        data() {
            return {
                crumbs: [{
                    name: '首页',
                    path: {
                        name: URL.HOME
                    }
                }, {
                    name: '图片裁剪',
                    silent: true
                }],
                columns: [{
                    title: '图像',
                    type: 'img',
                    prop: 'photos'
                }],
                alarmData: {},
                rois: [],
                previewObj: {
                    autoClose: 10000,
                    title: '截图预览',
                    show: {
                        value: false
                    },
                    confirm: () => {
                        let sex = parseInt(this.$refs.sex.value)
                        let markData = []
                        let id = this.getImageCropPreview.id

                        for (let obj of this.previewData) {
                            let mark = Object.assign({}, obj)

                            mark['gender'] = sex
                            mark['rotate'] = obj.rotate
                            mark['mark_img_id'] = obj.id
                            markData.push(mark)
                        }
                        this.markImageCrop({
                            markData,
                            id
                        })
                        this.clearImageCropList()
                        this.alarmData.page = this.page
                        this.fetchData()
                    }
                },
                gender: GENDER_CROP,
                rotates: ROTATE,
                page: 1,
                previewData: [],
                startId: -1
            }
        },
        created() {
            this.fetchData()
        },

        computed: {
            ...mapGetters({
                getImageCropList: GET_IMAGE_CROP_LIST,
                getPage: GET_PAGE,
                getImageCropPreview: GET_IMAGE_CROP_PREVIEW
            })
        },

        methods: {
            fetchData() {
                this.fetchImageCropList(this.alarmData)
            },
            search() {
                let startId = this.$refs.startId.value

                this.alarmData['start_id'] = startId
                this.clearImageCropList()
                this.fetchData()
            },
            ...mapActions({
                fetchImageCropList: FETCH_IMAGE_CROP_LIST,
                markImageCrop: MARK_IMAGE_CROP,
                putImageCropPreview: PUT_IMAGE_CROP_PREVIEW
            }),
            ...mapMutations({
                clearImageCropList: CLEAR_IMAGE_CROP_LIST,
                clearImageCropPreview: CLEAR_IMAGE_CROP_PREVIEW
            }),
            pageEvent(page) {
                this.rois = []
                this.page = page
                this.clearImageCropList()
                this.alarmData.page = page
                this.fetchData()
            },
            view() {
                this.clearImageCropPreview()
                let markData = []

                for (let obj of this.rois) {
                    let mark = {}

                    mark['area'] = obj.area
                    mark['gender'] = obj.gender
                    mark['group_id'] = obj.groupId
                    mark['has_glass'] = obj['has_glass']
                    mark['photo_base64'] = ''
                    mark['photo_id'] = obj.photoId
                    mark['rotate'] = obj.rotate
                    markData.push(mark)
                }
                this.putImageCropPreview(markData)
                setTimeout(() => {
                    this.previewData = this.getImageCropPreview.mark_rlt
                }, 1500)
                this.previewObj.show.value = !this.previewObj.show.value
            },
            storeROI(obj) {
                let areaROI = obj.areaROI

                if (this.rois.length) {
                    for (let [index, roi] of this.rois.entries()) {
                        if (roi.photoId == obj.photoId) {
                            this.rois.splice(index, 1)
                        }
                    }
                }
                obj['has_glass'] = false
                obj['gender'] = '1'
                obj['area'] = areaROI.x + ',' + areaROI.y + ',' + areaROI.w + ',' + areaROI.h
                this.rois.push(obj)
            },
            changeGlass(e) {
                let val = e.target.checked, photoId = parseInt(e.target.id)

                for (let obj of this.previewData) {
                    if (obj.id == photoId) {
                        obj['has_glass'] = val
                    }
                }
            },
            changeRotate(e) {
                let val = e.target.value, photoId = parseInt(e.target.id)

                for (let obj of this.previewData) {
                    if (obj.id == photoId) {
                        obj['rotate'] = val
                    }
                }
            }
        },
        components: {
            PaginationComponent,
            CrumbsComponent,
            TableComponent,
            PanelComponent,
            CropperComponent,
            ConfirmComponent
        },
        destroyed() {
            this.clearImageCropList()
        }
    }
</script>

<style scoped>
    .alarm-history{
        padding: 50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        .table_content{
            width:100%;
            height: 30px;
            .condition {
                color:#fff;
                padding: 0 4px;
                &>div{
                    float: left;
                }
                .datepicker{
                    display:inline-block;
                    margin: 0 22px 10px 0;
                }
            }
            input, select{
                margin-right:10px;
                margin-bottom:10px;
                min-width: 192px;
            }
            input.custom{
                min-width: 180px;
            }
        }
        .alarm-content{
            margin-top:20px;
            .result-item{
                float: left;
                padding: 4px;
                margin:3px;
            }
        }
    }
    .nodata{
        text-align: center;
    }
    ul{
        height:100%;
        box-sizing: border-box;
        overflow-y: auto;
        li{
            display:list-item;
            float: left;
            padding: 10px;
            img{
                height: 200px;
            }
        }
    }
    select {
        border: 1px solid #FFFFFF;
        box-shadow: 0 2px 4px 0 rgba(0,0,0,0.50);
        border-radius: 8px;
        outline: none;
        color: #FFF;
        padding: 3px 5px;
        height: 30px;
        width: 150px;
        padding-left: 6px;
        background: url(../../images/arrow-down.png) right center no-repeat #163C4C;
    }
</style>