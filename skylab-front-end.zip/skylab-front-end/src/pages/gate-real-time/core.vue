<template>
    <div class="core">
        <div class="table_content">
            <div class="condition">
                <input type="text" class="input-style" placeholder="请输入core名称" v-model="searchObj.name"/>
                <a href="#" class="button-style search" @click.prevent="search">搜索</a>
                <a href="#" class="button-style" @click.prevent="add" style="float: right;">新建</a>
            </div>
            <TableComponent :data="getCore" :columns="columns">
                <span v-for="(item, index) in this.getCore" :slot="'events' + index">
                    <a href="#" title="修改"  @click.prevent="edit(index)">修改</a>
                    &nbsp;&nbsp;
                    <a href="#" title="删除"  @click.prevent="del(index)">删除</a>
                </span>
            </TableComponent>
            <div style="overflow: hidden;">
                <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
            </div>
            <ConfirmComponent :show="editObj.show" :title="editObj.text" :confirm="editObj.confirm">
                <div slot="content">
                    <div class="panel-body" style="padding-left: -11px;">
                        <div class="form-group">
                            <label class="control-label col3">名称</label>
                            <div class="col9">
                                <input type="text" name="corename" placeholder="必填" class="form-control form-input" v-if="coreData.id" v-model="coreData.name"/>
                                <input type="text" name="corename" placeholder="必填" class="form-control form-input" v-model="coreData.name" v-else>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">IP</label>
                            <div class="col9">
                                <input type="text" name="ip" placeholder="必填" class="form-control form-input" v-if="coreData.id" v-model="coreData.ip"/>
                                <input type="text" name="ip" placeholder="必填" class="form-control form-input" v-model="coreData.ip" v-else>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">PORT</label>
                            <div class="col9">
                                <input type="text" name="port" placeholder="必填" class="form-control form-input" v-if="coreData.id" v-model="coreData.port"/>
                                <input type="text" name="port" placeholder="必填" class="form-control form-input" v-model="coreData.port" v-else>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">类型</label>
                            <div class="col9" v-if="coreData.id">
                                <select name="type" class="form-control form-select" v-model="coreData.type">
                                    <option :value="option.value" v-for="option in coreSlt">{{option.text}}</option>
                                </select>
                            </div>
                            <div class="col9" v-else>
                                <select name="type" class="form-control form-select">
                                    <option :value="option.value" v-for="option in coreSlt">{{option.text}}</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
            <ConfirmComponent :show="deleteObj.show" :title="deleteObj.text" :confirm="deleteObj.confirm" :content="deleteObj.content">
            </ConfirmComponent>
        </div>  
    </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import TableComponent from '@nanyun/table'
import PaginationComponent from '@nanyun/pagination'
import ConfirmComponent from '@nanyun/confirm'
import {GET_CORE, FETCH_CORE, ADD_CORE, DEL_CORE, SET_CORE, GET_PAGE, UPDATE_CORE, SEARCH_CORE} from
'store/modules/core'
import {CORE} from 'common/config'
import URL from 'common/url'

export default {
    data() {
        return {
            coreData: {},
            searchObj: {
                name: '',
                page: ''
            },
            index: '',
            editObj: {
                autoClose: 10000,
                text: this.index ? '编辑CORE' : '新增CORE',
                show: {
                    value: false
                },
                confirm: () => {
                    if (this.index === '') {
                        this.coreData.name = document.querySelector('[name=corename]').value
                        this.coreData.ip = document.querySelector('[name=ip]').value
                        this.coreData.port = document.querySelector('[name=port]').value
                        this.coreData.type = document.querySelector('[name=type]').value
                        this.addCore(this.coreData).then(() => {
                            this.fetchData()
                        })
                    } else {
                        this.updateCore(this.coreData).then(() => {
                            this.fetchData()
                        })
                    }
                }
            },
            deleteObj: {
                autoClose: 10000,
                text: '确认删除',
                content: '确定删除该core?',
                show: {
                    value: false
                },
                confirm: () => {
                    this.delCore(this.index).then(() => {
                        this.fetchCore()
                    })
                }
            },
            coreSlt: CORE,
            columns: [{
                title: '名称',
                prop: 'name'
            }, {
                title: 'IP',
                prop: 'ip',
            }, {
                title: 'PORT',
                prop: 'port',
            }, {
                title: '操作',
                type: 'events'
            }]
        }
    },
    created() {
        this.fetchData()
    },
    computed: {
        ...mapGetters({
            getCore: GET_CORE,
            getPage: GET_PAGE,
        }),
    },
    methods: {
        fetchData() {
            this.fetchCore()
        },
        ...mapActions({
            fetchCore: FETCH_CORE,
            delCore: DEL_CORE,
            addCore: ADD_CORE,
            setCore: SET_CORE,
            updateCore: UPDATE_CORE,
            searchCore: SEARCH_CORE
        }),
        search() {
            this.searchCore(this.searchObj)
        },
        add() {
            this.editObj.show.value = !this.editObj.show.value
            this.coreData = {}
            this.index = ''
        },
        edit(index) {
            this.editObj.show.value = !this.editObj.show.value
            this.coreData = Object.assign({}, this.getCore[index])
            this.index = this.coreData.id
        },
        del(index) {
            this.deleteObj.show.value = !this.deleteObj.show.value
            this.coreData = Object.assign({}, this.getCore[index])
            this.index = this.coreData.id
        },
        pageEvent(page) {
            this.searchObj.page = page
            this.searchCore(this.searchObj)
        }
    },
    components: {
        TableComponent,
        PaginationComponent,
        ConfirmComponent,
    }
}
</script>

<style scoped>
    .core{
        height: 100%;
        /*padding: 50px 80px;*/
        box-sizing: border-box;
        min-height: 100%;
        width: 1300px;
        /*margin: 20px 55px 70px 25px;*/
        .condition{
            margin-top: 16px;
            margin-bottom: 15px;
            input{
                height: 16px;
            }
            .btn{
                display: inline-block;
                color: #fff;
                text-decoration: none;
                padding-left: 32px;
                padding-right: 32px;
                margin-left: 17px;
                background: #4990e2;
                border-radius: 3px;
                font-size: 12px;
                line-height: 2;
                &.search{
                    vertical-align: top;
                }
            }
        }
        .form-select{
            width: 84%;
        }
        .minWidth{
            min-width:150px;
        }
    }
</style>