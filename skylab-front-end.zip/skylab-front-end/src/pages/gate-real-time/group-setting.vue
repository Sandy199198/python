<template>
    <div class="group-setting">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="table_content">
            <div class="condition">
                <input type="text" class="input-style" placeholder="请输入底库名称" v-model="searchObj.name"/>
                <a href="#" class="button-style search" @click.prevent="search">搜索</a>
                <a href="#" class="button-style" @click.prevent="add">新建底库</a>
                <a href="#" class="button-style" @click.prevent="bulk" style="float: right;">批量入库</a>
                <a href="#" class="button-style" @click.prevent="addPhoto" style="float: right;">单张入库</a>
            </div>
            <TableComponent :data="getGroup" :columns="columns">
                <span v-for="(item, index) in this.getGroup" :slot="'events' + index">
                    <a href="#" title="查看"  @click.prevent="view(index)">查看</a>
                    &nbsp;&nbsp;
                    <a href="#" title="修改"  @click.prevent="edit(index)">修改</a>
                    &nbsp;&nbsp;
                    <a href="#" title="删除"  @click.prevent="del(index)">删除</a>
                </span>
            </TableComponent>
            <div style="overflow: hidden;">
                <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
            </div>
            <ConfirmComponent :show="editObj.show" :title="editObj.text" :confirm="editObj.confirm">
                <div slot="content">
                    <div class="panel-body-group" style="padding-left: -11px;">
                        <div class="form-group">
                            <label class="control-label col3">底库名</label>
                            <div class="col9">
                                <input type="text" name="groupname" placeholder="必填" class="form-control form-input" v-if="groupData.id" v-model="groupData.name"/>
                                <input type="text" name="groupname" placeholder="必填" class="form-control form-input" v-model="groupData.name" v-else>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">状态</label>
                            <div class="col9">
                                <select name="status" class="form-control form-select" v-model="groupData.status" v-if="groupData.status != null">
                                    <option v-for="option in statusList" :value="option.value">{{option.text}}</option>
                                </select>
                                <select name="status" class="form-control form-select" v-else>
                                    <option v-for="option in statusList" :value="option.value">{{option.text}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">所属分局</label>
                            <div class="col9" v-if="groupData.user_group_id">
                                <select name="user_group_id" class="form-control form-select" v-model="groupData.user_group_id">
                                    <option :value="option.id" v-for="option in this.getUserGroupList">{{option.name}}</option>
                                </select>
                            </div>
                            <div class="col9" v-else>
                                <select name="user_group_id" class="form-control form-select">
                                    <option :value="option.id" v-for="option in this.getUserGroupList">{{option.name}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">备注</label>
                            <div class="col9 simple">
                                <textarea name="remark" class="form-control form-textarea" rows="3" v-model="groupData.remark"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
            <ConfirmComponent :show="deleteObj.show" :title="deleteObj.text" :confirm="deleteObj.confirm" :content="deleteObj.content">
            </ConfirmComponent>
            <ConfirmComponent :show="addPhotoObj.show" title="新增人员" :confirm="addPhotoObj.confirm" :cancel="addPhotoObj.cancel">
                <div slot="content">
                    <div class="panel-body new-member" style="padding-top:-11px;">
                        <div class="member-img">
                            <form name="imgOption">
                                <IconUploadComponent :type="defaultSetting.iconType" v-on:changeImg="change()" v-on:dltImg="dltImg()" v-if="path == null"></IconUploadComponent>
                                <IconUploadComponent :type="defaultSetting.iconType" v-on:changeImg="change()" v-else :imgSrc="path" v-on:dltImg="dltImg()"></IconUploadComponent>
                            </form>
                        </div>
                        <div class="member-items">
                            <div class="form-group">
                                <label class="control-label col3">底库</label>
                                <div class="col9">
                                    <select class="form-control form-select" name="m_group_id">
                                        <option :value="option.id" v-for="option in getGroup">{{option.name}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">姓名</label>
                                <div class="col9">
                                    <input type="text" name="m_name" placeholder="选填" class="form-control form-input" v-model="memberData.name"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">性别</label>
                                <div class="col9">
                                    <select name="m_gender" class="form-select form-control">
                                        <option :value="item.value" v-for="item in bulkItems.gender">{{item.text}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">证件类型</label>
                                <div class="col9">
                                    <select class="form-control form-select" name="m_cert_type">
                                        <option v-for="item in bulkItems.certType" :value="item.value">{{item.text}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">证件号码</label>
                                <div class="col9">
                                    <input type="text" name="m_cert_id" placeholder="选填" class="form-control form-input" v-model="memberData.cert_id"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">案底</label>
                                <div class="col9">
                                    <select class="form-control form-select" name="m_criminal_record">
                                        <option v-for="item in bulkItems.crmRecord" :value="item.value">{{item.text}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">身份类型</label>
                                <div class="col9">
                                    <select name="m_label" class="form-control form-select">
                                        <option v-for="item in bulkItems.label" :value="item.value">{{item.text}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">备注</label>
                                <div class="col9 simple">
                                    <textarea name="m_remark" class="form-control form-textarea" rows="3" v-model="memberData.remark"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
            <ConfirmComponent :show="bulkObj.show" :title="bulkObj.text">
                <div slot="content">
                    <div class="panel-body bulkcontainer" style="padding-top: -11px">
                        <div class="uploadtips">
                            <i class="fa fa-info-circle text-primary"></i>{{tips}}
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">选择底库</label>
                            <div class="col9">
                                <select class="form-control form-select" name="b_group_id">
                                    <option :value="item.id" v-for="item in getGroup">{{item.name}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">证件类型</label>
                            <div class="col9">
                                <select class="form-control form-select" name="b_cert_type">
                                    <option v-for="item in bulkItems.certType" :value="item.value">{{item.text}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">案底</label>
                            <div class="col9">
                                <select class="form-control form-select" name="b_criminal_record">
                                    <option v-for="item in bulkItems.crmRecord" :value="item.value">{{item.text}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">身份类型</label>
                            <div class="col9">
                                <select name="b_label" class="form-control form-select">
                                    <option v-for="item in bulkItems.label" :value="item.value">{{item.text}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">信息勾选</label>
                            <div class="col9 bulk-info-check">
                                <div class="info-check">
                                    <input type="checkbox" name="infos" value="0" checked disabled id="info_0">
                                    <label for="info_0">姓名</label>
                                </div>
                                <div class="info-check">
                                    <input type="checkbox" name="infos" value="1" id="info_1" v-on:change="toggleInfo">
                                    <label for="info_1">性别</label>
                                </div>
                                <div class="info-check">
                                    <input type="checkbox" name="infos" value="2" id="info_2" v-on:change="toggleInfo">
                                    <label for="info_2">证件号</label>
                                </div>
                                <div class="info-check">
                                    <input type="checkbox" name="infos" value="3" id="info_3" v-on:change="toggleInfo">
                                    <label for="info_3">备注</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">上传图片</label>
                            <div class="col9">
                                <input type="file" class="fileupload" multiple="multiple" accept="image/jpeg, image/png, image/bmp" v-on:change="bulkChange">
                                <a href="#" @click.prevent="bulkEvent" class="btn bulkbtn">批量新建</a>
                            </div>
                        </div>
                        <div class="uploadtips">
                            <i class="fa fa-exclamation-circle text-sky"></i>
                            <span>{{subTips}}</span>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
            <DialogComponent :show="uploadInfo.show" :title="uploadInfo.text" :cancel="uploadInfo.cancel">
                <div slot="content">
                    <div class="panel-body" style="padding-top: -11px">
                        <div class="form-group-info" v-if="isProgress">
                            <ProgressComponent :styleSetting="defaultSetting.styleS"></ProgressComponent>
                        </div>
                        <div class="form-group-info" v-else>
                            <p class="success-title">批量上传已完成！</p>
                            <div class="success-info">
                                <Tag class="left-tag" :type="defaultSetting.success">{{bulkMemberDataList.length}}</Tag>
                                <Tag :type="defaultSetting.danger">{{bulkMemberErrorList.length}}</Tag>
                            </div>
                            <div v-if="getBulkUploadError.length">
                                <p class="success-title">失败列表</p>
                                <div class="fail-table" v-for="item in getBulkUploadError">{{item.fields}}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </DialogComponent>
            <ConfirmComponent :show="error.show" :title="error.text" :content="error.content"></ConfirmComponent>
        </div>    
    </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import TableComponent from '@nanyun/table'
import PaginationComponent from '@nanyun/pagination'
import ConfirmComponent from '@nanyun/confirm'
import DialogComponent from '@nanyun/dialog'
import {GET_GROUP, FETCH_GROUP_PAGINATION, ADD_GROUP, DEL_GROUP, SET_GROUP, GET_PAGE, UPDATE_GROUP, SEARCH_GROUP} from
'store/modules/group'
import {GET_USER_GROUP_LIST, FETCH_USER_GROUP_LIST} from 'store/modules/user_group_info'
import {STATUS, GENDER, CERTTYPE, CRIMINALRECORD, LABEL } from 'common/config'
import CrumbsComponent from 'common/components/crumbs.vue'
import URL from 'common/url'
import {ADD_MEMBER, SET_MEMBER, GET_UPLOAD_IMG, UPLOAD_IMG, GET_BULK_UPLOAD_ERROR, GET_BULK_UPLOAD, BULK_UPLOAD_ERROR, BULK_UPLOAD, CLEAR_BULK_UPLOAD_ERROR} from
'store/modules/member'
import IconUploadComponent from 'common/components/icon-upload.vue'
import Tag from 'common/components/tag.vue'
import Thumbnail from 'common/components/thumbnail.vue'
import ProgressComponent from 'common/components/progress.vue'
import {verifyCertId, verifyGender} from 'common/utils'

export default {
    data() {
        return {
            crumbs: [{
                name: '首页',
                path: {
                    name: URL.HOME
                }
            }, {
                name: '底库管理',
                slient: true
            }],
            groupData: {
                status: '1'
            },
            searchObj: {
                name: '',
                page: ''
            },
            index: '',
            editObj: {
                autoClose: 10000,
                text: this.index ? '编辑底库' : '新增底库',
                show: {
                    value: false
                },
                confirm: () => {
                    if (this.index === '') {
                        this.groupData.name = document.querySelector('[name=groupname]').value
                        this.groupData.status = document.querySelector('[name=status]').value
                        this.groupData['user_group_id'] = document.querySelector('[name=user_group_id]').value
                        this.groupData.remark = document.querySelector('[name=remark]').value
                        this.addGroup(this.groupData)
                        this.fetchData()
                    } else {
                        this.updateGroup(this.groupData)
                    }
                }
            },
            deleteObj: {
                autoClose: 10000,
                text: '确认删除',
                content: '确定删除该底库?',
                show: {
                    value: false
                },
                confirm: () => {
                    this.delGroup(this.index).then(() => {
                        this.fetchGroup()
                    })
                }
            },
            allBranch: [],
            statusList: STATUS,
            path: '',
            memberData: {},
            error: {
                autoClose: 10001,
                text: '提示',
                content: '1111',
                show: {
                    value: false
                },
            },
            defaultSetting: {
                success: 'success',
                danger: 'danger',
                iconType: 'default',
                styleS: {
                    width: '50%'
                }
            },
            bulkMemberData: {},
            bulkMemberDataList: [],
            bulkMemberErrorList: [],
            photoIds: [],
            tips: '选择一张或者多张照片直接批量上传，每张照片都将作为一个独立的人员加入底库。',
            subTips: '(为保证正确解析,文件名请以勾选信息格式顺序命名,如:xx_男_12345678_xx)',
            infos: [0],
            uploadInfo: {
                autoClose: 10000,
                text: '批量上传详情',
                show: {
                    value: false
                },
                cancel: () => {
                    this.bulkMemberDataList.map((item) => {
                        this.addMember(item).then(() => {
                            this.fetchData()
                        })
                    })
                }
            },
            bulkObj: {
                autoClose: 10000,
                text: '批量上传详情',
                show: {
                    value: false
                }
            },
            bulkItems: {
                gender: GENDER,
                certType: CERTTYPE,
                crmRecord: CRIMINALRECORD,
                label: LABEL
            },
            editUpload: 'icon',
            isProgress: true,
            imgObj: {
                autoClose: 10000,
                text: '图像展示',
                show: {
                    value: false
                },
                list: []
            },
            addPhotoObj: {
                autoClose: 10000,
                show: {
                    value: false
                },
                confirm: () => {
                    this.memberData.gender = document.querySelector('[name=m_gender]').value
                    this.memberData['group_id'] = document.querySelector('[name=m_group_id]').value
                    this.memberData['cert_type'] = document.querySelector('[name=m_cert_type]').value
                    this.memberData['criminal_record'] = document.querySelector('[name=m_criminal_record]').value
                    this.memberData.label = document.querySelector('[name=m_label]').value
                    this.memberData.name = document.querySelector('[name=m_name]').value
                    this.memberData['cert_id'] = document.querySelector('[name=m_cert_id]').value
                    this.memberData['photo_ids'] = this.photoIds.toString()
                    this.memberData.remark = document.querySelector('[name=m_remark]').value
                    this.addMember(this.memberData).then(() => {
                        this.fetchData()
                    })
                },
            },
        }
    },
    created() {
        this.fetchData()
    },
    computed: {
        ...mapGetters({
            getGroup: GET_GROUP,
            getPage: GET_PAGE,
            getUserGroupList: GET_USER_GROUP_LIST,
            getUploadImg: GET_UPLOAD_IMG,
            getBulkUploadError: GET_BULK_UPLOAD_ERROR,
            getBulkUpload: GET_BULK_UPLOAD
        }),
        columns() {
            let tempColumns = [{
                title: '底库名称',
                prop: 'name'
            }, {
                title: '底库人员数量',
                prop: 'subject_count',
            }, {
                title: '状态',
                prop: 'status',
                handle: d => {
                    if (d == 0) {
                        return '私有'
                    } else {
                        return '公开'
                    }
                }
            }, {
                title: '所属分局',
                prop: 'user_group_id',
                handle: d => {
                    let groupName = '-'

                    this.getUserGroupList.forEach(function (group) {
                        if (group.id == d) {
                            groupName = group.name
                        }
                    })
                    return groupName
                }
            }, {
                title: '备注',
                prop: 'remark',
                handle: d => {
                    return d ? d : '-'
                }
            }, {
                title: '操作',
                type: 'events'
            }]

            return tempColumns
        }
    },
    methods: {
        fetchData() {
            this.fetchGroup()
            this.fetchUserGroupList()
        },
        ...mapActions({
            fetchGroup: FETCH_GROUP_PAGINATION,
            delGroup: DEL_GROUP,
            addGroup: ADD_GROUP,
            setGroup: SET_GROUP,
            fetchUserGroupList: FETCH_USER_GROUP_LIST,
            updateGroup: UPDATE_GROUP,
            searchGroup: SEARCH_GROUP,
            addMember: ADD_MEMBER,
            setMember: SET_MEMBER,
            uploadImg: UPLOAD_IMG,
            bulkUpload: BULK_UPLOAD
        }),
        ...mapMutations({
            clearBulkUploadError: CLEAR_BULK_UPLOAD_ERROR
        }),
        search() {
            this.searchGroup(this.searchObj)
        },
        add() {
            this.editObj.show.value = !this.editObj.show.value
            this.groupData = {}
            this.index = ''
        },
        edit(index) {
            this.editObj.show.value = !this.editObj.show.value
            this.groupData = Object.assign({}, this.getGroup[index])
            this.index = this.groupData.id
        },
        del(index) {
            this.deleteObj.show.value = !this.deleteObj.show.value
            this.groupData = Object.assign({}, this.getGroup[index])
            this.index = this.groupData.id
        },
        view(index) {
            this.$router.push({
                name: URL.MANAGE.MEMBER_INFO,
                params: {
                    groupId: this.getGroup[index].id,
                }
            })
        },
        addPhoto() {
            this.memberData = {}
            this.photoIds = []
            this.path = ''
            this.addPhotoObj.show.value = !this.addPhotoObj.show.value
        },
        change() {
            let imgOption = document.querySelector('[name=imgOption]')

            this.uploadImg(imgOption).then(() => {
                this.photoIds[0] = this.getUploadImg.id
                this.path = this.getUploadImg.path
            })
        },
        dltImg() {
            this.getUploadImg = {}
            this.photoIds = []
        },
        pageEvent(page) {
            this.searchObj.page = page
            this.searchGroup(this.searchObj)
        },
        bulk() {
            this.bulkObj.show.value = !this.bulkObj.show.value
        },
        toggleInfo(e) {
            let value = e.currentTarget.value

            if (this.infos.indexOf(value) > -1) {
                this.infos.splice(value, 1)
            } else {
                this.infos.push(value)
            }
        },
        bulkEvent() {
            this.bulkChange()
        },
        setBulkMemberData() {
            this.bulkMemberData = {}
            this.bulkMemberData['group_id'] = document.querySelector('[name=b_group_id]').value
            this.bulkMemberData['criminal_record'] = document.querySelector('[name=b_criminal_record]').value
            this.bulkMemberData['label'] = document.querySelector('[name=b_label]').value
            this.bulkMemberData['cert_type'] = document.querySelector('[name=b_cert_type]').value
        },
        bulkChange(e) {
            this.bulkMemberDataList = []
            this.bulkMemberErrorList = []
            this.clearBulkUploadError()
            let fileReg = /^([^_]+)_([^_]*)_([^_]*)_([^_.]*)(?:\.\w+)?$/
            let files = e.currentTarget.files, len = files.length
            let groupId = document.querySelector('[name=b_group_id]').value
            let ciminalRecord = document.querySelector('[name=b_criminal_record]').value
            let label = document.querySelector('[name=b_label]').value
            let certType = document.querySelector('[name=b_cert_type]').value

            if (files.length > 200) {
                this.error.content = '单次上传图片数不能大于200张!'
                this.error.show.value = !this.error.show.value
                return
            }
            this.bulkObj.show.value = !this.bulkObj.show.value
            this.uploadInfo.show.value = !this.uploadInfo.show.value
            this.isProgress = true
            for (let index = 0; index < len; index++) {
                let file = files[index], options = new FormData(), filename = file.name
                let fileName = filename.replace(/\.\w+$/, ''), name = '', number = '', duty = '', genderStr  = ''
                let photoInfo = fileName.split('_')

                options.append('photo', file)
                this.defaultSetting.styleS.width = (index + 1) / len * 100 + '%'
                this.infos.map((n, index) => {
                    if (n == 0) {
                        name = photoInfo[0] || fileName
                    } else {
                        for (let i = 1; i < photoInfo.length; i++) {
                            if (n == 1 && verifyGender(photoInfo[i])) {
                                genderStr = photoInfo[i]
                            } else if (n == 2 && verifyCertId(photoInfo[i])) {
                                number = photoInfo[i]
                            } else if (n == 3 && photoInfo.length > 3) {
                                duty = photoInfo[3]
                            }
                        }
                    }
                })
                this.bulkUpload({
                    formData: options,
                    name: filename
                }).then(() => {
                    // this.setBulkMemberData()
                    this.bulkMemberData = {}
                    this.bulkMemberData['group_id'] = groupId
                    this.bulkMemberData['criminal_record'] = ciminalRecord
                    this.bulkMemberData['label'] = label
                    this.bulkMemberData['cert_type'] = certType
                    this.bulkMemberData.name = name
                    this.bulkMemberData['cert_id'] = number
                    this.bulkMemberData.remark = duty
                    GENDER.map((item) => {
                        if (item.text == genderStr) {
                            this.bulkMemberData.gender = item.value
                        }
                    })
                }).then(() => {
                    if (this.getBulkUpload.id) {
                        this.bulkMemberDataList.push(Object.assign({
                            'photo_ids': this.getBulkUpload.id
                        }, this.bulkMemberData))
                    } else {
                        this.bulkMemberErrorList = this.getBulkUploadError
                    }
                    if (index == len - 1) { this.isProgress = false }
                })
            }
        },
    },
    components: {
        TableComponent,
        PaginationComponent,
        ConfirmComponent,
        CrumbsComponent,
        IconUploadComponent,
        Tag,
        ProgressComponent,
        Thumbnail,
        DialogComponent
    }
}
</script>

<style scoped>
    @keyframes rotate{
        0%{-webkit-transform:rotate(0);transform:rotate(0)}
        50%{-webkit-transform:rotate(180deg);transform:rotate(180deg)}
        100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}
    }
    .group-setting{
        height: 100%;
        padding: 50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        width: 100%;
        form{
            height: 100%;
        }
        .condition{
            margin-top: 16px;
            margin-bottom: 15px;
            input{
                height: 16px;
            }
        }
        .btn{
            display: inline-block;
            color: #fff;
            text-decoration: none;
            width: 90px;
            height: 30px;
            text-align: center;
            margin-left: 5px;
            background: #4990e2;
            border-radius: 3px;
            font-size: 12px;
            line-height: 30px;
            &.search{
                vertical-align: top;
                margin-left: 0;
            }
            &.bulkbtn{
                height: 24px;
                line-height: 24px;
                margin-left: 0;
                color: #FFF;
                outline: none;
                cursor: pointer;
                background-image: linear-gradient(-180deg, #0082AC 0%, #008BC8 100%);
                border: 1px solid #FFFFFF;
                box-shadow: 0 1px 2px 0 #50E3C2;
                border-radius: 8px;
            }
        }
        .panel-body-group{
            background-image: linear-gradient(-180deg, #000304 2%, #002636 99%);
            border-radius: 7px;
            padding: 10px;
            opacity: 0.8;
            min-height: 180px;
            .form-select{
                width: 84%;
            }
        }
        .form-select{
            width: 86%;
        }
        .fileupload{
            position: absolute;
            width: 100px;
            height: 24px;
            opacity: 0;
        }
        .panel-body.new-member{
            display: flex;
            width: 620px;
            opacity: 0.8;
            background-image: linear-gradient(-180deg, #000304 4%, #002636 99%);
            border: 0 solid #FFFFFF;
            border-radius: 7px;
            padding: 10px;
            .member-img{
                flex: 1;
                position: relative;
                width: 100%;
                height: 338px;
                background: #f0f0f0;
                border: 1px solid #d6d6d6;
                .thumbnail{
                    float: left;
                    width: 33%;
                    height: 30%;
                    margin-top: 12px;
                    position: relative;
                }
                img{
                    max-width: 100%;
                    max-height: 100%;
                }
            }
            .member-items{
                flex: 1;
            }
        }
        .bulkcontainer{
            opacity: 0.8;
            background-image: linear-gradient(-180deg, #000304 4%, #002636 99%);
            border: 0 solid #FFFFFF;
            border-radius: 7px;
            padding: 10px;
        }
        .uploadtips{
            line-height: 18px;
            margin-bottom: 10px;
            color: #39b3d7;
            .text-primary{
                color: #39b3d7;
            }
            i{
                margin-right: 5px;
            }
            span,.text-sky{
                color: #39b3d7;
            }
        }
        .form-group-info{
            text-align: center;
            width: 100%;
            .left-tag{
                margin-right: 20px;
            }
        }
        .success-title{
            font-size:16px;
            font-weight:bold;
            line-height:32px;
        }
        .success-info{
            display: flex;
        }
        .fail-table{
            text-align: left;
        }
        .panel-body.bulkcontainer{
            width: 420px;
            &>div{
                width: 100%;
            }
        }
    }
</style>