<template>
    <div class="group">
        <transition class="header-z-index">
        </transition>
        <router-view class="right-content"></router-view>
        <div class="loading">
            <div class="spinner">
                <div class="react1"></div>
                <div class="react2"></div>
                <div class="react3"></div>
                <div class="react4"></div>
                <div class="react5"></div>
            </div>
        </div>
    </div>  
</template>

<script>
import LEFTURL from 'common/url'
import {
    mapGetters,
    mapActions,
    mapMutations } from 'vuex'
import {
    DISABLED_ERROR } from 'store/modules/common'
export default {
    data() {
        return {
            menu: {
                realTimeSubM: false,
                groupSubM: false,
                searchSubM: false
            },
            LEFTURL,
        }
    },
    methods: {
        closeDialog() {
            this.$store.commit({
                type: DISABLED_ERROR
            }, {
                slient: true
            })
        }
    }
}
</script>

<style scoped>
    .group{
        display: flex;
        height: 100%;
        background: #182c41;
    }
    .left-content{
        padding-top: 10px;
        width: 200px;
        background: #23313c;
        height: 100%;
        overflow: hidden;
        position: relative;
    }
    .right-content{
        flex: 1;
        width: 100%;
        margin: 10px 50px 20px 25px;
    }
    .header-z-index{
        z-index:1000;
    }
    .loading{
        position:absolute;
        top:50%;
        left:50%;
        z-index:-1;
        color:#FFF;
        font-size:50px;
        margin-left:-25px;
        margin-top:-120px;
    }

    .spinner {
        margin: 100px auto;
        width: 50px;
        height: 40px;
        text-align: center;
        font-size: 10px;
    }

    .spinner > div {
        background-color: #FFF;
        height: 100%;
        width: 6px;
        display: inline-block;

        -webkit-animation: sk-stretchdelay 1.2s infinite ease-in-out;
        animation: sk-stretchdelay 1.2s infinite ease-in-out;
    }

    .spinner .rect2 {
        -webkit-animation-delay: -1.1s;
        animation-delay: -1.1s;
    }

    .spinner .rect3 {
        -webkit-animation-delay: -1.0s;
        animation-delay: -1.0s;
    }

    .spinner .rect4 {
        -webkit-animation-delay: -0.9s;
        animation-delay: -0.9s;
    }

    .spinner .rect5 {
        -webkit-animation-delay: -0.8s;
        animation-delay: -0.8s;
    }

    @-webkit-keyframes sk-stretchdelay {
        0%, 40%, 100% { -webkit-transform: scaleY(0.4) }  
        20% { -webkit-transform: scaleY(1.0) }
    }

    @keyframes sk-stretchdelay {
        0%, 40%, 100% { 
            transform: scaleY(0.4);
            -webkit-transform: scaleY(0.4);
        }  20% { 
            transform: scaleY(1.0);
            -webkit-transform: scaleY(1.0);
        }
    }
</style>
