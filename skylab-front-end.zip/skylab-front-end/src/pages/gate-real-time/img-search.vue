<template>
    <div class="img-search">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <h4>检索条件</h4>
        <form class="search-option" name="formDate">
            <input type="text" name="groups" style="display: none;">
            <div class="result">
                <div class="title">
                    条件选择
                </div>
                <div class="condition">
                    结果&nbsp;&nbsp;
                    <select name="limit" ref="limit">
                        <option :value="item.value" v-for="item in resultValueList">{{item.text}}</option>
                    </select>
                </div>
            </div>
            <div class="group">
                <div class="title">
                    底库选择<span role="groupErr" class="error">请选择底库</span>
                </div>
                <div class="condition group-content">
                    <div>
                        <div class="group-select" v-for="item in getGroup">
                            <input type="checkbox" :id="'group' + item.id" name="group" :value="item.id" v-on:change="changeGroup">
                            <label :for="'group' + item.id">{{item.name}}</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="select-img">
                <div class="title">
                    图片选择(支持批量上传)<span role="imgErr" class="error">请上传图片</span>
                </div>
                <div class="condition img-content">
                    <div class="img-con">
                        <div class="file-upload">
                            <input type="file" name="images" multiple v-on:change="onChange" accept="image/jpeg, image/png, image/bmp" class="upload">
                            <div class="upload-con">
                                <a href="#" class="upload-btn">
                                    <i class="fa fa-cloud-upload"></i>
                                    <span>点击此处<br>上传图片</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <h4>检测结果</h4>
        <div class="search-content">
            <TableComponent :data="getImgSearch" :columns="columns">
                <span v-for="(items, index) in getImgSearch" :slot="'sourceImg' + index">
                    <div class="capture-item" >
                        <div class="item-score">
                            <img :src="items.sourceImg" alt="">
                        </div>
                    </div>
                </span>
                <span v-for="(item, index) in getImgSearch" :slot="'photos' + index">
                    <span v-if="item.photos && item.photos.length">
                        <div class="result-item" v-for="(n, i) in item.photos">
                            <div class="item-score">
                                <img :src="n.path" alt="" @click.prevent="showInfo(n)">
                                <span class="score">{{n ? n.score.toFixed(2) : '-'}}</span>
                            </div>
                            <div class="item-info">
                                <p :title="n.subject ? n.subject.group.name : '-'">{{n.subject ? n.subject.group.name : '-'}}</p>
                                <p :title="n.subject.timestamp | formatDate">{{n.subject.timestamp | formatDate}}</p>
                            </div>
                        </div>
                    </span>
                <span>
            </TableComponent>
        </div>  
        <DialogComponent :show="editObj.show" :title="editObj.text" class="dialog-con">
            <div slot="content">
                <div class="panel-body new-member" style="padding-top:-11px;">
                    <ImgSearchInfoComponent :data="memberData" :groups="getGroup"></ImgSearchInfoComponent>
                </div>
            </div>
        </DialogComponent>
    </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import FileUploadComponent from 'common/components/upload.vue'
import ImgSearchInfoComponent from 'common/components/img-search-info.vue'
import {RESULT} from 'common/config'
import {GET_GROUP, FETCH_GROUP} from 'store/modules/group'
import DialogComponent from '@nanyun/dialog'
import {GET_IMG_SEARCH, FETCH_IMG_SEARCH, GET_PAGE, CLEAR_IMG_SEARCH} from 'store/modules/search'
import {formatDate, parseDateStrToTimestamp, convertToSeconds} from 'common/utils'
import { GENDER, CERTTYPE, CRIMINALRECORD, LABEL } from 'common/config'
import CrumbsComponent from 'common/components/crumbs.vue'
import URL from 'common/url'
import TableComponent from '@nanyun/table'

export default {
    data() {
        return {
            crumbs: [{
                name: '首页',
                path: {
                    name: URL.HOME
                }
            }, {
                name: '图片检索',
                slient: true
            }],
            resultValueList: RESULT,
            groupList: [],
            editObj: {
                autoClose: 10000,
                text: '照片详情',
                show: {
                    value: false
                },
            },
            memberData: {},
            imgCardMode: 'img',
            columns: [{
                title: '上传图像',
                type: 'img',
                width: '200px',
                prop: 'sourceImg'
            }, {
                title: '比对图像',
                type: 'img',
                prop: 'photos'
            }],
        }
    },
    created() {
        this.fetchData()
    },
    computed: {
        ...mapGetters({
            getGroup: GET_GROUP,
            getPage: GET_PAGE,
            getImgSearch: GET_IMG_SEARCH
        }),
    },
    methods: {
        fetchData() {
            this.fetchGroup()
        },
        ...mapActions({
            fetchGroup: FETCH_GROUP,
            fetchImgSearch: FETCH_IMG_SEARCH,
        }),
        ...mapMutations({
            clearImgSearch: CLEAR_IMG_SEARCH
        }),
        changeGroup(e) {
            let val = e.target.value, index = this.groupList.indexOf(val)
            let groupErr = document.querySelector('[role=groupErr]')

            if (index > -1) {
                this.groupList.splice(index, 1)
            } else {
                this.groupList.push(val)
                groupErr.style.display = 'none'
            }
        },
        showInfo(obj) {
            this.editObj.show.value = !this.editObj.show.value
            this.memberData = Object.assign({}, obj)
        },
        onChange(e) {
            this.clearImgSearch()
            let groupErr = document.querySelector('[role=groupErr]')

            if (this.groupList.length == 0) {
                groupErr.style.display = 'inline-block'
                return
            }
            groupErr.style.display = 'none'
            let files = e.currentTarget.files, len = files.length
            let groups = this.groupList.toString()
            let limit = this.$refs.limit.value

            if (files.length > 200) {
                console.log('单次上传图片数不能大于200张!')
                return
            }
            for (let index = 0; index < len; index++) {
                let options = {}
                let file = files[index]
                let formdata = new FormData()
                let src

                formdata.append('limit', limit)
                formdata.append('group', groups)
                formdata.append('groups', groups)
                formdata.append('images', file)
                let reader = new FileReader()

                reader.readAsDataURL(file)
                reader.onload = (e) => {
                    src = e.target.result
                    this.fetchImgSearch({
                        formdata,
                        src
                    })
                }
            }
        }
    },
    components: {
        FileUploadComponent,
        DialogComponent,
        ImgSearchInfoComponent,
        CrumbsComponent,
        TableComponent
    },
    destroyed() {
        this.clearImgSearch()
    }
}
</script>

<style scoped>
h4{
    font-size: 14px;
    line-height: 24px;
    margin-top: 0;
    margin-bottom: 10px;
}
.img-search{
    color: #fff;
    width: 100%;
    padding: 50px 80px;
    box-sizing: border-box;
    min-height: 100%;
}
.search-option{
    width: 100%;
    display: flex;
    font-size: 14px;
    line-height: 50px;
    background-image: linear-gradient(-180deg, #003F54 4%, #00283A 99%);
    border: 1px solid #00CBF9;
    border-radius: 7px;
    &>div{
        flex: 1; 
        border-right: 1px solid #003F54;
        &:last-child{
            border-right: none;
        }
    }
    .title{
        padding-left: 10px;
        .error{
            color: crimson;
            margin-left: 5px;
            display: none;
        }
    }
    .condition{
        text-align: center;
        font-size: 12px;
        line-height: 24px;
        padding: 44px 10px;
        background-image: linear-gradient(-180deg, #000304 4%, #002636 99%);
        border-bottom-left-radius: 7px;
        border-bottom-right-radius: 7px;
        select {
            border: 1px solid #FFFFFF;
            box-shadow: 0 2px 4px 0 rgba(0,0,0,0.50);
            border-radius: 8px;
            outline: none;
            color: #FFF;
            padding: 3px 5px;
            height: 30px;
            width: 200px;
            padding-left: 6px;
            background: url(../../images/arrow-down.png) right center no-repeat #163C4C;
        }
        .group-select{
            height: 30px;
        }
        .img-con{
            width: 100%;
            height: 114px;
            line-height: 18px;
            position: relative;
            overflow: auto;
            padding: 2px 3px;
            &>div{
                padding: 0;
            }
            .file-upload{
                position: absolute;
                cursor: pointer;
                left: 50%;
                top: 50%;
                margin-left: -57px;
                margin-top: -20px;
                &:hover .upload-btn{
                    color: #fff;
                }
            }
            .upload{
                opacity: 0;
                z-index: 1;
                width: 114px;
                height: 40px;
                position: absolute;
                left: 0;
                top: 0;
            }
            .upload-con{
                position: relative;
            }
            .upload-btn{
                color: #aaa;
                i{
                    float: left;
                    font-size: 36px;
                    margin-right: 10px;
                }
                span{
                    float: left;
                    font-size: 16px;
                }
            }
        }
        &.group-content{
            padding: 10px 10px;
            &>div{
                flex-wrap: wrap;
                display: flex;
                height: 100px;
                overflow: auto;
            }
            .group-select{
                flex: 1;
                min-width: 20%;
                text-align: left;
                padding-left: 20px;
                input{
                    float: left;
                    margin-top: 7px;
                }
                label{
                    width: 68%;
                    float: left;
                    margin-left: 5px;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
            }
        }
        &.img-content{
            padding: 0;
        }
    }
}
.search-btn-content{
    margin-top: 20px;
    text-align: right;
}
.btn{
    display: inline-block;
    color: #fff;
    text-decoration: none;
    width: 90px;
    height: 30px;
    text-align: center;
    margin-left: 5px;
    background: #4990e2;
    border-radius: 3px;
    font-size: 12px;
    line-height: 30px;
    &.search{
        vertical-align: top;
        margin-left: 0;
    }
}
.dialog-con{
    color: #000;
}
.panel-body.new-member{
    /*display: flex;*/
    width: 620px;
    color: #000;
}
.search-content{
    >span{
        color:#fff;
        padding: 0 4px 5px 5px;
    }
    .capture-item{
        width: 130px;
        height: 130px;
        padding: 4px;
        margin-left: 10%;
        .item-score{
            position: relative;
            height: 110px;
            cursor: pointer;
            >img{
                max-width: 130px;
                max-height: 110px;
            }
        }
    }
    .result-item{
        width: 130px;
        height: 165px;
        float: left;
        padding: 4px;
        border: 1px solid #717982;
        margin:3px;
        .item-score{
            position: relative;
            height: 110px;
            cursor: pointer;
            .score{
                position: absolute;
                right: 20px;
                bottom: 2px;
                padding: 2px 3px;
                border-radius: 3px;
                background-color: #cd5d40;
            }
            .active{
                border: 1px solid red;
            }
            img{
                max-height: 110px;
                max-width: 130px;
            }
        }
        .item-info{
            margin-top: 10px;
            text-align: center;
            >p{
                font-family: '宋体';
                font-size:12px;
                text-overflow:ellipsis;
                white-space:nowrap;
                overflow:hidden;
                margin: 0;
                line-height: 20px;
                .button-style{
                    padding: 0 5px 0 5px;
                }
            }
        }
    }
}
</style>