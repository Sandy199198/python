<template>
    <div class="member-info">
        <CrumbsComponent :crumbs="crumbs"></CrumbsComponent>
        <div class="table_content">
            <div class="condition">
                <input type="text" class="input-style" placeholder="请输入姓名" v-model="searchObj.name"/>
                <input type="text" class="input-style" placeholder="请输入证件号码" v-model="searchObj.cert_id"/>
            </div>
            <div class="condition">
                <select name="sex" v-model="searchObj.gender">
                    <option value="">性别/不限</option>
                    <option :value="item.value" v-for="item in bulkItems.gender">{{item.text}}</option>
                </select>
                <select name="record" v-model="searchObj.criminalRecord">
                    <option value="">案底/不限</option>
                    <option :value="item.value" v-for="item in bulkItems.crmRecord">{{item.text}}</option>
                </select>
                <select name="id" v-model="searchObj.label">
                    <option value="">身份类型/不限</option>
                    <option :value="item.value" v-for="item in bulkItems.certType">{{item.text}}</option>
                </select>
                <select name="group" v-model="searchObj.groupId">
                    <option value="">底库/不限</option>
                    <option :value="item.id" v-for="item in getGroup">{{item.name}}</option>
                </select>
                <a href="#" class="button-style search" @click.prevent="search">搜索</a>
                <a href="#" class="button-style" @click.prevent="bulk" style="float: right;">批量新建</a>
                <a href="#" class="button-style" @click.prevent="add" style="float: right;">新建</a>
            </div>
            <TableComponent :data="getMember" :columns="columns" :trHeight="style.height">
                <!-- <span v-for="(item, index) in getMember" :slot="'element' + index"> -->
                <span v-for="(item, index) in getMember" :slot="'array' + index">
                    <span>{{item.name}}</span><br>
                    <span>证件号: {{item.cert_id ? item.cert_id : '-'}}</span>
                </span>
                <span v-for="(item, index) in getMember" :slot="'photos' + index">
                    <span v-if="item.photos && item.photos.length">
                        <img v-for="(key, val) in item.photos" :src="key.path" @click.prevent="viewImage(key.path)" title="查看原图" :style="style.imgStyle" v-if="item.photos && item.photos.length && val < 3">
                        <a href="#" @click.prevent="showMore(index)" class="img-more" v-if="item.photos && item.photos.length && item.photos.length > 3"><i class="fa fa-angle-double-right"></i></a>
                    </span>
                    <span v-else><i class="fa fa-warning"></i>暂未上传底库图片</span>
                </span>
                <span v-for="(item, index) in getMember" :slot="'events' + index">
                    <a href="#" title="修改"  @click.prevent="edit(index)">修改</a>
                    &nbsp;&nbsp;
                    <a href="#" title="删除"  @click.prevent="del(index)">删除</a>
                </span>
            </TableComponent>
            <div>
                <PaginationComponent :pageData="getPage" v-on:pageClick="pageEvent" :pagesNumber="5"></PaginationComponent>
            </div>
            <ConfirmComponent :show="editObj.show" :title="this.index == '' ? '新增人员' : '编辑人员'" :confirm="editObj.confirm" :cancel="editObj.cancel">
                <div slot="content">
                    <div class="panel-body new-member" style="padding-top:-11px;">
                        <div class="member-img" v-if="isAdd">
                            <form name="imgOption">
                                <IconUploadComponent :type="defaultSetting.iconType" v-on:changeImg="change()" v-on:dltImg="dltImg()" v-if="path == null"></IconUploadComponent>
                                <IconUploadComponent :type="defaultSetting.iconType" v-on:changeImg="change()" v-else :imgSrc="path" v-on:dltImg="dltImg()"></IconUploadComponent>
                            </form>
                        </div>
                        <div class="member-img" v-else>
                            <div class="thumbnail" v-for="(item, index) in imgList">
                                <Thumbnail :imgSrc="item.path" v-on:dltImg="deleteImgItem" :keyNode="item.id"></Thumbnail>
                            </div>
                            <div class="thumbnail">
                                <form name="iconImgOption">
                                    <IconUploadComponent :type="editUpload" v-on:changeImg="iconUploadChange()"></IconUploadComponent>
                                </form>
                            </div>
                        </div>
                        <div class="member-items">
                            <div class="form-group">
                                <label class="control-label col3">底库</label>
                                <div class="col9">
                                    <select class="form-control form-select" name="m_group_id" v-model="memberData.group_id" v-if="memberData.group_id">
                                        <option :value="option.id" v-for="option in getGroup">{{option.name}}</option>
                                    </select>
                                    <select class="form-control form-select" name="m_group_id" v-else>
                                        <option :value="option.id" v-for="option in getGroup">{{option.name}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">姓名</label>
                                <div class="col9">
                                    <input type="text" name="m_name" placeholder="选填" class="form-control form-input" v-model="memberData.name"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">性别</label>
                                <div class="col9">
                                    <select name="m_gender" class="form-select form-control" v-model="memberData.gender" v-if="memberData.gender">
                                        <option :value="item.value" v-for="item in bulkItems.gender">{{item.text}}</option>
                                    </select>
                                    <select name="m_gender" class="form-select form-control" v-else>
                                        <option :value="item.value" v-for="item in bulkItems.gender">{{item.text}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">证件类型</label>
                                <div class="col9">
                                    <select class="form-control form-select" name="m_cert_type" v-model="memberData.cert_type" v-if="memberData.cert_type">
                                        <option v-for="item in bulkItems.certType" :value="item.value">{{item.text}}</option>
                                    </select>
                                    <select class="form-control form-select" name="m_cert_type" v-else>
                                        <option v-for="item in bulkItems.certType" :value="item.value">{{item.text}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">证件号码</label>
                                <div class="col9">
                                    <input type="text" name="m_cert_id" placeholder="选填" class="form-control form-input" v-model="memberData.cert_id"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">案底</label>
                                <div class="col9">
                                    <select class="form-control form-select" name="m_criminal_record" v-model="memberData.criminal_record" v-if="memberData.criminal_record">
                                        <option v-for="item in bulkItems.crmRecord" :value="item.value">{{item.text}}</option>
                                    </select>
                                    <select class="form-control form-select" name="m_criminal_record" v-else>
                                        <option v-for="item in bulkItems.crmRecord" :value="item.value">{{item.text}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">身份类型</label>
                                <div class="col9">
                                    <select name="m_label" class="form-control form-select" v-if="memberData.label" v-model="memberData.label">
                                        <option v-for="item in bulkItems.label" :value="item.value">{{item.text}}</option>
                                    </select>
                                    <select name="m_label" class="form-control form-select" v-else>
                                        <option v-for="item in bulkItems.label" :value="item.value">{{item.text}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col3">备注</label>
                                <div class="col9 simple">
                                    <textarea name="m_remark" class="form-control form-textarea" rows="3" v-model="memberData.remark"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
            <ConfirmComponent :show="bulkObj.show" :title="bulkObj.text">
                <div slot="content">
                    <div class="panel-body bulkcontainer" style="padding-top: -11px">
                        <div class="uploadtips">
                            <i class="fa fa-info-circle text-primary"></i>{{tips}}
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">选择底库</label>
                            <div class="col9">
                                <select class="form-control form-select" name="b_group_id">
                                    <option :value="item.id" v-for="item in getGroup">{{item.name}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">证件类型</label>
                            <div class="col9">
                                <select class="form-control form-select" name="b_cert_type">
                                    <option v-for="item in bulkItems.certType" :value="item.value">{{item.text}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">案底</label>
                            <div class="col9">
                                <select class="form-control form-select" name="b_criminal_record">
                                    <option v-for="item in bulkItems.crmRecord" :value="item.value">{{item.text}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">身份类型</label>
                            <div class="col9">
                                <select name="b_label" class="form-control form-select">
                                    <option v-for="item in bulkItems.label" :value="item.value">{{item.text}}</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">信息勾选</label>
                            <div class="col9 bulk-info-check">
                                <div class="info-check">
                                    <input type="checkbox" name="infos" value="0" checked disabled id="info_0">
                                    <label for="info_0">姓名</label>
                                </div>
                                <div class="info-check">
                                    <input type="checkbox" name="infos" value="1" id="info_1" v-on:change="toggleInfo">
                                    <label for="info_1">性别</label>
                                </div>
                                <div class="info-check">
                                    <input type="checkbox" name="infos" value="2" id="info_2" v-on:change="toggleInfo">
                                    <label for="info_2">证件号</label>
                                </div>
                                <div class="info-check">
                                    <input type="checkbox" name="infos" value="3" id="info_3" v-on:change="toggleInfo">
                                    <label for="info_3">备注</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col3">上传图片</label>
                            <div class="col9">
                                <input type="file" class="fileupload" multiple="multiple" accept="image/jpeg, image/png, image/bmp" v-on:change="bulkChange">
                                <a href="#" @click.prevent="bulkEvent" class="btn bulkbtn">批量新建</a>
                            </div>
                        </div>
                        <div class="uploadtips">
                            <i class="fa fa-exclamation-circle text-sky"></i>
                            <span>{{subTips}}</span>
                        </div>
                    </div>
                </div>
            </ConfirmComponent>
            <DialogComponent :show="uploadInfo.show" :title="uploadInfo.text" :cancel="uploadInfo.cancel">
                <div slot="content">
                    <div class="panel-body" style="padding-top: -11px">
                        <div class="form-group-info" v-if="isProgress">
                            <ProgressComponent :styleSetting="defaultSetting.styleS"></ProgressComponent>
                        </div>
                        <div class="form-group-info" v-else>
                            <p class="success-title">批量上传已完成！</p>
                            <div class="success-info">
                                <Tag class="left-tag" :type="defaultSetting.success">{{bulkMemberDataList.length}}</Tag>
                                <Tag :type="defaultSetting.danger">{{bulkMemberErrorList.length}}</Tag>
                            </div>
                            <div v-if="getBulkUploadError.length">
                                <p class="success-title">失败列表</p>
                                <div class="fail-table" v-for="item in getBulkUploadError">{{item.fields}}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </DialogComponent>
            <ConfirmComponent :show="deleteObj.show" :title="deleteObj.text" :confirm="deleteObj.confirm" :content="deleteObj.content">
            </ConfirmComponent>
            <ConfirmComponent :show="error.show" :title="error.text" :content="error.content"></ConfirmComponent>
            <DialogComponent :show="imgObj.show" :title="imgObj.text">
                <div slot="content">
                    <div class="panel-body img-show-list" style="padding-top: -11px">
                        <div class="img-show-item" v-for="item in imgObj.list">
                            <img :src="item.path">
                        </div>
                    </div>
                </div>
            </DialogComponent>
            <DialogComponent :show="viewBigImage" title="查看原图">
                <div slot="content">
                    <div style="text-align: center">
                        <img :src="imageSrc"></img>
                    </div>
                </div>
            </DialogComponent>
        </div>    
    </div>
</template>

<script>
import {
    mapGetters,
    mapMutations,
    mapActions } from 'vuex'
import TableComponent from '@nanyun/table'
import PaginationComponent from '@nanyun/pagination'
import DialogComponent from '@nanyun/dialog'
import ConfirmComponent from '@nanyun/confirm'
import IconUploadComponent from 'common/components/icon-upload.vue'
import Tag from 'common/components/tag.vue'
import Thumbnail from 'common/components/thumbnail.vue'
import ProgressComponent from 'common/components/progress.vue'
import {verifyCertId, verifyGender} from 'common/utils'
import { GENDER, CERTTYPE, CRIMINALRECORD, LABEL } from 'common/config'
import {GET_MEMBER, FETCH_MEMBER, ADD_MEMBER, DEL_MEMBER, SET_MEMBER, GET_PAGE, UPDATE_MEMBER, GET_UPLOAD_IMG, UPLOAD_IMG, GET_BULK_UPLOAD_ERROR, GET_BULK_UPLOAD, BULK_UPLOAD_ERROR, BULK_UPLOAD, CLEAR_BULK_UPLOAD_ERROR} from
'store/modules/member'
import {GET_GROUP, FETCH_GROUP} from 'store/modules/group'
import CrumbsComponent from 'common/components/crumbs.vue'
import URL from 'common/url'

export default {
    data() {
        return {
            crumbs: [{
                name: '首页',
                path: {
                    name: URL.HOME
                }
            }, {
                name: '底库人员配置',
                slient: true
            }],
            error: {
                autoClose: 10001,
                text: '提示',
                content: '1111',
                show: {
                    value: false
                },
            },
            defaultSetting: {
                success: 'success',
                danger: 'danger',
                iconType: 'default',
                styleS: {
                    width: '50%'
                }
            },
            bulkMemberData: {},
            bulkMemberDataList: [],
            bulkMemberErrorList: [],
            photoIds: [],
            tips: '选择一张或者多张照片直接批量上传，每张照片都将作为一个独立的人员加入底库。',
            subTips: '(为保证正确解析,文件名请以勾选信息格式顺序命名,如:xx_男_12345678_xx)',
            memberData: {},
            searchObj: {
                certId: '',
                criminalRecord: '',
                label: '',
                groupId: '',
                gender: ''
            },
            style: {
                imgStyle: {
                    width: 'auto',
                    height: '110px',
                    marginRight: '5px',
                    maxWidth: '100%',
                    cursor: 'pointer'
                },
                height: '124px'
            },
            columns: [{
                title: '图像预览',
                type: 'img',
                width: '320px',
                prop: 'photos'
            }, {
                title: '姓名/证件号',
                prop: ['name', 'cert_id'],
                width: '210px',
            }, {
                title: '底库',
                prop: 'group',
                handle: d => {
                    if (typeof d === 'object') {
                        return d.name
                    }
                }
            }, {
                title: '性别',
                prop: 'gender',
                handle: d => {
                    if (d == 0) {
                        return '未知'
                    } else if (d == 1) {
                        return '男'
                    } else {
                        return '女'
                    }
                }
            }, {
                title: '案底',
                prop: 'criminal_record',
                handle: d => {
                    if (d == 0) {
                        return '未知'
                    } else if (d == 1) {
                        return '无'
                    } else {
                        return '有'
                    }
                }
            }, {
                title: '身份类型',
                prop: 'label',
                handle: d => {
                    if (d == 0) {
                        return '未知'
                    } else if (d == 1) {
                        return '普通人员'
                    } else {
                        return '可疑人员'
                    }
                }
            }, {
                title: '备注',
                prop: 'remark',
                handle: d => {
                    if (!d) {
                        return '-'
                    } else {
                        return d
                    }
                }
            }, {
                title: '操作',
                type: 'events'
            }],
            index: '',
            path: '',
            imgList: [],
            editObj: {
                autoClose: 10000,
                // text: this.index == '' ? '新增用户' : '编辑用户',
                show: {
                    value: false
                },
                confirm: () => {
                    if (this.index == '') {
                        this.memberData.gender = document.querySelector('[name=m_gender]').value
                        this.memberData['group_id'] = document.querySelector('[name=m_group_id]').value
                        this.memberData['cert_type'] = document.querySelector('[name=m_cert_type]').value
                        this.memberData['criminal_record'] = document.querySelector('[name=m_criminal_record]').value
                        this.memberData.label = document.querySelector('[name=m_label]').value
                        this.memberData.name = document.querySelector('[name=m_name]').value
                        this.memberData['cert_id'] = document.querySelector('[name=m_cert_id]').value
                        this.memberData['photo_ids'] = this.photoIds.toString()
                        this.memberData.remark = document.querySelector('[name=m_remark]').value
                        this.addMember(this.memberData).then(() => {
                            this.search()
                        })
                    } else {
                        this.memberData.gender = document.querySelector('[name=m_gender]').value
                        this.memberData['group_id'] = document.querySelector('[name=m_group_id]').value
                        this.memberData['cert_type'] = document.querySelector('[name=m_cert_type]').value
                        this.memberData['criminal_record'] = document.querySelector('[name=m_criminal_record]').value
                        this.memberData.label = document.querySelector('[name=m_label]').value
                        this.memberData.name = document.querySelector('[name=m_name]').value
                        this.memberData['cert_id'] = document.querySelector('[name=m_cert_id]').value
                        this.memberData['photo_ids'] = this.photoIds.toString()
                        this.memberData.remark = document.querySelector('[name=m_remark]').value
                        this.updateMember(this.memberData).then(() => {
                            this.search()
                        })
                    }
                },
            },
            deleteObj: {
                autoClose: 10000,
                text: '确认删除',
                content: '确定删除该人员信息?',
                show: {
                    value: false
                },
                confirm: () => {
                    this.delMember(this.index).then(() => {
                        this.search()
                    })
                }
            },
            uploadInfo: {
                autoClose: 10000,
                text: '批量上传详情',
                show: {
                    value: false
                },
                cancel: () => {
                    this.bulkMemberDataList.map((item) => {
                        this.addMember(item).then(() => {
                            this.fetchMember()
                        })
                    })
                }
            },
            bulkObj: {
                autoClose: 10000,
                text: '批量上传详情',
                show: {
                    value: false
                }
            },
            bulkItems: {
                gender: GENDER,
                certType: CERTTYPE,
                crmRecord: CRIMINALRECORD,
                label: LABEL
            },
            isAdd: true,
            editUpload: 'icon',
            isProgress: true,
            infos: [0],
            imgObj: {
                autoClose: 10000,
                text: '图像展示',
                show: {
                    value: false
                },
                list: []
            },
            viewBigImage: {
                value: false
            },
            imageSrc: ''
        }
    },
    created() {
        this.fetchData()
    },
    computed: {
        ...mapGetters({
            getGroup: GET_GROUP,
            getPage: GET_PAGE,
            getMember: GET_MEMBER,
            getUploadImg: GET_UPLOAD_IMG,
            getBulkUploadError: GET_BULK_UPLOAD_ERROR,
            getBulkUpload: GET_BULK_UPLOAD,
        }),
    },
    methods: {
        fetchData() {
            let groupId = this.$route.params.groupId
            let obj = {}

            if (groupId) {
                obj = {
                    'group_id': groupId
                }
                this.searchObj.groupId = groupId
            }
            this.fetchGroup()
            this.fetchMember(obj)
        },
        ...mapActions({
            fetchGroup: FETCH_GROUP,
            fetchMember: FETCH_MEMBER,
            delMember: DEL_MEMBER,
            addMember: ADD_MEMBER,
            setMember: SET_MEMBER,
            updateMember: UPDATE_MEMBER,
            uploadImg: UPLOAD_IMG,
            bulkUpload: BULK_UPLOAD
        }),
        ...mapMutations({
            clearBulkUploadError: CLEAR_BULK_UPLOAD_ERROR
        }),
        search() {
            this.fetchMember(this.searchObj)
        },
        add() {
            this.index = ''
            this.isAdd = true
            this.memberData = {}
            this.photoIds = []
            this.path = ''
            this.editObj.show.value = !this.editObj.show.value
        },
        edit(index) {
            this.isAdd = false
            this.imgList = []
            this.photoIds = []
            this.memberData = Object.assign({}, this.getMember[index])
            this.index = this.memberData.id
            this.memberData.photos.map((item) => {
                this.imgList.push(Object.assign({}, item))
                this.photoIds.push(item.id)
            })
            this.editObj.show.value = !this.editObj.show.value
        },
        del(index) {
            this.deleteObj.show.value = !this.deleteObj.show.value
            this.memberData = Object.assign({}, this.getMember[index])
            this.index = this.memberData.id
        },
        pageEvent(page) {
            this.searchObj.page = page
            this.fetchMember(this.searchObj)
        },
        change() {
            let imgOption = document.querySelector('[name=imgOption]')

            this.uploadImg(imgOption).then(() => {
                this.photoIds[0] = this.getUploadImg.id
                this.path = this.getUploadImg.path
            })
        },
        dltImg() {
            this.getUploadImg = {}
            this.photoIds = []
        },
        deleteImgItem(index) {
            let value = this.photoIds.indexOf(parseInt(index))
            let imgListArray = this.imgList

            for (let d of imgListArray) {
                if (d.id == index) {
                    this.imgList.splice(imgListArray.indexOf(d), 1)
                    this.photoIds.splice(value, 1)
                }
            }
        },
        iconUploadChange() {
            let iconImgOption = document.querySelector('[name=iconImgOption]')

            this.uploadImg(iconImgOption).then(() => {
                this.photoIds.push(this.getUploadImg.id)
                this.imgList.push(Object.assign({}, this.getUploadImg))
            })
        },
        toggleInfo(e) {
            let value = e.currentTarget.value

            if (this.infos.indexOf(value) > -1) {
                this.infos.splice(value, 1)
            } else {
                this.infos.push(value)
            }
        },
        bulk() {
            this.bulkObj.show.value = !this.bulkObj.show.value
        },
        bulkEvent() {
            this.bulkChange()
        },
        setBulkMemberData() {
            this.bulkMemberData = {}
            this.bulkMemberData['group_id'] = document.querySelector('[name=b_group_id]').value
            this.bulkMemberData['criminal_record'] = document.querySelector('[name=b_criminal_record]').value
            this.bulkMemberData['label'] = document.querySelector('[name=b_label]').value
            this.bulkMemberData['cert_type'] = document.querySelector('[name=b_cert_type]').value
        },
        bulkChange(e) {
            this.bulkMemberDataList = []
            this.bulkMemberErrorList = []
            this.clearBulkUploadError()
            let fileReg = /^([^_]+)_([^_]*)_([^_]*)_([^_.]*)(?:\.\w+)?$/
            let files = e.currentTarget.files, len = files.length
            let groupId = document.querySelector('[name=b_group_id]').value
            let ciminalRecord = document.querySelector('[name=b_criminal_record]').value
            let label = document.querySelector('[name=b_label]').value
            let certType = document.querySelector('[name=b_cert_type]').value

            if (files.length > 200) {
                this.error.content = '单次上传图片数不能大于200张!'
                this.error.show.value = !this.error.show.value
                return
            }
            this.bulkObj.show.value = !this.bulkObj.show.value
            this.uploadInfo.show.value = !this.uploadInfo.show.value
            this.isProgress = true
            for (let index = 0; index < len; index++) {
                let file = files[index], options = new FormData(), filename = file.name
                let fileName = filename.replace(/\.\w+$/, ''), name = '', number = '', duty = '', genderStr  = ''
                let photoInfo = fileName.split('_')

                options.append('photo', file)
                this.defaultSetting.styleS.width = (index + 1) / len * 100 + '%'
                this.infos.map((n, index) => {
                    if (n == 0) {
                        name = photoInfo[0] || fileName
                    } else {
                        for (let i = 1; i < photoInfo.length; i++) {
                            if (n == 1 && verifyGender(photoInfo[i])) {
                                genderStr = photoInfo[i]
                            } else if (n == 2 && verifyCertId(photoInfo[i])) {
                                number = photoInfo[i]
                            } else if (n == 3 && photoInfo.length > 3) {
                                duty = photoInfo[3]
                            }
                        }
                    }
                })
                this.bulkUpload({
                    formData: options,
                    name: filename
                }).then(() => {
                    // this.setBulkMemberData()
                    this.bulkMemberData = {}
                    this.bulkMemberData['group_id'] = groupId
                    this.bulkMemberData['criminal_record'] = ciminalRecord
                    this.bulkMemberData['label'] = label
                    this.bulkMemberData['cert_type'] = certType
                    this.bulkMemberData.name = name
                    this.bulkMemberData['cert_id'] = number
                    this.bulkMemberData.remark = duty
                    GENDER.map((item) => {
                        if (item.text == genderStr) {
                            this.bulkMemberData.gender = item.value
                        }
                    })
                }).then(() => {
                    if (this.getBulkUpload.id) {
                        this.bulkMemberDataList.push(Object.assign({
                            'photo_ids': this.getBulkUpload.id
                        }, this.bulkMemberData))
                    } else {
                        this.bulkMemberErrorList = this.getBulkUploadError
                    }
                    if (index == len - 1) { this.isProgress = false }
                })
            }
        },
        showMore(index) {
            this.imgObj.list = []
            this.imgObj.show.value = !this.imgObj.show.value
            this.imgObj.list = Object.assign({}, this.getMember[index]).photos
        },
        viewImage(src) {
            this.viewBigImage.value = true
            this.imageSrc = src
        }
    },
    components: {
        TableComponent,
        PaginationComponent,
        DialogComponent,
        ConfirmComponent,
        IconUploadComponent,
        Tag,
        ProgressComponent,
        Thumbnail,
        CrumbsComponent
    }
}
</script>

<style scoped>
    @keyframes rotate{
        0%{-webkit-transform:rotate(0);transform:rotate(0)}
        50%{-webkit-transform:rotate(180deg);transform:rotate(180deg)}
        100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}
    }
    .member-info{
        height: 100%;
        width: 100%;
        padding: 50px 80px;
        box-sizing: border-box;
        min-height: 100%;
        form{
            height: 100%;
        }
        .condition{
            margin-top: 16px;
            margin-bottom: 15px;
            input{
                /*border-radius: 4px;*/
                height: 30px;
                width: 200px;
                box-sizing: border-box;
                background: #163C4C;
                border: 1px solid #FFFFFF;
                box-shadow: 0 2px 4px 0 rgba(0,0,0,0.50);
                border-radius: 8px;
                outline: none;
                color: #FFF;
                padding: 3px 5px;
            }
            select {
                border: 1px solid #FFFFFF;
                box-shadow: 0 2px 4px 0 rgba(0,0,0,0.50);
                border-radius: 8px;
                outline: none;
                color: #FFF;
                padding: 3px 5px;
                height: 30px;
                width: 200px;
                padding-left: 6px;
                background: url(../../images/arrow-down.png) right center no-repeat #163C4C;
            }
        }
        .btn{
            display: inline-block;
            color: #fff;
            text-decoration: none;
            width: 90px;
            height: 30px;
            text-align: center;
            margin-left: 5px;
            background: #4990e2;
            border-radius: 3px;
            font-size: 12px;
            line-height: 30px;
            &.search{
                vertical-align: top;
                margin-left: 0;
            }
            &.bulkbtn{
                height: 24px;
                line-height: 24px;
                margin-left: 0;
                color: #FFF;
                outline: none;
                cursor: pointer;
                background-image: linear-gradient(-180deg, #0082AC 0%, #008BC8 100%);
                border: 1px solid #FFFFFF;
                box-shadow: 0 1px 2px 0 #50E3C2;
                border-radius: 8px;
            }
        }
        .fileupload{
            position: absolute;
            width: 100px;
            height: 24px;
            opacity: 0;
        }
        .panel-body.new-member{
            display: flex;
            width: 620px;
            opacity: 0.8;
            background-image: linear-gradient(-180deg, #000304 4%, #002636 99%);
            border: 0 solid #FFFFFF;
            border-radius: 7px;
            padding: 10px;
            .member-img{
                flex: 1;
                position: relative;
                width: 100%;
                height: 338px;
                background: #f0f0f0;
                border: 1px solid #d6d6d6;
                .thumbnail{
                    float: left;
                    width: 33%;
                    height: 30%;
                    margin-top: 12px;
                    position: relative;
                }
                img{
                    max-width: 100%;
                    max-height: 100%;
                }
            }
            .member-items{
                flex: 1;
            }
        }
        .bulkcontainer{
            opacity: 0.8;
            background-image: linear-gradient(-180deg, #000304 4%, #002636 99%);
            border: 0 solid #FFFFFF;
            border-radius: 7px;
            padding: 10px;
        }
        .uploadtips{
            line-height: 18px;
            margin-bottom: 10px;
            color: #39b3d7;
            .text-primary{
                color: #39b3d7;
            }
            i{
                margin-right: 5px;
            }
            span,.text-sky{
                color: #39b3d7;
            }
        }
        .col9{
            width:70%;
            float:left;
            min-height: 1px;
            &.bulk-info-check{
                display: flex;
                div{
                    flex: 1;
                    line-height: 24px;
                    color: #fff;
                }
            }
        }
        .form-select{
            width: 86%;
        }
        .minWidth{
            min-width:150px;
        }
        .success-title{
            font-size:16px;
            font-weight:bold;
            line-height:32px;
        }
        .form-group-info{
            text-align: center;
            width: 100%;
            .left-tag{
                margin-right: 20px;
            }
        }
        .success-info{
            display: flex;
        }
        .fail-table{
            text-align: left;
        }
        .panel-body.bulkcontainer{
            width: 420px;
            &>div{
                width: 100%;
            }
        }
        .loading>div{
            border-radius: 100%;
            margin: 2px;
            border: 2px solid #4990e2;
            border-bottom-color: transparent;
            height: 26px;
            width: 26px;
            background: 0 0!important;
            display: inline-block;
            -webkit-animation: rotate .75s 0s linear infinite;
            animation: rotate .75s 0s linear infinite;
        }
        .img-more{
            float: right;
            /*height: 110px;*/
            line-height: 110px;
            color: #5ab5f1;
            font-size: 16px;
        }
        .panel-body.img-show-list{
            width: 380px;
            display: inline-flex;
            flex-wrap: wrap;
            align-content: flex-start;
            .img-show-item{
                flex: 1;
                img{
                    width: 90px;
                    height: 110px;
                }
            }
        }
    }
</style>