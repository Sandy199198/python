<template>
    <div class="gis">
        <div class="gis-map" id="gis-map" :style="getWinHeightStyle">
            <GisCamerasComponent class="gis-siderbar" :go="goToGis" :branchs="getBranchCameras" :selectedCameraId="selectedCameraId"></GisCamerasComponent>
            <GisAlarmComponent class="gis-info" :alarms="filterAlarms()" v-on:openDetailDialog="openDetailDialog"></GisAlarmComponent>
        </div>
        <DialogComponent :show="showDetails" title="查看详情">
            <div slot="content">
                <AlarmDetails :data="alarmDialogData"></AlarmDetails>
            </div>
        </DialogComponent> 
    </div>
</template>

<script>
import ol from 'openlayers'
import 'openlayers/css/ol.css'
import { DEFAULT_CENTER } from 'common/config'
import URL from 'common/url'
import {
    setCameraSymbols,
    setCameraSymbol,
    setAlarmAboutCamera } from 'common/utils'
import {
    mapGetters,
    mapActions,
    mapMutations } from 'vuex'
import {
    CLEAR_PROMPT,
    GET_SERVICES,
    GET_HEIGHT_STYLE } from 'store/modules/common'
import {
    GET_ALARMS,
    SET_ALARM,
    DEL_ALARM,
    CLEAR_ALARMS } from 'store/modules/alarms'
import {
    GET_CAMERAS,
    GET_BRANCH_CAMERAS,
    FETCH_CAMERAS,
    GET_COORDINATE_BY_ID } from 'store/modules/cameras'
import { GET_ALARM } from 'store/modules/alarms'

import GisCamerasComponent from 'pages/gis/gis-cameras.vue'
import GisAlarmComponent from 'pages/gis/gis-alarms.vue'
import DialogComponent from '@nanyun/dialog'
import AlarmDetails from 'pages/gate-real-time/alarm-details.vue'

let map
let mounted
let cameraPromise

export default {

    data: function () {
        return {
            selectedCameraId: -1,
            showDetails: {
                value: false
            },
            alarmDialogData: {}
        }
    },

    created() {
        mounted = false

        cameraPromise = Promise.all([this.fetchCameras(true), new Promise((resolve, reject) => {
            setTimeout(() => {
                resolve()
            }, 600)
        })])
    },

    mounted() {
        let currentId = +this.$route.params.cameraId
        let selected = !Object.is(currentId, NaN)

        this.selectedCameraId = currentId

        cameraPromise.then(() => {
            let camera

            if (selected) {
                camera = this.getCameraById(currentId)
            }

            map = new ol.Map({
                target: 'gis-map',
                layers: [
                    new ol.layer.Tile({
                        source: new ol.source.XYZ({
                            url: `${this.getServices.GisServer}{z}/{x}/{y}.png`
                        })
                    })
                ],
                controls: [
                    new ol.control.Zoom(),
                    new ol.control.ZoomSlider()
                ],
                view: new ol.View({
                    center: camera ? camera.latlng.split(',').map(Number) : DEFAULT_CENTER,
                    maxZoom: 15,
                    zoom: 10
                })
            })

            setTimeout(() => {
                this.createSymbols(selected, camera)
            }, 100)

        })
    },

    watch: {
        $route() {
            let currentId = +this.$route.params.cameraId
            let selected = !Object.is(currentId, NaN)
            let camera

            this.selectedCameraId = -1
            map.getOverlays().clear()

            if (selected) {
                this.selectedCameraId = currentId
                camera = this.getCameraById(currentId)
            }

            let pan = ol.animation.pan({
                source: map.getView().getCenter(),
                duration: 1000,
                easing: ol.easing.easeOut
            })

            map.beforeRender(pan)
            map.getView().setCenter(camera ? camera.latlng.split(',').map(Number) : DEFAULT_CENTER)

            this.createSymbols(selected, camera)
        },
        getAlarm(alarm) {
            if (!mounted) {
                this.delAlarm(alarm)
                setTimeout(() => {
                    this.setAlarm(alarm)
                }, 1000)
                return
            }

            setAlarmAboutCamera({
                ol,
                map,
                alarm,
                move: false,
                tip: false
            })
        }
    },

    computed: {
        ...mapGetters({
            getAlarms: GET_ALARMS,
            getCameras: GET_CAMERAS,
            getBranchCameras: GET_BRANCH_CAMERAS,
            getAlarm: GET_ALARM,
            getWinHeightStyle: GET_HEIGHT_STYLE,
            getServices: GET_SERVICES
        })
    },

    methods: {
        goToGis(id) {
            this.$router.push({
                name: URL.GIS,
                params: {
                    cameraId: id
                }
            })
        },
        getCameraById(id) {
            for (let camera of this.getCameras) {
                if (id == camera.id) {
                    return camera
                }
            }
            return null
        },
        filterAlarms() {
            let list = []
            let cameraId = this.$route.params.cameraId

            if (Object.is(cameraId, undefined)) {
                return this.getAlarms
            } else {
                for (let alarm of this.getAlarms) {
                    if (this.$route.params.cameraId == alarm.camera_id) {
                        list.push(alarm)
                    }
                }

                return list
            }
        },
        isAlarmCamera(camera) {
            for (let alarm of this.getAlarms) {
                if (camera.id == alarm.camera_id) {
                    return true
                }
            }
            return false
        },
        createSymbols(selected, camera) {
            if (selected) {
                setCameraSymbol({
                    ol,
                    map,
                    camera,
                    createdCallback: cameraSymbol => {
                        if (this.isAlarmCamera(camera)) {
                            cameraSymbol.getElement().className = 'map-camera alarm'
                        }
                        mounted = true
                    }
                })
            } else {
                setCameraSymbols({
                    ol,
                    map,
                    cameras: this.getCameras,
                    clickCallback: cameraSymbol => {
                        this.$router.push({
                            name: URL.GIS,
                            params: {
                                cameraId: cameraSymbol.getId(),
                            }
                        })
                    },
                    createdCallback: () => {
                        mounted = true

                        for (let alarm of this.getAlarms) {
                            setAlarmAboutCamera({
                                ol,
                                map,
                                alarm,
                                move: false,
                                tip: false
                            })
                        }
                    }
                })
            }
        },
        ...mapActions({
            fetchCameras: FETCH_CAMERAS
        }),
        ...mapMutations({
            clearPrompt: CLEAR_PROMPT,
            clearAlarms: CLEAR_ALARMS,
            setAlarm: SET_ALARM,
            delAlarm: DEL_ALARM
        }),
        openDetailDialog(details) {
            this.alarmDialogData = details
            this.showDetails.value = true
        }
    },

    destroyed() {
        this.clearAlarms()
        this.clearPrompt()
        map.destroyed = true
        map.getOverlays().clear()
        map = null
    },

    components: {
        GisCamerasComponent,
        GisAlarmComponent,
        DialogComponent,
        AlarmDetails
    }
}
</script>

<style scoped>
    .gis{
        height: 100%;
        .gis-siderbar{
            width: 400px;
            height: 80%;
            left: 80px;
            margin-top:15px;
            position: fixed;
            z-index:999;
            border-radius: 5px;
        }
        .gis-map{
            width: 100%;
            height: 100%
        }
        .gis-info{
            width:400px;
            height: 80%;
            position: fixed;
            z-index:999;
            right: 80px;
            margin-top:15px;
            border-radius: 5px;
        }
    }    
</style>