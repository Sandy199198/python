<template>
    <div class="gis-alarms">
        <div class="gis-alarms-header">
            <div class="gis-alarm-pic-header"><i class="fa fa-video-camera"></i>&nbsp;抓拍</div>
            <div class="gis-alarm-pic-header"><i class="fa fa-user"></i>&nbsp;比对</div>
            <div class="gis-alarm-info-header"><i class="fa fa-file-text"></i>&nbsp;信息</div>
        </div>
        <transition-group name="alarm-list" tag="ul" mode="out-in">
            <li v-for="alarm of alarms" :key="alarm.id"> 
                <div class="gis-alarm-pic"><img :src="alarm.face" alt="" @click.prevent="viewAlarmDetails(alarm)"></div>
                <div class="gis-alarm-pic"><img :src="alarm.target_face" alt=""></div>
                <div class="gis-alarm-info">
                    <p>分数: {{alarm.score.toFixed(2)}}</p>
                    <p :title="alarm.group_name">底库: {{alarm.group_name}}</p>
                    <p :title="alarm.subject_name">姓名: {{alarm.subject_name}}</p>
                    <p>时间: {{alarm.timestamp | formatDate}}</p>
                </div>
            </li>
        </transition-group>
    </div>    
</template>

<script>
    export default {
        props: {
            alarms: {
                type: Array,
                default() {
                    return []
                }
            }
        },
        methods: {
            viewAlarmDetails(alarm) {
                alarm.from = 'alarm'
                this.$emit('openDetailDialog', alarm)
            }
        }
    }
</script>

<style>
    .gis-alarms {
        color: #FFF;
        background: rgba(0,0,0,0.3);
        padding: 40px 0 0;
        box-sizing: border-box;
        position: relative;
        overflow: hidden;
        .gis-alarms-header{
            /*background: rgba(50,60,78,1);*/
            width: 94%;
            position: absolute;
            top: 10px;
            left: 3%;
            display:flex;
            border-bottom: 1px solid #777;
            font-size: 20px;
            >div{
                height: 30px;
                line-height: 30px;
                text-align: center;
            }
            .gis-alarm-pic-header{
                width:90px;
            }
            .gis-alarm-info-header{
                flex:1;
            }
        }
        ul{
            background: rgba(255,255,255,0.6);
            height:95%;
            padding:0 10px;
            box-sizing: border-box;
            overflow-y: auto;
            margin: 15px;
            border-radius: 5px;
            li{
                display: flex;
                border-bottom:1px solid #555;
                .gis-alarm-pic{
                    width:90px;
                    height:90px;
                    text-align: center;
                    padding:1px;
                    border:1px solid #4a90e2;
                    overflow:hidden;
                    margin:10px 2px;
                    box-sizing: border-box;
                    border-radius: 2px;
                    cursor:pointer;
                    >img{
                        max-height: 100%;
                        max-width: 100%;
                    }
                }
                .gis-alarm-info{
                    flex: 1;
                    p{
                        font-family: '宋体';
                        font-size:12px;
                        text-overflow:ellipsis;
                        width:172px;
                        white-space:nowrap;
                        overflow:hidden;
                        color: #030303;
                    }
                }
            }
        }
    }
</style>