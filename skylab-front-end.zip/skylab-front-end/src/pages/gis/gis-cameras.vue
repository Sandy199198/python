<template>
    <div class="gis-cameras">
        <div class="title">
            <h3>
                相机列表
            </h3>
        </div>
        <div class="branch-wrapper">
            <ul class="branch">
                <li v-for="info in branchs">
                    <a href="#" :title="info.branch" @click.prevent="selectBranch(info.branch)">
                        <i class="fa" :class="getCurrentClassName(info.branch)"></i>
                        {{info.branch}}
                    </a>
                    <ul class="camera" v-if="isCurrentBranch(info.branch)">
                        <li v-for="camera in info.cameras" :class="selected(camera)">
                            <a href="#" :title="camera.name" @click.prevent="go(camera.id)" :class="selected(camera)">
                                <i class="fa fa-video-camera"></i>
                                {{camera.name}}
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
    export default {

        props: {
            branchs: {
                type: Array,
                default: function () {
                    return []
                }
            },
            selectedCameraId: {
                type: Number,
                default: -1
            },
            go: {
                type: Function,
                default() {}
            }
        },

        data() {
            return {
                branchStates: {}
            }
        },

        watch: {
            branchs() {
                for (let info of this.branchs) {
                    if (this.currentBranchName == info.branch) {
                        this.branchStates[info.branch] = true
                    } else {
                        this.branchStates[info.branch] = false
                    }
                }
            }
        },

        computed: {
            currentBranchName() {
                if (this.branchs.length) {
                    for (let branch of this.branchs) {
                        for (let camera of branch.cameras) {
                            if (this.selectedCameraId == camera.id) {
                                return branch.branch
                            }
                        }
                    }
                    return ''
                } else {
                    return ''
                }
            }
        },

        methods: {
            getCurrentClassName(name) {
                let current = this.isCurrentBranch(name)

                return {
                    'fa-minus-square': current,
                    'fa-plus-square': !current,
                }
            },

            isCurrentBranch(name) {
                return this.branchStates[name]
            },

            selectBranch(name) {
                let oldValue = this.branchStates[name]

                this.branchStates = Object.assign({}, this.branchStates, {
                    [name]: !oldValue
                })
            },

            selected(camera) {
                return {
                    selected: camera ? camera.id == this.selectedCameraId : false
                }
            }
        }

    }
</script>

<style scoped>
.gis-cameras {
    color: #FFF;
    background: rgba(0,0,0,0.3);
    position: relative;
    .title{
        padding:0 10px;
        box-sizing: border-box;
        width: 100%;
        position: absolute;
        text-align: center;
        h3{
            margin:0 auto;
            width: 100%;
            padding-top:10px;
            border-bottom: 1px solid #777;
            height: 30px;
            line-height: 30px;
            font-size: 20px;
        }
    }
    .branch-wrapper{
        padding-top:40px;
        height: 100%;
        box-sizing: border-box;
    }
    .branch{
        height: 95%;
        overflow-y: auto;
        background: rgba(255,255,255,0.6);
        margin: 15px;
        border-radius: 5px;
        >li{
            >a{
                color:#4A4A4A;
                display: inline-block;
                width: 100%;
                box-sizing: border-box;
                padding: 15px 0 5px 20px;
                overflow:hidden;
                text-overflow: ellipsis;
                white-space:nowrap;
                font-size: 16px;
                i{
                    margin-right: 6px
                }
            }   
        } 
    }
    .camera {
        >li{
            >a {
                color:#4A4A4A;
                display: inline-block;
                width: 100%;
                padding: 6px 0 6px 40px;
                box-sizing: border-box;
                overflow:hidden;
                text-overflow: ellipsis;
                white-space:nowrap;
                i{
                    margin-right: 10px;
                }
                &:hover{
                    color:#FFF;
                }
            }
            >a.selected {
                /*box-shadow: inset 0 0 5px #111;*/
                color:#FFF;
                background: rgba(109,158,225,0.6);
            }
        }
    }
}
</style>