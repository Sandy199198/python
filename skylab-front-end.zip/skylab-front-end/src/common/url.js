export default {
    ROOT: 'root',
    HOME: 'home',
    LOGIN: 'login',
    GIS: 'gis',
    GATE_REAL_TIME: {
        REAL_TIME: 'real-time',
        CAPTURE_HISTORY: 'capture-history',
        ALARM_HISTORY: 'alarm-history'
    },
    GATE: {
        GATE_STATISTICS: 'gate-statistics',
        BRANCH_STATISTICS: 'branch-statistics',
        BRANCH_STAT: 'branch-stat',
        CAMERA_STAT: 'camera-stat'
    },
    ACCESS: {
        SYSTEM_ACCESS: 'system-access',
        SYSTEM_DETAIL: 'system-detail'
    },
    MANAGE: {
        GROUP_SETTING: 'group-setting',
        MEMBER_INFO: 'member-info',
        PHOTO_MANAGE: 'photo-manage',
        IMAGE_FILTER: 'image-filter',
        IMAGE_CROP: 'image-crop',
        IMAGE_CROP_RESULT: 'image-crop-result'
    },
    SEARCH: {
        IMG_SEARCH: 'img-search',
        CAPTURE_SEARCH: 'capture-search',
        VIDEO_SEARCH: 'video-search',
        CAPTURE_VIDEO_SEARCH: 'capture-video-search',
        ALARM_VIDEO_SEARCH: 'alarm-video-search',
    },
    DETERMINATION: 'determination',
    RESOURCE: {
        RESOURCE_SERVER: 'resource-server',
        RESOURCE_SERVICE: 'resource-service',
        RESOURCE_CITYWIDE_SERVER: 'resource-citywide-server',
        RESOURCE_BRANCH_SERVER: 'resource-branch-server'
    },
    CITYWIDE: 'citywide',
    DEFAULT: 'default',
    SYSTEM: {
        SYSTEM_MANAGE: 'system-manage',
        USER: 'user',
        GROUP: 'group',
        LOG: 'log',
        CORE: 'core',
        SYSTEM_SETTING: 'system-setting'
    },
    ANALYSIS: {
        COLLISION_POINTS: 'collision-point',
        COLLISION_TIME: 'collision-time',
        COLLISION: 'collision',
        PEER: 'peer',
        FREQUENCY: 'frequency',
        COLLISION_INFO: 'collision-info',
        COLLISION_DETAIL: 'collision-detail'
    },
    CHEAT: {
        VIDEO_SETTING: 'video-setting',
        DEPLOY_SETTING: 'deploy-setting'
    },
    CAPTURE_MASTER: {
        SERVER_CONFIG: 'server-config',
        CAMERA_SETTING: 'camera-setting',
        CLIENT_GROUP: 'client-group',
        DEPLOYMENT: 'deployment',
        HOME: 'capture-master-home'
    },
    NOT_FOUND: '404'
}
