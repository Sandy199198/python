export default {
    chart: {
        backgroundColor: 'rgba(0,0,0,0)'
    }
}
