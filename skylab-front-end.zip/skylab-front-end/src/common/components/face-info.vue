<template>
    <div class="tab-img-con">   
        <p>{{this.header}}</p>
        <div class="img-con">
            <div class="img-face">
                <div class="thumbnail" :class="{'nobody': !bodyIsShow}"><img :src="data.face"></div>
                <span>脸部抓拍</span>
            </div>
            <div class="img-body" v-show="bodyIsShow">
                <div class="thumbnail"><img :src="data.body"></div>
                <span>整体抓拍</span>
            </div>
        </div>
        <div class="form-group" v-if="path">
            <label class="control-label col3">视频</label>
            <div class="col9">
                <a href="#" class="video-btn" @click.prevent="videoEvent">
                    <i class="fa fa-play-circle"></i>视频回放
                </a>
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col3">编号</label>
            <div class="col9">
                <input type="text" disabled class="form-control" v-model="data.id"/>
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col3">时间</label>
            <div class="col9">
                <input type="text" disabled class="form-control" v-model="data.timestamp"/>
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col3">地点</label>
            <div class="col9">
                <input type="text" disabled class="form-control" v-model="data.camera_location"/>
            </div>
        </div>
    </div>
</template>
<script>
const emptyfuc = () => {}

export default {
    props: {
        data: {
            type: Object,
            default() {
                return {}
            }
        },
        title: {
            type: String,
            default() {
                return ''
            }
        },
        body: {
            type: String,
            default() {
                return ''
            }
        },
        videoPlay: {
            type: Function,
            default: emptyfuc
        }
    },
    data() {
        return {
            header: this.title ? this.title : '抓拍信息',
            bodyIsShow: !this.body ? true : false,
            path: this.data['video-path'] ? this.data['video-path'] : ''
        }
    },
    methods: {
        videoEvent() {
            this.$emit('videoPlay', this.path)
        }
    }
}
</script>
<style>
.tab-img-con{
    width: 100%;
    p{
        margin: 0 0 10px 0;
        line-height: 28px;
        padding-left: 5px;
        font-size: 14px;
        background: #fafafa;
        border-bottom: 1px solid #ececec;
    }
    .form-group{
        height: 40px;
        position: relative;
        margin-left: -11px;
        margin-right: -11px;
    }
    .col3{
        width: 25%;
        float: left;
        min-height: 1px;
    }
    .col9{
        width:70%;
        float:left;
        min-height: 1px;
        &.bulk-info-check{
            display: flex;
            div{
                flex: 1;
                line-height: 24px;
            }
        }
    }
    .control-label{
        padding-right: 15px;
        padding-top: 5px;
        text-align: right;
    }
    lable{
        line-height: 32px;
        display: inline-block;
        margin-bottom: 5px;
    }
    .form-select{
        width: 86%;
    }
    .minWidth{
        min-width:150px;
    }
    .form-group-info{
        text-align: center;
        width: 100%;
        .left-tag{
            margin-right: 20px;
        }
    }
    .fail-table{
        text-align: left;
    }
    .video-btn{
        background: #b0b0b0;
        color: #fff;
        font-size: 11px;
        padding: 0 12px;
        display: inline-block;
        font-weight: 600;
        text-align: center;
        white-space: nowrap;
        border-radius: 3px;
        height: 24px;
        line-height: 24px;
        width: 75%;
        border: 1px solid #b0b0b0;
    }
}
.img-con{
    display: flex;                 
    &>div{
        flex: 1;
        padding: 5px 10px 15px 10px;
        text-align: center;
        .thumbnail{
            width: 190px;
            height: 230px;
            background: #eee;
            &:after{
                display:inline-block;
                width:0;
                height:100%;
                vertical-align:middle;
                content:'';
            }
            &.nobody{
                margin: 0 auto;
            }
        }
        span{
            line-height: 24px;
        }
    }
    img{
        max-width: 100%;
        max-height: 100%;
        display: inline-block;
        vertical-align: middle;
    }
}   
</style>