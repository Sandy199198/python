<template>
    <span class="panel-span">
        <a href="#" title="查看七天统计"  :class="currentClassName(WEEK)" @click.prevent="innerChange(WEEK)">七天</a>
        &nbsp;&nbsp;
        <a href="#" title="查看一个月统计"  :class="currentClassName(MONTH)" @click.prevent="innerChange(MONTH)">一个月</a>
    </span>
</template>

<script>
    import { WEEK, MONTH } from 'common/utils'

    export default {
        props: {
            select: {
                type: Function,
                default() {}
            }
        },
        data() {
            return {
                selected: WEEK,
                WEEK,
                MONTH
            }
        },
        methods: {
            innerChange(type) {
                this.selected = type
                this.select(type)
            },
            currentClassName(type) {
                return {
                    selected: this.selected == type
                }
            }
        }
    }
</script>

<style scoped>
    .panel-span{
        a{
            color:#aaa;
        }
        .selected{
            cursor: default;
            color:#FFF;
        }
    }
</style>