<template>
    <div class="progress">
        <div class="progress-bar" :style="styleSetting"></div>
    </div>
</template>
<script>
    export default {
        props: {
            styleSetting: {
                type: Object,
                default: {}
            }
        }
    }
</script>
<style>
    .progress{
        background-color: rgba(0,0,0,.06);
        height: 13px;
        box-shadow: inset 0 1px 2px rgba(0,0,0,.1);
        border-radius: 2px;
        overflow: hidden;
    }
    .progress-bar{
        background: #1d89cf;
        height: 14px;
        box-shadow: none;
    }
</style>