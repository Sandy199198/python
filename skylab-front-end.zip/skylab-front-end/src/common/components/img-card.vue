<template>
    <div class="result-item" v-if="typeBool">
        <div class="item-score">
            <img :src="data.path" @click.prevent="showInfo()">
            <span class="score">{{data.score.toFixed(2)}}</span>
        </div>
        <div class="item-info">
            <span class="name">
                {{data.subject.name}}
            </span><br/>
            <span class="group-name">
                {{data.subject.group.name}}
            </span><br/>
            <span class="time">
                {{data.subject.timestamp | formatDate}}
            </span>
        </div>
    </div>
    <div class="result-item" v-else>
        <div class="item-score">
            <img :src="data.path">
            <span class="score">{{data.score.toFixed(2)}}</span>
        </div>
        <div class="item-info">
            <span class="name">
                {{data.camera_name}}
            </span><br/>
            <span class="time">
                {{data.timestamp | formatDate}}
            </span><br/>
            <span class="group-name">
                <a href="#" title="新增到底库" @click.prevent="importGroup" :id="idIndex"><i class="fa fa-share-square"></i>入库</a>
            </span>
        </div>
    </div>
</template>
<script>
import {formatDate, parseDateStrToTimestamp, convertToSeconds} from 'common/utils'
const empFunc = () => {}

export default {
    props: {
        data: {
            type: Object,
            default() {
                return {}
            }
        },
        callback: {
            type: Function,
            default: empFunc
        },
        mode: {
            type: String,
            default() {
                return ''
            }
        },
        idIndex: {
            type: String,
            default() {
                return ''
            }
        }
    },
    data() {
        return {
            typeBool: this.mode == 'img'
        }
    },
    methods: {
        showInfo() {
            this.$emit('callback', null)
        },
        importGroup(e) {
            let id = e.target.id
            let arr = id.split('_')

            this.$emit('callback', arr)
        }
    }
}
</script>
<style scoped>
.result-item{
    width: 160px;
    height: 230px;
    padding: 4px;
    border: 1px solid;
    .item-score{
        position: relative;
        height: 150px;
        text-align: center;
        display: -webkit-box;
        -webkit-box-align: center;
        -webkit-box-pack: center;
        display: -moz-box;
        -moz-box-align: center;
        -moz-box-pack: center;
        display: -o-box;
        -o-box-align: center;
        -o-box-pack: center;
        display: -ms-box;
        -ms-box-align: center;
        -ms-box-pack: center;
        display: box;
        box-align: center;
        box-pack: center;
        .score{
            position: absolute;
            right: 20px;
            bottom: 2px;
            padding: 2px 3px;
            border-radius: 3px;
            background-color: #e56544;
        }
        img{
            cursor: pointer;
            max-height: 150px;
            max-width: 150px;
        }
    }
    .item-info{
        margin-top: 5px;
        text-align: center;
        line-height: 22px;
        .group-name{
            line-height: 28px;
        }
        a{
            color: #fff;
            border-radius: 3px;
            padding: 1px 3px;
            background: #4990e2;
        }
    }
}
</style>