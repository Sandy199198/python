<template>
    <div class="img-search-info">
        <div class="member-img">
            <img :src="data.path">
        </div>
        <div class="member-items">
            <div class="form-group">
                <label class="control-label col3">底库</label>
                <div class="col9">
                    <select class="form-control form-select" name="m_group_id" v-model="data.group_id">
                        <option :value="option.id" v-for="option in groups">{{option.name}}</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col3">姓名</label>
                <div class="col9">
                    <input type="text" name="m_name" placeholder="选填" class="form-control form-input" v-model="data.name"/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col3">性别</label>
                <div class="col9">
                    <select name="m_gender" class="form-select form-control" v-model="data.gender">
                        <option :value="item.value" v-for="item in bulkItems.gender">{{item.text}}</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col3">证件类型</label>
                <div class="col9">
                    <select class="form-control form-select" name="m_cert_type" v-model="data.cert_type">
                        <option v-for="item in bulkItems.certType" :value="item.value">{{item.text}}</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col3">证件号码</label>
                <div class="col9">
                    <input type="text" name="m_cert_id" placeholder="选填" class="form-control form-input" v-model="data.cert_id"/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col3">案底</label>
                <div class="col9">
                    <select class="form-control form-select" name="m_criminal_record" v-model="data.criminal_record">
                        <option v-for="item in bulkItems.crmRecord" :value="item.value">{{item.text}}</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col3">身份类型</label>
                <div class="col9">
                    <select class="form-control form-select" name="m_label" v-model="data.label">
                        <option v-for="item in bulkItems.label" :value="item.value">{{item.text}}</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col3">备注</label>
                <div class="col9 simple">
                    <textarea name="m_remark" placeholder="选填" class="form-control form-textarea" rows="3" v-model="data.remark"></textarea>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import { GENDER, CERTTYPE, CRIMINALRECORD, LABEL } from 'common/config'

export default {
    props: {
        path: {
            type: String,
            default() {
                return ''
            }
        },
        data: {
            type: Object,
            default() {
                return {}
            }
        },
        groups: {
            type: Array,
            default() {
                return []
            }
        }
    },
    data() {
        return {
            bulkItems: {
                gender: GENDER,
                certType: CERTTYPE,
                crmRecord: CRIMINALRECORD,
                label: LABEL
            },
        }
    },
}
</script>
<style scoped>
.img-search-info{
    display: flex;
    width: 100%;
    color: #fff;
    width: 620px;
    background-image: linear-gradient(-180deg, #000304 2%, #002636 99%);
    border-radius: 7px;
    padding: 10px;
    opacity: 0.8;
    .member-img{
        position: relative;
        width: 50%;
        height: 338px;
        background: rgba(255,255,255,.3);
        border:none;
        text-align: center;
        &:after{
            display:inline-block;
            width:0;
            height:100%;
            vertical-align:middle;
            content:'';
        }
        img{
            max-width: 100%;
            max-height: 100%;
            display: inline-block;
            vertical-align: middle;
        }
    }
    .member-items{
        width: 50%;
    }
    .form-group{
        height: 40px;
        position: relative;
        margin-left: -11px;
        margin-right: -11px;
    }
    .col3{
        width: 25%;
        float: left;
        min-height: 1px;
    }
    .col9{
        width:70%;
        float:left;
        min-height: 1px;
        &.bulk-info-check{
            display: flex;
            div{
                flex: 1;
                line-height: 24px;
            }
        }
    }
    .control-label{
        padding-right: 15px;
        padding-top: 5px;
        text-align: right;
    }
    lable{
        line-height: 32px;
        display: inline-block;
        margin-bottom: 5px;
    }
    .form-select{
        width: 86%;
    }
    .minWidth{
        min-width:150px;
    }
    .success-title{
        font-size:16px;
        font-weight:bold;
        line-height:32px;
    }
    .form-group-info{
        text-align: center;
        width: 100%;
        .left-tag{
            margin-right: 20px;
        }
    }
    input:disabled, select:disabled, textarea:disabled{
        cursor: not-allowed;
        background-color: #eeeeee;
    }
}
</style>
