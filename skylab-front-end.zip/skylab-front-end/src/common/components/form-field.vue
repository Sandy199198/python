<template>
    <div class="form-group">
        <div class="label" :style="labelStyle">
            <slot name="label"></slot>
        </div>
        <div class="field" :style="fieldStyle">
            <slot name="field"></slot>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                labelFlex: 1,
                fieldFlex: 2,
            }
        },
        computed: {
            labelStyle() {
                return {
                    flex: this.labelFlex
                }
            },
            fieldStyle() {
                return {
                    flex: this.fieldFlex
                }
            }
        }
    }
</script>

<style scoped>
    .form-group {
        margin:10px 0;
        display: flex;
        .label {
            text-align: right;
            padding-right: 20px;
            box-sizing: border-box;
            line-height: 20px;
            cursor: pointer;
        }
        .field {
            padding-right: 30px;
        }
    }
</style>