<template>
    <div class="video-upload-container">
        <div class="file-con">
            <div class="file-upload">
                <input type="file" name="videos" multiple v-on:change="onChange" accept="audio/mp4, video/mp4" class="upload">
                <div class="upload-con">
                    <a href="#" class="upload-btn" @click.prevent="upload">
                        <i class="fa fa-cloud-upload"></i>
                        <span>点击此处<br>上传视频</span>
                    </a>
                </div>
            </div>
        </div>
        <div class="file-con">
            <div class="img-show">
                <div class="video-list-con" v-if="videos.length">
                    <ul>
                        <li v-for="(item, index) in videos">
                            <span class="video-name">{{item.name || item.filename}}</span>
                            <span class="capcity">{{item.size || '-'}}</span>
                            <a href="#" @click.prevent="delItem" :id="index"><i class="fa fa-times-circle" :id="index"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    const EMPTY_FUNC = () => {}
    const EMPTY_ARR = () => {
        return []
    }

    export default {
        props: {
            changeFile: {
                type: Function,
                default: EMPTY_FUNC
            },
            fileUpload: {
                type: Function,
                default: EMPTY_FUNC
            },
            delFileItem: {
                type: Function,
                default: EMPTY_FUNC
            },
            videoList: {
                type: Array,
                default: EMPTY_ARR
            }
        },
        data() {
            return {
                isBtnshow: false
            }
        },
        computed: {
            videos() {
                let arr = []

                this.videoList.map((item, key) => {
                    let obj = {}

                    for (let i in item) {
                        if (i == 'size') {
                            obj[i] = parseFloat(item[i] / 1024 / 1024).toFixed(2) + 'MB'
                        } else {
                            obj[i] = item[i]
                        }
                    }
                    arr.push(obj)
                })
                return arr
            }
        },
        methods: {
            onChange(e) {
                let files = e.currentTarget.files
                let callbackArr = []

                for (let i = 0; i < files.length; i++) {
                    let file = files[i]

                    callbackArr.push(file)
                }
                this.$emit('changeFile', callbackArr)
            },
            upload() {
                this.changeFile()
                this.$emit('fileUpload', null)
            },
            delItem(e) {
                let index = e.currentTarget.id

                this.$emit('delFileItem', index)
            }
        }
    }
</script>

<style scoped>
.video-upload-container{
    height: 100%;
    display: flex;
}
.file-con{
    position: relative;
    flex: 1;
    height: 100%;
}
.file-upload{
    position: absolute;
    cursor: pointer;
    left: 50%;
    top: 50%;
    margin-left: -57px;
    margin-top: -20px;
    &:hover .upload-btn{
        color: #fff;
    }
}
.upload{
    opacity: 0;
    z-index: 1;
    width: 114px;
    height: 40px;
    margin-left: -57px;
    position: absolute;
}
.upload-con{
    position: relative;
}
.upload-btn{
    color: #aaa;
    i{
        float: left;
        font-size: 36px;
        margin-right: 10px;
    }
    span{
        float: left;
        font-size: 16px;
    }
}
.img-show{
    position: relative;
    width: 100%;
    text-align: center;
    padding: 5px 5px;
    box-sizing: border-box;
    .delbtn{
        position: absolute;
        top: -2px;
        right: 2px;
        color: #555;
    }
    .video-list-con{
        width: 100%;
        height: 100%;
        border: 1px solid #535b68;
        color: #4c91df;
        box-sizing: border-box;
        padding: 5px;
        overflow: auto;
    }
    li{
        font-size: 14px;
        color: #fff;
        line-height: 22px;
        overflow: hidden;
        width: 100%;
        &:hover{
            background: #535b68;
        }
        span.video-name{
            float: left;
            width: 50%;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        span.capcity{
            float: left;
            width: 30%;
        }
        a{
            font-size: 18px;
            float: right;
            color: #fff;
        }
    }
}
</style>