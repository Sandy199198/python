<template>
    <div style="height: 100%;">
        <div class="file-upload" v-show="isBtnShow">
            <input type="file" name="photo" v-on:change="onImgChange" accept="image/jpeg, image/png, image/bmp" class="upload" v-if="icon">
            <input type="file" name="photo" v-on:change="onChange" accept="image/jpeg, image/png, image/bmp" class="upload" v-else>
            <div class="upload-con" :class="{iconstyle: icon}">
                <a href="#" class="upload-btn" @click.prevent="iconUpload"  v-if="icon">
                    <i class="fa fa-plus"></i>
                </a>
                <a href="#" class="upload-btn" @click.prevent="upload" v-else>
                    <i class="fa fa-cloud-upload"></i>
                    <span>点击此处<br>上传图片</span>
                </a>
            </div>
        </div>
        <div class="img-show" v-show="!isBtnShow">
            <img name="img" :src="this.imgSrc">
            <a href="#" @click.prevent="delImg" class="delbtn"><i class="fa fa-times"></i></a>
        </div>
    </div>
</template>

<script>
    const EMPTY_FUNC = () => {}

    export default {
        props: {
            changeImg: {
                type: Function,
                default: EMPTY_FUNC
            },
            fileUpload: {
                type: Function,
                default: EMPTY_FUNC
            },
            dltImg: {
                type: Function,
                default: EMPTY_FUNC
            },
            type: {
                type: String,
                default: ''
            },
            imgSrc: {
                type: String,
                default: ''
            },
            keyNode: {
                type: Number,
                default: 0
            }
        },
        data() {
            return {
                isBtnShow: !this.imgSrc,
                icon: this.type == 'icon'
            }
        },
        methods: {
            onChange(e) {
                let file = e.currentTarget.files[0]
                let reader = new FileReader()

                reader.readAsDataURL(file)
                this.$emit('changeImg', null)
                this.isBtnShow = false
            },
            onImgChange(e) {
                let file = e.currentTarget.files[0]
                let reader = new FileReader()

                reader.readAsDataURL(file)
                this.$emit('changeImg', null)
                // this.isBtnShow = false
            },
            upload() {
                this.changeImg()
                this.$emit('fileUpload', null)
            },
            iconUpload() {
                this.changeImg()
                this.$emit('fileUpload', null)
            },
            delImg() {
                let file = document.querySelector('[name=photo]')
                let img = document.querySelector('[name=img]')

                file.value = ''
                img.src = ''
                this.isBtnShow = true
                this.$emit('dltImg', null)
            },
            deleteimg(e) {
                let index = e.target.id
                let file = document.querySelector('[name=photo]')
                let img = document.querySelector('[name=img]')

                file.value = ''
                img.src = ''
                // this.isBtnShow = true
                this.$emit('dltImg', index)
            }
        }
    }
</script>

<style scoped>
.file-upload{
    position: absolute;
    cursor: pointer;
    left: 50%;
    top: 50%;
    margin-left: -57px;
    margin-top: -20px;
    &:hover .upload-btn{
        color: #fff;
    }
}
.upload{
    opacity: 0;
    z-index: 1;
    width: 114px;
    height: 40px;
    position: absolute;
}
.upload-con{
    position: relative;
    &.iconstyle{
        margin-left: 34px;
    }
}
.upload-btn{
    color: #aaa;
    i{
        float: left;
        font-size: 36px;
        margin-right: 10px;
    }
    span{
        float: left;
        font-size: 16px;
    }
}
.img-show{
    position: relative;
    width: 100%;
    height: 100%;
    text-align: center;
    display: -webkit-box;
    -webkit-box-align: center;
    -webkit-box-pack: center;
    display: -moz-box;
    -moz-box-align: center;
    -moz-box-pack: center;
    display: -o-box;
    -o-box-align: center;
    -o-box-pack: center;
    display: -ms-box;
    -ms-box-align: center;
    -ms-box-pack: center;
    display: box;
    box-align: center;
    box-pack: center;
    .delbtn{
        position: absolute;
        top: 2px;
        right: 2px;
        color: #555;
        width: 20px;
        height: 20px;
        font-size: 18px;
        background: rgba(255,255,255,.7);
        border-radius: 50%;
    }
    img{
        max-width: 300px;
        max-height: 330px;
    }
}
</style>