<template>
    <div class="tab-img-con">
        <p>{{this.header}}</p>
        <div class="match-con" v-if="data.photos && data.photos.length">
            <div class="match-img-items">
                <a href="#" @click.prevent="changeImg(index)" :class="{'active': index == key}" class="match-img-item" v-for="(item, index) in data.photos" v-if="index < 3">
                    <img :src="item.path">
                    <div class="mask"></div>
                    <span class="label label-warning img-score">{{item.score.toFixed(2)}}</span>
                </a>
            </div>
            <div class="match-items" :class="{'fade': this.isChange}">
                <div class="form-group">
                    <label class="control-label col3">姓名</label>
                    <div class="col9">
                        <input type="text" disabled class="form-control" v-model="photoItemObj.subject.name"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col3">性别</label>
                    <div class="col9">
                        <input type="text" disabled class="form-control" v-bind:value="parseNumToString(this.defaultObj.gender, photoItemObj.subject.gender)"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col3">标记</label>
                    <div class="col9">
                        <input type="text" disabled class="form-control" v-bind:value="this.parseNumToString(this.defaultObj.criminalRecord, photoItemObj.subject.criminal_record)"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col3">证件类型</label>
                    <div class="col9">
                        <input type="text" disabled class="form-control" v-bind:value="this.parseNumToString(this.defaultObj.certType, photoItemObj.subject.cert_type)"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col3">证件号码</label>
                    <div class="col9">
                        <input type="text" disabled class="form-control" v-model="photoItemObj.subject.cert_id"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col3">底库</label>
                    <div class="col9">
                        <input type="text" disabled class="form-control" v-model="photoItemObj.group.name"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col3">案底</label>
                    <div class="col9">
                        <input type="text" disabled class="form-control" v-bind:value="parseNumToString(this.defaultObj.label, photoItemObj.subject.label)"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col3">备注</label>
                    <div class="col9">
                        <input type="text" disabled class="form-control" v-model="photoItemObj.subject.remark"/>
                    </div>
                </div>
            </div>
        </div>
        <div class="match-con" v-else>
            <i class="fa fa-exclamation-circle"></i>暂无匹配信息
        </div>
    </div>
</template>
<script>
import { GENDER, CERTTYPE, CRIMINALRECORD, LABEL } from 'common/config'

export default {
    props: {
        data: {
            type: Object,
            default() {
                return {}
            }
        },
        title: {
            type: String,
            default: ''
        },
        defaultSlt: {
            type: String,
            default: ''
        }
    },
    computed: {
        photoItemObj() {
            let obj = Object.assign({}, this.data.photos[this.key])

            return obj
        }
    },
    data() {
        return {
            header: this.title ? this.title : '匹配信息',
            key: this.defaultSlt ? this.defaultSlt : '0',
            isChange: false,
            defaultObj: {
                gender: GENDER,
                label: LABEL,
                criminalRecord: CRIMINALRECORD,
                certType: CERTTYPE
            },
        }
    },
    methods: {
        changeImg(index) {
            if (index == this.key) {
                return
            } else {
                this.key = index
            }
            this.isChange = true
            this.photoItemObj = Object.assign({}, this.data.photos[this.key])
            setTimeout(() => {
                this.isChange = false
            }, 100)
        },
        parseNumToString(obj, d) {
            for (let i in obj) {
                if (obj[i].value == d) {
                    return obj[i].text
                }
            }
        },
    }
}
</script>
<style>
.tab-img-con{
    width: 100%;
    p{
        margin: 0 0 10px 0;
        line-height: 28px;
        padding-left: 5px;
        font-size: 14px;
        background: #fafafa;
        border-bottom: 1px solid #ececec;
    }
    .form-group{
        height: 40px;
        position: relative;
        margin-left: -11px;
        margin-right: -11px;
    }
    .col3{
        width: 25%;
        float: left;
        min-height: 1px;
    }
    .col9{
        width:70%;
        float:left;
        min-height: 1px;
        &.bulk-info-check{
            display: flex;
            div{
                flex: 1;
                line-height: 24px;
            }
        }
    }
    .control-label{
        padding-right: 15px;
        padding-top: 5px;
        text-align: right;
    }
    lable{
        line-height: 32px;
        display: inline-block;
        margin-bottom: 5px;
    }
    .form-select{
        width: 86%;
    }
    .minWidth{
        min-width:150px;
    }
    .form-group-info{
        text-align: center;
        width: 100%;
        .left-tag{
            margin-right: 20px;
        }
    }
    .fail-table{
        text-align: left;
    }
}
.match-img-items{
    padding-left: 3px;
    margin-bottom: 10px;
    a{
        display: inline-block;
        width: 110px;
        position: relative;
        height: 110px;
        color: #fff;
        margin: 0 12px;
        background: #eee;
        opacity: 0.5;
        text-align: center;
        &:hover{
            opacity: 1;
        }
        &.active{
            opacity: 1;
            .mask{
                display: block;
            }
        }
        img{
            max-width: 100%;
            max-height: 100%;
        }
        span{
            background: #f4b04f;
            height: 16px;
            line-height: 16px;
            position: absolute;
            bottom: 3px;
            right: 3px;
            border-radius: 3px;
        }
        .mask{
            width: 104px;
            height: 104px;
            position: absolute;
            top: 0;
            left: 0;
            display: none;
            border: 3px solid #3E8FE0;
        }
    }
}
.match-items{
    transition: all 0.2s;
    opacity: 1;
    &.fade{
        opacity: 0;
    }
}
input:disabled{
    cursor: not-allowed;
    background-color: #eeeeee;
}
</style>