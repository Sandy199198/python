<template>
    <div class="selectorWrapper">
        <input class="input-style" type="text" v-model="innerValue" @focus="show" @blur="hide" @keyup.prevent.up="change(-1)" @keyup.prevent.down="change(1)" @keyup.enter="selectByIndex" @input="input">
        <div class="list" :style="disClassName" role="listWrapper">
            <ul>
                <li v-for="(item,index) in getCurrentList" :style="getLiHeight">
                    <a href="#" :class="isSelected(index)" @click.prevent="select(item.name)">{{item.name}}</a>
                </li>
            </ul>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        list: {
            type: Array,
            default() {
                return []
            }
        },
        value: {
            type: String,
            default: ''
        },
        callback: {
            type: Function,
            default() {}
        },
        height: {
            type: Number,
            default: 25
        }
    },

    data() {
        return {
            index: -1,
            display: false,
            innerValue: this.value,
            timer: 0,
            hideTimer: 0
        }
    },

    created() {
        this.index = this.getCurrentIndex(this.innerValue)
    },

    watch: {
        value(value) {
            this.innerValue = value
            this.index = this.getCurrentIndex(this.innerValue)
        }
    },

    computed: {
        disClassName() {
            return {
                display: this.display ? 'block' : 'none'
            }
        },

        getCurrentList() {
            if (this.innerValue == '') {
                return this.list.concat()
            } else {
                let newList = []

                for (let item of this.list) {
                    if (item.name.startsWith(this.innerValue)) {
                        newList.push(item)
                    }
                }
                return newList
            }
        },

        getLiHeight() {
            return {
                height: `${this.height}px`
            }
        }
    },

    methods: {
        input() {
            this.show()
            this.index = 0

            let listWrapper = this.$el.querySelector('[role=listWrapper]')

            listWrapper.scrollTop = 0
        },

        show() {
            this.display = true
        },

        hide() {
            this.hideTimer = setTimeout(() => {
                this.display = false
                this.index = this.getCurrentIndex(this.innerValue)
                if (Object.is(this.callback(this.innerValue), false)) {
                    this.innerValue = this.value
                }
            }, 500)
        },

        select(value) {
            clearTimeout(this.hideTimer)
            this.innerValue = value
            this.display = false
            this.index = this.getCurrentIndex(this.innerValue)
            if (Object.is(this.callback(this.innerValue), false)) {
                this.innerValue = this.value
            }
        },

        selectByIndex() {
            if (this.index in this.getCurrentList) {
                this.select(this.getCurrentList[this.index].name)
            }
        },

        change(num) {
            let index = this.index + num

            if (index < 0 || index >= this.getCurrentList.length) return
            this.index = index

            let listWrapper = this.$el.querySelector('[role=listWrapper]')

            listWrapper.scrollTop = index * this.height
        },

        getCurrentIndex(value) {
            for (let [index, item] of this.getCurrentList.entries()) {
                if (item.name == value) {
                    return index
                }
            }

            return -1
        },

        isSelected(index) {
            return {
                selected: this.index == index
            }
        }
    }
}
</script>

<style scoped>
.selectorWrapper{
    position: relative;
    display: inline-block;
    z-index:5;
    .list{
        position: absolute;
        background: #FFF;
        top: 26px;
        left: 0;
        width: 100%;
        overflow-y: auto;
        max-height: 250px;
        li{
            a{
                float: left;
                width: 100%;
                height: 100%;
                padding: 0 10px;
                line-height: 25px;
                box-sizing: border-box;
                overflow: hidden;
                white-space: nowrap;
                text-overflow: ellipsis;
                color: #666;
            }
            .selected{
                background: #3890de;
                color:#FFF;
            }
        }
    }
}
</style>