<template>
    <div style="height: 100%;">
        <div class="img-show-div">
            <img name="img" :src="this.imgSrc">
            <a href="#" @click.prevent="deleteimg" class="deletebtn"><i class="fa fa-times" :id="this.keyNode"></i></a>
        </div>
    </div>
</template>
<script>
    const EMPTY_FUNC = () => {}

    export default {
        props: {
            dltImg: {
                type: Function,
                default: EMPTY_FUNC
            },
            imgSrc: {
                type: String,
                default: ''
            },
            keyNode: {
                type: Number,
                default: 0
            }
        },
        methods: {
            deleteimg(e) {
                let index = e.target.id
                // let img = document.querySelector('[name=img]')

                this.$emit('dltImg', index)
            }
        }
    }
</script>
<style scoped>
.img-show-div{
    position: relative;
    width: 100%;
    height: 100%;
    text-align: center;
    .deletebtn{
        position: absolute;
        top: 2px;
        right: 2px;
        color: #555;
        width: 20px;
        height: 20px;
        font-size: 18px;
        background: rgba(255,255,255,.7);
        border-radius: 50%;
    }
    img{
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
        width: 95%;
        max-height: 100%;
    }
}
</style>