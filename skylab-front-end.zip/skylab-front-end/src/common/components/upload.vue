<template>
    <div style="height: 100%;">
        <div class="file-upload" v-show="isBtnShow">
            <input type="file" name="images" v-on:change="onChange" accept="image/jpeg, image/png, image/bmp" class="upload">
            <div class="upload-con">
                <a href="#" class="upload-btn" @click.prevent="upload">
                    <i class="fa fa-cloud-upload"></i>
                    <span>点击此处<br>上传图片</span>
                </a>
            </div>
        </div>
        <div class="img-show" v-show="!isBtnShow">
            <button class="delbtn" @click.prevent="delImg">删除该图片</button>
            <img name="img" src="">
        </div>
    </div>
</template>

<script>
    const EMPTY_FUNC = () => {}

    export default {
        props: {
            changeImg: {
                type: Function,
                default: EMPTY_FUNC
            },
            fileUpload: {
                type: Function,
                default: EMPTY_FUNC
            }
        },
        data() {
            return {
                isBtnShow: true
            }
        },
        methods: {
            onChange(e) {
                let file = e.currentTarget.files[0]
                let reader = new FileReader()

                reader.readAsDataURL(file)
                reader.onload = (e) => {
                    this.isBtnShow = false
                    if (e.target.result) {
                        let img = document.querySelector('[name=img]')

                        img.src = e.target.result
                    }
                }

                this.$emit('changeImg', null)
            },
            upload() {
                this.changeImg()
                this.$emit('fileUpload', null)
            },
            delImg() {
                let file = document.querySelector('[name=images]')
                let img = document.querySelector('[name=img]')

                file.value = ''
                img.src = ''
                this.isBtnShow = true
            }
        }
    }
</script>

<style scoped>
.file-upload{
    position: absolute;
    cursor: pointer;
    left: 50%;
    top: 50%;
    margin-left: -57px;
    margin-top: -20px;
    &:hover .upload-btn{
        color: #fff;
    }
}
.upload{
    opacity: 0;
    z-index: 1;
    width: 114px;
    height: 40px;
    position: absolute;
    left: 0;
    top: 0;
}
.upload-con{
    position: relative;
}
.upload-btn{
    color: #aaa;
    i{
        float: left;
        font-size: 36px;
        margin-right: 10px;
    }
    span{
        float: left;
        font-size: 16px;
    }
}
.img-show{
    position: relative;
    width: 100%;
    text-align: center;
    display: -webkit-box;
    -webkit-box-align: center;
    -webkit-box-pack: center;
    display: -moz-box;
    -moz-box-align: center;
    -moz-box-pack: center;
    display: -o-box;
    -o-box-align: center;
    -o-box-pack: center;
    display: -ms-box;
    -ms-box-align: center;
    -ms-box-pack: center;
    display: box;
    box-align: center;
    box-pack: center;
    .delbtn{
        position: absolute;
        top: -2px;
        right: 2px;
        color: #555;
    }
    img{
        max-width: 114px;
        max-height: 114px;
        /*height: 100%;*/
    }
}
</style>