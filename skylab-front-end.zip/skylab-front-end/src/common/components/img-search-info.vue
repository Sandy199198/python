<template>
    <div class="img-search-info">
        <div class="member-img">
            <img :src="data.path">
        </div>
        <div class="member-items">
            <div class="form-group">
                <label class="control-label col3">底库</label>
                <div class="col9">
                    <select class="form-control form-select" name="m_group_id" disabled v-if="data.subject" v-model="data.subject.group_id">
                        <option :value="option.id" v-for="option in groups">{{option.name}}</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col3">姓名</label>
                <div class="col9">
                    <input type="text" name="m_name" placeholder="选填" class="form-control form-input" disabled v-if="data.subject" v-model="data.subject.name"/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col3">性别</label>
                <div class="col9">
                    <select name="m_gender" class="form-select form-control" disabled v-if="data.subject" v-model="data.subject.gender">
                        <option :value="item.value" v-for="item in bulkItems.gender">{{item.text}}</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col3">证件类型</label>
                <div class="col9">
                    <select class="form-control form-select" name="m_cert_type" disabled v-if="data.subject" v-model="data.subject.cert_type">
                        <option v-for="item in bulkItems.certType" :value="item.value">{{item.text}}</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col3">证件号码</label>
                <div class="col9">
                    <input type="text" name="m_cert_id" placeholder="选填" class="form-control form-input" v-if="data.subject" disabled v-model="data.subject.cert_id"/>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col3">案底</label>
                <div class="col9">
                    <select class="form-control form-select" name="m_criminal_record" disabled v-if="data.subject" v-model="data.subject.criminal_record">
                        <option v-for="item in bulkItems.crmRecord" :value="item.value">{{item.text}}</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col3">身份类型</label>
                <div class="col9">
                    <select name="m_label" class="form-control form-select" disabled v-if="data.subject" v-model="data.subject.label">
                        <option v-for="item in bulkItems.label" :value="item.value">{{item.text}}</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col3">备注</label>
                <div class="col9 simple">
                    <textarea name="m_remark" class="form-control form-textarea" rows="3" disabled v-if="data.subject" v-model="data.subject.remark"></textarea>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import { GENDER, CERTTYPE, CRIMINALRECORD, LABEL } from 'common/config'

export default {
    props: {
        data: {
            type: Object,
            default() {
                return {}
            }
        },
        groups: {
            type: Array,
            default() {
                return []
            }
        }
    },
    data() {
        return {
            bulkItems: {
                gender: GENDER,
                certType: CERTTYPE,
                crmRecord: CRIMINALRECORD,
                label: LABEL
            },
        }
    }
}
</script>
<style>
.img-search-info{
    display: flex;
    width: 100%;
    color: #000;
    .member-img{
        position: relative;
        width: 50%;
        height: 338px;
        background: #f0f0f0;
        border: 1px solid #d6d6d6;
        text-align: center;
        &:after{
            display:inline-block;
            width:0;
            height:100%;
            vertical-align:middle;
            content:'';
        }
        .thumbnail{
            float: left;
            width: 33%;
            height: 30%;
            margin-top: 5px;
            position: relative;
        }
        img{
            max-width: 100%;
            max-height: 100%;
            display: inline-block;
            vertical-align: middle;
        }
    }
    .member-items{
        width: 50%;
    }
    .form-select{
        width: 86%;
    }
    .success-title{
        font-size:16px;
        font-weight:bold;
        line-height:32px;
    }
    .form-group-info{
        text-align: center;
        width: 100%;
        .left-tag{
            margin-right: 20px;
        }
    }
    input:disabled, select:disabled, textarea:disabled{
        cursor: not-allowed;
        background-color: #eeeeee;
    }
}
</style>
