<template>
    <div>
        <div class="module-header">
            <slot name="title"></slot>
        </div> 
        <div class="module-content">
            <slot name="content"></slot>
        </div>
    </div>
</template>

<script> </script>

<style scoped>
    .module-header{
        color:#FFF;
        padding:10px 30px;
        background-image: linear-gradient(-180deg, #003F54 4%, #00283A 99%);
        border: 1px solid #00CBF9;
        border-bottom: none;
        border-top-left-radius: 7px;
        border-top-right-radius: 7px;
    }
    .module-content{
        padding:20px 50px;
        background-image: linear-gradient(-180deg, #000304 4%, #002636 99%);
        border: 1px solid #00CBF9;
        border-top: none;
        border-bottom-left-radius: 7px;
        border-bottom-right-radius: 7px;
    }
</style>