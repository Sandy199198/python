<template>
    <span></span>
</template>

<script>
    export default {
        props: {
            num: {
                type: Number,
                default: 0
            }
        },
        watch: {
            num(val) {
                this.$el.style.backgroundPositionY = `${-1 * this.num * 50}px`
            }
        },
        mounted() {
            setTimeout(() => {
                this.$el.style.backgroundPositionY = `${-1 * this.num * 50}px`
            }, 100)
        }
    }
</script>

<style scoped>
    span{
        display: inline-block;
        width: 34px;
        height: 50px;
        background-image: url('../../images/0-9.png');
        background-position: 0 0;
        transition: all 1s ease;
    }
</style>