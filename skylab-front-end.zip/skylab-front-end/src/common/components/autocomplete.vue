<template>
    <div class="autocomplete" v-bind:class="{'open':openSuggestion}">
        <input class="input-style" type="text" v-model="selection" :placeholder="cameraObj.placeholder"
            @keydown.enter = 'enter'
            @keydown.down = 'down'
            @keydown.up = 'up'
            @input = 'change'
        />
        <ul class="dropdown-menu" style="width:100%">
            <li v-for="(suggestion, index) in matches"
                v-bind:class="{'active': isActive(index)}"
                @click="suggestionClick(index)"
            >
                <a href="#">{{ suggestion }}</a>
            </li>
        </ul>
    </div>
</template>

<script>

export default {

    data() {
        return {
            open: false,
            current: 0,
            selection: '',
            suggestions: []
        }
    },

    props: {
        data: {
            type: Array,
            required: true
        },
        cameraObj: {
            type: Object,
            required: true
        }
    },

    computed: {
        //根据input输入过滤suggestion
        matches() {
            let tmpData = []

            if (this.cameraObj.selected) {
                this.selection = this.cameraObj.selected
            }
            for (let camera of this.data) {
                if (this.cameraObj.type == 'name') {
                    tmpData.push(camera.name)
                }
                if (this.cameraObj.type == 'location') {
                    tmpData.push(camera.location)
                }
            }
            this.suggestions = tmpData
            return this.suggestions.filter((str) => {
                return str.indexOf(this.selection.trim()) >= 0
            })
        },

        openSuggestion() {
            return this.selection !== '' &&
                   this.matches.length != 0 &&
                   this.open === true
        }
    },

    methods: {
        //回车选中
        enter() {
            this.selection = this.matches[this.current]
            this.open = false
            this.$emit('selection', this.selection, this.cameraObj.type)
        },
        //面板展开，向上选择
        up() {
            if (this.current > 0)
                this.current--
        },
        //面板展开，向下选择
        down() {
            if (this.current < this.suggestions.length - 1)
                this.current++
        },
        //选中状态样式
        isActive(index) {
            return index === this.current
        },
        //input值改变事件
        change() {
            this.cameraObj.selected = ''
            if (this.open == false) {
                this.open = true
                this.current = 0
            }
            this.$emit('selection', this.selection, this.cameraObj.type)
        },
        //选中事件
        suggestionClick(index) {
            this.selection = this.matches[index]
            this.open = false
            this.$emit('selection', this.selection, this.cameraObj.type)
        }
    }
}

</script>

<style scoped>
.autocomplete{
    position:relative;
    margin-left:5px;
    margin-right:5px;
    margin-top:-2px;
}
 .input-style {
    min-width: 180px;
}
.dropup,
.dropdown {
  position: relative;
}
.dropdown-toggle:focus {
  outline: 0;
}
.dropdown-menu {
  position: absolute;
  top: 100%;
  left: 0;
  z-index: 1000;
  display: none;
  float: left;
  min-width: 160px;
  padding: 5px 0;
  margin: 2px 0 0;
  font-size: 14px;
  text-align: left;
  list-style: none;
  background-color: #fff;
  -webkit-background-clip: padding-box;
          background-clip: padding-box;
  border: 1px solid #ccc;
  border: 1px solid rgba(0, 0, 0, .15);
  border-radius: 4px;
  -webkit-box-shadow: 0 6px 12px rgba(0, 0, 0, .175);
          box-shadow: 0 6px 12px rgba(0, 0, 0, .175);
}
.dropdown-menu.pull-right {
  right: 0;
  left: auto;
}
.dropdown-menu .divider {
  height: 1px;
  margin: 9px 0;
  overflow: hidden;
  background-color: #e5e5e5;
}
.dropdown-menu > li > a {
  display: block;
  padding: 3px 20px;
  clear: both;
  font-weight: normal;
  line-height: 1.42857143;
  color: #333;
  white-space: nowrap;
}
.dropdown-menu > li > a:hover,
.dropdown-menu > li > a:focus {
  color: #262626;
  text-decoration: none;
  background-color: #f5f5f5;
}
.dropdown-menu > .active > a,
.dropdown-menu > .active > a:hover,
.dropdown-menu > .active > a:focus {
  color: #fff;
  text-decoration: none;
  background-color: #337ab7;
  outline: 0;
}
.open > .dropdown-menu {
  display: block;
}
.open > a {
  outline: 0;
}
.dropdown-menu-right {
  right: 0;
  left: auto;
}
.dropdown-menu-left {
  right: auto;
  left: 0;
}
.dropdown-header {
  display: block;
  padding: 3px 20px;
  font-size: 12px;
  line-height: 1.42857143;
  color: #777;
  white-space: nowrap;
}
.dropdown-backdrop {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 990;
}
</style>