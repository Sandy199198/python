<template>
    <div class="crumbs">
        <ul>
            <li class="icon"><i class="fa fa-align-justify"></i></li>
            <li v-for="crumb,index in crumbs">
                <a href="#" :class="silentClassName(crumb.silent)" @click.prevent="go(crumb)">{{crumb.name}}</a><span v-if="index < crumbs.length - 1">&nbsp;/&nbsp;</span>
            </li>
        </ul>
    </div>
</template>

<script>
    import URL from 'common/utils'

    export default {
        props: {
            crumbs: {
                type: Array,
                default: []
            }
        },

        methods: {

            silentClassName(silent) {
                return {
                    silent
                }
            },

            go(crumb) {
                if (crumb.silent) {
                    return
                }
                this.$router.push(crumb.path)
            }
        }
    }
</script>

<style scoped>
    .crumbs{
        border-bottom:1px solid #424c60;
        margin-bottom: 30px;
        ul {
            font-size: 14px;
            color:#FFF;
            overflow:hidden;
            padding-bottom: 5px;
            border-bottom:1px solid #000;
            li{
                float: left;
                &.icon{
                    margin-right:10px;
                    i{
                        margin-top:2px;
                    }
                }
            }
            a{
                float: left;
                color:#FFF;
                &:hover{
                    text-decoration: underline;
                }
                &.silent{
                    cursor: default;
                    color: #aaa;
                    &:hover{
                        text-decoration: none;
                    }
                }
            }
        }
    }
</style>