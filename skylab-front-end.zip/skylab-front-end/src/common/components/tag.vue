<template>
    <div class="tag-con">
        <div :class="{'upload-success': isSuccess, 'upload-danger': isDanger}">
            <div :class="{'bg-success': isSuccess, 'bg-danger': isDanger}">
                <i class="fa" :class="{'fa-check': isSuccess, 'fa-times': isDanger}"></i>
            </div>
            <div>
                <strong :class="{'text-success': isSuccess, 'text-danger': isDanger}">
                    <slot></slot>
                </strong>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: {
            type: {
                type: String,
                default: ''
            }
        },
        data() {
            return {
                isSuccess: this.type == 'success',
                isDanger: this.type == 'danger'
            }
        }
    }
</script>
<style>
.tag-con{
    width: 100%;
    text-align: center;
}
.upload-success{
    flex: 1;
    border: 1px solid #32b16c;
    border-radius: 3px;
    overflow: hidden;
    &>div{
        float: left;
        width: 50%;
        height: 28px;
    }
    .bg-success{
        background: #5ebd5e;
        color: #fff;
        font-size: 16px;
        line-height: 28px;
    }
    .text-success{
        color: #5ebd5e;
        font-size: 16px;
        line-height: 28px;
    }
}
.upload-danger{
    flex: 1;
    border: 1px solid #e66454;
    border-radius: 3px;
    overflow: hidden;
    &>div{
        float: left;
        width: 50%;
        height: 28px;
    }
    .bg-danger {
        background: #e66454;
        color: #fff;
        font-size: 16px;
        line-height: 28px;
    }
    .text-danger{
        color: #e66454;
        font-size: 16px;
        line-height: 28px;
    }
}
</style>