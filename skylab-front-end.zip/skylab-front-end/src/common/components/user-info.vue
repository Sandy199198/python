<template>
    <div class="user-info" :style="style"><i class="fa fa-user"></i>&nbsp;&nbsp;{{getUserInfo.username}}&nbsp;&nbsp; <a href="#" @click.prevent="innerLogout"><i class="fa fa-power-off"></i>&nbsp;&nbsp;退出</a></div>
</template>

<script>
    import { GET_USER_INFO, LOGOUT } from 'store/modules/auth'
    import {
        mapGetters,
        mapActions } from 'vuex'

    export default {
        props: {
            style: {
                type: Object,
                default() {
                    return {}
                }
            }
        },
        computed: {
            ...mapGetters({
                getUserInfo: GET_USER_INFO
            })
        },
        methods: {
            innerLogout() {
                this.logout({
                    router: this.$router,
                    route: this.$route
                })
            },
            ...mapActions({
                logout: LOGOUT
            })
        }
    }
</script>

<style>
    .user-info{
        position: absolute;
        top: 50%;
        right: 30px;
        height: 30px;
        line-height: 30px;
        margin-top: -15px;
        color: #fff;
        a {
            margin-left: 10px;
            color: #fff;
            &:hover {
                color: #bbb;
                text-decoration: underline;
            }
        }
    }
</style>