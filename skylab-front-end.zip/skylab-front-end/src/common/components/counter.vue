<template>
    <span style="margin:0 10px">
        <NumberComponent v-for="item in len" :num="+item.num"></NumberComponent>
    </span>
</template>

<script>
    import NumberComponent from 'common/components/number.vue'

    export default {
        props: {
            init: 0,
        },
        computed: {
            len() {
                let content = ('' + this.init).split('')
                let data = []

                for (let [i, n] of content.entries()) {
                    data.push({
                        id: content.length - 1 - i,
                        num: n
                    })
                }
                return data
            }
        },
        components: {
            NumberComponent
        }
    }
</script>

<style scoped>
    span{
        display:inline-block;
        font-size:0;
        height: 50px;
        vertical-align: text-bottom;
    }
</style>