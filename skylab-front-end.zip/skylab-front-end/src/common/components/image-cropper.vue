<template lang="html">
  <div>
      <div class="v-cropper">
        <div class="v-cropper-top">
          <div class="v-cropper-container">
            <img :src="img" alt="" ref="image"/>
          </div>
          <!-- <div>
              <button class="v-cropper-cancel" @click="submitCropper">完成裁剪</button>
          </div> -->
        </div>
      </div>
  </div>
</template>

<script>
import Cropper from 'cropperjs'
import 'cropperjs/dist/cropper.css'

export default {
    name: 'VueCropper',
    props: {
        img: {
            type: String,
            required: true
        },
        id: {
            type: Number,
            required: true
        },
        groupId: {
            type: Number,
            required: true
        }
    },
    data() {
        return {
            cropper: {},
            naturalWidth: '',
            naturalHeight: '',
            scale: 1,
            imageDataStr: '',
            imageData: {},
            croppedImg: '',
            rotate: 0
        }
    },
    methods: {
        init() {
            let croperBg = document.querySelector('.cropper-container')
            let container = document.querySelector('.v-cropper-container')

            this.naturalWidth = this.cropper.initialImageData.naturalWidth
            this.naturalHeight = this.cropper.initialImageData.naturalHeight
            this.scale = this.naturalWidth / 500

            let height = parseInt(this.naturalHeight / this.scale)

            container.style.height = height + 'px'
            croperBg.style.height = height + 'px'
            //
            let data = { left: 0, top: 0, width: 500, height: height }

            this.cropper.containerData.height = height
            this.cropper.cropBoxData.maxWidth = 500
            this.cropper.cropBoxData.maxHeight = height
            this.cropper.setCanvasData(data)
        },
        getCropBoxData() {
            let data = this.cropper.getCropBoxData()

            this.rotate = this.cropper.getData().rotate
            this.imageData.x = isNaN(parseInt(data.left * this.scale)) ? 0 : parseInt(data.left * this.scale)
            this.imageData.y = isNaN(parseInt(data.top * this.scale)) ? 0 : parseInt(data.top * this.scale)
            this.imageData.w = isNaN(parseInt(data.width * this.scale)) ? 0 : parseInt(data.width * this.scale)
            this.imageData.h = isNaN(parseInt(data.height * this.scale)) ? 0 : parseInt(data.height * this.scale)
            this.imageDataStr = JSON.stringify(this.imageData)
            // this.croppedImg = this.cropper.getCroppedCanvas(this.imageData).toDataURL()
        },
        submit() {
            this.$emit('storeArea', {
                groupId: this.groupId,
                photoId: this.id,
                photoBase64: '',
                areaROI: this.imageData,
                rotate: this.rotate
            })
        },
        rotateImg() {
            this.cropper.rotate(90)
            this.init()
        },
        submitCropper() {
            this.getCropBoxData()
            this.submit()
        }
    },
    computed: {
        image() {
            return this.$refs.image
        }
    },
    mounted() {
        let that = this

        that.cropper = new Cropper(that.image, {
            dragMode: 'crop',
            autoCrop: false,
            viewMode: 3,
            // guides: false,
            // center: false,
            background: false,
            // movable: false,
            zoomable: false,
            aspectRatio: this.ratio,
            checkCrossOrigin: true,
            rotatable: true,
            crop: function (e) {
                that.getCropBoxData()
                that.submit()
            },
            ready() {
                that.init()
            }
        })
    }
}
</script>

<style lang="css">
  .v-cropper{
    width: 520px;
    padding: 10px;
    background-color: #fff;
    box-shadow: 0 0 14px rgba(0,0,0,.4);
  }

  .v-cropper-container{
    width: 100%;
    overflow: hidden;
    margin-bottom: 10px;
  }
  .v-cropper-container img {
    max-width: 100%;
  }
  .v-cropper-cancel{
    color: #fff;
    background-color: #2489b6;
    border: 1px solid #dcdcdc;
    z-index:999999;
  }
  .v-cropper-cancel:hover{
    background-color: #ccc;
    border: 1px solid #ccc;
  }
  .v-cropper-cancel:after{
    background-color: rgba(204,204,204,.6);
    box-shadow: 0 6px 14px rgba(204,204,204,.6);
  }
  .v-cropper-cancel:hover:after{
    background-color: rgba(204,204,204,0);
    box-shadow: 0 6px 14px rgba(204,204,204,0);
  }
  .v-cropper-submit{
    color: #fff;
    background-color: #f23030;
    border: 1px solid #f23030;
  }
  .v-cropper-submit[disabled="disabled"]{
    cursor: not-allowed;
  }
  .v-cropper-submit:hover{
    background-color: #cd3219;
    border: 1px solid #cd3219;
  }
  .v-cropper-submit:after{
    background-color: rgba(242,48,48,.4);
    box-shadow: 0 6px 14px rgba(242,48,48,.4);
  }
  .v-cropper-submit:hover:after{
    background-color: rgba(242,48,48,0);
    box-shadow: 0 6px 14px rgba(242,48,48,0);
  }
</style>
