export const DEFAULT_CENTER = [13382320.737564765, 3530618.2629718445]
export const ROLES = [{text: '管理员', value: '2'}, {text: '普通用户', value: '3'}]
export const NOTIFICATIONS = [{text: '通知', value: '1'}, {text: '不通知', value: '0' }]
export const ACTIONS = [
    {text: '登录', value: '1'},
    {text: '登出', value: '2'},
    {text: '确认告警', value: '3'},
    {text: '增加点位', value: '4'},
    {text: '修改点位', value: '5'},
    {text: '删除点位', value: '6'}
]
export const RESOLUTIONS = [
    {text: '标清', value: 'sd'},
    {text: '高清', value: 'hd'},
    {text: '超清', value: 'native'}
]
export const GENDER = [
    {text: '未知', value: '0'},
    {text: '男', value: '1'},
    {text: '女', value: '2'}
]
export const CERTTYPE = [
    {text: '未知', value: '0'},
    {text: '身份证', value: '1'},
    {text: '护照', value: '2'},
    {text: '军官证', value: '3'}
]
export const CRIMINALRECORD = [
    {text: '未知', value: '0'},
    {text: '无', value: '1'},
    {text: '有', value: '2'}
]
export const LABEL = [
    {text: '未知', value: '0'},
    {text: '普通人员', value: '1'},
    {text: '可疑人员', value: '2'}
]
export const ALARM_STATUS = [
    {text: '一次提示', value: '0'},
    {text: '持续提示', value: '1'}
]
export const STATUS = [
    {text: '公开', value: '1'},
    {text: '私有', value: '0'}
]
export const RESULT = [
    {text: '返回1条结果', value: '1'},
    {text: '返回5条结果', value: '5'},
    {text: '返回10条结果', value: '10'},
    {text: '返回20条结果', value: '20'}
]
export const CAPTURE_RESULT = [
    {text: '返回3条结果', value: '1'},
    {text: '返回15条结果', value: '5'},
    {text: '返回30条结果', value: '10'},
    {text: '返回60条结果', value: '20'},
    {text: '返回150条结果', value: '50'},
    {text: '返回300条结果', value: '100'},
]
export const MARKS = [
    {text: '未标记', value: '0'},
    {text: '已标记', value: '1'}
]
export const VIDEO_STATUS = [
    {text: '等待中', value: '0', clsName: 'warning'},
    {text: '识别中', value: '1', clsName: 'warning'},
    {text: '成功', value: '2', clsName: 'success'},
    {text: '识别异常', value: '3', clsName: 'danger'},
]
export const VIDEOTYPE = [
    {text: '普通视频', value: '0'},
    {text: '普通视频滤重', value: '1'}
]
export const EXPORTSTATUS = [
    {text: '等待中', value: '0', clsName: 'warning'},
    {text: '导出中', value: '1', clsName: 'warning'},
    {text: '导出完成', value: '2', clsName: 'success'},
    {text: '导出异常', value: '3', clsName: 'danger'}
]
export const CORP = [
    {text: '面部和身体', value: 'face,body'},
    {text: '面部', value: 'face'},
]
export const CORE = [
    {text: 'Master', value: '0'},
    {text: 'Slave', value: '1'}
]
export const SETTING = [
    {text: '不开启', value: ''},
    {text: '开启', value: '1'}
]
export const EXPORT_STATUS = [
    {text: '等待中', value: '0', clsName: 'primary'},
    {text: '导出中', value: '1', clsName: 'warning'},
    {text: '成功', value: '2', clsName: 'success'},
    {text: '失败', value: '3', clsName: 'danger'},
]
export const DEVICE_STATUS = [
    {text: '闲置', value: '0', clsName: 'primary'},
    {text: '正常', value: '1', clsName: 'success'},
    {text: '故障', value: '2', clsName: 'danger'},
]

export const CAMERA_TYPE = [
    {text: '普通相机', value: '0'},
    {text: '普通相机滤重', value: '1'},
    {text: '海康抓拍机', value: '2'}
]

export const  DEPLOY_TYPE = [
    {text: '识别告警', value: '0'},
    {text: '通过告警', value: '1'}
]

export const DEVICE_CROP = [
    {text: '面部及身体及全图', value: 'face,body,full'},
    {text: '面部及身体', value: 'face,body'},
    {text: '面部', value: 'face'}
]
export const GENDER_CROP = [
    {text: '男', value: '1'},
    {text: '女', value: '2'}
]
export const ROTATE = [
    {text: '不旋转', value: '0'},
    {text: '顺时针旋转90度', value: '90'},
    {text: '逆时针旋转90度', value: '270'},
    {text: '旋转180度', value: '180'}
]
