import { formatDate, getIp } from 'common/utils'

export default function (Vue) {
    registerDirectives(Vue)
    registerFilters(Vue)
}

function registerDirectives(Vue) {

    Vue.directive('focus', {
        bind(el, binding) {
            el.addEventListener('focus', function () {
                let elem = this.closest(binding.expression)

                elem.className += ` focus`
            })
            el.addEventListener('blur', function () {
                let elem = this.closest(binding.expression)

                elem.className = elem.className.replace(/\s?focus/, '')
            })
        }
    })

}

function registerFilters(Vue) {
    Vue.filter('formatDate', function (value) {
        return formatDate(value, 'Y-M-D h:m')
    })

    Vue.filter('getIp', function (value) {
        return getIp(value)
    })
}
