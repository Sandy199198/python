
import router from 'pages/main/router'
import URL from 'common/url'
import {GET_SERVICES } from 'store/modules/common'
import {DEFAULT_CENTER} from 'common/config'

export const WEEK = 60 * 60 * 24 * 7
export const MONTH = 60 * 60 * 24 * 30

export const computeSize = {
    beforeMount() {
        this.contentHeightStyle = {
            height: (document.documentElement.clientHeight - ((this.$route.path.indexOf('main') != -1) ? 77 : 49)) + 'px',
            // height: (document.documentElement.clientHeight - ((this.$route.path.indexOf('main') != -1) ? 129 : 165)) + 'px',
            overflowX: 'hidden',
            overflowY: 'auto'
        }
    }
}

export function getIp(host) {
    return host.split(':')[0]
}

export function computeUnit(num) {
    if (num > 1024) {
        return [(num / 1024).toFixed(2), 'KBps']
    } else if (num > 1048576) {
        return [(num / 1048576).toFixed(2), 'MBps']
    } else {
        return [num, 'Bps']
    }
}

export function supplement(list, number, content = 0) {
    return Array.from({
        length: number - list.length
    }).fill(content).concat(list)
}

export function fillIn(num, digit) {
    let n = String(num)
    let preDigit = []

    for (let i = n.length; i < digit; i++) {
        preDigit.push(0)
    }

    return preDigit.join('') + num
}

export function splitTime({
    start = '',
    end = '',
    interval = '',
    format = ''
} = {}) {
    let sections = Math.ceil((end - start) / interval)
    let result = []

    for (let i = 0; i < sections; i++) {
        result.push(formatDate(start + (interval * i) - 1000, format))
    }

    return result
}

export function analyzeHttpCode(res) {
    let status = res.status

    if (status == 200) {
        if (res.redirected) {
            router.push({
                name: URL.LOGIN,
                params: {
                    redirect: router.history.current
                }
            })
            return Promise.reject(new Error('登陆过期，请重新登录'))
        } else {
            return res.json()
        }
    } else if (status == 401) {
        router.push({
            name: URL.LOGIN,
            params: {
                redirect: router.history.current
            }
        })
        return Promise.reject(new Error())
    } else if (status == 404 || status == 400 || status == 403) {
        return res.json().then(data => {
            return Promise.reject({
                message: data.error.message,
                type: 1
            })
        })
    } else if (status == 301 || status == 302) {
        res.json().then(data => {
            router.push({
                name: data.location,
                params: {
                    redirect: router.history.current
                }
            })
        })
        return Promise.reject(new Error())
    } else {
        return Promise.reject(new Error('服务异常，请稍后重试'))
    }
}

export function formatDate(timestamp, format) {
    let reg = /Y|M|D|h|m|s/g
    let date = new Date(timestamp * 1000)

    // format = 'Y-M-D h:m:s'
    return format.replace(reg, (match) => {
        switch (match) {
            case 'Y':
                return date.getFullYear()
            case 'M':
                return fillIn(date.getMonth() + 1, 2)
            case 'D':
                return fillIn(date.getDate(), 2)
            case 'h':
                return fillIn(date.getHours(), 2)
            case 'm':
                return fillIn(date.getMinutes(), 2)
            case 's':
                return fillIn(date.getSeconds(), 2)
        }
    })
}

export function statisticBurdenStyle(immutable, value) {
    if (value >= 90) {
        immutable = immutable.updateIn(['series', 0, 'data', 0, 'color'], v => '#CC0033')
    } else if (value >= 80) {
        immutable = immutable.updateIn(['series', 0, 'data', 0, 'color'], v => '#FF6666')
    } else if (value >= 60) {
        immutable = immutable.updateIn(['series', 0, 'data', 0, 'color'], v => '#FFCC33')
    } else {
        immutable = immutable.updateIn(['series', 0, 'data', 0, 'color'], v => 'rgb(0,144,142)')
    }
    return immutable
}

export function getInitialDate({
    seconds = 60 * 60 * 24,
    hours = undefined
} = {}) {
    let now = new Date()
    let end = parseInt(new Date(now.getFullYear(), now.getMonth(), now.getDate(), hours == undefined ? now.getHours() : hours, 0, 0) / 1000, 10)
    let start = parseInt(+new Date((end - seconds) * 1000) / 1000, 10)

    return {
        start,
        end
    }
}



export function statisticIOFilter(series, data, Immutable) {
    loop: for (let [i, d] of data.entries()) {
        for (let index = 0; index < series.get('series').size; index++) {
            let s = series.get('series').get(index)

            if (s && s.get('name') == d.metric.device) {
                series = series.setIn(['series', index, 'data', series.getIn(['series', index, 'data']).size], +d.value[1])
                continue loop
            }
        }
        series = series.setIn(['series', i],
            Immutable.fromJS({
                name: d.metric.device,
                data: [+d.value[1]]
            })
        )
    }
    return series
}

export function setCameraSymbol({
    ol = null,
    map = null,
    camera = null,
    timeout = 0,
    animation = true,
    clickCallback = function () {},
    createdCallback = function () {}
}) {
    let symbol = document.createElement('a')
    let coordinate = camera.latlng.split(',')
    let symbolOverlay

    symbol.href = '#'
    symbol.className = 'map-camera' + (animation ? ' init' : '')
    // symbol.className = 'map-camera'
    symbol.title = camera.name
    symbol.dataset['id'] = camera.id

    symbol.addEventListener('click', e => {
        e.preventDefault()
        clickCallback(symbolOverlay)
    })

    symbolOverlay = new ol.Overlay({
        id: camera.id,
        element: symbol,
        position: coordinate,
        offset: [-12, -35]
    })

    if (animation) {
        let shadow = document.createElement('div')

        shadow.className = 'map-shadow'
        map.addOverlay(symbolOverlay)
        setTimeout(() => {
            if (!map.destroyed) {
                map.addOverlay(new ol.Overlay({
                    element: shadow,
                    position: coordinate,
                    offset: [-9, -1]
                }))

                symbol.className = 'map-camera'
                createdCallback(symbolOverlay)
            }
        }, timeout)
    } else {
        setTimeout(() => {
            if (!map.destroyed) {
                map.addOverlay(symbolOverlay)
                createdCallback(symbolOverlay)
            }
        }, 0)
    }

    return symbolOverlay
}

export function setCameraSymbols({
    ol = null,
    map = null,
    cameras = [],
    clickCallback = function () {},
    itemCreateCallback = function () {},
    createdCallback = function () {}
} = {}) {
    let created = 0
    let listOverlay = []

    for (let [index, camera] of cameras.entries()) {
        listOverlay.push(setCameraSymbol({
            ol,
            map,
            camera,
            animation: cameras.length > 50 ? false : true,
            timeout: 500 + index * 100,
            clickCallback,
            createdCallback(symbolOverlay) {
                created++
                itemCreateCallback(symbolOverlay)
                if (created == cameras.length) {
                    createdCallback(listOverlay)
                }
            }
        }))
    }

    return listOverlay
}

export function setAlarmAboutCamera({
    ol = null,
    map = null,
    alarm = null,
    move = true,
    tip = true
} = {}) {
    let oldOverlay = map.getOverlayById(alarm.camera_id)

    if (!oldOverlay) return

    let elem = oldOverlay.getElement()
    let position = oldOverlay.getPosition().map(Number)

    map.removeOverlay(oldOverlay)

    if (move) {
        let pan = ol.animation.pan({
            source: map.getView().getCenter(),
            duration: 1000,
            easing: ol.easing.easeOut
        })

        map.beforeRender(pan)
        map.getView().setCenter(position)
    }

    if (tip) {
        let card = document.createElement('div')
        let cardId = `alarm-${alarm.camera_id}`
        let alarmCard = new ol.Overlay({
            id: cardId,
            element: card,
            position: position,
            insertFirst: false,
            offset: [-37, -110]
        })
        let oldCard = map.getOverlayById(cardId)

        oldCard && map.removeOverlay(oldCard)
        card.className = 'alarm-card init'
        card.innerHTML = `
            <div class="img"><img src="${alarm.face}" alt="" width="70" /></div>
        `
        setTimeout(() => {
            card.className = 'alarm-card'
        }, 500)
        map.addOverlay(alarmCard)
    }


    elem.className = 'map-camera alarm'
    elem.dataset.alarm = true
    map.addOverlay(new ol.Overlay({
        id: alarm.camera_id,
        element: elem,
        position: position,
        insertFirst: false,
        offset: [-12, -35]
    }))
}

export function parseDateStrToTimestamp(string) {
    if (!string) return ''
    let datetime = string.split(' '),
        date = datetime[0],
        time = datetime[1],
        dateArr = date.split('-'),
        timeArr = time.split(':')

    return +new Date(dateArr[0], (dateArr[1] - 1), dateArr[2], timeArr[0], timeArr[1])
}

export function convertToSeconds(data) {
    if (!Number[Symbol.hasInstance](data)) {
        data = +data
    }
    return parseInt(data / 1000, 10)
}

export function convertDoubleNumber(number) {
    return parseInt(number / 10) === 0 ? '0' + number : number
}

export function parseDate(timestamp) {
    if (timestamp == null) return ''
    let date = new Date(timestamp * 1000)

    return date.getFullYear() + '-' + this.add0(date.getMonth() + 1) + '-' + this.add0(date.getDate()) + ' ' + this.add0(date.getHours()) + ':' + this.add0(date.getMinutes())
}

export function verifyCertId(certId) {
    let pattern = /\d{17}[\d|x]|\d{15}/

    return pattern.test(certId)
}

export function verifyGender(gender) {
    let pattern = /^['男'|'女']$/

    return pattern.test(gender)
}

export function videoTimestamp(d) {
    d = parseInt(d)
    let hh = parseInt(d / 3600)

    if (hh < 10) {
        hh = '0' + hh
    }
    let mm = parseInt((d - hh * 3600) / 60)

    if (mm < 10) {
        mm = '0' + mm
    }
    let ss = parseInt((d - hh * 3600) % 60)

    if (ss < 10) {
        ss = '0' + ss
    }

    return hh + ':' + mm + ':' + ss
}

export function printError(name, e) {
    console.log('Error request:' + name)
    console.log(e.message)
}

export function preRequest(context) {
    return new Promise((resolve, reject) => {
        fetch(`${context.getters[GET_SERVICES].Skylab}user_token`, {
            credentials: 'include',
        }).then(res => {
            return analyzeHttpCode(res)
        }).then(data => {
            resolve(data.data.access_token)
        }).catch(e => {
            console.log('获取user_token失败')
            router.push({
                name: URL.LOGIN,
                params: {
                    redirect: router.history.current
                }
            })
            reject(new Error('登陆过期，请重新登录'))
        })
    })
}

export function setmapSymbol({
    ol = null,
    map = null,
    latlng = []
}) {
    let cameraMarker = document.getElementById('mapCamera')

    if (cameraMarker) {
        cameraMarker.remove()
    }
    let symbol = document.createElement('a')
    let coordinate = latlng
    let symbolOverlay

    symbol.href = '#'
    symbol.className = 'map-camera'
    symbol.id = 'mapCamera'

    symbolOverlay = new ol.Overlay({
        element: symbol,
        position: coordinate,
        offset: [-12, -35]
    })

    map.addOverlay(symbolOverlay)

    return symbolOverlay
}
