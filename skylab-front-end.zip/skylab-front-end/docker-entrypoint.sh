export SASS_BINARY_SITE="https://npm.taobao.org/mirrors/node-sass"
npm install
npm run eslint
npm test
cp /frontend/depends/video.js /frontend/node_modules/video.js/dist/
webpack --config webpack.config.release.js