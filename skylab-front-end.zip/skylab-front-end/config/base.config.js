var path = require('path')

module.exports = {
    module: {
        loaders: [{
            test: /\.js$/,
            exclude: /node_modules\/(?!@nanyun\/)/,
            loader: 'babel'
        }, {
            test: /\.vue$/,
            loader: 'vue',
            exclude: /node_modules\/(?!@nanyun\/)/
        }, {
            test: /\.scss$/,
            loaders: ['style', 'css', 'postcss', 'sass']
        }, {
            test: /\.css$/,
            loaders: ['style', 'css', 'postcss']
        }, {
            test: /\.(png|jpe?g|gif|svg)(\?.*)?$/,
            loader: 'url',
            query: {
                limit: 10000,
                name: 'image/[name].[ext]'
            }
        }, {
            test: /\.(woff2?|eot|ttf|otf)(\?.*)?$/,
            loader: 'url',
            query: {
                limit: 10000,
                name: 'fonts/[name].[ext]'
            }
        }, {
            test: /\.(mp3|swf)$/,
            loader: 'file'
        }, {
            test: /\.json$/,
            loader: 'json',
            exclude: /node_modules\/(?!vue-video-player\/)/,
        }]
    },
    eslint: {
        formatter: require('eslint-friendly-formatter')
    },
    vue: {
        loaders: {
            css: 'style!css!postcss!sass'
        }
    },
    resolve: {
        alias: {
            vue: 'vue/dist/vue.js',
            pages: path.join(__dirname, '../src/pages'),
            store: path.join(__dirname, '../src/store'),
            common: path.join(__dirname, '../src/common'),
            styles: path.join(__dirname, '../src/styles'),
            images: path.join(__dirname, '../src/images'),
            medias: path.join(__dirname, '../src/medias')
        }
    }
}
