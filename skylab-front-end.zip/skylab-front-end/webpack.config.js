var path = require('path')
var webpack = require('webpack')
var ExtractTextPlugin = require('extract-text-webpack-plugin')
var HtmlWebpackPlugin = require('html-webpack-plugin')
var baseConfig = require('./config/base.config')
var merge = require('webpack-merge')

function resolveApp(relativePath) {
    return path.resolve(relativePath);
}

var config = {
    context: __dirname,
    entry: ['webpack/hot/dev-server', 'webpack-hot-middleware/client?reload=true', 'whatwg-fetch', path.join(__dirname, 'src', 'main.js')],
    output: {
        publicPath: '/',
        path: path.join(__dirname, '/dist'),
        filename: 'bundle.js'
    },
    plugins: [
        new webpack.HotModuleReplacementPlugin(),
        new HtmlWebpackPlugin({
            template: 'index.html',
            favicon: resolveApp('favicon.ico')
        }),
        new webpack.DefinePlugin({
            'process.env': {
                NODE_ENV: '"development"'
            }
        }),
        new webpack.NoErrorsPlugin()
    ]
}

module.exports = merge(config, baseConfig, {
    module: {
        preLoaders: [{
            test: /\.vue$/,
            loader: 'eslint',
            exclude: /node_modules/
        }, {
            test: /\.js$/,
            loader: 'eslint',
            exclude: /node_modules/
        }]
    }
})
