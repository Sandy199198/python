import Vue from 'vue'
import { expect } from 'chai'
import Home from '../src/pages/home/home.vue'

let Ctor = Vue.extend(Home)
let ins = new Ctor({
    propsData: {}
}).$mount()

describe('测试初始化数据', function () {

    it('test', function () {
        expect(ins.$el.textContent).to.be.equal('这是首页')
    })

})
