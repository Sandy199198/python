module.exports = {
    browserslist: 'last 2 versions',
    plugins: [
        require('autoprefixer'),
        require('postcss-flexbugs-fixes'),
    ]
}
