var express = require('express')
var webpack = require('webpack')
var webpackDevMiddleware = require('webpack-dev-middleware')
var webpackHotMiddleware = require('webpack-hot-middleware')
var config = require('./webpack.config')
var compiler = webpack(config)
var connectHistoryApiFallback = require('connect-history-api-fallback')

app = express()

app.use(connectHistoryApiFallback())

app.use(webpackDevMiddleware(compiler, {
    publicPath: config.output.publicPath,
    stats: {
        colors: true,
        chunks: false
    }
}))

var hotMiddleware = webpackHotMiddleware(compiler)

app.use(hotMiddleware)

module.exports = app.listen(8080, '0.0.0.0', function (err) {
    if (err) {
        console.log(err)
        return
    }
})
