#!/bin/bash
if [[ $1 == "force"  ]]; then
    sudo rm -r node_modules
fi
sudo rm -r static
sudo rm package-lock.json
docker run --rm --net=host -v $PWD:/frontend -v $PWD/docker-entrypoint.sh:/docker-entrypoint.sh registry.cn-hangzhou.aliyuncs.com/sun-docker/frontend-builder:latest
if [ ! -d static ]; then
    echo static 目录木有创建成功，重新编译呗
    exit 3
fi
cd /home/sun/project/security-plus-deploy/work-folder/
./supervisor-skylab.sh down -v
cd -
docker build . -t registry.cn-hangzhou.aliyuncs.com/sun-docker/skylab-frontend:latest
docker push registry.cn-hangzhou.aliyuncs.com/sun-docker/skylab-frontend:latest
cd /home/sun/project/security-plus-deploy/work-folder/
./supervisor-skylab.sh up -d