var path = require('path')
var webpack = require('webpack')
var ExtractTextPlugin = require('extract-text-webpack-plugin')
var HtmlWebpackPlugin = require('html-webpack-plugin')

function resolveApp(relativePath) {
    return path.resolve(relativePath);
}

module.exports = {
    context: __dirname,
    entry: {
        main: path.join(__dirname, 'src', 'main.js'),
        lib: ['vue', 'vuex', 'velocity-animate', 'highcharts', 'vue-router', 'openlayers', 'whatwg-fetch']
    },
    output: {
        path: path.join(__dirname, 'static'),
        filename: '[name]_[chunkhash:6].js',
        chunkFilename: '[name]_[chunkhash:6].js',
        publicPath: '/static/'
    },
    module: {
        loaders: [{
            test: /\.js$/,
            exclude: /node_modules\/(?!@nanyun\/)/,
            loader: 'babel'
        }, {
            test: /\.vue$/,
            loader: 'vue',
            exclude: /node_modules\/(?!@nanyun\/)/
        }, {
            test: /\.scss$/,
            loader: ExtractTextPlugin.extract(['css', 'postcss', 'sass'])
        }, {
            test: /\.css$/,
            loader: ExtractTextPlugin.extract(['css', 'postcss'])
        }, {
            test: /\.(png|jpe?g|gif|svg)(\?.*)?$/,
            loader: 'url',
            query: {
                limit: 10000,
                name: 'image/[name]_[hash:6].[ext]'
            }
        }, {
            test: /\.(woff2?|eot|ttf|otf)(\?.*)?$/,
            loader: 'url',
            query: {
                limit: 10000,
                name: 'fonts/[name]_[hash:6].[ext]'
            }
        }, {
            test: /\.(mp3|swf)$/,
            loader: 'file'
        }, {
            test: /\.json$/,
            loader: 'json',
            exclude: /node_modules\/(?!vue-video-player\/)/,
        }]
    },
    vue: {
        loaders: {
            css: ExtractTextPlugin.extract(['css', 'postcss', 'sass'])
        }
    },
    resolve: {
        alias: {
            vue: 'vue/dist/vue.js',
            pages: path.join(__dirname, 'src/pages'),
            store: path.join(__dirname, 'src/store'),
            common: path.join(__dirname, 'src/common'),
            styles: path.join(__dirname, 'src/styles'),
            images: path.join(__dirname, 'src/images'),
            medias: path.join(__dirname, 'src/medias')
        }
    },
    plugins: [
        new webpack.optimize.CommonsChunkPlugin({
            name: 'lib'
        }),
        new webpack.optimize.UglifyJsPlugin({
            compress: {
                warnings: false
            }
        }),
        new webpack.optimize.CommonsChunkPlugin('inline', 'inline_[chunkhash:6].js'),
        new ExtractTextPlugin("style/style_[contenthash:6].css"),
        new HtmlWebpackPlugin({
            template: 'index.html',
            chunksSortMode: 'dependency',
            chunks: ['inline','lib','main'],
            favicon: resolveApp('favicon.ico')
        }),
        new webpack.DefinePlugin({
            'process.env': {
                NODE_ENV: '"production"'
            }
        }),
        new webpack.NoErrorsPlugin()
    ]
}
