module.exports = {
    '/login': {
        target: 'http://192.168.0.10:9000',
        changeOrigin: true
    },
    '/applications/**': {
        target: 'http://192.168.0.10:9000',
        changeOrigin: true
    },
    '/users/**': {
        target: 'http://192.168.0.10:8200',
        changeOrigin: true
    },
    '/usergroups/**': {
        target: 'http://192.168.0.10:8200',
        changeOrigin: true
    },
    '/statistic/**': {
        target: 'http://192.168.0.10:8200',
        changeOrigin: true
    }
}
